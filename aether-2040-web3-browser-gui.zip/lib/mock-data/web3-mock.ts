// 2040 Web3.0 Abstract Operating Environment Mock Datasets & Entities

export type Web3ObjectType =
  | 'network'
  | 'protocol'
  | 'contract'
  | 'token'
  | 'identity'
  | 'dao'
  | 'transaction'
  | 'block'
  | 'event'
  | 'document';

export interface Web3Object {
  id: string;
  type: Web3ObjectType;
  name: string;
  identifier: string; // e.g., 0x9B2F... or oxford.aero.id
  networkId: string;
  networkName: string;
  state: 'verified' | 'active' | 'syncing' | 'finalized' | 'evaluating';
  protocol: string;
  gasIndex?: string;
  shard?: string;
  latency?: string;
  entropy?: number;
  signers?: number;
  timestamp: string;
  description: string;
  metadata: {
    label: string;
    value: string;
    highlight?: boolean;
  }[];
  functions?: {
    name: string;
    type: 'read' | 'write' | 'zk-proof';
    params: string[];
    invocationsLast24h: number;
  }[];
  holdersOrPeers?: {
    id: string;
    name: string;
    share: string;
    role: string;
  }[];
  telemetryLogs?: string[];
}

export interface NetworkNode {
  id: string;
  name: string;
  tier: 'L1 Base' | 'L2 Spatial Shard' | 'Zero-Knowledge Mesh' | 'Compute Grid';
  tps: number;
  latencyMs: number;
  activeContracts: number;
  totalPeers: number;
  status: 'optimal' | 'nominal' | 'degraded';
  region: string;
  consensusEngine: string;
  color: string;
}

export interface MockTransaction {
  id: string;
  hash: string;
  timestamp: string;
  from: string;
  fromName: string;
  to: string;
  toName: string;
  network: string;
  objectType: string;
  value: string;
  fee: string;
  state: 'pending' | 'processing' | 'confirmed';
  proofType: string;
  shard: string;
  blockNumber: number;
}

export interface MockWebPage {
  id: string;
  url: string;
  title: string;
  category: 'Scientific' | 'Aerospace Infrastructure' | 'Logistics' | 'Decentralized Research';
  badge: string;
  associatedObjects: string[]; // Web3Object IDs
  snippet: string;
  content: {
    heroHeading: string;
    leadText: string;
    stats: { label: string; value: string; unit?: string }[];
    sections: {
      title: string;
      body: string;
      codeSnippet?: string;
      verifiedObjectLink?: string;
    }[];
  };
}

// 8 Primary 2040 Networks
export const MOCK_NETWORKS: NetworkNode[] = [
  {
    id: 'net-aether-4',
    name: 'Aether-4 Subnet',
    tier: 'L1 Base',
    tps: 184500,
    latencyMs: 3.2,
    activeContracts: 42100,
    totalPeers: 12480,
    status: 'optimal',
    region: 'London-Heathrow Subsea Mesh',
    consensusEngine: 'Asynchronous BFT Proof-of-Time',
    color: '#4D8BC4',
  },
  {
    id: 'net-vortex-mesh',
    name: 'Vortex Shard Mesh',
    tier: 'L2 Spatial Shard',
    tps: 640000,
    latencyMs: 1.1,
    activeContracts: 19800,
    totalPeers: 6420,
    status: 'optimal',
    region: 'North Sea Wind Array Relay',
    consensusEngine: 'Vector Homomorphic Shard Sync',
    color: '#58A878',
  },
  {
    id: 'net-chronos-l2',
    name: 'Chronos Temporal Mesh',
    tier: 'L2 Spatial Shard',
    tps: 92000,
    latencyMs: 5.4,
    activeContracts: 11200,
    totalPeers: 3840,
    status: 'nominal',
    region: 'Cambridge Optical Node',
    consensusEngine: 'Deterministic Clock Invariance',
    color: '#D99F44',
  },
  {
    id: 'net-veritas-zk',
    name: 'Veritas Zero-Knowledge Fabric',
    tier: 'Zero-Knowledge Mesh',
    tps: 450000,
    latencyMs: 2.8,
    activeContracts: 33400,
    totalPeers: 8900,
    status: 'optimal',
    region: 'Oxford Quantum Ring',
    consensusEngine: 'Recursive Halo2 SNARK Assembler',
    color: '#9C88FF',
  },
  {
    id: 'net-helios-grid',
    name: 'Helios Compute Grid',
    tier: 'Compute Grid',
    tps: 1200000,
    latencyMs: 0.9,
    activeContracts: 8750,
    totalPeers: 4120,
    status: 'optimal',
    region: 'Cornwall Tidal Gateway',
    consensusEngine: 'Proof of Verifiable Computation',
    color: '#48DBFB',
  },
  {
    id: 'net-borealis-storage',
    name: 'Borealis Storage Shard',
    tier: 'L1 Base',
    tps: 45000,
    latencyMs: 12.4,
    activeContracts: 15400,
    totalPeers: 7200,
    status: 'nominal',
    region: 'Edinburgh Cold Archive',
    consensusEngine: 'Erasure Proof-of-Replication',
    color: '#74B9FF',
  },
];

// Rich 2040 Web3 Objects
export const MOCK_OBJECTS: Web3Object[] = [
  {
    id: 'obj-contract-optics',
    type: 'contract',
    name: 'Autonomous Quantum Optics Allocator',
    identifier: '0x7F9A...88E1',
    networkId: 'net-veritas-zk',
    networkName: 'Veritas Zero-Knowledge Fabric',
    state: 'verified',
    protocol: 'RFC-4091 / Quantum Beam Allocation',
    gasIndex: '0.00012 µP',
    shard: 'ZK-Shard-04 (Oxford)',
    latency: '1.8ms',
    entropy: 0.994,
    signers: 14,
    timestamp: '2040-09-03 13:42:01.084 GMT',
    description: 'Hardware-grounded smart contract executing zero-latency optical routing between quantum memory nodes.',
    metadata: [
      { label: 'Compiler', value: 'Rust/Wasm-ZK v6.2 (Formal Verified)' },
      { label: 'Memory Allocation', value: '128 MB Vector Shard' },
      { label: 'Signatory Threshold', value: '9 of 14 Cryptographic Keys' },
      { label: 'Audit Proof', value: 'Halo-2 SNARK Digest #84A9' },
      { label: 'Execution Mode', value: 'Deterministic Micro-Task' },
    ],
    functions: [
      { name: 'allocatePhotonChannel', type: 'zk-proof', params: ['beamFreq: u64', 'destNode: id40'], invocationsLast24h: 184920 },
      { name: 'verifyPhaseCoherence', type: 'read', params: ['sampleDigest: bytes32'], invocationsLast24h: 942100 },
      { name: 'settleEnergyEpoch', type: 'write', params: ['epochId: u32', 'payoutProof: bytes'], invocationsLast24h: 1440 },
    ],
    holdersOrPeers: [
      { id: 'peer-oxford-1', name: 'Oxford Quantum Foundry Node A', share: '34.2%', role: 'Anchor Sequencer' },
      { id: 'peer-cam-1', name: 'Cambridge Optical Relay 3', share: '28.5%', role: 'Verification Node' },
      { id: 'peer-imp-1', name: 'Imperial Photonics Lab', share: '22.1%', role: 'Proof Generator' },
      { id: 'peer-npl-1', name: 'National Physical Laboratory', share: '15.2%', role: 'Time Oracle' },
    ],
    telemetryLogs: [
      '[13:42:01.084] ZK-Proof verification passed: Root Hash 0x9a8f...3e21 in 0.4ms',
      '[13:41:58.210] Phase angle lock confirmed at 1550nm wavelength',
      '[13:41:40.002] Multi-sig epoch 4091 finalized across 14 sovereign validators',
      '[13:40:12.890] Shard state root anchored to Veritas Zero-Knowledge Fabric',
    ],
  },
  {
    id: 'obj-identity-vane',
    type: 'identity',
    name: 'Dr. Eleanor Vane (Director of Aerospace Mesh)',
    identifier: 'eleanor.vane.aero.id',
    networkId: 'net-aether-4',
    networkName: 'Aether-4 Subnet',
    state: 'verified',
    protocol: 'DID:2040 Sovereign Identity Protocol',
    gasIndex: 'N/A (Sovereign Pass)',
    shard: 'Identity-Ring-London',
    latency: '0.8ms',
    signers: 3,
    timestamp: '2040-09-03 08:15:00 GMT',
    description: 'Decentralized cryptographic credential holding aerospace operations clearance and quantum cryptographic keys.',
    metadata: [
      { label: 'Security Clearance', value: 'Class IV Aerospace & Autonomous Systems', highlight: true },
      { label: 'Hardware Key', value: 'Secure Enclave YubiQuantum-9' },
      { label: 'Public Credential Hash', value: 'did:aether:884b-990a-112e-fa01' },
      { label: 'Revocation Oracle', value: 'Royal Aeronautical Registry' },
      { label: 'Trust Rank', value: '99.98% Cryptographic Verifiability' },
    ],
    holdersOrPeers: [
      { id: 'id-org-1', name: 'Royal Aerospace Institute', share: 'Issuer', role: 'Institutional Root' },
      { id: 'id-org-2', name: 'UK Space Navigation Trust', share: 'Attestor', role: 'Telemetry Authority' },
    ],
    telemetryLogs: [
      '[13:30:00] Session signature refreshed via biometric quantum enclave',
      '[12:04:12] Attestation verified: Sub-orbital corridor clearance valid until 2041-01',
      '[09:15:44] Identity state beacon broadcast to London-Heathrow Subsea Mesh',
    ],
  },
  {
    id: 'obj-token-compute',
    type: 'token',
    name: 'Vortex Quantum Compute Credit',
    identifier: 'VQ-COMP',
    networkId: 'net-vortex-mesh',
    networkName: 'Vortex Shard Mesh',
    state: 'active',
    protocol: 'ERC-2040 Sharded Compute Standard',
    gasIndex: '0.00004 VQ',
    shard: 'Shard-Compute-7',
    latency: '1.2ms',
    timestamp: '2040-09-03 13:40:00 GMT',
    description: 'Fractionalized compute reservation token representing 1 Tera-Qubit second of verifiable cloud execution.',
    metadata: [
      { label: 'Circulating Reserve', value: '45,200,000 VQ-COMP' },
      { label: 'Burn Velocity', value: '18,400 units/min' },
      { label: 'Backing Standard', value: 'Proof-of-Computation Energy Equivalent' },
      { label: 'Decimals', value: '18' },
    ],
    holdersOrPeers: [
      { id: 'h-1', name: 'National Grid Supercomputing Reserve', share: '41.2%', role: 'Staker' },
      { id: 'h-2', name: 'Atmospheric Research DAO', share: '24.8%', role: 'Consumer' },
      { id: 'h-3', name: 'High-Speed Rail 2 Network AI', share: '18.0%', role: 'Consumer' },
    ],
    telemetryLogs: [
      '[13:41:20] 450 VQ-COMP burned for atmospheric simulation batch #9982',
      '[13:39:11] Liquidity pool rebalanced automatically across North Sea Shards',
    ],
  },
  {
    id: 'obj-dao-climate',
    type: 'dao',
    name: 'North Atlantic Environmental Telemetry Consortium',
    identifier: 'dao.ocean.climate.net',
    networkId: 'net-chronos-l2',
    networkName: 'Chronos Temporal Mesh',
    state: 'active',
    protocol: 'Autonomous Collective Governance v5',
    gasIndex: '0.002 µP',
    shard: 'Temporal-Shard-9',
    latency: '3.1ms',
    signers: 320,
    timestamp: '2040-09-03 11:20:00 GMT',
    description: 'Decentralized autonomous research collective managing 12,000 autonomous subsea buoys across the Celtic Sea and Atlantic.',
    metadata: [
      { label: 'Active Proposals', value: '3 Under Vote' },
      { label: 'Treasury Balance', value: '14.2M Sovereign Energy Units' },
      { label: 'Quorum Ratio', value: '66.7% Quadratic Vote' },
      { label: 'Sensor Fleet', value: '12,450 Verified Nodes' },
    ],
    functions: [
      { name: 'submitBuoyTelemetry', type: 'write', params: ['buoyId: u32', 'salinity: f32', 'temp: f32'], invocationsLast24h: 890400 },
      { name: 'disburseResearchGrant', type: 'write', params: ['recipient: id', 'amount: u128'], invocationsLast24h: 12 },
    ],
    holdersOrPeers: [
      { id: 'd-1', name: 'Met Office Oceanography Division', share: '30%', role: 'Founding Member' },
      { id: 'd-2', name: 'Plymouth Marine Laboratory', share: '25%', role: 'Core Scientific Lead' },
      { id: 'd-3', name: 'Celtic Tidal Energy Trust', share: '20%', role: 'Infrastructure Node' },
    ],
    telemetryLogs: [
      '[13:38:00] Proposal #84 approved: Upgrade Gulf Stream telemetry buoys to L2 firmware',
      '[13:12:44] 1,200 sensor packets aggregated into Epoch Root #40921',
    ],
  },
  {
    id: 'obj-protocol-spatial',
    type: 'protocol',
    name: 'Spatial Internet & Cartography Protocol (SICP-40)',
    identifier: 'sicp://mesh.spatial.v4',
    networkId: 'net-aether-4',
    networkName: 'Aether-4 Subnet',
    state: 'verified',
    protocol: 'SICP-40 Core',
    gasIndex: 'Zero-Rated Infrastructure',
    shard: 'Global Spatial Index',
    latency: '0.4ms',
    timestamp: '2040-09-03 12:00:00 GMT',
    description: 'Unified decentralized protocol for rendering spatial coordinates, object relationships, and autonomous machine routing.',
    metadata: [
      { label: 'Standard Specification', value: 'RFC-4088' },
      { label: 'Spatial Coordinate Depth', value: 'Sub-millimeter 3D Tensor' },
      { label: 'Topology Engine', value: 'WebGPU Spatial Tessellation' },
    ],
    holdersOrPeers: [
      { id: 'sicp-1', name: 'Ordnance Survey Digital 2040', share: 'Anchor', role: 'Geospatial Authority' },
      { id: 'sicp-2', name: 'European Aerospace Mesh', share: 'Co-Author', role: 'Airspace Integration' },
    ],
    telemetryLogs: [
      '[13:42:15] Spatial coordinate transform executed in 0.04ms on WebGPU canvas',
      '[13:30:10] Global coordinate tree synchronized across 6 continents',
    ],
  },
];

// Rich 2040 Browser Web Pages with Integrated Web3 Objects
export const MOCK_PAGES: MockWebPage[] = [
  {
    id: 'page-observatory',
    url: 'aether://observatory.mesh',
    title: 'Aether Spatial Observatory 2040',
    category: 'Scientific',
    badge: 'INTERNAL OPERATING SYSTEM',
    associatedObjects: ['obj-protocol-spatial', 'obj-contract-optics', 'obj-identity-vane'],
    snippet: 'Central spatial telemetry and decentralized network observatory for the 2040 Internet.',
    content: {
      heroHeading: 'Aether 2040 Operating Environment',
      leadText: 'Next-generation Anglo-futurist spatial browser combining technical drafting, aerospace instruments, and decentralized state resolution.',
      stats: [
        { label: 'Global Shard Mesh TPS', value: '2,621,500', unit: 'tx/s' },
        { label: 'Zero-Knowledge Proof Latency', value: '1.4', unit: 'ms' },
        { label: 'Active Sovereign Nodes', value: '42,940', unit: 'peers' },
        { label: 'State Verification', value: '100%', unit: 'formal' },
      ],
      sections: [
        {
          title: 'Spatial Architecture & Sub-Surface Routing',
          body: 'The 2040 Internet replaces static DNS lookup tables with high-precision cryptographic object resolvers. Webpages, autonomous agents, and scientific arrays interact via verifiable vector shards.',
          verifiedObjectLink: 'obj-protocol-spatial',
        },
        {
          title: 'Subsea Fiber & North Sea Wind Power Coupling',
          body: 'Consensus verification is power-coupled directly to UK offshore wind generation and Celtic tidal turbines. Energy-efficient BFT clock cycles prevent computational waste.',
          verifiedObjectLink: 'obj-contract-optics',
        },
      ],
    },
  },
  {
    id: 'page-quantum-lab',
    url: 'https://oxford.quantum.lab.ac.uk/beams/telemetry',
    title: 'Oxford Quantum Optics Foundry - Beam Router',
    category: 'Scientific',
    badge: 'VERIFIED LABORATORY PROTOCOL',
    associatedObjects: ['obj-contract-optics', 'obj-identity-vane', 'obj-token-compute'],
    snippet: 'Real-time telemetry and atomic clock coherence for the Oxford cryogenic photonic link.',
    content: {
      heroHeading: 'Cryogenic Photonic Routing & Shard Coherence',
      leadText: 'Operating 24 continuous entangled photon streams between the Clarendon Laboratory and Rutherford Appleton Node.',
      stats: [
        { label: 'Coherence Fidelity', value: '99.998', unit: '%' },
        { label: 'Entanglement Rate', value: '10.4', unit: 'GB/s' },
        { label: 'Cryo Temp', value: '12.4', unit: 'mK' },
        { label: 'Smart Allocator', value: '0x7F9A...88E1' },
      ],
      sections: [
        {
          title: 'Autonomous Beam Switching Contract',
          body: 'Photon beam switches are directly controlled by smart contract 0x7F9A...88E1 on the Veritas Zero-Knowledge Fabric. Allocation parameters are verified in hardware before laser pulse discharge.',
          verifiedObjectLink: 'obj-contract-optics',
          codeSnippet: `// Veritas ZK Hardware Dispatch
verify_halo2_proof(&proof_digest, &photon_matrix)?;
dispatch_cryo_beam_channel(channel_id: 4, target_node: "OX-CAM-01");`,
        },
        {
          title: 'Sovereign Verification & Attestation',
          body: 'Clearance key issued by Dr. Eleanor Vane (eleanor.vane.aero.id) with multi-signature validation across 14 independent university validators.',
          verifiedObjectLink: 'obj-identity-vane',
        },
      ],
    },
  },
  {
    id: 'page-ocean-telemetry',
    url: 'https://atlantic.buoy.mesh.org/telemetry/gulf-stream',
    title: 'North Atlantic Oceanographic Buoy Mesh',
    category: 'Decentralized Research',
    badge: 'DAO AUTONOMOUS INFRASTRUCTURE',
    associatedObjects: ['obj-dao-climate', 'obj-token-compute'],
    snippet: 'Decentralized sensor network monitoring thermohaline circulation and marine salinity.',
    content: {
      heroHeading: 'Thermohaline Circulation Live Sensor Mesh',
      leadText: 'Continuous data feeds collected from 12,450 autonomous surface and sub-surface gliders across the North Atlantic.',
      stats: [
        { label: 'Gliders Active', value: '12,450', unit: 'units' },
        { label: 'Mean Salinity', value: '35.12', unit: 'PSU' },
        { label: 'Gulf Stream Velocity', value: '1.84', unit: 'm/s' },
        { label: 'DAO Governance', value: 'Active' },
      ],
      sections: [
        {
          title: 'Autonomous Data Aggregation & Proof-of-Telemetry',
          body: 'Buoys sign sensory telemetry with low-power cryptographic chips. Data is pooled into Chronos Temporal Mesh and published to the global climate ledger.',
          verifiedObjectLink: 'obj-dao-climate',
        },
      ],
    },
  },
  {
    id: 'page-aerospace-corridor',
    url: 'https://national-airspace.aero.gov.uk/corridor-4',
    title: 'London-Edinburgh Autonomous Flight Corridor 4',
    category: 'Aerospace Infrastructure',
    badge: 'CRITICAL INFRASTRUCTURE',
    associatedObjects: ['obj-identity-vane', 'obj-protocol-spatial'],
    snippet: 'Real-time vector airspace control and drone highway deconfliction registry.',
    content: {
      heroHeading: 'High-Altitude Autonomous Logistics Corridor',
      leadText: 'Managing 1,800 active autonomous commercial transports in high-density UK Flight Corridor 4 using deterministic spatial state meshes.',
      stats: [
        { label: 'Airborne Craft', value: '1,842', unit: 'units' },
        { label: 'Deconfliction Margin', value: '100.0', unit: '%' },
        { label: 'Beacon Latency', value: '0.4', unit: 'ms' },
        { label: 'Regulatory Authority', value: 'CAA Digital 2040' },
      ],
      sections: [
        {
          title: 'Spatial Internet Coordinate Mesh',
          body: 'Every drone transponder continuously calculates its spatial polygon against the global SICP-40 mesh. Flight rights are minted as dynamic cryptographic state tokens.',
          verifiedObjectLink: 'obj-protocol-spatial',
        },
      ],
    },
  },
];

// 20 Initial Mock Transactions for Live Simulation
export const INITIAL_TRANSACTIONS: MockTransaction[] = [
  {
    id: 'tx-001',
    hash: '0x8b32f...91a2',
    timestamp: '13:42:09.112',
    from: 'eleanor.vane.aero.id',
    fromName: 'Dr. Eleanor Vane',
    to: '0x7F9A...88E1',
    toName: 'Quantum Optics Allocator',
    network: 'Veritas Zero-Knowledge Fabric',
    objectType: 'Contract Call',
    value: '450 VQ-COMP',
    fee: '0.00012 µP',
    state: 'confirmed',
    proofType: 'Halo-2 SNARK',
    shard: 'ZK-Shard-04',
    blockNumber: 18492041,
  },
  {
    id: 'tx-002',
    hash: '0x2a19c...44e8',
    timestamp: '13:42:07.842',
    from: 'buoy-node-8812.net',
    fromName: 'Celtic Sea Buoy #8812',
    to: 'dao.ocean.climate.net',
    toName: 'Ocean Telemetry DAO',
    network: 'Chronos Temporal Mesh',
    objectType: 'Telemetry State Sync',
    value: '0.00 SEU',
    fee: '0.00004 µP',
    state: 'confirmed',
    proofType: 'Deterministic BFT Root',
    shard: 'Temporal-Shard-9',
    blockNumber: 9912048,
  },
  {
    id: 'tx-003',
    hash: '0x99fe1...32b0',
    timestamp: '13:42:05.201',
    from: 'drone-corridor-4.mesh',
    fromName: 'Airspace Transponder #184',
    to: 'sicp://mesh.spatial.v4',
    toName: 'Spatial Internet Protocol',
    network: 'Aether-4 Subnet',
    objectType: 'Spatial Token Mint',
    value: '1 Vector Slot',
    fee: '0.00001 µP',
    state: 'confirmed',
    proofType: 'Vector Proof',
    shard: 'London-Heathrow Subsea Mesh',
    blockNumber: 1421099,
  },
  {
    id: 'tx-004',
    hash: '0x5c42d...18f3',
    timestamp: '13:42:01.004',
    from: 'oxford.quantum.lab',
    fromName: 'Oxford Quantum Lab',
    to: 'cambridge.optical.relay',
    toName: 'Cambridge Optical Relay',
    network: 'Vortex Shard Mesh',
    objectType: 'Photon Beam Reservation',
    value: '1.2k Tera-Qubit',
    fee: '0.00018 VQ',
    state: 'confirmed',
    proofType: 'Coherence State Proof',
    shard: 'North Sea Wind Array Relay',
    blockNumber: 4209188,
  },
  {
    id: 'tx-005',
    hash: '0x1122a...88ff',
    timestamp: '13:41:58.910',
    from: 'edinburgh.cold.archive',
    fromName: 'Edinburgh Storage Node',
    to: '0x7F9A...88E1',
    toName: 'Quantum Optics Allocator',
    network: 'Veritas Zero-Knowledge Fabric',
    objectType: 'Replication Proof',
    value: '0.00 µP',
    fee: '0.00002 µP',
    state: 'confirmed',
    proofType: 'Erasure SNARK',
    shard: 'Edinburgh Cold Archive',
    blockNumber: 8819204,
  },
];
