'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  Web3Object,
  NetworkNode,
  MockTransaction,
  MockWebPage,
  MOCK_NETWORKS,
  MOCK_OBJECTS,
  MOCK_PAGES,
  INITIAL_TRANSACTIONS,
} from '@/lib/mock-data/web3-mock';
import { ThemeMode, DensityMode, MotionMode } from '@/styles/tokens';

export type BrowserInteractionMode = 'browse' | 'explore' | 'map' | 'object' | 'observatory';
export type ContextPanelTab = 'network' | 'identity' | 'objects' | 'activity' | 'security';

export interface TabItem {
  id: string;
  title: string;
  url: string;
  pageId?: string;
  objectId?: string;
  networkId?: string;
  isLoading: boolean;
  faviconColor: string;
  associatedObjectsCount: number;
}

export interface BookmarkItem {
  id: string;
  title: string;
  url: string;
  type: 'website' | 'network' | 'object' | 'protocol' | 'token' | 'contract' | 'identity';
  identifier: string;
  timestamp: string;
}

export interface HistoryItem {
  id: string;
  title: string;
  url: string;
  type: 'site' | 'object' | 'network' | 'protocol';
  timestamp: string;
  network?: string;
}

interface BrowserContextType {
  // Tabs & Navigation
  tabs: TabItem[];
  activeTabId: string;
  activeTab: TabItem;
  navigateTab: (tabId: string, urlOrTarget: string) => void;
  openNewTab: (url?: string, title?: string, pageId?: string) => void;
  closeTab: (tabId: string) => void;
  reorderTabs: (newTabs: TabItem[]) => void;
  goBack: () => void;
  goForward: () => void;
  refreshActiveTab: () => void;

  // Visual State & Modes
  mode: BrowserInteractionMode;
  setMode: (mode: BrowserInteractionMode) => void;
  contextPanelOpen: boolean;
  setContextPanelOpen: (open: boolean) => void;
  toggleContextPanel: (tab?: ContextPanelTab) => void;
  activeContextTab: ContextPanelTab;
  setActiveContextTab: (tab: ContextPanelTab) => void;

  // Selected Entities
  selectedObject: Web3Object | null;
  setSelectedObject: (obj: Web3Object | null) => void;
  objectMorphLevel: 1 | 2 | 3 | 4;
  setObjectMorphLevel: (level: 1 | 2 | 3 | 4) => void;
  hoveredObject: Web3Object | null;
  setHoveredObject: (obj: Web3Object | null) => void;
  hoverPos: { x: number; y: number } | null;
  setHoverPos: (pos: { x: number; y: number } | null) => void;

  selectedNetwork: NetworkNode | null;
  setSelectedNetwork: (net: NetworkNode | null) => void;

  // Active Web Page
  activePage: MockWebPage | null;
  associatedObjects: Web3Object[];

  // Address Bar & Search
  barQuery: string;
  setBarQuery: (query: string) => void;
  barActive: boolean;
  setBarActive: (active: boolean) => void;
  resolvedQueryType: 'url' | 'network' | 'contract' | 'identity' | 'token' | 'protocol' | 'unknown';
  executeResolvedQuery: (target: string) => void;

  // Live Transactions
  transactions: MockTransaction[];
  selectedTransaction: MockTransaction | null;
  setSelectedTransaction: (tx: MockTransaction | null) => void;
  activeTxSimulation: MockTransaction | null;
  runTxSimulation: (tx?: MockTransaction) => void;
  txSimulationStep: number; // 0=Origin, 1=Ingress, 2=Shard, 3=Block, 4=Root (Finalized)

  // Command Palette
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;

  // Bookmarks & History
  bookmarks: BookmarkItem[];
  addBookmark: (item: Omit<BookmarkItem, 'id' | 'timestamp'>) => void;
  removeBookmark: (id: string) => void;
  history: HistoryItem[];

  // Settings & Theme
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  density: DensityMode;
  setDensity: (density: DensityMode) => void;
  motionMode: MotionMode;
  setMotionMode: (mode: MotionMode) => void;

  // Demo Guided Journey
  isDemoRunning: boolean;
  demoStep: number;
  demoStepText: string;
  startDemoJourney: () => void;
  stopDemoJourney: () => void;

  // Networks and Objects dataset
  allNetworks: NetworkNode[];
  allObjects: Web3Object[];
  allPages: MockWebPage[];
}

const BrowserContext = createContext<BrowserContextType | undefined>(undefined);

export function BrowserProvider({ children }: { children: ReactNode }) {
  // Theme & Presets
  const [theme, setTheme] = useState<ThemeMode>('obsidian');
  const [density, setDensity] = useState<DensityMode>('standard');
  const [motionMode, setMotionMode] = useState<MotionMode>('full');

  // Mode
  const [mode, setMode] = useState<BrowserInteractionMode>('browse');

  // Initial Tabs
  const [tabs, setTabs] = useState<TabItem[]>([
    {
      id: 'tab-1',
      title: 'Aether Spatial Observatory 2040',
      url: 'aether://observatory.mesh',
      pageId: 'page-observatory',
      isLoading: false,
      faviconColor: '#4D8BC4',
      associatedObjectsCount: 3,
    },
    {
      id: 'tab-2',
      title: 'Oxford Quantum Optics Foundry',
      url: 'https://oxford.quantum.lab.ac.uk/beams/telemetry',
      pageId: 'page-quantum-lab',
      isLoading: false,
      faviconColor: '#9C88FF',
      associatedObjectsCount: 3,
    },
    {
      id: 'tab-3',
      title: 'North Atlantic Oceanographic Mesh',
      url: 'https://atlantic.buoy.mesh.org/telemetry/gulf-stream',
      pageId: 'page-ocean-telemetry',
      isLoading: false,
      faviconColor: '#58A878',
      associatedObjectsCount: 2,
    },
  ]);

  const [activeTabId, setActiveTabId] = useState<string>('tab-1');
  const [tabHistory, setTabHistory] = useState<Record<string, { stack: string[]; index: number }>>({
    'tab-1': { stack: ['aether://observatory.mesh'], index: 0 },
    'tab-2': { stack: ['https://oxford.quantum.lab.ac.uk/beams/telemetry'], index: 0 },
    'tab-3': { stack: ['https://atlantic.buoy.mesh.org/telemetry/gulf-stream'], index: 0 },
  });

  // Context Panel
  const [contextPanelOpen, setContextPanelOpen] = useState<boolean>(false);
  const [activeContextTab, setActiveContextTab] = useState<ContextPanelTab>('objects');

  // Hovered and Selected Objects
  const [selectedObject, setSelectedObject] = useState<Web3Object | null>(null);
  const [objectMorphLevel, setObjectMorphLevel] = useState<1 | 2 | 3 | 4>(1);
  const [hoveredObject, setHoveredObject] = useState<Web3Object | null>(null);
  const [hoverPos, setHoverPos] = useState<{ x: number; y: number } | null>(null);

  // Network Selection
  const [selectedNetwork, setSelectedNetwork] = useState<NetworkNode | null>(MOCK_NETWORKS[0]);

  // Address Bar
  const [barQuery, setBarQuery] = useState<string>('aether://observatory.mesh');
  const [barActive, setBarActive] = useState<boolean>(false);

  // Transactions
  const [transactions, setTransactions] = useState<MockTransaction[]>(INITIAL_TRANSACTIONS);
  const [selectedTransaction, setSelectedTransaction] = useState<MockTransaction | null>(null);
  const [activeTxSimulation, setActiveTxSimulation] = useState<MockTransaction | null>(null);
  const [txSimulationStep, setTxSimulationStep] = useState<number>(0);

  // Command Palette
  const [commandPaletteOpen, setCommandPaletteOpen] = useState<boolean>(false);

  // Bookmarks
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([
    {
      id: 'bm-1',
      title: 'Aether Spatial Observatory',
      url: 'aether://observatory.mesh',
      type: 'website',
      identifier: 'aether-core',
      timestamp: '2040-09-01',
    },
    {
      id: 'bm-2',
      title: 'Autonomous Quantum Optics Allocator',
      url: 'object://0x7F9A...88E1',
      type: 'contract',
      identifier: '0x7F9A...88E1',
      timestamp: '2040-09-02',
    },
    {
      id: 'bm-3',
      title: 'Veritas Zero-Knowledge Fabric',
      url: 'network://veritas-zk',
      type: 'network',
      identifier: 'net-veritas-zk',
      timestamp: '2040-09-02',
    },
    {
      id: 'bm-4',
      title: 'Dr. Eleanor Vane (Aerospace ID)',
      url: 'identity://eleanor.vane.aero.id',
      type: 'identity',
      identifier: 'eleanor.vane.aero.id',
      timestamp: '2040-09-03',
    },
  ]);

  // History
  const [history, setHistory] = useState<HistoryItem[]>([
    { id: 'h-1', title: 'Aether Spatial Observatory', url: 'aether://observatory.mesh', type: 'site', timestamp: '13:42 GMT' },
    { id: 'h-2', title: 'Autonomous Quantum Optics Allocator', url: '0x7F9A...88E1', type: 'object', timestamp: '13:38 GMT', network: 'Veritas ZK' },
    { id: 'h-3', title: 'Oxford Quantum Optics Foundry', url: 'https://oxford.quantum.lab.ac.uk', type: 'site', timestamp: '13:30 GMT' },
    { id: 'h-4', title: 'Vortex Shard Mesh', url: 'net-vortex-mesh', type: 'network', timestamp: '13:15 GMT', network: 'L2 Shard' },
    { id: 'h-5', title: 'North Atlantic Oceanographic Mesh', url: 'https://atlantic.buoy.mesh.org', type: 'site', timestamp: '12:45 GMT' },
  ]);

  // Demo state
  const [isDemoRunning, setIsDemoRunning] = useState<boolean>(false);
  const [demoStep, setDemoStep] = useState<number>(0);
  const [demoStepText, setDemoStepText] = useState<string>('');

  // Active Tab Derived
  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  // Active Page
  const activePage = MOCK_PAGES.find((p) => p.id === activeTab.pageId || p.url === activeTab.url) || MOCK_PAGES[0];

  // Associated Objects for current page
  const associatedObjects = activePage.associatedObjects
    .map((id) => MOCK_OBJECTS.find((o) => o.id === id))
    .filter((o): o is Web3Object => Boolean(o));

  // Keyboard shortcut for Cmd+K (Command palette) and Esc
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setCommandPaletteOpen(false);
        setBarActive(false);
        setHoveredObject(null);
        if (selectedObject && objectMorphLevel > 1) {
          setObjectMorphLevel((prev) => (prev - 1) as any);
        } else {
          setSelectedObject(null);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedObject, objectMorphLevel]);

  // Automatic Background Transaction Generator (Simulating deterministic network flow)
  useEffect(() => {
    const interval = setInterval(() => {
      const randomNet = MOCK_NETWORKS[Math.floor(Math.random() * MOCK_NETWORKS.length)];
      const randomObj = MOCK_OBJECTS[Math.floor(Math.random() * MOCK_OBJECTS.length)];
      const randomId = Math.random().toString(36).substring(2, 7);

      const newTx: MockTransaction = {
        id: `tx-${Date.now()}`,
        hash: `0x${Math.random().toString(16).substring(2, 10)}...${randomId}`,
        timestamp: new Date().toISOString().substring(11, 19) + '.' + Math.floor(Math.random() * 900 + 100),
        from: `node-${randomId}.mesh`,
        fromName: `Telemetry Peer #${Math.floor(Math.random() * 9000 + 1000)}`,
        to: randomObj.identifier,
        toName: randomObj.name,
        network: randomNet.name,
        objectType: randomObj.type === 'contract' ? 'Contract Call' : randomObj.type === 'identity' ? 'Credential Attest' : 'State Shard Sync',
        value: `${(Math.random() * 250).toFixed(1)} ${randomNet.tier.includes('L2') ? 'VQ-COMP' : 'µP'}`,
        fee: '0.00004 µP',
        state: 'confirmed',
        proofType: randomNet.consensusEngine.split(' ')[0] + ' Proof',
        shard: `Shard-${Math.floor(Math.random() * 16 + 1)}`,
        blockNumber: 18492000 + Math.floor(Math.random() * 5000),
      };

      setTransactions((prev) => [newTx, ...prev.slice(0, 39)]);
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  // Determine query resolver type
  const resolveQueryType = (query: string): 'url' | 'network' | 'contract' | 'identity' | 'token' | 'protocol' | 'unknown' => {
    const q = query.trim().toLowerCase();
    if (q.startsWith('http://') || q.startsWith('https://') || q.startsWith('aether://') || q.includes('.mesh') || q.includes('.org') || q.includes('.com') || q.includes('.uk')) {
      return 'url';
    }
    if (q.startsWith('0x') || q.includes('contract') || q.includes('allocator')) {
      return 'contract';
    }
    if (q.includes('.id') || q.includes('did:') || q.includes('vane') || q.includes('dr.') || q.includes('identity')) {
      return 'identity';
    }
    if (q.includes('net') || q.includes('mesh') || q.includes('shard') || q.includes('fabric') || q.includes('veritas') || q.includes('aether-4')) {
      return 'network';
    }
    if (q.includes('token') || q.includes('comp') || q.includes('vq') || q.includes('credit')) {
      return 'token';
    }
    if (q.includes('protocol') || q.includes('sicp') || q.includes('rfc')) {
      return 'protocol';
    }
    return 'unknown';
  };

  const resolvedQueryType = resolveQueryType(barQuery);

  // Navigate Tab
  const navigateTab = useCallback((tabId: string, target: string) => {
    const matchedPage = MOCK_PAGES.find(
      (p) => p.url.toLowerCase() === target.toLowerCase() || p.id === target || p.title.toLowerCase().includes(target.toLowerCase())
    );

    const matchedObject = MOCK_OBJECTS.find(
      (o) => o.identifier.toLowerCase() === target.toLowerCase() || o.id === target || o.name.toLowerCase().includes(target.toLowerCase())
    );

    const matchedNetwork = MOCK_NETWORKS.find(
      (n) => n.id === target || n.name.toLowerCase().includes(target.toLowerCase())
    );

    setTabs((prev) =>
      prev.map((t) => {
        if (t.id === tabId) {
          if (matchedPage) {
            return {
              ...t,
              title: matchedPage.title,
              url: matchedPage.url,
              pageId: matchedPage.id,
              objectId: undefined,
              networkId: undefined,
              associatedObjectsCount: matchedPage.associatedObjects.length,
              isLoading: true,
            };
          } else if (matchedObject) {
            return {
              ...t,
              title: `[Object] ${matchedObject.name}`,
              url: `object://${matchedObject.identifier}`,
              pageId: undefined,
              objectId: matchedObject.id,
              networkId: undefined,
              associatedObjectsCount: 1,
              isLoading: true,
            };
          } else if (matchedNetwork) {
            return {
              ...t,
              title: `[Network] ${matchedNetwork.name}`,
              url: `network://${matchedNetwork.id}`,
              pageId: undefined,
              objectId: undefined,
              networkId: matchedNetwork.id,
              associatedObjectsCount: 4,
              isLoading: true,
            };
          } else {
            return {
              ...t,
              title: target,
              url: target.startsWith('http') || target.startsWith('aether://') ? target : `https://${target}`,
              pageId: 'page-observatory',
              isLoading: true,
            };
          }
        }
        return t;
      })
    );

    // Record in history
    setHistory((prev) => [
      {
        id: `h-${Date.now()}`,
        title: matchedPage ? matchedPage.title : matchedObject ? matchedObject.name : target,
        url: target,
        type: matchedObject ? 'object' : matchedNetwork ? 'network' : 'site',
        timestamp: new Date().toISOString().substring(11, 16) + ' GMT',
      },
      ...prev,
    ]);

    setBarQuery(target);

    // Fast loading settle
    setTimeout(() => {
      setTabs((prev) => prev.map((t) => (t.id === tabId ? { ...t, isLoading: false } : t)));
    }, 280);
  }, []);

  const selectTab = useCallback((tabId: string) => {
    setActiveTabId(tabId);
    setTabs((prev) => {
      const found = prev.find((t) => t.id === tabId);
      if (found) {
        setBarQuery(found.url);
      }
      return prev;
    });
  }, []);

  const openNewTab = useCallback((url = 'aether://observatory.mesh', title = 'Aether Spatial Observatory', pageId = 'page-observatory') => {
    const newId = `tab-${Date.now()}`;
    const newTab: TabItem = {
      id: newId,
      title,
      url,
      pageId,
      isLoading: false,
      faviconColor: '#4D8BC4',
      associatedObjectsCount: 3,
    };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newId);
    setBarQuery(url);
  }, []);

  const closeTab = useCallback((tabId: string) => {
    setTabs((prev) => {
      if (prev.length <= 1) return prev;
      const idx = prev.findIndex((t) => t.id === tabId);
      const filtered = prev.filter((t) => t.id !== tabId);
      if (activeTabId === tabId) {
        const nextActive = filtered[Math.max(0, idx - 1)];
        setActiveTabId(nextActive.id);
      }
      return filtered;
    });
  }, [activeTabId]);

  const reorderTabs = useCallback((newTabs: TabItem[]) => {
    setTabs(newTabs);
  }, []);

  const goBack = useCallback(() => {
    // Spatial history back
    if (history.length > 1) {
      const prevItem = history[1];
      navigateTab(activeTabId, prevItem.url);
    }
  }, [history, activeTabId, navigateTab]);

  const refreshActiveTab = useCallback(() => {
    setTabs((prev) => prev.map((t) => (t.id === activeTabId ? { ...t, isLoading: true } : t)));
    setTimeout(() => {
      setTabs((prev) => prev.map((t) => (t.id === activeTabId ? { ...t, isLoading: false } : t)));
    }, 240);
  }, [activeTabId]);

  const goForward = useCallback(() => {
    // Reload active
    refreshActiveTab();
  }, [refreshActiveTab]);

  const toggleContextPanel = useCallback((tab?: ContextPanelTab) => {
    if (tab) {
      setActiveContextTab(tab);
      setContextPanelOpen(true);
    } else {
      setContextPanelOpen((prev) => !prev);
    }
  }, []);

  const addBookmark = useCallback((item: Omit<BookmarkItem, 'id' | 'timestamp'>) => {
    const newBm: BookmarkItem = {
      ...item,
      id: `bm-${Date.now()}`,
      timestamp: new Date().toISOString().substring(0, 10),
    };
    setBookmarks((prev) => [newBm, ...prev]);
  }, []);

  const removeBookmark = useCallback((id: string) => {
    setBookmarks((prev) => prev.filter((b) => b.id !== id));
  }, []);

  const executeResolvedQuery = useCallback((target: string) => {
    setBarActive(false);
    navigateTab(activeTabId, target);
  }, [activeTabId, navigateTab]);

  // Transaction Simulation Runner
  const runTxSimulation = useCallback((tx?: MockTransaction) => {
    const targetTx = tx || transactions[0];
    setActiveTxSimulation(targetTx);
    setTxSimulationStep(0);

    // Sequence stages: 0 (Origin) -> 1 (Ingress) -> 2 (Shard) -> 3 (Block) -> 4 (Root Settled)
    const timers = [
      setTimeout(() => setTxSimulationStep(1), 800),
      setTimeout(() => setTxSimulationStep(2), 1700),
      setTimeout(() => setTxSimulationStep(3), 2600),
      setTimeout(() => setTxSimulationStep(4), 3500),
      setTimeout(() => {
        // finished
      }, 4500),
    ];

    return () => timers.forEach(clearTimeout);
  }, [transactions]);

  // Guided Demo Scenario Journey
  const startDemoJourney = useCallback(() => {
    setIsDemoRunning(true);
    setDemoStep(1);
    setDemoStepText('1. Initializing Aether 2040 Spatial Observatory...');
    setMode('browse');
    navigateTab(activeTabId, 'aether://observatory.mesh');

    setTimeout(() => {
      setDemoStep(2);
      setDemoStepText('2. Resolving target decentralized laboratory: oxford.quantum.lab...');
      setBarQuery('oxford.quantum.lab');
      setBarActive(true);
    }, 2500);

    setTimeout(() => {
      setDemoStep(3);
      setDemoStepText('3. Loading verified quantum optical routing page & detecting smart contracts...');
      setBarActive(false);
      navigateTab(activeTabId, 'https://oxford.quantum.lab.ac.uk/beams/telemetry');
    }, 4500);

    setTimeout(() => {
      setDemoStep(4);
      setDemoStepText('4. Activating Web3 Context Layer: Contract 0x7F9A...88E1 & ZK-Fabric state...');
      setContextPanelOpen(true);
      setActiveContextTab('objects');
    }, 7000);

    setTimeout(() => {
      setDemoStep(5);
      setDemoStepText('5. Morphing Contract Object into Deep Technical Inspection & Formal Verification...');
      const obj = MOCK_OBJECTS[0];
      setSelectedObject(obj);
      setObjectMorphLevel(2);
    }, 9500);

    setTimeout(() => {
      setDemoStep(6);
      setDemoStepText('6. Expanding to Level 3: Verifiable ZK Functions, Signatures, and Foundry Peers...');
      setObjectMorphLevel(3);
    }, 12000);

    setTimeout(() => {
      setDemoStep(7);
      setDemoStepText('7. Switching to Spatial Network Cartography Map: Veritas Zero-Knowledge Fabric...');
      setSelectedObject(null);
      setMode('map');
      setSelectedNetwork(MOCK_NETWORKS[3]);
    }, 15000);

    setTimeout(() => {
      setDemoStep(8);
      setDemoStepText('8. Executing Real-time Hardware Transaction Packet Flight Simulation...');
      setMode('browse');
      runTxSimulation(transactions[0]);
    }, 18500);

    setTimeout(() => {
      setDemoStep(9);
      setDemoStepText('9. Entering Immersive Fullscreen Observatory Mode...');
      setMode('observatory');
    }, 22500);

    setTimeout(() => {
      setDemoStep(10);
      setDemoStepText('10. Demo Journey Complete. Aether 2040 Browser ready for exploration.');
      setIsDemoRunning(false);
    }, 26500);
  }, [activeTabId, navigateTab, runTxSimulation, transactions]);

  const stopDemoJourney = useCallback(() => {
    setIsDemoRunning(false);
    setDemoStep(0);
    setDemoStepText('');
  }, []);

  return (
    <BrowserContext.Provider
      value={{
        tabs,
        activeTabId,
        activeTab,
        navigateTab,
        openNewTab,
        closeTab,
        reorderTabs,
        goBack,
        goForward,
        refreshActiveTab,

        mode,
        setMode,
        contextPanelOpen,
        setContextPanelOpen,
        toggleContextPanel,
        activeContextTab,
        setActiveContextTab,

        selectedObject,
        setSelectedObject,
        objectMorphLevel,
        setObjectMorphLevel,
        hoveredObject,
        setHoveredObject,
        hoverPos,
        setHoverPos,

        selectedNetwork,
        setSelectedNetwork,

        activePage,
        associatedObjects,

        barQuery,
        setBarQuery,
        barActive,
        setBarActive,
        resolvedQueryType,
        executeResolvedQuery,

        transactions,
        selectedTransaction,
        setSelectedTransaction,
        activeTxSimulation,
        runTxSimulation,
        txSimulationStep,

        commandPaletteOpen,
        setCommandPaletteOpen,

        bookmarks,
        addBookmark,
        removeBookmark,
        history,

        theme,
        setTheme,
        density,
        setDensity,
        motionMode,
        setMotionMode,

        isDemoRunning,
        demoStep,
        demoStepText,
        startDemoJourney,
        stopDemoJourney,

        allNetworks: MOCK_NETWORKS,
        allObjects: MOCK_OBJECTS,
        allPages: MOCK_PAGES,
      }}
    >
      {children}
    </BrowserContext.Provider>
  );
}

export function useBrowser() {
  const context = useContext(BrowserContext);
  if (!context) {
    throw new Error('useBrowser must be used within a BrowserProvider');
  }
  return context;
}
