// Aether Anglo-Futurist 2040 Design Tokens

export const DESIGN_TOKENS = {
  materials: {
    obsidian: {
      canvas: '#0B0D0E',
      surface: '#121518',
      surfaceElevated: '#181C20',
      surfaceHighlight: '#22272E',
      borderSubtle: '#262C34',
      borderDefault: '#323A44',
      borderStrong: '#4A5564',
      textPrimary: '#F2F4F7',
      textSecondary: '#A4B0C0',
      textMuted: '#6B7A8D',
      gridLine: 'rgba(255, 255, 255, 0.035)',
      crosshair: 'rgba(255, 255, 255, 0.12)',
    },
    archive: {
      canvas: '#F4F2EB',
      surface: '#ECE9DF',
      surfaceElevated: '#E4E0D4',
      surfaceHighlight: '#DBD6C7',
      borderSubtle: '#D3CCBA',
      borderDefault: '#BBB19B',
      borderStrong: '#8C826C',
      textPrimary: '#1C1E21',
      textSecondary: '#4D535E',
      textMuted: '#7E8794',
      gridLine: 'rgba(0, 0, 0, 0.04)',
      crosshair: 'rgba(0, 0, 0, 0.15)',
    },
  },
  accents: {
    mutedBlue: {
      dark: '#4D8BC4',
      light: '#2868A2',
      bgDark: 'rgba(77, 139, 196, 0.12)',
      bgLight: 'rgba(40, 104, 162, 0.12)',
      borderDark: 'rgba(77, 139, 196, 0.35)',
      borderLight: 'rgba(40, 104, 162, 0.35)',
    },
    paleGreen: {
      dark: '#58A878',
      light: '#367B52',
      bgDark: 'rgba(88, 168, 120, 0.12)',
      bgLight: 'rgba(54, 123, 82, 0.12)',
      borderDark: 'rgba(88, 168, 120, 0.35)',
      borderLight: 'rgba(54, 123, 82, 0.35)',
    },
    amber: {
      dark: '#D99F44',
      light: '#B27B24',
      bgDark: 'rgba(217, 159, 68, 0.12)',
      bgLight: 'rgba(178, 123, 36, 0.12)',
      borderDark: 'rgba(217, 159, 68, 0.35)',
      borderLight: 'rgba(178, 123, 36, 0.35)',
    },
    controlledRed: {
      dark: '#C85252',
      light: '#9E3232',
      bgDark: 'rgba(200, 82, 82, 0.12)',
      bgLight: 'rgba(158, 50, 50, 0.12)',
      borderDark: 'rgba(200, 82, 82, 0.35)',
      borderLight: 'rgba(158, 50, 50, 0.35)',
    },
  },
  density: {
    minimal: {
      basePadding: '16px',
      itemGap: '12px',
      fontSizeScale: 1.05,
      chromeHeight: '44px',
      tabHeight: '34px',
    },
    standard: {
      basePadding: '12px',
      itemGap: '8px',
      fontSizeScale: 1.0,
      chromeHeight: '40px',
      tabHeight: '30px',
    },
    dense: {
      basePadding: '8px',
      itemGap: '6px',
      fontSizeScale: 0.92,
      chromeHeight: '36px',
      tabHeight: '26px',
    },
    engineering: {
      basePadding: '6px',
      itemGap: '4px',
      fontSizeScale: 0.85,
      chromeHeight: '32px',
      tabHeight: '24px',
    },
  },
  motion: {
    springFast: { stiffness: 400, damping: 28 },
    springStandard: { stiffness: 320, damping: 26 },
    springSmooth: { stiffness: 220, damping: 24 },
    springSpatial: { stiffness: 180, damping: 22 },
    easingAero: [0.16, 1, 0.3, 1], // Anglo aerospace snappy decelerate
    easingSnappy: [0.25, 0.1, 0.25, 1],
  },
};

export type ThemeMode = 'obsidian' | 'archive';
export type DensityMode = 'minimal' | 'standard' | 'dense' | 'engineering';
export type MotionMode = 'full' | 'reduced' | 'minimal';
