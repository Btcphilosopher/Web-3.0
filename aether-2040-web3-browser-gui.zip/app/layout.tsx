import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Aether 2040 Web3 Browser GUI',
  description: 'Anglo-futurist 2040 Web3 browser GUI and visual operating environment with aerospace instrumentation, interactive spatial navigation, network cartography, and technical object inspection.',
  openGraph: {
    title: 'Aether 2040 Web3 Browser GUI',
    description: 'Anglo-futurist 2040 Web3 browser GUI and visual operating environment with aerospace instrumentation, interactive spatial navigation, network cartography, and technical object inspection.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aether 2040 Web3 Browser GUI',
    description: 'Anglo-futurist 2040 Web3 browser GUI and visual operating environment with aerospace instrumentation, interactive spatial navigation, network cartography, and technical object inspection.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Chivo+Mono:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300&family=Instrument+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Instrument+Serif:ital@0;1&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased selection:bg-neutral-800 selection:text-neutral-100 overflow-hidden select-none" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
