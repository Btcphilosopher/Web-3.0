'use client';

import React from 'react';
import { BrowserProvider } from '@/lib/visual-state/browser-store';
import { SFBrowserChrome } from '@/components/browser/SFBrowserChrome';

export default function Page() {
  return (
    <BrowserProvider>
      <SFBrowserChrome />
    </BrowserProvider>
  );
}
