'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import { X, CheckCircle2, ShieldAlert, Cpu, ArrowRight, Zap, ShieldCheck } from 'lucide-react';

export function SFTransactionFlightSimulator() {
  const { activeTxSimulation, txSimulationStep, runTxSimulation } = useBrowser();

  if (!activeTxSimulation) return null;

  const steps = [
    { label: 'Origin Node', detail: activeTxSimulation.fromName },
    { label: 'Ingress Filter', detail: 'Signature & Quorum Check' },
    { label: 'State Shard', detail: activeTxSimulation.shard },
    { label: 'Block Finality', detail: `Block #${activeTxSimulation.blockNumber}` },
    { label: 'Memory Root', detail: 'Halo-2 SNARK Digest' },
  ];

  return (
    <AnimatePresence>
      <div className="fixed bottom-10 right-10 z-50 w-96 p-4 rounded bg-[#101418] border border-[#3A4554] shadow-2xl backdrop-blur-md text-xs font-mono-tech select-none">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 mb-3 hairline-b">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#D99F44] animate-bounce" />
            <div>
              <div className="text-[9px] text-neutral-400 uppercase">Hardware Packet Flight</div>
              <div className="text-xs font-semibold text-neutral-100">{activeTxSimulation.objectType}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => runTxSimulation(undefined)}
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Animated Flight Track */}
        <div className="relative py-2 mb-3">
          <div className="h-1 w-full bg-neutral-800 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#4D8BC4] to-[#58A878]"
              initial={{ width: '0%' }}
              animate={{ width: `${((txSimulationStep + 1) / steps.length) * 100}%` }}
              transition={{ duration: 0.4 }}
            />
          </div>

          <div className="flex justify-between items-center mt-2 text-[9px]">
            {steps.map((step, idx) => {
              const isPast = idx < txSimulationStep;
              const isCurrent = idx === txSimulationStep;
              return (
                <div key={idx} className="flex flex-col items-center text-center w-16">
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[8px] mb-1 transition-colors ${
                      isPast
                        ? 'bg-[#58A878] text-white'
                        : isCurrent
                        ? 'bg-[#4D8BC4] text-white ring-2 ring-[#4D8BC4]/40 animate-pulse'
                        : 'bg-neutral-800 text-neutral-500'
                    }`}
                  >
                    {isPast ? '✓' : idx + 1}
                  </div>
                  <span className={isCurrent ? 'text-neutral-100 font-semibold' : 'text-neutral-400'}>
                    {step.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Current State Card */}
        <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800 text-[10px] space-y-1">
          <div className="flex justify-between">
            <span className="text-neutral-500">Destination:</span>
            <span className="text-[#4D8BC4] font-medium truncate max-w-[180px]">{activeTxSimulation.toName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-neutral-500">Value Transfer:</span>
            <span className="text-[#58A878] font-medium">{activeTxSimulation.value}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-neutral-500">ZK Proof:</span>
            <span className="text-neutral-300">{activeTxSimulation.proofType}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-neutral-500">Status:</span>
            <span className="text-[#58A878] font-semibold uppercase">
              {txSimulationStep >= 4 ? 'FINALIZED & ANCHORED' : 'ROUTING PACKET...'}
            </span>
          </div>
        </div>
      </div>
    </AnimatePresence>
  );
}
