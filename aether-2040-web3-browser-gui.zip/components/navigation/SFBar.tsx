'use client';

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import {
  Search,
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Shield,
  Layers,
  Box,
  UserCheck,
  Coins,
  FileCode2,
  Activity,
  Sliders,
  Sparkles,
  Command,
  Bookmark,
  ExternalLink,
  Globe,
} from 'lucide-react';

export function SFBar() {
  const {
    activeTab,
    barQuery,
    setBarQuery,
    barActive,
    setBarActive,
    resolvedQueryType,
    executeResolvedQuery,
    goBack,
    goForward,
    refreshActiveTab,
    contextPanelOpen,
    toggleContextPanel,
    allNetworks,
    allObjects,
    allPages,
    bookmarks,
    addBookmark,
    setCommandPaletteOpen,
  } = useBrowser();

  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Handle outside click to close dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setBarActive(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [setBarActive]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (barQuery.trim()) {
      executeResolvedQuery(barQuery.trim());
      setBarActive(false);
    }
  };

  // Filter results for live dropdown
  const queryLower = barQuery.toLowerCase().trim();

  const matchedPages = allPages.filter(
    (p) => p.title.toLowerCase().includes(queryLower) || p.url.toLowerCase().includes(queryLower)
  );

  const matchedObjects = allObjects.filter(
    (o) => o.name.toLowerCase().includes(queryLower) || o.identifier.toLowerCase().includes(queryLower)
  );

  const matchedNetworks = allNetworks.filter(
    (n) => n.name.toLowerCase().includes(queryLower) || n.region.toLowerCase().includes(queryLower)
  );

  const isBookmarked = bookmarks.some((b) => b.url === activeTab.url);

  return (
    <div
      id="sf-navigation-bar"
      ref={containerRef}
      className="relative flex items-center justify-between gap-2 px-3 py-1.5 hairline-b bg-[#0E1114] text-neutral-200 z-30"
    >
      {/* Navigation History Controls */}
      <div className="flex items-center gap-1">
        <button
          id="sf-nav-btn-back"
          type="button"
          onClick={goBack}
          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-100 transition-colors"
          title="Spatial History Back"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button
          id="sf-nav-btn-forward"
          type="button"
          onClick={goForward}
          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-100 transition-colors"
          title="Forward"
        >
          <ArrowRight className="w-4 h-4" />
        </button>
        <button
          id="sf-nav-btn-reload"
          type="button"
          onClick={refreshActiveTab}
          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-100 transition-colors"
          title="Refresh State Shard"
        >
          <RotateCw className={`w-3.5 h-3.5 ${activeTab.isLoading ? 'animate-spin text-[#4D8BC4]' : ''}`} />
        </button>
      </div>

      {/* Central Omnibar & Resolver */}
      <div className="relative flex-1 max-w-3xl mx-2">
        <form onSubmit={handleSubmit} className="w-full">
          <div
            className={`flex items-center gap-2 px-3 py-1 rounded-sm border transition-all duration-200 ${
              barActive
                ? 'bg-[#15191E] border-[#4D8BC4] ring-1 ring-[#4D8BC4]/30'
                : 'bg-[#121518] border-[#2A313A] hover:border-[#38424E]'
            }`}
          >
            {/* Context/Resolver Glyph */}
            <div className="flex items-center gap-1 flex-shrink-0 text-xs font-mono-tech">
              {resolvedQueryType === 'contract' ? (
                <span className="flex items-center gap-1 text-[#9C88FF] bg-[#9C88FF]/10 px-1.5 py-0.5 rounded text-[10px]">
                  <Box className="w-3 h-3" /> CONTRACT
                </span>
              ) : resolvedQueryType === 'identity' ? (
                <span className="flex items-center gap-1 text-[#58A878] bg-[#58A878]/10 px-1.5 py-0.5 rounded text-[10px]">
                  <UserCheck className="w-3 h-3" /> IDENTITY
                </span>
              ) : resolvedQueryType === 'network' ? (
                <span className="flex items-center gap-1 text-[#48DBFB] bg-[#48DBFB]/10 px-1.5 py-0.5 rounded text-[10px]">
                  <Layers className="w-3 h-3" /> NETWORK
                </span>
              ) : resolvedQueryType === 'token' ? (
                <span className="flex items-center gap-1 text-[#D99F44] bg-[#D99F44]/10 px-1.5 py-0.5 rounded text-[10px]">
                  <Coins className="w-3 h-3" /> TOKEN
                </span>
              ) : (
                <Search className="w-3.5 h-3.5 text-neutral-400" />
              )}
            </div>

            {/* Main Input */}
            <input
              id="sf-omnibar-input"
              ref={inputRef}
              type="text"
              value={barQuery}
              onFocus={() => setBarActive(true)}
              onChange={(e) => setBarQuery(e.target.value)}
              placeholder="Search Web, Resolve Decentralized Object, Network, or Identity..."
              className="w-full bg-transparent text-xs font-mono-tech text-neutral-100 placeholder-neutral-500 focus:outline-none tracking-tight"
            />

            {/* Bookmark button */}
            <button
              type="button"
              onClick={() => {
                if (!isBookmarked) {
                  addBookmark({
                    title: activeTab.title,
                    url: activeTab.url,
                    type: 'website',
                    identifier: activeTab.url,
                  });
                }
              }}
              className={`p-1 rounded hover:bg-neutral-800 transition-colors ${
                isBookmarked ? 'text-[#D99F44]' : 'text-neutral-500 hover:text-neutral-300'
              }`}
              title={isBookmarked ? 'Bookmarked' : 'Add to Bookmarks Library'}
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
            </button>

            {/* Command Palette Trigger Glyph */}
            <button
              type="button"
              onClick={() => setCommandPaletteOpen(true)}
              className="hidden sm:flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-mono-tech bg-neutral-800/80 text-neutral-400 border border-neutral-700/60 hover:text-neutral-200"
              title="Open Command Console (Ctrl+K)"
            >
              <Command className="w-2.5 h-2.5" /> K
            </button>
          </div>
        </form>

        {/* Live Search & Object Resolver Results Dropdown */}
        <AnimatePresence>
          {barActive && (
            <motion.div
              initial={{ opacity: 0, y: 4, scale: 0.99 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 4, scale: 0.99 }}
              transition={{ duration: 0.15 }}
              className="absolute top-full left-0 right-0 mt-1.5 p-2 rounded-sm bg-[#12161A] border border-[#323A44] shadow-2xl z-50 max-h-[440px] overflow-y-auto"
            >
              {/* Categories Navigation Bar */}
              <div className="flex items-center gap-1.5 px-2 pb-2 mb-2 hairline-b text-[10px] font-mono-tech text-neutral-400 overflow-x-auto">
                <span className="text-neutral-200 uppercase font-semibold">Categories:</span>
                <span className="px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-200">All</span>
                <span className="px-1.5 py-0.5 rounded hover:bg-neutral-800 cursor-pointer">Networks</span>
                <span className="px-1.5 py-0.5 rounded hover:bg-neutral-800 cursor-pointer">Contracts</span>
                <span className="px-1.5 py-0.5 rounded hover:bg-neutral-800 cursor-pointer">Identities</span>
                <span className="px-1.5 py-0.5 rounded hover:bg-neutral-800 cursor-pointer">Tokens</span>
              </div>

              {/* Matched Web Pages */}
              {matchedPages.length > 0 && (
                <div className="mb-3">
                  <div className="text-[10px] font-mono-tech uppercase tracking-wider text-neutral-400 px-2 py-1">
                    Web & Research Portals
                  </div>
                  {matchedPages.map((page) => (
                    <div
                      key={page.id}
                      onClick={() => executeResolvedQuery(page.url)}
                      className="flex items-center justify-between p-2 rounded hover:bg-neutral-800/80 cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <Globe className="w-3.5 h-3.5 text-[#4D8BC4]" />
                        <div>
                          <div className="text-xs text-neutral-200 group-hover:text-white font-medium">
                            {page.title}
                          </div>
                          <div className="text-[10px] font-mono-tech text-neutral-400">{page.url}</div>
                        </div>
                      </div>
                      <span className="text-[9px] font-mono-tech px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-neutral-300">
                        {page.category}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Matched Web3 Objects */}
              {matchedObjects.length > 0 && (
                <div className="mb-3">
                  <div className="text-[10px] font-mono-tech uppercase tracking-wider text-neutral-400 px-2 py-1">
                    Verifiable Decentralized Objects
                  </div>
                  {matchedObjects.map((obj) => (
                    <div
                      key={obj.id}
                      onClick={() => executeResolvedQuery(obj.identifier)}
                      className="flex items-center justify-between p-2 rounded hover:bg-neutral-800/80 cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        {obj.type === 'contract' ? (
                          <FileCode2 className="w-3.5 h-3.5 text-[#9C88FF]" />
                        ) : obj.type === 'identity' ? (
                          <UserCheck className="w-3.5 h-3.5 text-[#58A878]" />
                        ) : (
                          <Coins className="w-3.5 h-3.5 text-[#D99F44]" />
                        )}
                        <div>
                          <div className="text-xs text-neutral-200 group-hover:text-white font-medium">
                            {obj.name}
                          </div>
                          <div className="text-[10px] font-mono-tech text-neutral-400">
                            {obj.identifier} • {obj.networkName}
                          </div>
                        </div>
                      </div>
                      <span className="text-[9px] font-mono-tech px-1.5 py-0.5 rounded bg-[#58A878]/10 text-[#58A878] border border-[#58A878]/30 uppercase">
                        {obj.state}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Matched Autonomous Networks */}
              {matchedNetworks.length > 0 && (
                <div>
                  <div className="text-[10px] font-mono-tech uppercase tracking-wider text-neutral-400 px-2 py-1">
                    Subnet Mesh & L2 Shards
                  </div>
                  {matchedNetworks.map((net) => (
                    <div
                      key={net.id}
                      onClick={() => executeResolvedQuery(net.id)}
                      className="flex items-center justify-between p-2 rounded hover:bg-neutral-800/80 cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <Layers className="w-3.5 h-3.5 text-[#48DBFB]" />
                        <div>
                          <div className="text-xs text-neutral-200 group-hover:text-white font-medium">
                            {net.name}
                          </div>
                          <div className="text-[10px] font-mono-tech text-neutral-400">
                            {net.region} • {net.tps.toLocaleString()} TPS
                          </div>
                        </div>
                      </div>
                      <span className="text-[9px] font-mono-tech px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300">
                        {net.tier}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Right Controls: Web3 Context Layer Trigger & Security Gauge */}
      <div className="flex items-center gap-2">
        <button
          id="sf-btn-context-panel"
          type="button"
          onClick={() => toggleContextPanel()}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono-tech border transition-all ${
            contextPanelOpen
              ? 'bg-[#4D8BC4]/15 border-[#4D8BC4] text-[#4D8BC4]'
              : 'bg-neutral-800/60 border-neutral-700/80 text-neutral-300 hover:bg-neutral-800'
          }`}
          title="Toggle Web3 Context Layer (Inspect Networks, Objects, Security)"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span className="hidden md:inline">CONTEXT</span>
          {activeTab.associatedObjectsCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-[#58A878] animate-pulse" />
          )}
        </button>
      </div>
    </div>
  );
}
