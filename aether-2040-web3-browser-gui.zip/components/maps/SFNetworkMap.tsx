'use client';

import React, { useRef, useEffect, useState } from 'react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import { NetworkNode } from '@/lib/mock-data/web3-mock';
import { Layers, Radio, Cpu, Activity, ZoomIn, ZoomOut, RotateCcw, ShieldCheck } from 'lucide-react';

export function SFNetworkMap() {
  const { allNetworks, selectedNetwork, setSelectedNetwork, setMode } = useBrowser();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // 60FPS High-Precision Spatial Canvas Rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;

    const resize = () => {
      canvas.width = canvas.parentElement?.clientWidth || 800;
      canvas.height = canvas.parentElement?.clientHeight || 600;
    };
    resize();
    window.addEventListener('resize', resize);

    // Pre-calculated node coordinates in 2040 Spatial Grid
    const nodeCoords: Record<string, { x: number; y: number }> = {
      'net-aether-4': { x: 380, y: 280 },
      'net-vortex-mesh': { x: 560, y: 190 },
      'net-chronos-l2': { x: 240, y: 200 },
      'net-veritas-zk': { x: 440, y: 410 },
      'net-helios-grid': { x: 190, y: 390 },
      'net-borealis-storage': { x: 620, y: 360 },
    };

    const render = () => {
      time += 0.02;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      // Apply pan & zoom
      ctx.translate(canvas.width / 2 + pan.x, canvas.height / 2 + pan.y);
      ctx.scale(zoom, zoom);
      ctx.translate(-canvas.width / 2, -canvas.height / 2);

      // 1. Draw Technical Drafting Coordinates & Grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // 2. Draw Radar Range Rings
      ctx.strokeStyle = 'rgba(77, 139, 196, 0.08)';
      ctx.lineWidth = 1;
      [100, 200, 320].forEach((r) => {
        ctx.beginPath();
        ctx.arc(380, 280, r, 0, Math.PI * 2);
        ctx.stroke();
      });

      // 3. Draw Subnet Inter-Mesh Links & Flowing Pulses
      const links = [
        ['net-aether-4', 'net-vortex-mesh'],
        ['net-aether-4', 'net-chronos-l2'],
        ['net-aether-4', 'net-veritas-zk'],
        ['net-vortex-mesh', 'net-borealis-storage'],
        ['net-chronos-l2', 'net-helios-grid'],
        ['net-veritas-zk', 'net-helios-grid'],
        ['net-veritas-zk', 'net-borealis-storage'],
      ];

      links.forEach(([fromId, toId], idx) => {
        const from = nodeCoords[fromId];
        const to = nodeCoords[toId];
        if (!from || !to) return;

        // Static Shard Link Line
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(from.x, from.y);
        ctx.lineTo(to.x, to.y);
        ctx.stroke();
        ctx.setLineDash([]);

        // Animated Traveling Packet along link
        const progress = (time * 0.5 + idx * 0.25) % 1;
        const px = from.x + (to.x - from.x) * progress;
        const py = from.y + (to.y - from.y) * progress;

        ctx.fillStyle = idx % 2 === 0 ? '#4D8BC4' : '#58A878';
        ctx.beginPath();
        ctx.arc(px, py, 2.5, 0, Math.PI * 2);
        ctx.fill();
      });

      // 4. Draw Spatial Nodes
      allNetworks.forEach((net) => {
        const pos = nodeCoords[net.id] || { x: 400, y: 300 };
        const isSelected = selectedNetwork?.id === net.id;

        // Glow ring for selected
        if (isSelected) {
          ctx.strokeStyle = 'rgba(77, 139, 196, 0.4)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(pos.x, pos.y, 22 + Math.sin(time * 3) * 2, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Outer boundary
        ctx.fillStyle = isSelected ? '#1A232D' : '#101418';
        ctx.strokeStyle = isSelected ? '#4D8BC4' : '#323A44';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Core dot
        ctx.fillStyle = net.color || '#58A878';
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 4, 0, Math.PI * 2);
        ctx.fill();

        // Label
        ctx.font = '10px "Chivo Mono", monospace';
        ctx.fillStyle = isSelected ? '#F2F4F7' : '#A4B0C0';
        ctx.textAlign = 'center';
        ctx.fillText(net.name, pos.x, pos.y + 26);
        ctx.font = '8px "Chivo Mono", monospace';
        ctx.fillStyle = '#6B7A8D';
        ctx.fillText(`${(net.tps / 1000).toFixed(0)}k TPS`, pos.x, pos.y + 36);
      });

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resize);
    };
  }, [allNetworks, selectedNetwork, zoom, pan]);

  // Click to select node
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = (e.clientX - rect.left - (canvas.width / 2 + pan.x)) / zoom + canvas.width / 2;
    const clickY = (e.clientY - rect.top - (canvas.height / 2 + pan.y)) / zoom + canvas.height / 2;

    const nodeCoords: Record<string, { x: number; y: number }> = {
      'net-aether-4': { x: 380, y: 280 },
      'net-vortex-mesh': { x: 560, y: 190 },
      'net-chronos-l2': { x: 240, y: 200 },
      'net-veritas-zk': { x: 440, y: 410 },
      'net-helios-grid': { x: 190, y: 390 },
      'net-borealis-storage': { x: 620, y: 360 },
    };

    for (const net of allNetworks) {
      const pos = nodeCoords[net.id];
      if (pos) {
        const dist = Math.hypot(clickX - pos.x, clickY - pos.y);
        if (dist < 20) {
          setSelectedNetwork(net);
          break;
        }
      }
    }
  };

  return (
    <div id="sf-network-map-viewport" className="relative w-full h-full bg-[#090B0D] overflow-hidden flex flex-col select-none">
      {/* Top Map Header & Controls */}
      <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between pointer-events-none">
        <div className="pointer-events-auto p-2.5 rounded bg-[#101418]/90 border border-[#28303A] backdrop-blur-md flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-[#4D8BC4] animate-ping" />
          <div>
            <div className="text-[10px] font-mono-tech text-neutral-400 uppercase">
              2040 Spatial Internet Cartography
            </div>
            <h2 className="text-xs font-semibold text-neutral-100 font-mono-tech">
              Global Shard Mesh & Subnet Topology
            </h2>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-1.5 p-1 rounded bg-[#101418]/90 border border-[#28303A] backdrop-blur-md">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2.5, z + 0.2))}
            className="p-1.5 rounded hover:bg-neutral-800 text-neutral-300"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.6, z - 0.2))}
            className="p-1.5 rounded hover:bg-neutral-800 text-neutral-300"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              setZoom(1);
              setPan({ x: 0, y: 0 });
            }}
            className="p-1.5 rounded hover:bg-neutral-800 text-neutral-300"
            title="Reset Orientation"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setMode('browse')}
            className="px-2.5 py-1 text-xs font-mono-tech rounded bg-[#4D8BC4] text-white hover:bg-[#3B7BB4] transition-colors"
          >
            Return to Browse
          </button>
        </div>
      </div>

      {/* Main Canvas */}
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        onMouseDown={(e) => {
          setIsDragging(true);
          setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
        }}
        onMouseMove={(e) => {
          if (isDragging) {
            setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
          }
        }}
        onMouseUp={() => setIsDragging(false)}
        className="w-full h-full cursor-grab active:cursor-grabbing"
      />

      {/* Node Inspector Overlay (Bottom-Left) */}
      {selectedNetwork && (
        <div className="absolute bottom-4 left-4 z-20 w-80 p-3.5 rounded bg-[#101418]/95 border border-[#323A44] shadow-2xl backdrop-blur-md text-xs font-mono-tech space-y-2.5">
          <div className="flex items-center justify-between hairline-b pb-2">
            <span className="text-[10px] text-[#4D8BC4] uppercase font-semibold">
              Selected Subnet Node
            </span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300">
              {selectedNetwork.tier}
            </span>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-neutral-100">{selectedNetwork.name}</h3>
            <div className="text-[10px] text-neutral-400">{selectedNetwork.region}</div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[10px]">
            <div className="p-2 rounded bg-neutral-900 border border-neutral-800">
              <div className="text-neutral-500">THROUGHPUT</div>
              <div className="text-neutral-200 font-semibold">{selectedNetwork.tps.toLocaleString()} TPS</div>
            </div>
            <div className="p-2 rounded bg-neutral-900 border border-neutral-800">
              <div className="text-neutral-500">LATENCY</div>
              <div className="text-[#58A878] font-semibold">{selectedNetwork.latencyMs} ms</div>
            </div>
          </div>

          <div className="text-[10px] text-neutral-300 space-y-1">
            <div>Consensus: <span className="text-neutral-100">{selectedNetwork.consensusEngine}</span></div>
            <div>Active Peers: <span className="text-neutral-100">{selectedNetwork.totalPeers.toLocaleString()}</span></div>
            <div>Active Contracts: <span className="text-neutral-100">{selectedNetwork.activeContracts.toLocaleString()}</span></div>
          </div>
        </div>
      )}
    </div>
  );
}
