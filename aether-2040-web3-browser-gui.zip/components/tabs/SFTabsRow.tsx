'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser, TabItem } from '@/lib/visual-state/browser-store';
import { Plus, X, Globe, Layers, ShieldCheck, Box } from 'lucide-react';

export function SFTabsRow() {
  const { tabs, activeTabId, navigateTab, openNewTab, closeTab, density } = useBrowser();

  const tabHeightClass =
    density === 'engineering'
      ? 'h-6 text-xs'
      : density === 'dense'
      ? 'h-7 text-xs'
      : density === 'minimal'
      ? 'h-9 text-sm'
      : 'h-8 text-xs';

  return (
    <div
      id="sf-tabs-container"
      className="flex items-center w-full px-2 pt-1 gap-1 overflow-x-auto select-none hairline-b bg-neutral-950/40"
    >
      <div className="flex items-center gap-1 flex-1 min-w-0">
        <AnimatePresence initial={false}>
          {tabs.map((tab) => {
            const isActive = tab.id === activeTabId;
            return (
              <motion.div
                key={tab.id}
                layout
                initial={{ opacity: 0, scale: 0.92, y: 3 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, width: 0, transition: { duration: 0.16 } }}
                transition={{ type: 'spring', stiffness: 360, damping: 28 }}
                onClick={() => {
                  navigateTab(tab.id, tab.url);
                }}
                className={`group relative flex items-center gap-2 px-3 rounded-t-sm cursor-pointer border-t border-x transition-colors duration-150 ${tabHeightClass} ${
                  isActive
                    ? 'bg-[#15191E] border-[#363F4B] text-neutral-100 font-medium shadow-sm'
                    : 'bg-[#0E1012] border-transparent text-neutral-400 hover:bg-[#121518] hover:text-neutral-200'
                }`}
                style={{
                  maxWidth: '220px',
                  minWidth: '130px',
                }}
              >
                {/* Active Indicator Line */}
                {isActive && (
                  <motion.div
                    layoutId="active-tab-indicator"
                    className="absolute top-0 left-0 right-0 h-[2px] bg-[#4D8BC4]"
                    transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  />
                )}

                {/* Loading Line animation */}
                {tab.isLoading && (
                  <motion.div
                    initial={{ x: '-100%' }}
                    animate={{ x: '100%' }}
                    transition={{ repeat: Infinity, duration: 0.8, ease: 'linear' }}
                    className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#58A878]"
                  />
                )}

                {/* Favicon / Object Type Indicator */}
                <div className="flex-shrink-0">
                  {tab.objectId ? (
                    <Box className="w-3.5 h-3.5 text-[#9C88FF]" />
                  ) : tab.networkId ? (
                    <Layers className="w-3.5 h-3.5 text-[#58A878]" />
                  ) : tab.url.startsWith('aether://') ? (
                    <ShieldCheck className="w-3.5 h-3.5 text-[#4D8BC4]" />
                  ) : (
                    <Globe className="w-3.5 h-3.5 text-neutral-400" />
                  )}
                </div>

                {/* Tab Title */}
                <span className="truncate flex-1 tracking-tight text-[11px] font-sans">
                  {tab.title}
                </span>

                {/* Web3 Object Count Badge */}
                {tab.associatedObjectsCount > 0 && (
                  <span
                    className="flex-shrink-0 px-1 py-0.2 text-[9px] font-mono-tech rounded bg-neutral-800/80 text-neutral-300 border border-neutral-700/60"
                    title={`${tab.associatedObjectsCount} verified Web3 objects linked`}
                  >
                    {tab.associatedObjectsCount}
                  </span>
                )}

                {/* Close Button */}
                {tabs.length > 1 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      closeTab(tab.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 hover:bg-neutral-800 p-0.5 rounded text-neutral-400 hover:text-neutral-200 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* New Tab Button */}
      <button
        id="sf-btn-new-tab"
        type="button"
        onClick={() => openNewTab()}
        className="flex items-center justify-center w-7 h-7 rounded hover:bg-neutral-800/70 text-neutral-400 hover:text-neutral-200 transition-colors"
        title="Open New Spatial Tab (Ctrl+T)"
      >
        <Plus className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
