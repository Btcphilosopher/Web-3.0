'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import {
  X,
  Box,
  Layers,
  ShieldCheck,
  CheckCircle2,
  FileCode2,
  Activity,
  Cpu,
  Users,
  ChevronRight,
  Terminal,
  Play,
  RotateCw,
  Clock,
  Sparkles,
  Lock,
} from 'lucide-react';

export function SFObjectInspectorModal() {
  const {
    selectedObject,
    setSelectedObject,
    objectMorphLevel,
    setObjectMorphLevel,
    runTxSimulation,
  } = useBrowser();

  const [executingFn, setExecutingFn] = useState<string | null>(null);
  const [fnLogs, setFnLogs] = useState<string[]>([]);

  if (!selectedObject) return null;

  const handleSimulateFunction = (fnName: string) => {
    setExecutingFn(fnName);
    const newLog = `[${new Date().toISOString().substring(11, 19)}] Executed function ${fnName}() -> Verified by Veritas ZK-Fabric in 0.38ms (Proof Root #89FA)`;
    setTimeout(() => {
      setFnLogs((prev) => [newLog, ...prev]);
      setExecutingFn(null);
    }, 600);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 12 }}
          transition={{ type: 'spring', stiffness: 320, damping: 28 }}
          className="w-full max-w-4xl bg-[#111418] border border-[#323A44] rounded-sm shadow-2xl overflow-hidden flex flex-col max-h-[88vh]"
        >
          {/* Top Bar with Morph Level Steps */}
          <div className="p-3 hairline-b flex items-center justify-between bg-neutral-950/80">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-[#9C88FF]" />
              <div>
                <span className="text-[10px] font-mono-tech text-neutral-400 uppercase">
                  Web3 Spatial Object Inspector
                </span>
                <h3 className="text-sm font-semibold text-neutral-100">{selectedObject.name}</h3>
              </div>
            </div>

            {/* Level Morphing Controls */}
            <div className="flex items-center gap-1 bg-[#181D22] p-1 rounded border border-neutral-800 text-[10px] font-mono-tech">
              <span className="text-neutral-400 px-1">Morph Level:</span>
              {([1, 2, 3, 4] as const).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setObjectMorphLevel(lvl)}
                  className={`px-2 py-0.5 rounded transition-colors ${
                    objectMorphLevel === lvl
                      ? 'bg-[#4D8BC4] text-white font-bold'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
                  }`}
                >
                  {lvl === 1 ? 'Overview' : lvl === 2 ? 'Architecture' : lvl === 3 ? 'Functions' : 'Telemetry'}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setSelectedObject(null)}
              className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Morph Body Views */}
          <div className="p-5 overflow-y-auto flex-1 space-y-4 text-xs font-mono-tech">
            {/* LEVEL 1: OVERVIEW & FINGERPRINT */}
            {objectMorphLevel === 1 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="p-3 rounded border border-neutral-800 bg-neutral-900/60">
                    <div className="text-[10px] text-neutral-500 uppercase">Object Identifier</div>
                    <div className="text-neutral-200 font-semibold truncate">{selectedObject.identifier}</div>
                  </div>
                  <div className="p-3 rounded border border-neutral-800 bg-neutral-900/60">
                    <div className="text-[10px] text-neutral-500 uppercase">Native Network</div>
                    <div className="text-[#4D8BC4] font-semibold">{selectedObject.networkName}</div>
                  </div>
                  <div className="p-3 rounded border border-neutral-800 bg-neutral-900/60">
                    <div className="text-[10px] text-neutral-500 uppercase">Cryptographic State</div>
                    <div className="text-[#58A878] font-semibold uppercase flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> {selectedObject.state}
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded border border-neutral-800 bg-[#14181E]">
                  <div className="text-[10px] text-neutral-500 uppercase mb-1">Description & Purpose</div>
                  <p className="text-neutral-300 font-sans text-xs leading-relaxed">{selectedObject.description}</p>
                </div>

                {/* Metadata Fields */}
                <div className="p-3 rounded border border-neutral-800 bg-neutral-900/40">
                  <div className="text-[10px] text-neutral-400 uppercase mb-2">Cryptographic Metadata</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                    {selectedObject.metadata.map((meta, i) => (
                      <div key={i} className="flex justify-between p-1.5 rounded bg-neutral-950/60 border border-neutral-800">
                        <span className="text-neutral-400">{meta.label}:</span>
                        <span className={meta.highlight ? 'text-[#58A878] font-semibold' : 'text-neutral-200'}>
                          {meta.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* LEVEL 2: SHARD ARCHITECTURE & FORMAL SPECS */}
            {objectMorphLevel === 2 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                <div className="p-4 rounded border border-[#2A3440] bg-[#13181E] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-[#4D8BC4] font-semibold">FORMALLY VERIFIED SHARD ARCHITECTURE</span>
                    <span className="text-[10px] text-neutral-500">RFC-4091 / ZK-WASM Engine</span>
                  </div>

                  {/* Architecture Diagram Visualization */}
                  <div className="p-3 rounded bg-black/60 border border-neutral-800 text-[10px] space-y-2 text-neutral-300">
                    <div className="flex items-center gap-2 text-neutral-400">
                      <span>[Origin Node]</span>
                      <span className="text-neutral-600">────────►</span>
                      <span className="text-[#58A878]">[Hardware Enclave]</span>
                      <span className="text-neutral-600">────────►</span>
                      <span className="text-[#9C88FF]">[Halo2 Proof Engine]</span>
                      <span className="text-neutral-600">────────►</span>
                      <span className="text-[#4D8BC4]">[Veritas Shard Root]</span>
                    </div>
                    <div className="text-[9px] text-neutral-400">
                      State Transition Proof Digest: <span className="text-neutral-300">0x9a8f44...3e2109ab</span> (Verified in 0.38ms)
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px]">
                    <div className="p-2 rounded bg-neutral-900 border border-neutral-800">
                      <div className="text-neutral-500">GAS INDEX</div>
                      <div className="text-neutral-200 font-semibold">{selectedObject.gasIndex || '0.00012 µP'}</div>
                    </div>
                    <div className="p-2 rounded bg-neutral-900 border border-neutral-800">
                      <div className="text-neutral-500">STATE SHARD</div>
                      <div className="text-[#4D8BC4] font-semibold">{selectedObject.shard || 'Shard-04'}</div>
                    </div>
                    <div className="p-2 rounded bg-neutral-900 border border-neutral-800">
                      <div className="text-neutral-500">LATENCY</div>
                      <div className="text-[#58A878] font-semibold">{selectedObject.latency || '1.8ms'}</div>
                    </div>
                    <div className="p-2 rounded bg-neutral-900 border border-neutral-800">
                      <div className="text-neutral-500">ENTROPY RATING</div>
                      <div className="text-neutral-200 font-semibold">{selectedObject.entropy || 0.994}</div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* LEVEL 3: VERIFIABLE FUNCTIONS & PEERS */}
            {objectMorphLevel === 3 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                <div className="space-y-2">
                  <div className="text-[10px] text-neutral-400 uppercase">Available Verifiable Functions</div>
                  {selectedObject.functions && selectedObject.functions.length > 0 ? (
                    selectedObject.functions.map((fn) => (
                      <div
                        key={fn.name}
                        className="p-3 rounded border border-neutral-800 bg-[#13171C] flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-[#4D8BC4]">{fn.name}</span>
                            <span className="text-[9px] px-1 py-0.5 rounded bg-neutral-800 text-neutral-400 uppercase">
                              {fn.type}
                            </span>
                          </div>
                          <div className="text-[10px] text-neutral-500 mt-0.5">
                            Parameters: ({fn.params.join(', ')}) • {fn.invocationsLast24h.toLocaleString()} calls/24h
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={executingFn === fn.name}
                          onClick={() => handleSimulateFunction(fn.name)}
                          className="px-2.5 py-1 rounded bg-[#1C232B] hover:bg-[#252E38] border border-[#323D4A] text-[#58A878] text-[10px] font-medium flex items-center gap-1 transition-all"
                        >
                          {executingFn === fn.name ? (
                            <>
                              <RotateCw className="w-3 h-3 animate-spin" /> Verifying...
                            </>
                          ) : (
                            <>
                              <Play className="w-3 h-3" /> Simulate Call
                            </>
                          )}
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="p-3 text-neutral-500">No external function invocations declared.</div>
                  )}
                </div>

                {/* Function Execution Terminal Output */}
                {fnLogs.length > 0 && (
                  <div className="p-3 rounded bg-black/80 border border-neutral-800 text-[10px] text-[#58A878] space-y-1">
                    <div className="text-neutral-400 flex items-center gap-1 pb-1 hairline-b">
                      <Terminal className="w-3 h-3" /> Execution Proof Log:
                    </div>
                    {fnLogs.map((log, idx) => (
                      <div key={idx}>{log}</div>
                    ))}
                  </div>
                )}

                {/* Multi-Sig Peers */}
                {selectedObject.holdersOrPeers && (
                  <div className="space-y-2">
                    <div className="text-[10px] text-neutral-400 uppercase">Anchor Validator Nodes & Signatories</div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {selectedObject.holdersOrPeers.map((peer) => (
                        <div key={peer.id} className="p-2 rounded bg-neutral-900/80 border border-neutral-800 flex justify-between">
                          <div>
                            <div className="text-neutral-200 font-medium">{peer.name}</div>
                            <div className="text-[9px] text-neutral-500">{peer.role}</div>
                          </div>
                          <span className="text-[10px] text-[#4D8BC4] font-semibold">{peer.share}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* LEVEL 4: LIVE TELEMETRY & EVENT STREAM */}
            {objectMorphLevel === 4 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-neutral-400 uppercase">Live Sensor & Node Event Stream</span>
                  <span className="text-[10px] text-[#58A878] flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-[#58A878] animate-pulse" /> LIVE STREAMING
                  </span>
                </div>

                <div className="p-3 rounded bg-black/80 border border-neutral-800 space-y-2 text-[10px] font-mono-tech max-h-64 overflow-y-auto">
                  {selectedObject.telemetryLogs ? (
                    selectedObject.telemetryLogs.map((log, i) => (
                      <div key={i} className="text-neutral-300">
                        {log}
                      </div>
                    ))
                  ) : (
                    <div className="text-neutral-500">No active telemetry events recorded.</div>
                  )}
                </div>
              </motion.div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="p-3 hairline-t bg-neutral-950/60 flex items-center justify-between text-xs font-mono-tech">
            <div className="text-neutral-400 text-[10px]">
              Object State Anchor: <span className="text-neutral-200">Formal ZK Proof #4092</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  runTxSimulation();
                  setSelectedObject(null);
                }}
                className="px-3 py-1.5 rounded bg-[#4D8BC4] text-white hover:bg-[#3B7BB4] transition-colors font-medium flex items-center gap-1"
              >
                <Play className="w-3.5 h-3.5" /> Simulate Packet Flight
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
