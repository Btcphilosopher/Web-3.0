'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import { Box, CheckCircle2, ChevronRight, Shield, Layers } from 'lucide-react';

export function SFObjectPreview() {
  const { hoveredObject, hoverPos, setSelectedObject, setObjectMorphLevel, setHoveredObject } = useBrowser();

  if (!hoveredObject || !hoverPos) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 4 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 4 }}
        transition={{ duration: 0.12 }}
        style={{
          position: 'fixed',
          left: Math.min(window.innerWidth - 300, Math.max(16, hoverPos.x - 140)),
          top: Math.min(window.innerHeight - 200, hoverPos.y + 24),
          zIndex: 999,
        }}
        className="w-72 p-3 rounded bg-[#101418] border border-[#36404D] shadow-2xl backdrop-blur-md text-xs pointer-events-auto"
        onMouseEnter={() => {}}
        onMouseLeave={() => setHoveredObject(null)}
      >
        {/* Header Badge */}
        <div className="flex items-center justify-between pb-1.5 mb-1.5 hairline-b text-[10px] font-mono-tech">
          <span className="uppercase text-[#9C88FF] flex items-center gap-1 font-semibold">
            <Box className="w-3 h-3" /> {hoveredObject.type}
          </span>
          <span className="text-[#58A878] flex items-center gap-0.5">
            <CheckCircle2 className="w-3 h-3" /> {hoveredObject.state}
          </span>
        </div>

        {/* Title & Identifier */}
        <h4 className="font-semibold text-neutral-100 text-xs mb-1">{hoveredObject.name}</h4>
        <div className="font-mono-tech text-[10px] text-neutral-400 mb-2 truncate">
          {hoveredObject.identifier}
        </div>

        {/* Shard & Network Details */}
        <div className="p-1.5 rounded bg-neutral-900/90 border border-neutral-800 text-[10px] font-mono-tech space-y-1 mb-2 text-neutral-300">
          <div className="flex justify-between">
            <span className="text-neutral-500">Network:</span>
            <span className="text-neutral-200">{hoveredObject.networkName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-neutral-500">Protocol:</span>
            <span className="text-neutral-200">{hoveredObject.protocol}</span>
          </div>
          {hoveredObject.shard && (
            <div className="flex justify-between">
              <span className="text-neutral-500">State Shard:</span>
              <span className="text-[#4D8BC4]">{hoveredObject.shard}</span>
            </div>
          )}
        </div>

        {/* Open Full Object Button */}
        <button
          type="button"
          onClick={() => {
            setSelectedObject(hoveredObject);
            setObjectMorphLevel(2);
            setHoveredObject(null);
          }}
          className="w-full py-1 px-2 rounded bg-[#181E24] hover:bg-[#202730] border border-[#2E3844] hover:border-[#4D8BC4] text-[#4D8BC4] text-[10px] font-mono-tech font-medium flex items-center justify-center gap-1 transition-all"
        >
          <span>MORPH INTO DEEP INSPECTION</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </motion.div>
    </AnimatePresence>
  );
}
