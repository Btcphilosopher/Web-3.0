'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import {
  Search,
  Command,
  Layers,
  Box,
  Compass,
  Sliders,
  Sparkles,
  Zap,
  Globe,
  Sun,
  Moon,
  Maximize2,
  X,
} from 'lucide-react';

export function SFCommandPalette() {
  const {
    commandPaletteOpen,
    setCommandPaletteOpen,
    setMode,
    theme,
    setTheme,
    density,
    setDensity,
    startDemoJourney,
    openNewTab,
    navigateTab,
    activeTabId,
    allObjects,
    allNetworks,
    setSelectedObject,
    setObjectMorphLevel,
    setSelectedNetwork,
    toggleContextPanel,
  } = useBrowser();

  const [search, setSearch] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (commandPaletteOpen) {
      inputRef.current?.focus();
    }
  }, [commandPaletteOpen]);

  if (!commandPaletteOpen) return null;

  interface CommandOption {
    id: string;
    title: string;
    category: string;
    icon: React.ReactNode;
    action: () => void;
  }

  const commands: CommandOption[] = [
    {
      id: 'cmd-demo',
      title: 'Run Scripted Guided Visual Journey (10 Steps)',
      category: 'Simulations',
      icon: <Sparkles className="w-3.5 h-3.5 text-[#D99F44]" />,
      action: () => {
        setCommandPaletteOpen(false);
        startDemoJourney();
      },
    },
    {
      id: 'cmd-map',
      title: 'Open Spatial Internet Cartography Map',
      category: 'Navigation',
      icon: <Compass className="w-3.5 h-3.5 text-[#4D8BC4]" />,
      action: () => {
        setCommandPaletteOpen(false);
        setMode('map');
      },
    },
    {
      id: 'cmd-observatory',
      title: 'Open Fullscreen Immersive Observatory',
      category: 'Navigation',
      icon: <Maximize2 className="w-3.5 h-3.5 text-[#58A878]" />,
      action: () => {
        setCommandPaletteOpen(false);
        setMode('observatory');
      },
    },
    {
      id: 'cmd-context',
      title: 'Toggle Web3 Context Layer Panel',
      category: 'Inspection',
      icon: <Sliders className="w-3.5 h-3.5 text-[#48DBFB]" />,
      action: () => {
        setCommandPaletteOpen(false);
        toggleContextPanel();
      },
    },
    {
      id: 'cmd-theme-obsidian',
      title: 'Set Material Theme: Obsidian (Aerospace Dark)',
      category: 'Appearance',
      icon: <Moon className="w-3.5 h-3.5 text-neutral-400" />,
      action: () => {
        setTheme('obsidian');
        setCommandPaletteOpen(false);
      },
    },
    {
      id: 'cmd-theme-archive',
      title: 'Set Material Theme: Archive (Drafting Light)',
      category: 'Appearance',
      icon: <Sun className="w-3.5 h-3.5 text-[#D99F44]" />,
      action: () => {
        setTheme('archive');
        setCommandPaletteOpen(false);
      },
    },
    {
      id: 'cmd-density-eng',
      title: 'Set Information Density: Engineering',
      category: 'Layout',
      icon: <Layers className="w-3.5 h-3.5 text-[#9C88FF]" />,
      action: () => {
        setDensity('engineering');
        setCommandPaletteOpen(false);
      },
    },
    ...allObjects.map((obj) => ({
      id: `cmd-obj-${obj.id}`,
      title: `Inspect Object: ${obj.name} (${obj.identifier})`,
      category: 'Decentralized Objects',
      icon: <Box className="w-3.5 h-3.5 text-[#9C88FF]" />,
      action: () => {
        setSelectedObject(obj);
        setObjectMorphLevel(2);
        setCommandPaletteOpen(false);
      },
    })),
    ...allNetworks.map((net) => ({
      id: `cmd-net-${net.id}`,
      title: `Connect Subnet: ${net.name} (${net.region})`,
      category: 'Networks',
      icon: <Layers className="w-3.5 h-3.5 text-[#48DBFB]" />,
      action: () => {
        setSelectedNetwork(net);
        setMode('map');
        setCommandPaletteOpen(false);
      },
    })),
  ];

  const filtered = commands.filter(
    (c) =>
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/75 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: -8 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: -8 }}
          transition={{ duration: 0.15 }}
          className="w-full max-w-2xl bg-[#111418] border border-[#323A44] rounded-sm shadow-2xl overflow-hidden flex flex-col font-mono-tech"
        >
          {/* Top Search Input */}
          <div className="p-3 hairline-b flex items-center gap-2 bg-[#0E1114]">
            <Search className="w-4 h-4 text-neutral-400" />
            <input
              ref={inputRef}
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Type an architectural command, network, or object..."
              className="w-full bg-transparent text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setCommandPaletteOpen(false)}
              className="p-1 rounded hover:bg-neutral-800 text-neutral-400"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Commands List */}
          <div className="max-h-80 overflow-y-auto p-2 space-y-1">
            {filtered.length === 0 ? (
              <div className="p-4 text-center text-xs text-neutral-500">
                No matching architectural commands found.
              </div>
            ) : (
              filtered.map((cmd, idx) => (
                <div
                  key={cmd.id}
                  onClick={cmd.action}
                  className="flex items-center justify-between p-2 rounded hover:bg-[#181D24] cursor-pointer group text-xs transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    {cmd.icon}
                    <span className="text-neutral-200 group-hover:text-white font-medium">
                      {cmd.title}
                    </span>
                  </div>
                  <span className="text-[10px] text-neutral-500 uppercase">{cmd.category}</span>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="p-2.5 hairline-t bg-neutral-950/80 flex items-center justify-between text-[10px] text-neutral-500">
            <span>Navigation: Click or Enter</span>
            <span>ESC to dismiss console</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
