'use client';

import React from 'react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import { SFStartPage } from '@/components/browser/SFStartPage';
import {
  ShieldCheck,
  Box,
  Layers,
  ChevronRight,
  ExternalLink,
  Code,
  Terminal,
  Activity,
  CheckCircle2,
} from 'lucide-react';

export function SFWebPageContent() {
  const {
    activePage,
    activeTab,
    setHoveredObject,
    setHoverPos,
    setSelectedObject,
    setObjectMorphLevel,
    allObjects,
  } = useBrowser();

  // If start page / observatory mesh is loaded or no specific page found
  if (!activePage || activeTab.url === 'aether://observatory.mesh' || activeTab.pageId === 'page-observatory') {
    return <SFStartPage />;
  }

  return (
    <div
      id="sf-web-page-viewport"
      className="w-full h-full overflow-y-auto p-6 md:p-10 bg-[#0C0E11] text-neutral-200 select-text"
    >
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Page Top Header with Badge */}
        <div className="space-y-2 pb-6 hairline-b">
          <div className="flex items-center gap-2 text-xs font-mono-tech">
            <span className="px-2 py-0.5 rounded bg-[#4D8BC4]/15 border border-[#4D8BC4]/40 text-[#4D8BC4] font-semibold text-[10px]">
              {activePage.badge}
            </span>
            <span className="text-neutral-500">•</span>
            <span className="text-neutral-400">{activePage.category}</span>
          </div>

          <h1 className="text-2xl md:text-3xl font-serif-display font-normal text-neutral-100 tracking-tight">
            {activePage.content.heroHeading}
          </h1>

          <p className="text-sm font-sans text-neutral-400 max-w-2xl leading-relaxed">
            {activePage.content.leadText}
          </p>
        </div>

        {/* Live Telemetry Metric Blocks */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono-tech">
          {activePage.content.stats.map((st, idx) => (
            <div
              key={idx}
              className="p-3 rounded border border-neutral-800 bg-[#12161B]/90 space-y-1"
            >
              <div className="text-[10px] text-neutral-500 uppercase">{st.label}</div>
              <div className="text-lg font-bold text-neutral-100 flex items-baseline gap-1">
                <span>{st.value}</span>
                {st.unit && <span className="text-xs text-neutral-400 font-normal">{st.unit}</span>}
              </div>
            </div>
          ))}
        </div>

        {/* Content Sections with Embedded Web3 Objects */}
        <div className="space-y-6">
          {activePage.content.sections.map((sec, idx) => {
            const linkedObject = sec.verifiedObjectLink
              ? allObjects.find((o) => o.id === sec.verifiedObjectLink)
              : null;

            return (
              <div
                key={idx}
                className="p-5 rounded border border-[#222A34] bg-[#101418] space-y-3 font-sans"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-neutral-100 font-serif-display">
                    {sec.title}
                  </h3>
                  {linkedObject && (
                    <span className="flex items-center gap-1 text-[10px] font-mono-tech text-[#58A878]">
                      <ShieldCheck className="w-3.5 h-3.5" /> FORMAL ZK-VERIFIED
                    </span>
                  )}
                </div>

                <p className="text-xs md:text-sm text-neutral-300 leading-relaxed">{sec.body}</p>

                {/* Code snippet if present */}
                {sec.codeSnippet && (
                  <div className="p-3 rounded bg-black/80 border border-neutral-800 font-mono-tech text-xs text-[#58A878] space-y-1">
                    <div className="text-neutral-500 text-[10px] flex items-center gap-1">
                      <Code className="w-3 h-3" /> Hardware Verified Snippet
                    </div>
                    <pre className="overflow-x-auto whitespace-pre-wrap">{sec.codeSnippet}</pre>
                  </div>
                )}

                {/* Embedded Web3 Object Highlight Card */}
                {linkedObject && (
                  <div
                    onMouseEnter={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      setHoverPos({ x: rect.left + rect.width / 2, y: rect.bottom });
                      setHoveredObject(linkedObject);
                    }}
                    onClick={() => {
                      setSelectedObject(linkedObject);
                      setObjectMorphLevel(2);
                    }}
                    className="p-3 rounded border border-[#2E3946] bg-[#141A22] hover:border-[#4D8BC4] hover:bg-[#18202A] cursor-pointer transition-all flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-2.5 font-mono-tech">
                      <Box className="w-4 h-4 text-[#9C88FF]" />
                      <div>
                        <div className="text-xs font-semibold text-neutral-100 group-hover:text-[#4D8BC4] transition-colors">
                          {linkedObject.name}
                        </div>
                        <div className="text-[10px] text-neutral-400">
                          {linkedObject.identifier} • {linkedObject.networkName}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#4D8BC4]">
                      <span>Hover for Preview / Click to Morph</span>
                      <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
