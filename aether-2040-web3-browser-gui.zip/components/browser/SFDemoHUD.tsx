'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import { Sparkles, X, Play, RotateCcw, CheckCircle2 } from 'lucide-react';

export function SFDemoHUD() {
  const { isDemoRunning, demoStep, demoStepText, stopDemoJourney, startDemoJourney } = useBrowser();

  if (!isDemoRunning && demoStep === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -50, opacity: 0 }}
        className="fixed top-2 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-[#12161B]/95 border border-[#4D8BC4] shadow-2xl backdrop-blur-md flex items-center gap-3 text-xs font-mono-tech select-none"
      >
        <div className="flex items-center gap-2 text-[#D99F44]">
          <Sparkles className="w-4 h-4 animate-spin" />
          <span className="font-bold">GUIDED DEMO:</span>
        </div>

        <span className="text-neutral-200 max-w-md truncate">{demoStepText}</span>

        <div className="flex items-center gap-1">
          <span className="px-2 py-0.5 rounded bg-neutral-800 text-[10px] text-neutral-400">
            {demoStep} / 10
          </span>
          <button
            type="button"
            onClick={stopDemoJourney}
            className="p-1 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
            title="Exit Demo"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
