'use client';

import React, { useState } from 'react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import { SFTabsRow } from '@/components/tabs/SFTabsRow';
import { SFBar } from '@/components/navigation/SFBar';
import { SFWebPageContent } from '@/components/browser/SFWebPageContent';
import { SFNetworkMap } from '@/components/maps/SFNetworkMap';
import { SFObservatoryMode } from '@/components/browser/SFObservatoryMode';
import { SFContextPanel } from '@/components/panels/SFContextPanel';
import { SFObjectPreview } from '@/components/objects/SFObjectPreview';
import { SFObjectInspectorModal } from '@/components/objects/SFObjectInspectorModal';
import { SFTransactionFlightSimulator } from '@/components/activity/SFTransactionFlightSimulator';
import { SFCommandPalette } from '@/components/browser/SFCommandPalette';
import { SFSettingsDrawer } from '@/components/browser/SFSettingsDrawer';
import { SFDemoHUD } from '@/components/browser/SFDemoHUD';
import {
  Globe,
  Layers,
  Compass,
  Maximize2,
  Sliders,
  Sparkles,
  UserCheck,
  ShieldCheck,
  Cpu,
  Activity,
  Terminal,
  Radio,
} from 'lucide-react';

export function SFBrowserChrome() {
  const {
    mode,
    setMode,
    theme,
    density,
    selectedNetwork,
    startDemoJourney,
    setCommandPaletteOpen,
    toggleContextPanel,
    activeTab,
  } = useBrowser();

  const [settingsOpen, setSettingsOpen] = useState<boolean>(false);

  return (
    <div
      id="sf-browser-root"
      className={`relative w-screen h-screen flex flex-col bg-[#0B0D0E] text-neutral-100 overflow-hidden ${
        theme === 'archive' ? 'theme-archive' : ''
      }`}
    >
      {/* 1. TOP WINDOW TITLEBAR & SYSTEM CONTROLS */}
      <header
        id="sf-browser-titlebar"
        className="flex items-center justify-between px-3 py-1.5 hairline-b bg-[#090B0D] select-none text-[11px] font-mono-tech z-40"
      >
        {/* Left: Aerospace Window Controls & Brand */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#C85252] border border-[#C85252]/40" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#D99F44] border border-[#D99F44]/40" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#58A878] border border-[#58A878]/40" />
          </div>
          <div className="flex items-center gap-2 pl-2 hairline-l text-neutral-400">
            <span className="font-bold tracking-widest text-neutral-200">AETHER</span>
            <span className="text-[9px] px-1 py-0.2 rounded bg-neutral-800 text-neutral-400">2040 GUI</span>
          </div>
        </div>

        {/* Center: Mode Switcher (Browse, Map, Observatory) */}
        <div className="flex items-center gap-1 p-0.5 rounded bg-[#13171C] border border-[#262E38] text-[10px]">
          <button
            type="button"
            onClick={() => setMode('browse')}
            className={`flex items-center gap-1 px-2.5 py-0.5 rounded transition-all ${
              mode === 'browse'
                ? 'bg-[#4D8BC4] text-white font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Globe className="w-3 h-3" />
            <span>BROWSE</span>
          </button>
          <button
            type="button"
            onClick={() => setMode('map')}
            className={`flex items-center gap-1 px-2.5 py-0.5 rounded transition-all ${
              mode === 'map'
                ? 'bg-[#4D8BC4] text-white font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Compass className="w-3 h-3" />
            <span>MAP</span>
          </button>
          <button
            type="button"
            onClick={() => setMode('observatory')}
            className={`flex items-center gap-1 px-2.5 py-0.5 rounded transition-all ${
              mode === 'observatory'
                ? 'bg-[#4D8BC4] text-white font-semibold shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Maximize2 className="w-3 h-3" />
            <span>OBSERVATORY</span>
          </button>
        </div>

        {/* Right: Quick Triggers (Demo Journey, Settings) */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={startDemoJourney}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#D99F44]/15 border border-[#D99F44]/40 text-[#D99F44] hover:bg-[#D99F44]/25 transition-colors text-[10px] font-semibold"
            title="Start Guided Visual Scenario"
          >
            <Sparkles className="w-3 h-3" />
            <span>RUN DEMO</span>
          </button>

          <button
            type="button"
            onClick={() => setSettingsOpen(true)}
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
            title="Open Environment Settings"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* 2. TABS ROW (In browse mode) */}
      {mode !== 'observatory' && <SFTabsRow />}

      {/* 3. NAVIGATION & BAR (In browse mode) */}
      {mode !== 'observatory' && <SFBar />}

      {/* 4. MAIN VIEWPORT AREA */}
      <main className="relative flex-1 w-full h-full overflow-hidden">
        {mode === 'browse' && <SFWebPageContent />}
        {mode === 'map' && <SFNetworkMap />}
        {mode === 'observatory' && <SFObservatoryMode />}

        {/* Retractable Sliding Context Layer */}
        <SFContextPanel />

        {/* Hover Tooltip Instrument */}
        <SFObjectPreview />

        {/* Deep Object Morphing Modal */}
        <SFObjectInspectorModal />

        {/* Live Transaction Flight Simulator */}
        <SFTransactionFlightSimulator />

        {/* Architectural Command Console (Cmd+K) */}
        <SFCommandPalette />

        {/* Environment Settings Drawer */}
        <SFSettingsDrawer isOpen={settingsOpen} onClose={() => setSettingsOpen(false)} />

        {/* Guided Demo Narration HUD */}
        <SFDemoHUD />
      </main>

      {/* 5. BOTTOM STATUS TELEMETRY BAR */}
      <footer
        id="sf-browser-statusbar"
        className="flex items-center justify-between px-3 py-1 hairline-t bg-[#080A0C] text-[10px] font-mono-tech text-neutral-400 z-30 select-none"
      >
        <div className="flex items-center gap-4">
          {/* Active Subnet */}
          <button
            type="button"
            onClick={() => setMode('map')}
            className="flex items-center gap-1 hover:text-neutral-200 transition-colors"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#58A878]" />
            <span className="text-neutral-300 font-semibold">{selectedNetwork?.name || 'Aether-4 Subnet'}</span>
            <span className="text-neutral-500">({selectedNetwork?.latencyMs || '3.2'}ms)</span>
          </button>

          {/* Sovereign Identity */}
          <button
            type="button"
            onClick={() => toggleContextPanel('identity')}
            className="hidden sm:flex items-center gap-1 hover:text-neutral-200 transition-colors"
          >
            <UserCheck className="w-3 h-3 text-[#58A878]" />
            <span className="text-neutral-300">Dr. Eleanor Vane</span>
            <span className="text-[9px] text-[#58A878]">VERIFIED</span>
          </button>

          {/* Proofs Engine */}
          <div className="hidden md:flex items-center gap-1 text-neutral-500">
            <ShieldCheck className="w-3 h-3 text-[#4D8BC4]" />
            <span>Halo2 SNARK Assembler</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-1 text-neutral-500">
            <Cpu className="w-3 h-3" />
            <span>WebGPU 60 FPS</span>
          </div>
          <div className="text-neutral-500">
            Density: <span className="text-neutral-300 uppercase">{density}</span>
          </div>
          <button
            type="button"
            onClick={() => setCommandPaletteOpen(true)}
            className="text-neutral-400 hover:text-neutral-200 hover:underline"
          >
            Press ⌘K
          </button>
        </div>
      </footer>
    </div>
  );
}
