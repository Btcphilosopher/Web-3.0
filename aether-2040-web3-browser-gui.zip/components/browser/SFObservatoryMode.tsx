'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import {
  Globe,
  Radio,
  Cpu,
  Layers,
  Activity,
  Box,
  ChevronLeft,
  Sparkles,
  Maximize2,
  Terminal,
} from 'lucide-react';

export function SFObservatoryMode() {
  const { setMode, allNetworks, allObjects, transactions, setSelectedObject, setObjectMorphLevel } = useBrowser();
  const [activeShardIndex, setActiveShardIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveShardIndex((prev) => (prev + 1) % allNetworks.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [allNetworks.length]);

  return (
    <div id="sf-observatory-fullscreen" className="relative w-full h-full bg-[#06080A] text-neutral-200 overflow-hidden flex flex-col p-6 select-none">
      {/* Top Telemetry Bar */}
      <div className="flex items-center justify-between pb-4 hairline-b z-20">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-[#4D8BC4] animate-ping" />
          <div>
            <div className="text-[10px] font-mono-tech text-neutral-400 uppercase tracking-widest">
              Aether 2040 Immersive Visual Operating Environment
            </div>
            <h1 className="text-base font-bold font-mono-tech text-neutral-100 tracking-tight">
              SPATIAL INTERNET OBSERVATORY & STATE MESH
            </h1>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setMode('browse')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#15191E] border border-[#2E3742] hover:border-[#4D8BC4] text-xs font-mono-tech text-neutral-200 hover:text-white transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Exit Observatory (Browse Mode)</span>
        </button>
      </div>

      {/* Main Multi-Matrix Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 pt-6 overflow-y-auto z-10 font-mono-tech">
        {/* Panel 1: Global Shard Matrix */}
        <div className="p-4 rounded border border-[#222A34] bg-[#0C0F13]/90 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 text-[10px] text-neutral-400 uppercase">
              <span className="flex items-center gap-1.5 font-semibold text-[#48DBFB]">
                <Layers className="w-3.5 h-3.5" /> Subnet Mesh Topology
              </span>
              <span>6 Tiers Online</span>
            </div>

            <div className="space-y-2">
              {allNetworks.map((net, idx) => (
                <div
                  key={net.id}
                  className={`p-2.5 rounded border transition-all ${
                    idx === activeShardIndex
                      ? 'border-[#4D8BC4] bg-[#141C24] text-neutral-100'
                      : 'border-neutral-800/80 bg-neutral-900/40 text-neutral-400'
                  }`}
                >
                  <div className="flex justify-between text-xs font-medium">
                    <span>{net.name}</span>
                    <span className="text-[#58A878]">{net.latencyMs}ms</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-neutral-500 mt-1">
                    <span>{net.region}</span>
                    <span>{net.tps.toLocaleString()} TPS</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 hairline-t text-[10px] text-neutral-400">
            Total Consensus Throughput: <span className="text-[#58A878] font-bold">2,621,500 TPS</span>
          </div>
        </div>

        {/* Panel 2: Verifiable Autonomous Objects Radar */}
        <div className="p-4 rounded border border-[#222A34] bg-[#0C0F13]/90 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 text-[10px] text-neutral-400 uppercase">
              <span className="flex items-center gap-1.5 font-semibold text-[#9C88FF]">
                <Box className="w-3.5 h-3.5" /> Autonomous Object Registry
              </span>
              <span>Zero-Knowledge Validated</span>
            </div>

            <div className="space-y-2">
              {allObjects.map((obj) => (
                <div
                  key={obj.id}
                  onClick={() => {
                    setSelectedObject(obj);
                    setObjectMorphLevel(2);
                  }}
                  className="p-2.5 rounded border border-neutral-800 bg-neutral-900/40 hover:border-[#9C88FF] hover:bg-[#161720] cursor-pointer transition-all"
                >
                  <div className="flex justify-between text-xs font-medium text-neutral-200">
                    <span className="truncate max-w-[180px]">{obj.name}</span>
                    <span className="text-[10px] text-[#9C88FF] uppercase">{obj.type}</span>
                  </div>
                  <div className="text-[10px] text-neutral-500 mt-0.5 truncate">{obj.identifier}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 hairline-t text-[10px] text-neutral-400">
            Click any object to trigger <span className="text-[#9C88FF]">Spatial Morphing</span>.
          </div>
        </div>

        {/* Panel 3: Live Hardware Flight Telemetry Stream */}
        <div className="p-4 rounded border border-[#222A34] bg-[#0C0F13]/90 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 text-[10px] text-neutral-400 uppercase">
              <span className="flex items-center gap-1.5 font-semibold text-[#58A878]">
                <Activity className="w-3.5 h-3.5" /> Global Proof Pipeline
              </span>
              <span className="flex items-center gap-1 text-[#58A878]">
                <span className="w-2 h-2 rounded-full bg-[#58A878] animate-pulse" /> LIVE
              </span>
            </div>

            <div className="space-y-2 max-h-[380px] overflow-y-auto">
              {transactions.slice(0, 6).map((tx) => (
                <div key={tx.id} className="p-2.5 rounded border border-neutral-800/80 bg-neutral-950/60 text-[10px] space-y-1">
                  <div className="flex justify-between text-neutral-200">
                    <span className="font-semibold text-[#4D8BC4]">{tx.toName}</span>
                    <span className="text-[#58A878]">{tx.value}</span>
                  </div>
                  <div className="flex justify-between text-neutral-500 text-[9px]">
                    <span>{tx.fromName}</span>
                    <span>{tx.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 hairline-t text-[10px] text-neutral-400 flex justify-between">
            <span>Proof Engine: Halo2 SNARK</span>
            <span className="text-[#58A878]">0.4ms Mean Finality</span>
          </div>
        </div>
      </div>
    </div>
  );
}
