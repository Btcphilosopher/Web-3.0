'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import { ThemeMode, DensityMode, MotionMode } from '@/styles/tokens';
import { X, Sliders, Moon, Sun, Cpu, Eye, Activity, ShieldCheck } from 'lucide-react';

export function SFSettingsDrawer({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const { theme, setTheme, density, setDensity, motionMode, setMotionMode } = useBrowser();

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ x: 360, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 360, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 340, damping: 30 }}
          className="w-80 md:w-96 bg-[#111418] border-l border-[#323A44] shadow-2xl p-5 flex flex-col justify-between font-mono-tech text-xs"
        >
          {/* Header */}
          <div>
            <div className="flex items-center justify-between pb-3 hairline-b mb-4">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#4D8BC4]" />
                <h3 className="font-semibold text-neutral-100 text-sm">ENVIRONMENT SETTINGS</h3>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* THEME PRESET */}
            <div className="mb-5 space-y-2">
              <div className="text-[10px] text-neutral-400 uppercase">Material Theme Preset</div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTheme('obsidian')}
                  className={`p-2.5 rounded border text-left flex items-center gap-2 transition-all ${
                    theme === 'obsidian'
                      ? 'border-[#4D8BC4] bg-[#161D24] text-neutral-100 font-bold'
                      : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Moon className="w-4 h-4 text-[#4D8BC4]" />
                  <div>
                    <div>Obsidian</div>
                    <div className="text-[9px] text-neutral-500 font-normal">Aerospace Dark</div>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setTheme('archive')}
                  className={`p-2.5 rounded border text-left flex items-center gap-2 transition-all ${
                    theme === 'archive'
                      ? 'border-[#D99F44] bg-[#1E1B15] text-[#D99F44] font-bold'
                      : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Sun className="w-4 h-4 text-[#D99F44]" />
                  <div>
                    <div>Archive</div>
                    <div className="text-[9px] text-neutral-500 font-normal">Technical Light</div>
                  </div>
                </button>
              </div>
            </div>

            {/* INFORMATION DENSITY */}
            <div className="mb-5 space-y-2">
              <div className="text-[10px] text-neutral-400 uppercase">Information Density</div>
              <div className="grid grid-cols-2 gap-1.5">
                {(['minimal', 'standard', 'dense', 'engineering'] as const).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setDensity(mode)}
                    className={`p-2 rounded border text-left transition-all ${
                      density === mode
                        ? 'border-[#58A878] bg-[#131E17] text-[#58A878] font-bold'
                        : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <div className="capitalize">{mode}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* MOTION ACCESSIBILITY */}
            <div className="mb-5 space-y-2">
              <div className="text-[10px] text-neutral-400 uppercase">Kotlin Motion Engine</div>
              <div className="grid grid-cols-3 gap-1.5 text-[10px]">
                {(['full', 'reduced', 'minimal'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMotionMode(m)}
                    className={`p-2 rounded border text-center transition-all ${
                      motionMode === m
                        ? 'border-[#9C88FF] bg-[#181622] text-[#9C88FF] font-bold'
                        : 'border-neutral-800 bg-neutral-900/60 text-neutral-400'
                    }`}
                  >
                    <div className="capitalize">{m}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* GPU ACCELERATION TELEMETRY */}
            <div className="p-3 rounded border border-neutral-800 bg-black/40 space-y-2 text-[10px]">
              <div className="flex items-center justify-between text-neutral-400">
                <span className="flex items-center gap-1">
                  <Cpu className="w-3.5 h-3.5 text-[#58A878]" /> WebGPU Topology Renderer
                </span>
                <span className="text-[#58A878]">60 FPS Active</span>
              </div>
              <div className="text-neutral-500 text-[9px]">
                Hardware accelerated spatial vector rasterizer enabled. Zero memory leak state loop.
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-3 hairline-t text-[10px] text-neutral-500 text-center">
            Aether 2040 Visual Operating Environment • v4.0.91
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
