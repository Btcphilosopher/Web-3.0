'use client';

import React, { useState } from 'react';
import { useBrowser } from '@/lib/visual-state/browser-store';
import {
  Search,
  Layers,
  Box,
  Compass,
  Sparkles,
  ArrowRight,
  Globe,
  Radio,
  Clock,
  ShieldCheck,
  Cpu,
} from 'lucide-react';

export function SFStartPage() {
  const {
    executeResolvedQuery,
    allNetworks,
    allObjects,
    bookmarks,
    startDemoJourney,
    setMode,
    setSelectedObject,
    setObjectMorphLevel,
  } = useBrowser();

  const [inputVal, setInputVal] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputVal.trim()) {
      executeResolvedQuery(inputVal.trim());
    }
  };

  return (
    <div
      id="sf-start-page-observatory"
      className="w-full h-full flex flex-col items-center justify-between p-6 md:p-12 overflow-y-auto bg-tech-grid relative select-none"
    >
      {/* Top Ambient Telemetry */}
      <div className="w-full max-w-4xl flex items-center justify-between text-[10px] font-mono-tech text-neutral-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#58A878] animate-pulse" />
          <span>SPATIAL INTERNET OBSERVATORY 2040</span>
        </div>
        <div className="flex items-center gap-3">
          <span>CONSENSUS: ASYNC-BFT</span>
          <span>LATENCY: 1.4ms</span>
          <button
            type="button"
            onClick={startDemoJourney}
            className="flex items-center gap-1 text-[#D99F44] hover:underline font-semibold"
          >
            <Sparkles className="w-3 h-3" /> Run Guided Demo Journey
          </button>
        </div>
      </div>

      {/* Center Search Console */}
      <div className="w-full max-w-2xl text-center space-y-6 my-auto">
        <div className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-light tracking-tight font-serif-display text-neutral-100">
            Aether Operating Environment
          </h1>
          <p className="text-xs md:text-sm font-mono-tech text-neutral-400 max-w-md mx-auto">
            Navigating autonomous networks, spatial coordinates, and decentralized objects.
          </p>
        </div>

        {/* Central Search Form */}
        <form onSubmit={handleSearchSubmit} className="w-full">
          <div className="relative flex items-center bg-[#13171C] border border-[#2E3744] hover:border-[#4D8BC4] focus-within:border-[#4D8BC4] rounded-sm p-1.5 shadow-2xl transition-all">
            <Search className="w-4 h-4 text-neutral-400 ml-2 mr-2 flex-shrink-0" />
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Search Web, Resolve Object ID, Contract, or Network Mesh..."
              className="w-full bg-transparent text-xs md:text-sm font-mono-tech text-neutral-100 placeholder-neutral-500 focus:outline-none"
            />
            <button
              type="submit"
              className="px-3 py-1.5 rounded bg-[#1C232B] hover:bg-[#4D8BC4] hover:text-white text-neutral-300 text-xs font-mono-tech transition-colors flex items-center gap-1 flex-shrink-0 border border-neutral-700/60"
            >
              <span>RESOLVE</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>

        {/* Quick Launch Chips */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-[11px] font-mono-tech">
          <span className="text-neutral-500 text-[10px] uppercase">Quick Targets:</span>
          <button
            type="button"
            onClick={() => executeResolvedQuery('oxford.quantum.lab')}
            className="px-2.5 py-1 rounded bg-[#101418] border border-neutral-800 hover:border-[#4D8BC4] text-neutral-300 hover:text-white transition-colors"
          >
            oxford.quantum.lab
          </button>
          <button
            type="button"
            onClick={() => executeResolvedQuery('0x7F9A...88E1')}
            className="px-2.5 py-1 rounded bg-[#101418] border border-neutral-800 hover:border-[#9C88FF] text-neutral-300 hover:text-white transition-colors"
          >
            0x7F9A...88E1 (Optics Allocator)
          </button>
          <button
            type="button"
            onClick={() => setMode('map')}
            className="px-2.5 py-1 rounded bg-[#101418] border border-neutral-800 hover:border-[#58A878] text-neutral-300 hover:text-white transition-colors flex items-center gap-1"
          >
            <Compass className="w-3 h-3 text-[#58A878]" /> Spatial Map
          </button>
        </div>
      </div>

      {/* Bottom Information Dashboard: Subnets, Objects, & Bookmarks */}
      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 text-xs font-mono-tech">
        {/* Networks */}
        <div className="p-3.5 rounded border border-neutral-800/80 bg-[#0E1114]/90 space-y-2">
          <div className="flex items-center justify-between text-[10px] text-neutral-400 uppercase">
            <span className="flex items-center gap-1 font-semibold text-[#48DBFB]">
              <Layers className="w-3 h-3" /> Active Subnets
            </span>
            <button type="button" onClick={() => setMode('map')} className="text-neutral-400 hover:underline">
              Map →
            </button>
          </div>
          <div className="space-y-1.5">
            {allNetworks.slice(0, 3).map((net) => (
              <div
                key={net.id}
                onClick={() => executeResolvedQuery(net.id)}
                className="flex justify-between p-1.5 rounded hover:bg-neutral-800 cursor-pointer text-neutral-300"
              >
                <span className="truncate max-w-[140px]">{net.name}</span>
                <span className="text-[#58A878] text-[10px]">{net.latencyMs}ms</span>
              </div>
            ))}
          </div>
        </div>

        {/* Verifiable Objects */}
        <div className="p-3.5 rounded border border-neutral-800/80 bg-[#0E1114]/90 space-y-2">
          <div className="flex items-center justify-between text-[10px] text-neutral-400 uppercase">
            <span className="flex items-center gap-1 font-semibold text-[#9C88FF]">
              <Box className="w-3 h-3" /> Verified Objects
            </span>
            <span className="text-neutral-500">{allObjects.length} Total</span>
          </div>
          <div className="space-y-1.5">
            {allObjects.slice(0, 3).map((obj) => (
              <div
                key={obj.id}
                onClick={() => {
                  setSelectedObject(obj);
                  setObjectMorphLevel(2);
                }}
                className="flex justify-between p-1.5 rounded hover:bg-neutral-800 cursor-pointer text-neutral-300"
              >
                <span className="truncate max-w-[140px]">{obj.name}</span>
                <span className="text-[#9C88FF] text-[10px] uppercase">{obj.type}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Bookmarks */}
        <div className="p-3.5 rounded border border-neutral-800/80 bg-[#0E1114]/90 space-y-2">
          <div className="flex items-center justify-between text-[10px] text-neutral-400 uppercase">
            <span className="flex items-center gap-1 font-semibold text-[#D99F44]">
              <Globe className="w-3 h-3" /> Bookmarks Library
            </span>
            <span className="text-neutral-500">{bookmarks.length} Saved</span>
          </div>
          <div className="space-y-1.5">
            {bookmarks.slice(0, 3).map((bm) => (
              <div
                key={bm.id}
                onClick={() => executeResolvedQuery(bm.url)}
                className="flex justify-between p-1.5 rounded hover:bg-neutral-800 cursor-pointer text-neutral-300"
              >
                <span className="truncate max-w-[140px]">{bm.title}</span>
                <span className="text-neutral-500 text-[10px]">{bm.type}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
