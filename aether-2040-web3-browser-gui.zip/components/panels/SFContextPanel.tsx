'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useBrowser, ContextPanelTab } from '@/lib/visual-state/browser-store';
import {
  X,
  Layers,
  UserCheck,
  Box,
  Activity,
  ShieldCheck,
  ExternalLink,
  ChevronRight,
  Cpu,
  Radio,
  Clock,
  Play,
  CheckCircle2,
  Lock,
} from 'lucide-react';

export function SFContextPanel() {
  const {
    contextPanelOpen,
    setContextPanelOpen,
    activeContextTab,
    setActiveContextTab,
    associatedObjects,
    setSelectedObject,
    setObjectMorphLevel,
    selectedNetwork,
    setSelectedNetwork,
    allNetworks,
    transactions,
    runTxSimulation,
    activePage,
  } = useBrowser();

  const tabs: { id: ContextPanelTab; label: string; icon: React.ReactNode }[] = [
    { id: 'objects', label: 'Objects', icon: <Box className="w-3.5 h-3.5" /> },
    { id: 'network', label: 'Network', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'identity', label: 'Identity', icon: <UserCheck className="w-3.5 h-3.5" /> },
    { id: 'activity', label: 'Activity', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'security', label: 'Security', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
  ];

  return (
    <AnimatePresence>
      {contextPanelOpen && (
        <motion.aside
          id="sf-context-panel"
          initial={{ x: 380, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 380, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 340, damping: 30 }}
          className="absolute top-0 right-0 bottom-0 w-80 md:w-96 z-40 bg-[#101316] border-l border-[#262C34] shadow-2xl flex flex-col backdrop-blur-md"
        >
          {/* Header & Tabs */}
          <div className="p-3 hairline-b flex items-center justify-between bg-neutral-950/60">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#4D8BC4]" />
              <h2 className="text-xs font-mono-tech tracking-wider uppercase text-neutral-200 font-semibold">
                Web3 Context Layer
              </h2>
            </div>
            <button
              type="button"
              onClick={() => setContextPanelOpen(false)}
              className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
              title="Close Context Layer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Sub-tab navigation */}
          <div className="flex items-center px-2 py-1.5 hairline-b bg-[#0E1114] gap-1 overflow-x-auto text-[11px] font-mono-tech">
            {tabs.map((tab) => {
              const isActive = activeContextTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveContextTab(tab.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors ${
                    isActive
                      ? 'bg-[#181D22] text-[#4D8BC4] border border-[#2E3742] font-medium'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs">
            {/* OBJECTS TAB */}
            {activeContextTab === 'objects' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-[11px] font-mono-tech text-neutral-400">
                  <span>DETECTED ON CURRENT PAGE ({associatedObjects.length})</span>
                  <span className="text-[10px] text-[#58A878]">FORMAL VERIFIED</span>
                </div>

                {associatedObjects.length === 0 ? (
                  <div className="p-4 text-center text-neutral-500 font-mono-tech">
                    No autonomous Web3 objects detected in this scope.
                  </div>
                ) : (
                  associatedObjects.map((obj) => (
                    <div
                      key={obj.id}
                      onClick={() => {
                        setSelectedObject(obj);
                        setObjectMorphLevel(2);
                      }}
                      className="p-3 rounded border border-[#2A313A] bg-[#14181D] hover:border-[#4D8BC4] hover:bg-[#181D24] cursor-pointer transition-all group"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[10px] font-mono-tech px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300 uppercase">
                          {obj.type}
                        </span>
                        <span className="flex items-center gap-1 text-[10px] font-mono-tech text-[#58A878]">
                          <CheckCircle2 className="w-3 h-3" /> {obj.state}
                        </span>
                      </div>
                      <h4 className="font-semibold text-neutral-100 group-hover:text-[#4D8BC4] transition-colors mb-1 text-sm">
                        {obj.name}
                      </h4>
                      <div className="font-mono-tech text-[10px] text-neutral-400 mb-2 truncate">
                        ID: {obj.identifier}
                      </div>
                      <p className="text-neutral-400 text-[11px] line-clamp-2 mb-2">
                        {obj.description}
                      </p>
                      <div className="flex items-center justify-between text-[10px] font-mono-tech text-neutral-400 pt-2 hairline-t">
                        <span>Latency: {obj.latency || '1.2ms'}</span>
                        <span className="text-[#4D8BC4] flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                          Inspect Deep State <ChevronRight className="w-3 h-3" />
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* NETWORK TAB */}
            {activeContextTab === 'network' && (
              <div className="space-y-3 font-mono-tech">
                <div className="p-3 rounded border border-[#2A313A] bg-[#14181D]">
                  <div className="text-[10px] text-neutral-400 uppercase mb-1">Active Subnet</div>
                  <h3 className="text-sm text-neutral-100 font-semibold mb-2">
                    {selectedNetwork?.name || 'Aether-4 Subnet'}
                  </h3>
                  <div className="grid grid-cols-2 gap-2 text-[11px] mb-3">
                    <div className="p-2 rounded bg-neutral-900 border border-neutral-800">
                      <div className="text-[9px] text-neutral-500">PEAK THROUGHPUT</div>
                      <div className="text-neutral-200 font-semibold">{selectedNetwork?.tps.toLocaleString()} TPS</div>
                    </div>
                    <div className="p-2 rounded bg-neutral-900 border border-neutral-800">
                      <div className="text-[9px] text-neutral-500">CONSENSUS LATENCY</div>
                      <div className="text-[#58A878] font-semibold">{selectedNetwork?.latencyMs} ms</div>
                    </div>
                  </div>
                  <div className="text-[10px] text-neutral-400 space-y-1">
                    <div>Region: <span className="text-neutral-200">{selectedNetwork?.region}</span></div>
                    <div>Consensus: <span className="text-neutral-200">{selectedNetwork?.consensusEngine}</span></div>
                    <div>Active Peers: <span className="text-neutral-200">{selectedNetwork?.totalPeers.toLocaleString()}</span></div>
                  </div>
                </div>

                <div className="text-[10px] text-neutral-400 uppercase">Available Mesh Networks</div>
                <div className="space-y-1.5">
                  {allNetworks.map((net) => (
                    <div
                      key={net.id}
                      onClick={() => setSelectedNetwork(net)}
                      className={`p-2 rounded border cursor-pointer flex items-center justify-between text-[11px] ${
                        selectedNetwork?.id === net.id
                          ? 'border-[#4D8BC4] bg-[#181D24] text-neutral-100'
                          : 'border-neutral-800 bg-[#121518] text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      <span className="font-medium">{net.name}</span>
                      <span className="text-[10px] text-neutral-500">{net.tier}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* IDENTITY TAB */}
            {activeContextTab === 'identity' && (
              <div className="space-y-3 font-mono-tech">
                <div className="p-3 rounded border border-[#2A313A] bg-[#14181D]">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 rounded-full bg-[#58A878]/20 border border-[#58A878]/40 flex items-center justify-center text-[#58A878]">
                      <UserCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs text-neutral-100 font-semibold">Dr. Eleanor Vane</div>
                      <div className="text-[10px] text-neutral-400">eleanor.vane.aero.id</div>
                    </div>
                  </div>
                  <div className="p-2 rounded bg-neutral-900 border border-neutral-800 text-[10px] text-neutral-300 space-y-1 mb-2">
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Security Clearance:</span>
                      <span className="text-[#58A878]">Class IV Aerospace</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Hardware Enclave:</span>
                      <span>YubiQuantum-9</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Trust Attestation:</span>
                      <span className="text-[#4D8BC4]">99.98% Cryptographic</span>
                    </div>
                  </div>
                  <div className="text-[10px] text-neutral-400">
                    Issuer: Royal Aeronautical Registry (DID:2040 Sovereign Spec)
                  </div>
                </div>
              </div>
            )}

            {/* ACTIVITY TAB */}
            {activeContextTab === 'activity' && (
              <div className="space-y-2 font-mono-tech">
                <div className="flex items-center justify-between text-[10px] text-neutral-400 pb-1">
                  <span>LIVE TRANSACTION STREAM</span>
                  <button
                    type="button"
                    onClick={() => runTxSimulation()}
                    className="text-[#4D8BC4] hover:underline flex items-center gap-1"
                  >
                    <Play className="w-3 h-3" /> Simulate Flight
                  </button>
                </div>
                <div className="space-y-1.5 max-h-[400px] overflow-y-auto">
                  {transactions.map((tx) => (
                    <div
                      key={tx.id}
                      onClick={() => runTxSimulation(tx)}
                      className="p-2 rounded border border-neutral-800 bg-[#121518] hover:border-neutral-700 cursor-pointer text-[10px] space-y-1"
                    >
                      <div className="flex justify-between text-neutral-300">
                        <span className="font-semibold text-[#4D8BC4] truncate max-w-[140px]">{tx.toName}</span>
                        <span className="text-[#58A878]">{tx.value}</span>
                      </div>
                      <div className="flex justify-between text-neutral-500 text-[9px]">
                        <span>{tx.hash}</span>
                        <span>{tx.timestamp}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SECURITY TAB */}
            {activeContextTab === 'security' && (
              <div className="space-y-3 font-mono-tech">
                <div className="p-3 rounded border border-[#58A878]/30 bg-[#58A878]/5">
                  <div className="flex items-center gap-2 text-[#58A878] text-xs font-semibold mb-2">
                    <ShieldCheck className="w-4 h-4" /> ZERO-KNOWLEDGE PROOF VERIFIED
                  </div>
                  <p className="text-[11px] text-neutral-300 mb-2">
                    All contract executions, state transitions, and identity certificates in this scope are formally verified by the Veritas ZK-Fabric.
                  </p>
                  <div className="p-2 rounded bg-neutral-950/80 border border-neutral-800 text-[9px] text-neutral-400 space-y-1">
                    <div>Proof Engine: Halo2 Recursive SNARK</div>
                    <div>State Root: 0x9a8f4410bc39e21...</div>
                    <div>Verification Latency: 0.42 ms</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}
