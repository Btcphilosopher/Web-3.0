// Kotlin-Inspired Motion & Transition Architecture for Aether 2040 Browser

export interface MotionConfig {
  stiffness: number;
  damping: number;
  mass?: number;
}

export const KOTLIN_SPRINGS = {
  // Snappy aerospace mechanical feedback
  snappy: { stiffness: 420, damping: 28, mass: 0.8 },
  // Smooth structural transition
  structural: { stiffness: 280, damping: 26, mass: 1 },
  // Spatial camera zoom & semantic depth
  spatial: { stiffness: 180, damping: 24, mass: 1.2 },
  // Micro-interaction button or toggle feedback
  tactile: { stiffness: 500, damping: 32, mass: 0.5 },
  // Gentle settle for large panels
  settle: { stiffness: 220, damping: 25, mass: 1 },
};

// Kotlin Animation Primitives definition for React Motion
export const SReveal = {
  initial: { opacity: 0, y: 8, filter: 'blur(3px)' },
  animate: { opacity: 1, y: 0, filter: 'blur(0px)' },
  exit: { opacity: 0, y: -6, filter: 'blur(2px)' },
  transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
};

export const SFade = {
  initial: { opacity: 0 },
  animate: { opacity: 1 },
  exit: { opacity: 0 },
  transition: { duration: 0.18, ease: 'easeInOut' },
};

export const SScale = {
  initial: { opacity: 0, scale: 0.94 },
  animate: { opacity: 1, scale: 1 },
  exit: { opacity: 0, scale: 0.96 },
  transition: { duration: 0.2, ease: [0.16, 1, 0.3, 1] },
};

export const SMorph = {
  initial: { scale: 0.96, opacity: 0.6 },
  animate: { scale: 1, opacity: 1 },
  exit: { scale: 0.96, opacity: 0 },
  transition: { type: 'spring', stiffness: 320, damping: 26 },
};

export const SExpand = {
  initial: { height: 0, opacity: 0 },
  animate: { height: 'auto', opacity: 1 },
  exit: { height: 0, opacity: 0 },
  transition: { duration: 0.25, ease: [0.16, 1, 0.3, 1] },
};

export const SSlideDrawer = {
  initial: { x: '100%', opacity: 0 },
  animate: { x: 0, opacity: 1 },
  exit: { x: '100%', opacity: 0 },
  transition: { type: 'spring', stiffness: 340, damping: 30 },
};

export const SZoomSpatial = {
  initial: { scale: 1.15, opacity: 0, filter: 'blur(6px)' },
  animate: { scale: 1, opacity: 1, filter: 'blur(0px)' },
  exit: { scale: 0.85, opacity: 0, filter: 'blur(6px)' },
  transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] },
};

export const SStaggerList = {
  container: {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.04,
      },
    },
  },
  item: {
    hidden: { opacity: 0, y: 6 },
    show: { opacity: 1, y: 0, transition: { duration: 0.2, ease: [0.16, 1, 0.3, 1] } },
  },
};
