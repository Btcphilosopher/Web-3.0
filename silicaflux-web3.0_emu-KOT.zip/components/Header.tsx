'use client';

import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  FastForward, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  Sun, 
  Moon, 
  Search, 
  Layers,
  Activity,
  Cpu
} from 'lucide-react';
import { ThemeMode, ViewDensity } from '@/lib/types';
import { SFButton } from './ui/SFButton';
import { SFSignal } from './ui/SFSignal';
import { soundFx } from '@/lib/audio/soundSystem';
import { web3Emu } from '@/lib/web3emu/engine';

interface HeaderProps {
  theme: ThemeMode;
  onToggleTheme: () => void;
  density: ViewDensity;
  onChangeDensity: (d: ViewDensity) => void;
  onOpenCommand: () => void;
  latestHeight: number;
  activeNodesCount: number;
  anomalyLevel: 'nominal' | 'elevated' | 'critical';
}

export const Header: React.FC<HeaderProps> = ({
  theme,
  onToggleTheme,
  density,
  onChangeDensity,
  onOpenCommand,
  latestHeight,
  activeNodesCount,
  anomalyLevel,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isSimRunning, setIsSimRunning] = useState<boolean>(true);
  const [simSpeed, setSimSpeed] = useState<number>(1.0);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const londonTime = now.toLocaleTimeString('en-GB', {
        timeZone: 'Europe/London',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      const ms = String(now.getMilliseconds()).padStart(3, '0');
      setTimeStr(`${londonTime}.${ms} LDN`);
    };

    updateClock();
    const interval = setInterval(updateClock, 80);
    return () => clearInterval(interval);
  }, []);

  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    soundFx.setMuted(next);
    if (!next) soundFx.playConfirm();
  };

  const handleToggleSim = () => {
    const next = !isSimRunning;
    setIsSimRunning(next);
    web3Emu.toggleSimulation(next);
    soundFx.playClick(600);
  };

  const handleStepSim = () => {
    web3Emu.stepSimulation();
    soundFx.playBlockMined();
  };

  const handleCycleSpeed = () => {
    const speeds = [0.5, 1.0, 2.0, 4.0];
    const nextIdx = (speeds.indexOf(simSpeed) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    setSimSpeed(nextSpeed);
    web3Emu.setSimulationSpeed(nextSpeed);
    soundFx.playClick(850);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0E0E0E] border-b border-[#2A2A2A] px-4 py-2.5 select-none">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Left: Brand & Telemetry */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            {/* Geometric Bento Emblem Logo */}
            <div className="w-7 h-7 bg-white text-black flex items-center justify-center shrink-0">
              <div className="w-3.5 h-3.5 border-2 border-black" />
            </div>
            <div className="flex items-baseline gap-1.5">
              <h1 className="text-base font-bold tracking-tighter uppercase text-[#E4E4E4]">
                SILICAFLUX
              </h1>
              <span className="text-[10px] font-mono opacity-50 tracking-widest text-[#E4E4E4]">
                v3.0.40
              </span>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-4 pl-4 border-l border-[#2A2A2A] text-[10px] font-mono tracking-wider uppercase">
            <div className="flex items-center space-x-2 text-[#00FF41]">
              <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse" />
              <span>Web3EMU: Operational</span>
            </div>

            <div className="opacity-50">
              Lat: <span className="text-[#E4E4E4] font-bold">12ms</span>
            </div>

            <div className="opacity-50">
              Block: <span className="text-[#E4E4E4] font-bold">#{latestHeight.toLocaleString()}</span>
            </div>

            <div className="opacity-50">
              Mesh: <span className="text-[#00FF41] font-bold">{activeNodesCount}/6 UK</span>
            </div>
          </div>
        </div>

        {/* Center: Command Palette Trigger */}
        <div className="flex-1 max-w-xs hidden md:block">
          <button
            onClick={onOpenCommand}
            className="w-full flex items-center justify-between px-3 py-1.5 bg-[#111111] border border-[#2A2A2A] hover:border-[#444444] text-[11px] text-[#888888] font-mono transition-colors"
          >
            <div className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-[#555555]" />
              <span className="tracking-wider uppercase text-[10px]">Search Mesh, Block, Tx...</span>
            </div>
            <kbd className="px-1.5 py-0.5 text-[9px] bg-[#1A1A1A] border border-[#333333] text-[#888888]">
              ⌘K
            </kbd>
          </button>
        </div>

        {/* Right: Simulation Controls, Density, Theme & Bento Timestamp Chip */}
        <div className="flex items-center gap-2">
          {/* Simulation Controls */}
          <div className="flex items-center bg-[#111111] border border-[#2A2A2A] p-0.5">
            <button
              title={isSimRunning ? 'Pause Web3EMU Simulation' : 'Resume Web3EMU Simulation'}
              onClick={handleToggleSim}
              className={`p-1.5 transition-colors ${
                isSimRunning ? 'text-[#00FF41] hover:bg-[#1A1A1A]' : 'text-[#F27D26] hover:bg-[#1A1A1A]'
              }`}
            >
              {isSimRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>
            <button
              title="Step Single Block"
              onClick={handleStepSim}
              className="p-1.5 text-[#888888] hover:text-[#E4E4E4] hover:bg-[#1A1A1A] transition-colors"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
            <button
              title={`Simulation Speed: ${simSpeed}x`}
              onClick={handleCycleSpeed}
              className="px-2 py-1 text-[10px] font-mono text-[#888888] hover:text-[#E4E4E4] hover:bg-[#1A1A1A] transition-colors font-bold"
            >
              {simSpeed}x
            </button>
          </div>

          {/* Density Selector */}
          <div className="hidden sm:flex items-center bg-[#111111] border border-[#2A2A2A] p-0.5 text-[10px] font-mono">
            {(['human', 'normal', 'high', 'engineering'] as ViewDensity[]).map((d) => (
              <button
                key={d}
                onClick={() => onChangeDensity(d)}
                className={`px-2 py-0.5 uppercase transition-colors ${
                  density === d
                    ? 'bg-white text-black font-bold'
                    : 'text-[#888888] hover:text-[#E4E4E4]'
                }`}
              >
                {d.slice(0, 4)}
              </button>
            ))}
          </div>

          {/* Sound Toggle */}
          <button
            title={isMuted ? 'Unmute Audio Feedback' : 'Mute Audio Feedback'}
            onClick={handleToggleMute}
            className="p-1.5 text-[#888888] hover:text-[#E4E4E4] bg-[#111111] border border-[#2A2A2A] transition-colors"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Theme Switcher */}
          <button
            title={`Switch to ${theme === 'obsidian' ? 'Archive (Light)' : 'Obsidian (Dark)'} Mode`}
            onClick={onToggleTheme}
            className="p-1.5 text-[#888888] hover:text-[#E4E4E4] bg-[#111111] border border-[#2A2A2A] transition-colors"
          >
            {theme === 'obsidian' ? <Sun className="w-3.5 h-3.5 text-[#D4AF37]" /> : <Moon className="w-3.5 h-3.5 text-[#4A90E2]" />}
          </button>

          {/* Bento Precision Timestamp Badge */}
          <div suppressHydrationWarning className="hidden xl:flex items-center px-3 py-1 border border-[#333333] bg-[#1A1A1A] text-[10px] font-mono text-[#E4E4E4] tracking-wider uppercase">
            <span>2040.Q4 // {timeStr}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
