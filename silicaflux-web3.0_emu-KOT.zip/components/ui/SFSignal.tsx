'use client';

import React from 'react';

export type SignalState = 'clear' | 'caution' | 'danger' | 'pulsing';

interface SFSignalProps {
  id?: string;
  state?: SignalState;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  showHousing?: boolean;
}

export const SFSignal: React.FC<SFSignalProps> = ({
  id,
  state = 'clear',
  label,
  size = 'md',
  showHousing = true,
}) => {
  const sizeMap = {
    sm: { dot: 'w-2 h-2', housing: 'p-1 gap-1' },
    md: { dot: 'w-3 h-3', housing: 'p-1.5 gap-1.5' },
    lg: { dot: 'w-4 h-4', housing: 'p-2 gap-2' },
  }[size];

  const getColor = () => {
    switch (state) {
      case 'clear':
        return 'bg-[var(--sf-green)] shadow-[0_0_8px_rgba(63,185,80,0.6)]';
      case 'caution':
        return 'bg-[var(--sf-amber)] shadow-[0_0_8px_rgba(210,153,34,0.6)]';
      case 'danger':
        return 'bg-[var(--sf-red)] shadow-[0_0_8px_rgba(248,81,73,0.6)]';
      case 'pulsing':
        return 'bg-[var(--sf-accent)] animate-signal-pulse shadow-[0_0_10px_rgba(56,139,253,0.8)]';
    }
  };

  return (
    <div id={id} className="inline-flex items-center gap-2 font-mono">
      {showHousing ? (
        <div
          className={`flex items-center rounded-sm bg-[#07090C] border border-[var(--sf-border-strong)] ${sizeMap.housing}`}
        >
          {/* Signal Indicator Light */}
          <div className={`rounded-full transition-all duration-300 ${sizeMap.dot} ${getColor()}`} />
        </div>
      ) : (
        <div className={`rounded-full transition-all duration-300 ${sizeMap.dot} ${getColor()}`} />
      )}

      {label && (
        <span className="text-[11px] uppercase tracking-wider text-[var(--sf-text-muted)] font-mono">
          {label}
        </span>
      )}
    </div>
  );
};
