'use client';

import React from 'react';

interface SFGaugeProps {
  id?: string;
  value: number; // 0 to 100
  label: string;
  size?: number;
  unit?: string;
  warningThreshold?: number;
  alertThreshold?: number;
  className?: string;
}

export const SFGauge: React.FC<SFGaugeProps> = ({
  id,
  value,
  label,
  size = 110,
  unit = '%',
  warningThreshold = 75,
  alertThreshold = 90,
  className = '',
}) => {
  const clamped = Math.max(0, Math.min(100, value));
  const radius = size * 0.38;
  const circumference = 2 * Math.PI * radius;
  // Arc angle of 240 degrees (leaving bottom 120 open)
  const arcLength = circumference * (240 / 360);
  const strokeDashoffset = arcLength - (clamped / 100) * arcLength;

  let color = 'var(--sf-accent)';
  if (clamped >= alertThreshold) {
    color = 'var(--sf-red)';
  } else if (clamped >= warningThreshold) {
    color = 'var(--sf-amber)';
  }

  return (
    <div id={id} className={`flex flex-col items-center justify-center p-2 ${className}`}>
      <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          className="transform -rotate-210"
        >
          {/* Background Track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="var(--sf-border-subtle)"
            strokeWidth={size * 0.07}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeLinecap="round"
          />
          {/* Progress Arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={size * 0.08}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-300 ease-out"
          />
        </svg>

        {/* Center Display */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-base font-bold font-mono text-[var(--sf-text)]">
            {clamped.toFixed(1)}
          </span>
          <span className="text-[10px] text-[var(--sf-text-dim)] font-mono">{unit}</span>
        </div>
      </div>

      <span className="text-[10px] uppercase font-mono tracking-wider text-[var(--sf-text-dim)] mt-0.5">
        {label}
      </span>
    </div>
  );
};
