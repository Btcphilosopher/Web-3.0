'use client';

import React from 'react';

interface SFDataFieldProps {
  id?: string;
  label: string;
  value: string | number;
  subValue?: string;
  delta?: string;
  deltaPositive?: boolean;
  unit?: string;
  status?: 'nominal' | 'warning' | 'alert' | 'idle';
  accentColor?: 'blue' | 'green' | 'amber' | 'default';
  className?: string;
  onClick?: () => void;
}

export const SFDataField: React.FC<SFDataFieldProps> = ({
  id,
  label,
  value,
  subValue,
  delta,
  deltaPositive,
  unit,
  status = 'nominal',
  accentColor = 'default',
  className = '',
  onClick,
}) => {
  const accentBorder = {
    blue: 'border-l-2 border-l-[#4A90E2]',
    green: 'border-l-2 border-l-[#00FF41]',
    amber: 'border-l-2 border-l-[#F27D26]',
    default: status === 'alert' 
      ? 'border-l-2 border-l-[#FF3B30]' 
      : status === 'warning' 
      ? 'border-l-2 border-l-[#F27D26]' 
      : 'border-l-2 border-l-[#3A3A3A]',
  }[accentColor];

  const statusColor = {
    nominal: 'border-[#2A2A2A] hover:border-[#3E3E3E]',
    warning: 'border-[#F27D26]/40 bg-[#F27D26]/5',
    alert: 'border-[#FF3B30]/40 bg-[#FF3B30]/5',
    idle: 'border-[#1C1C1C] opacity-70',
  }[status];

  return (
    <div
      id={id}
      onClick={onClick}
      className={`relative px-4 py-3 bg-[#111111] border transition-all duration-150 ${accentBorder} ${statusColor} ${
        onClick ? 'cursor-pointer active:scale-[0.99] hover:bg-[#161616]' : ''
      } ${className}`}
    >
      {/* Label and Delta */}
      <div className="flex items-center justify-between text-[9px] uppercase tracking-[0.18em] font-mono text-[#888888] mb-1.5">
        <span>{label}</span>
        {delta && (
          <span className={deltaPositive ? 'text-[#00FF41] font-bold' : 'text-[#F27D26] font-bold'}>
            {delta}
          </span>
        )}
      </div>

      {/* Main Value */}
      <div className="flex items-baseline gap-1.5">
        <span
          className="text-xl md:text-2xl font-light tracking-tighter text-[#E4E4E4] font-mono"
        >
          {value}
        </span>
        {unit && <span className="text-xs text-[#666666] font-mono lowercase">{unit}</span>}
      </div>

      {/* Sub Value */}
      {subValue && (
        <div className="mt-1 text-[10px] text-[#666666] font-mono truncate">
          {subValue}
        </div>
      )}
    </div>
  );
};

