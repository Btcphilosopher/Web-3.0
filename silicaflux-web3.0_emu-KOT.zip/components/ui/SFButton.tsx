'use client';

import React from 'react';
import { soundFx } from '@/lib/audio/soundSystem';

interface SFButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  active?: boolean;
}

export const SFButton: React.FC<SFButtonProps> = ({
  children,
  variant = 'secondary',
  size = 'md',
  active = false,
  className = '',
  onClick,
  ...props
}) => {
  const sizeStyles = {
    sm: 'px-2.5 py-1 text-xs gap-1.5',
    md: 'px-3.5 py-1.5 text-xs gap-2',
    lg: 'px-5 py-2.5 text-sm gap-2.5',
  }[size];

  const variantStyles = {
    primary:
      'bg-[var(--sf-accent)] text-white hover:bg-[var(--sf-accent)]/90 active:scale-[0.98] border border-[var(--sf-accent)] font-medium shadow-sm',
    secondary:
      'bg-[var(--sf-surface-elevated)] text-[var(--sf-text)] hover:bg-[var(--sf-surface-subtle)] active:scale-[0.98] border border-[var(--sf-border)] hover:border-[var(--sf-border-strong)]',
    outline:
      'bg-transparent text-[var(--sf-text)] hover:bg-[var(--sf-surface)] active:scale-[0.98] border border-[var(--sf-border)] hover:border-[var(--sf-text-muted)]',
    danger:
      'bg-[var(--sf-red)] text-white hover:bg-[var(--sf-red)]/90 active:scale-[0.98] border border-[var(--sf-red)] font-medium',
    ghost:
      'bg-transparent text-[var(--sf-text-muted)] hover:text-[var(--sf-text)] hover:bg-[var(--sf-surface)] active:scale-[0.98] border border-transparent',
  }[variant];

  const activeStyles = active
    ? 'border-[var(--sf-accent)] bg-[var(--sf-accent-subtle)] text-[var(--sf-accent)]'
    : '';

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    soundFx.playClick(920);
    if (onClick) onClick(e);
  };

  return (
    <button
      onClick={handleClick}
      className={`relative inline-flex items-center justify-center font-mono uppercase tracking-wider rounded-none select-none transition-all duration-100 disabled:opacity-40 disabled:pointer-events-none cursor-pointer ${sizeStyles} ${variantStyles} ${activeStyles} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};
