'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  NetworkNode, 
  Web3Block, 
  Web3Transaction, 
  QuantMetrics, 
  QuantVisualParameters, 
  VisualMovingSignal,
  ViewDensity 
} from '@/lib/types';
import { SFDataField } from '../ui/SFDataField';
import { SFGauge } from '../ui/SFGauge';
import { SFSignal } from '../ui/SFSignal';
import { SFButton } from '../ui/SFButton';
import { web3Emu } from '@/lib/web3emu/engine';
import { soundFx } from '@/lib/audio/soundSystem';
import { ZoomIn, ZoomOut, RefreshCw, AlertTriangle, ShieldCheck, Zap, Activity } from 'lucide-react';

interface ObservatoryViewProps {
  nodes: NetworkNode[];
  latestBlock: Web3Block | null;
  recentTxs: Web3Transaction[];
  quant: QuantMetrics;
  visualParams: QuantVisualParameters;
  density: ViewDensity;
  onSelectTx: (tx: Web3Transaction) => void;
  onSelectBlock: (height: number) => void;
}

export const ObservatoryView: React.FC<ObservatoryViewProps> = ({
  nodes,
  latestBlock,
  recentTxs,
  quant,
  visualParams,
  density,
  onSelectTx,
  onSelectBlock,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedNode, setSelectedNode] = useState<NetworkNode | null>(nodes[0] || null);
  const [zoom, setZoom] = useState<number>(1.0);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Moving transaction signal packets
  const signalsRef = useRef<VisualMovingSignal[]>([]);

  // Spawn new moving signals along rails when transactions arrive
  useEffect(() => {
    if (recentTxs.length > 0 && nodes.length > 1) {
      const latestTx = recentTxs[0];
      const fromNode = nodes[Math.floor(Math.random() * nodes.length)];
      const toNode = nodes.find(n => n.id !== fromNode.id) || nodes[0];

      const newSig: VisualMovingSignal = {
        id: `sig_${Date.now()}_${Math.random()}`,
        fromNodeId: fromNode.id,
        toNodeId: toNode.id,
        txHash: latestTx.hash,
        value: latestTx.valueEth,
        progress: 0,
        speed: 0.008 * visualParams.signalSpeedMultiplier,
        color: latestTx.type === 'contract_call' ? '#388BFD' : '#3FB950',
        type: latestTx.type === 'contract_call' ? 'event' : 'tx',
      };

      signalsRef.current.push(newSig);
      if (signalsRef.current.length > 25) {
        signalsRef.current.shift();
      }
    }
  }, [recentTxs, nodes, visualParams.signalSpeedMultiplier]);

  // Main Canvas Rendering Loop
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high-DPI displays
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.clearRect(0, 0, width, height);

    ctx.save();
    ctx.translate(pan.x + width / 2, pan.y + height / 2);
    ctx.scale(zoom, zoom);
    ctx.translate(-width / 2, -height / 2);

    // Draw Subtle Engineering Grid Lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let x = -width; x < width * 2; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, -height);
      ctx.lineTo(x, height * 2);
      ctx.stroke();
    }
    for (let y = -height; y < height * 2; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(-width, y);
      ctx.lineTo(width * 2, y);
      ctx.stroke();
    }

    // 1. Draw Network Connection Rails (British Signalling Layout)
    nodes.forEach(node => {
      node.peers.forEach(peerId => {
        const peerNode = nodes.find(n => n.id === peerId);
        if (peerNode) {
          ctx.beginPath();
          ctx.moveTo(node.x, node.y);
          ctx.lineTo(peerNode.x, peerNode.y);

          const isCongested = node.status === 'congested' || peerNode.status === 'congested';
          const isOffline = node.status === 'offline' || peerNode.status === 'offline';

          if (isOffline) {
            ctx.strokeStyle = 'rgba(248, 81, 73, 0.25)';
            ctx.setLineDash([4, 6]);
          } else if (isCongested) {
            ctx.strokeStyle = 'rgba(210, 153, 34, 0.5)';
            ctx.setLineDash([8, 4]);
          } else {
            ctx.strokeStyle = 'rgba(56, 139, 253, 0.25)';
            ctx.setLineDash([]);
          }

          ctx.lineWidth = visualParams.lineThickness;
          ctx.stroke();
          ctx.setLineDash([]);

          // Midpoint rail cross-tie ticks
          const midX = (node.x + peerNode.x) / 2;
          const midY = (node.y + peerNode.y) / 2;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
          ctx.fillRect(midX - 1.5, midY - 1.5, 3, 3);
        }
      });
    });

    // 2. Animate and Render Moving Transaction Signal Packets
    signalsRef.current.forEach((sig, idx) => {
      sig.progress += sig.speed;
      const fromNode = nodes.find(n => n.id === sig.fromNodeId);
      const toNode = nodes.find(n => n.id === sig.toNodeId);

      if (fromNode && toNode && sig.progress <= 1) {
        const currentX = fromNode.x + (toNode.x - fromNode.x) * sig.progress;
        const currentY = fromNode.y + (toNode.y - fromNode.y) * sig.progress;

        // Signal packet head
        ctx.fillStyle = sig.color;
        ctx.beginPath();
        ctx.arc(currentX, currentY, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // Signal tail
        const tailLength = 0.08;
        const tailX = fromNode.x + (toNode.x - fromNode.x) * Math.max(0, sig.progress - tailLength);
        const tailY = fromNode.y + (toNode.y - fromNode.y) * Math.max(0, sig.progress - tailLength);
        ctx.strokeStyle = sig.color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(tailX, tailY);
        ctx.lineTo(currentX, currentY);
        ctx.stroke();
      }
    });

    // Remove completed signals
    signalsRef.current = signalsRef.current.filter(s => s.progress <= 1);

    // 3. Render Network Nodes (Architectural Instrument Pods)
    nodes.forEach(node => {
      const isSelected = selectedNode?.id === node.id;
      const isOnline = node.status === 'online';
      const isCongested = node.status === 'congested';
      const isOffline = node.status === 'offline';

      // Outer Selection Ring
      if (isSelected) {
        ctx.strokeStyle = 'var(--sf-accent)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(node.x, node.y, 22, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Main Node Housing (Precision Octagonal / Diamond / Circle)
      ctx.fillStyle = isOffline ? '#220D0D' : isCongested ? '#2B1F0A' : '#101419';
      ctx.strokeStyle = isOffline ? '#F85149' : isCongested ? '#D29922' : isSelected ? '#388BFD' : '#3D4A59';
      ctx.lineWidth = 1.5;

      ctx.beginPath();
      ctx.arc(node.x, node.y, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Inner Core Status Indicator
      ctx.fillStyle = isOffline ? '#F85149' : isCongested ? '#D29922' : '#3FB950';
      ctx.beginPath();
      ctx.arc(node.x, node.y, 4, 0, Math.PI * 2);
      ctx.fill();

      // Node Label and Telemetry
      ctx.fillStyle = isSelected ? '#FFFFFF' : '#8892A2';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(node.name.split(' ')[0], node.x, node.y + 28);
      ctx.fillStyle = '#546070';
      ctx.font = '9px "JetBrains Mono", monospace';
      ctx.fillText(`${node.latencyMs}ms | ${node.tps} TPS`, node.x, node.y + 38);
    });

    ctx.restore();
  }, [nodes, selectedNode, zoom, pan, visualParams]);

  useEffect(() => {
    let animId: number;
    const loop = () => {
      renderCanvas();
      animId = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(animId);
  }, [renderCanvas]);

  // Mouse Interaction Handlers for Pan and Node Click
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) {
      setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
    }
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(false);
    // Detect if clicked on a node
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const width = canvas.clientWidth;
    const height = canvas.clientHeight;

    // Invert zoom and pan transformation
    const transformedX = (clickX - (pan.x + width / 2)) / zoom + width / 2;
    const transformedY = (clickY - (pan.y + height / 2)) / zoom + height / 2;

    const clickedNode = nodes.find(n => {
      const dist = Math.hypot(n.x - transformedX, n.y - transformedY);
      return dist <= 24;
    });

    if (clickedNode) {
      setSelectedNode(clickedNode);
      soundFx.playClick(900);
    }
  };

  const handleToggleNodeStatus = (nodeId: string) => {
    web3Emu.triggerNodeFailure(nodeId);
    soundFx.playAlert();
  };

  return (
    <div className="flex flex-col lg:flex-row h-full w-full gap-3 p-3 overflow-hidden select-none bg-[#0A0A0A]">
      {/* Primary Spatial Canvas */}
      <div className="relative flex-1 bg-[#111111] border border-[#2A2A2A] flex flex-col overflow-hidden min-h-[420px]">
        {/* Top Control Overlay */}
        <div className="absolute top-3 left-3 z-10 flex items-center gap-2 bg-[#181818]/90 backdrop-blur-xs border border-[#2A2A2A] p-1.5 font-mono text-xs">
          <span className="text-[#888888] uppercase text-[10px] px-1 font-bold">SPATIAL MESH</span>
          <button
            onClick={() => setZoom(z => Math.min(2.2, z + 0.15))}
            className="p-1 hover:bg-[#222222] text-[#AAAAAA] hover:text-white transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoom(z => Math.max(0.6, z - 0.15))}
            className="p-1 hover:bg-[#222222] text-[#AAAAAA] hover:text-white transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => { setZoom(1.0); setPan({ x: 0, y: 0 }); }}
            className="p-1 hover:bg-[#222222] text-[#666666] hover:text-white transition-colors"
            title="Reset Pan & Zoom"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Live Signal Legend Overlay */}
        <div className="absolute bottom-3 left-3 z-10 flex flex-wrap items-center gap-3 bg-[#181818]/90 backdrop-blur-xs border border-[#2A2A2A] px-3 py-1.5 font-mono text-[10px] text-[#888888]">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#00FF41]" />
            <span>VALUE TRANSFER</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#4A90E2]" />
            <span>CONTRACT EXECUTION</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#F27D26]" />
            <span>CONGESTION</span>
          </div>
        </div>

        {/* Interactive Canvas */}
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          className="w-full h-full cursor-grab active:cursor-grabbing"
        />
      </div>

      {/* Right Telemetry & Node Inspection Panel */}
      <div className="w-full lg:w-84 xl:w-96 flex flex-col gap-3 shrink-0">
        {/* High-Level Network Telemetry Strip */}
        <div className="grid grid-cols-2 gap-2">
          <SFDataField
            label="Throughput"
            value={`${quant.tpsCurrent}`}
            unit="TPS"
            subValue="Avg 142 TPS"
            delta="+12%"
            deltaPositive={true}
            accentColor="green"
          />
          <SFDataField
            label="Base Fee"
            value={`${latestBlock?.baseFeeGwei || 24}`}
            unit="GWEI"
            subValue="EIP-1559 Elastic"
            delta="-0.8"
            deltaPositive={true}
            accentColor="blue"
          />
        </div>

        {/* Computational Gas Load Dial */}
        <div className="bg-[#111111] border border-[#2A2A2A] border-l-2 border-l-[#4A90E2] p-3 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[9px] uppercase font-mono text-[#888888] tracking-[0.18em]">
              COMPUTATIONAL LOAD
            </span>
            <span className="text-sm font-mono font-bold text-[#E4E4E4] mt-0.5">
              {((latestBlock?.gasRatio || 0.45) * 100).toFixed(1)}% GAS LIMIT
            </span>
            <span className="text-[10px] font-mono text-[#666666] mt-1">
              {(latestBlock?.gasUsed || 13500000).toLocaleString()} / 30,000,000
            </span>
          </div>
          <SFGauge
            value={(latestBlock?.gasRatio || 0.45) * 100}
            label="CAPACITY"
            size={88}
          />
        </div>

        {/* Selected Node Inspector */}
        {selectedNode ? (
          <div className="bg-[#111111] border border-[#2A2A2A] p-3.5 flex flex-col gap-2.5 font-mono text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-[#2A2A2A]">
              <div className="flex items-center gap-2">
                <SFSignal
                  state={selectedNode.status === 'offline' ? 'danger' : selectedNode.status === 'congested' ? 'caution' : 'clear'}
                  size="sm"
                />
                <span className="font-bold text-[#E4E4E4] uppercase">{selectedNode.name}</span>
              </div>
              <span className={`text-[10px] px-1.5 py-0.5 font-bold uppercase ${
                selectedNode.status === 'online' ? 'bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/30' : 'bg-[#FF3B30]/10 text-[#FF3B30] border border-[#FF3B30]/30'
              }`}>
                {selectedNode.status}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <span className="text-[#666666] block text-[9px] uppercase tracking-wider">REGION</span>
                <span className="text-[#E4E4E4]">{selectedNode.region}</span>
              </div>
              <div>
                <span className="text-[#666666] block text-[9px] uppercase tracking-wider">IP ADDRESS</span>
                <span className="text-[#E4E4E4]">{selectedNode.ip}</span>
              </div>
              <div>
                <span className="text-[#666666] block text-[9px] uppercase tracking-wider">LATENCY</span>
                <span className="text-[#E4E4E4]">{selectedNode.latencyMs} ms</span>
              </div>
              <div>
                <span className="text-[#666666] block text-[9px] uppercase tracking-wider">BLOCKS MINED</span>
                <span className="text-[#E4E4E4]">{selectedNode.blocksValidated}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-[#2A2A2A] flex items-center justify-between">
              <span className="text-[10px] text-[#666666]">PEER NODES: {selectedNode.peers.length}</span>
              <SFButton
                size="sm"
                variant={selectedNode.status === 'offline' ? 'primary' : 'outline'}
                onClick={() => handleToggleNodeStatus(selectedNode.id)}
              >
                {selectedNode.status === 'offline' ? 'RESTORE NODE' : 'SIMULATE OUTAGE'}
              </SFButton>
            </div>
          </div>
        ) : (
          <div className="p-6 text-center text-xs font-mono text-[#666666] border border-[#2A2A2A] bg-[#111111]">
            CLICK ANY UK-MESH NODE TO INSPECT TELEMETRY
          </div>
        )}

        {/* Live Mempool Activity Feed */}
        <div className="bg-[#111111] border border-[#2A2A2A] p-3 flex flex-col gap-2 font-mono flex-1 overflow-hidden">
          <div className="flex items-center justify-between text-[9px] text-[#888888] uppercase tracking-[0.15em] border-b border-[#2A2A2A] pb-1.5 font-bold">
            <span>LIVE INCOMING SIGNALS</span>
            <span>{recentTxs.length} IN MESH</span>
          </div>

          <div className="divide-y divide-[#1C1C1C] overflow-y-auto max-h-48 scrollbar-thin">
            {recentTxs.slice(0, 5).map((tx) => (
              <div
                key={tx.hash}
                onClick={() => onSelectTx(tx)}
                className="py-1.5 px-1 hover:bg-[#181818] cursor-pointer text-xs flex items-center justify-between transition-colors"
              >
                <div className="flex items-center gap-2 truncate">
                  <span className={`w-1.5 h-1.5 rounded-full ${tx.type === 'contract_call' ? 'bg-[#4A90E2]' : 'bg-[#00FF41]'}`} />
                  <span className="font-mono text-[11px] text-[#E4E4E4] truncate">{tx.hash.slice(0, 10)}...</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] text-[#888888]">{tx.valueEth.toFixed(2)} ETH</span>
                  <span className="text-[9px] px-1 py-0.2 bg-[#1C1C1C] border border-[#2A2A2A] text-[#666666] uppercase">
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
