'use client';

import React, { useState } from 'react';
import { Web3Account, Web3Transaction } from '@/lib/types';
import { SFDataField } from '../ui/SFDataField';
import { SFButton } from '../ui/SFButton';
import { soundFx } from '@/lib/audio/soundSystem';
import { Wallet, Shield, ArrowUpRight, Coins, History, Check } from 'lucide-react';

interface AccountsViewProps {
  accounts: Record<string, Web3Account>;
  transactions: Web3Transaction[];
  onSelectTx: (tx: Web3Transaction) => void;
}

export const AccountsView: React.FC<AccountsViewProps> = ({
  accounts,
  transactions,
  onSelectTx,
}) => {
  const accountList = Object.values(accounts);
  const [selectedAcc, setSelectedAcc] = useState<Web3Account>(accountList[0]);

  const accTxs = transactions.filter(
    (t) => t.from === selectedAcc?.address || t.to === selectedAcc?.address
  );

  return (
    <div className="flex flex-col lg:flex-row h-full w-full gap-3 p-3 overflow-hidden select-none font-mono text-xs">
      {/* Left List: Sovereign & Institutional Vaults */}
      <div className="w-full lg:w-96 flex flex-col bg-[var(--sf-surface)] border border-[var(--sf-border)] overflow-hidden shrink-0">
        <div className="p-3 bg-[var(--sf-surface-elevated)] border-b border-[var(--sf-border)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-[var(--sf-accent)]" />
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs">SOVEREIGN VAULTS & ACCOUNTS</span>
          </div>
          <span className="text-[10px] text-[var(--sf-text-dim)]">{accountList.length} VAULTS</span>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-[var(--sf-border-subtle)] scrollbar-thin">
          {accountList.map((acc) => {
            const isSelected = selectedAcc?.address === acc.address;
            return (
              <div
                key={acc.address}
                onClick={() => {
                  soundFx.playClick(960);
                  setSelectedAcc(acc);
                }}
                className={`p-3 cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[var(--sf-accent-subtle)] border-l-3 border-[var(--sf-accent)] text-[var(--sf-text)]'
                    : 'hover:bg-[var(--sf-surface-subtle)] text-[var(--sf-text-muted)]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[var(--sf-text)]">{acc.label}</span>
                  <span className={`text-[9px] px-1.5 py-0.2 uppercase font-semibold ${
                    acc.type === 'treasury' ? 'bg-[var(--sf-brass-subtle)] text-[var(--sf-brass)]' : 'bg-[var(--sf-border-subtle)] text-[var(--sf-text-dim)]'
                  }`}>
                    {acc.type}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[11px] text-[var(--sf-text-muted)] mt-1.5">
                  <span className="text-sm font-bold text-[var(--sf-text)]">{acc.balanceEth.toLocaleString()} ETH</span>
                  <span className="text-[10px] text-[var(--sf-text-dim)]">{acc.txCount} TXs</span>
                </div>

                <div className="text-[10px] text-[var(--sf-text-dim)] mt-1 truncate">
                  {acc.address}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Selected Vault Inspection */}
      {selectedAcc && (
        <div className="flex-1 flex flex-col gap-3 overflow-y-auto scrollbar-thin">
          {/* Top Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <SFDataField
              label="Liquid ETH Balance"
              value={`${selectedAcc.balanceEth.toLocaleString()}`}
              unit="ETH"
              subValue={`~£${(selectedAcc.balanceEth * 2840).toLocaleString()}`}
              status={selectedAcc.type === 'treasury' ? 'nominal' : 'nominal'}
            />
            <SFDataField
              label="Token Portfolios"
              value={`${selectedAcc.tokens.length}`}
              unit="ASSETS"
              subValue="EVM Standard"
            />
            <SFDataField
              label="Nonce Sequencer"
              value={`#${selectedAcc.nonce}`}
              subValue="Sequence Counter"
            />
            <SFDataField
              label="Total Activity"
              value={`${selectedAcc.txCount}`}
              unit="TXs"
              subValue="Lifetime Operations"
            />
          </div>

          {/* Account Address Specification */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2">
            <div className="flex items-center justify-between border-b border-[var(--sf-border)] pb-2">
              <span className="font-bold text-[var(--sf-text)] uppercase text-xs">{selectedAcc.label}</span>
              <span className="text-[10px] text-[var(--sf-accent)] uppercase">{selectedAcc.type} SECURE CHAMBER</span>
            </div>
            <div>
              <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">ACCOUNT ADDRESS</span>
              <span className="text-[11px] text-[var(--sf-text)] select-all break-all font-bold">{selectedAcc.address}</span>
            </div>
          </div>

          {/* Token Holdings Table */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2">
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs border-b border-[var(--sf-border)] pb-2 flex items-center gap-2">
              <Coins className="w-3.5 h-3.5 text-[var(--sf-brass)]" />
              TOKENIZED INFRASTRUCTURE ASSETS & STERLING HOLDINGS ({selectedAcc.tokens.length})
            </span>

            {selectedAcc.tokens.length === 0 ? (
              <div className="py-4 text-center text-xs text-[var(--sf-text-dim)]">NO SECONDARY TOKEN ASSETS IN VAULT</div>
            ) : (
              <div className="divide-y divide-[var(--sf-border-subtle)]">
                {selectedAcc.tokens.map((tok) => (
                  <div key={tok.symbol} className="py-2.5 flex items-center justify-between">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-[var(--sf-text)] text-sm">{tok.symbol}</span>
                        <span className="text-[10px] text-[var(--sf-text-muted)]">{tok.name}</span>
                      </div>
                      <span className="text-[10px] text-[var(--sf-text-dim)] truncate max-w-xs">{tok.contractAddress}</span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="font-bold text-[var(--sf-text)] text-sm">{tok.balance.toLocaleString()} {tok.symbol}</span>
                      <span className="text-[10px] text-[var(--sf-green)]">£{(tok.usdValue * 0.78).toLocaleString()} EST</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Account Activity History */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2">
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs border-b border-[var(--sf-border)] pb-2 flex items-center gap-2">
              <History className="w-3.5 h-3.5 text-[var(--sf-accent)]" />
              ACCOUNT OPERATION LEDGER ({accTxs.length})
            </span>

            <div className="divide-y divide-[var(--sf-border-subtle)]">
              {accTxs.slice(0, 8).map((tx) => (
                <div
                  key={tx.hash}
                  onClick={() => onSelectTx(tx)}
                  className="py-2 flex items-center justify-between hover:bg-[var(--sf-surface-elevated)] px-2 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className={`w-2 h-2 rounded-full ${tx.from === selectedAcc.address ? 'bg-[var(--sf-amber)]' : 'bg-[var(--sf-green)]'}`} />
                    <span className="text-xs text-[var(--sf-text)] truncate">{tx.hash.slice(0, 16)}...</span>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-semibold text-[var(--sf-text)]">
                      {tx.from === selectedAcc.address ? '-' : '+'}{tx.valueEth.toFixed(3)} ETH
                    </span>
                    <span className="text-[9px] px-1 py-0.2 bg-[var(--sf-border-subtle)] text-[var(--sf-text-dim)] uppercase">{tx.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
