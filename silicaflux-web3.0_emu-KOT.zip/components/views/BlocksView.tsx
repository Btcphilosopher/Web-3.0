'use client';

import React, { useState } from 'react';
import { Web3Block, Web3Transaction } from '@/lib/types';
import { SFDataField } from '../ui/SFDataField';
import { SFGauge } from '../ui/SFGauge';
import { SFButton } from '../ui/SFButton';
import { soundFx } from '@/lib/audio/soundSystem';
import { Box, Layers, Hash, CheckCircle2, ChevronRight, FileCode, Clock } from 'lucide-react';

interface BlocksViewProps {
  blocks: Web3Block[];
  transactions: Web3Transaction[];
  onSelectTx: (tx: Web3Transaction) => void;
}

export const BlocksView: React.FC<BlocksViewProps> = ({
  blocks,
  transactions,
  onSelectTx,
}) => {
  const [selectedBlock, setSelectedBlock] = useState<Web3Block>(blocks[0] || null);

  const handleSelect = (b: Web3Block) => {
    soundFx.playClick(980);
    setSelectedBlock(b);
  };

  const currentBlockTxs = transactions.filter(t => t.blockHeight === selectedBlock?.height);

  return (
    <div className="flex flex-col lg:flex-row h-full w-full gap-3 p-3 overflow-hidden select-none font-mono">
      {/* Left List of Monolithic Archive Blocks */}
      <div className="w-full lg:w-96 flex flex-col bg-[var(--sf-surface)] border border-[var(--sf-border)] overflow-hidden shrink-0">
        <div className="p-3 bg-[var(--sf-surface-elevated)] border-b border-[var(--sf-border)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Box className="w-4 h-4 text-[var(--sf-accent)]" />
            <span className="text-xs font-bold text-[var(--sf-text)] uppercase">MONOLITHIC BLOCK ARCHIVE</span>
          </div>
          <span className="text-[10px] text-[var(--sf-text-dim)]">{blocks.length} BLOCKS STORED</span>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-[var(--sf-border-subtle)] scrollbar-thin">
          {blocks.map((b) => {
            const isSelected = selectedBlock?.height === b.height;
            return (
              <div
                key={b.height}
                onClick={() => handleSelect(b)}
                className={`p-3 cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[var(--sf-accent-subtle)] border-l-3 border-[var(--sf-accent)] text-[var(--sf-text)]'
                    : 'hover:bg-[var(--sf-surface-subtle)] text-[var(--sf-text-muted)]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-[var(--sf-text)]">#{b.height}</span>
                    <span className="text-[10px] px-1.5 py-0.2 bg-[var(--sf-border-subtle)] text-[var(--sf-text-dim)]">
                      {b.validatorRegion.split(' ')[0]}
                    </span>
                  </div>
                  <span className="text-xs text-[var(--sf-text-muted)]">{b.txCount} TXs</span>
                </div>

                {/* Gas Ratio Progress Bar */}
                <div className="mt-2 w-full h-1 bg-[var(--sf-surface-subtle)] overflow-hidden">
                  <div
                    className="h-full bg-[var(--sf-accent)] transition-all duration-300"
                    style={{ width: `${b.gasRatio * 100}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[10px] text-[var(--sf-text-dim)] mt-1.5 truncate">
                  <span className="truncate">{b.hash.slice(0, 18)}...</span>
                  <span className="shrink-0">{(b.gasRatio * 100).toFixed(0)}% GAS</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Selected Block Detailed Inspector */}
      {selectedBlock ? (
        <div className="flex-1 flex flex-col gap-3 overflow-y-auto scrollbar-thin">
          {/* Header Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <SFDataField
              label="Block Height"
              value={`#${selectedBlock.height}`}
              subValue="Confirmed Finality"
              status="nominal"
            />
            <SFDataField
              label="Transactions"
              value={`${selectedBlock.txCount}`}
              unit="TXs"
              subValue={`${selectedBlock.sizeKb} KB Payload`}
            />
            <SFDataField
              label="Base Fee"
              value={`${selectedBlock.baseFeeGwei}`}
              unit="GWEI"
              subValue="EIP-1559 Elastic"
            />
            <SFDataField
              label="Gas Used"
              value={`${(selectedBlock.gasRatio * 100).toFixed(1)}%`}
              subValue={`${(selectedBlock.gasUsed / 1000000).toFixed(2)}M / 30M`}
            />
          </div>

          {/* Block Hashes & Validator Details */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3 text-xs">
            <div className="flex items-center justify-between border-b border-[var(--sf-border)] pb-2">
              <span className="font-bold text-[var(--sf-text)] uppercase text-xs">ARCHIVE METRIC SPECIFICATION</span>
              <div className="flex items-center gap-1.5 text-[var(--sf-green)] text-[11px]">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>EVM STATE CONFIRMED</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">BLOCK HASH</span>
                <span className="text-[11px] text-[var(--sf-text)] select-all break-all">{selectedBlock.hash}</span>
              </div>
              <div>
                <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">PARENT HASH</span>
                <span className="text-[11px] text-[var(--sf-text)] select-all break-all">{selectedBlock.parentHash}</span>
              </div>
              <div>
                <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">STATE ROOT MERKLE</span>
                <span className="text-[11px] text-[var(--sf-text)] select-all break-all">{selectedBlock.stateRoot}</span>
              </div>
              <div>
                <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">VALIDATOR SIGNATURE NODE</span>
                <span className="text-[11px] text-[var(--sf-accent)] font-semibold">{selectedBlock.validator} ({selectedBlock.validatorRegion})</span>
              </div>
            </div>
          </div>

          {/* State Differences Delta */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2 text-xs">
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs border-b border-[var(--sf-border)] pb-2">
              Δ MERKLE STATE MUTATIONS ({selectedBlock.stateDiffs.length})
            </span>
            <div className="divide-y divide-[var(--sf-border-subtle)]">
              {selectedBlock.stateDiffs.map((diff, i) => (
                <div key={i} className="py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px]">
                  <span className="text-[var(--sf-text-muted)] truncate max-w-xs">{diff.address}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[var(--sf-text-dim)] line-through">{diff.oldVal}</span>
                    <span className="text-[var(--sf-text-dim)]">→</span>
                    <span className="text-[var(--sf-green)] font-semibold">{diff.newVal}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Included Transactions List */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2 text-xs">
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs border-b border-[var(--sf-border)] pb-2">
              INCLUDED TRANSACTIONS ({currentBlockTxs.length || selectedBlock.txCount})
            </span>

            <div className="divide-y divide-[var(--sf-border-subtle)]">
              {(currentBlockTxs.length > 0 ? currentBlockTxs : transactions.slice(0, selectedBlock.txCount)).map((tx) => (
                <div
                  key={tx.hash}
                  onClick={() => onSelectTx(tx)}
                  className="py-2 flex items-center justify-between hover:bg-[var(--sf-surface-elevated)] px-2 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3 truncate">
                    <span className={`w-2 h-2 rounded-full ${tx.type === 'contract_call' ? 'bg-[var(--sf-accent)]' : 'bg-[var(--sf-green)]'}`} />
                    <div className="flex flex-col truncate">
                      <span className="text-xs text-[var(--sf-text)] truncate">{tx.hash}</span>
                      <span className="text-[10px] text-[var(--sf-text-dim)]">From: {tx.from.slice(0, 12)}... → To: {tx.to.slice(0, 12)}...</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-semibold text-[var(--sf-text)]">{tx.valueEth.toFixed(3)} ETH</span>
                    <ChevronRight className="w-3.5 h-3.5 text-[var(--sf-text-dim)]" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
