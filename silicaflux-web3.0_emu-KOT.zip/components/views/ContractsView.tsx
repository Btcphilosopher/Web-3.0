'use client';

import React, { useState } from 'react';
import { SmartContract, Web3Transaction } from '@/lib/types';
import { SFDataField } from '../ui/SFDataField';
import { SFButton } from '../ui/SFButton';
import { soundFx } from '@/lib/audio/soundSystem';
import { web3Emu } from '@/lib/web3emu/engine';
import { Cpu, Terminal, Play, Database, FileCode, CheckCircle2, ChevronRight } from 'lucide-react';

interface ContractsViewProps {
  contracts: Record<string, SmartContract>;
  onSelectTx: (tx: Web3Transaction) => void;
}

export const ContractsView: React.FC<ContractsViewProps> = ({
  contracts,
  onSelectTx,
}) => {
  const contractList = Object.values(contracts);
  const [selectedContract, setSelectedContract] = useState<SmartContract>(contractList[0]);
  const [activeTab, setActiveTab] = useState<'methods' | 'storage' | 'code'>('methods');
  const [executingMethod, setExecutingMethod] = useState<string | null>(null);

  const handleRunMethod = (methodName: string) => {
    setExecutingMethod(methodName);
    soundFx.playConfirm();

    // Inject simulated contract interaction into Web3EMU
    const fromAcc = '0x4A81b2C1A3F9D701E788B2c7d91e6b78E3f2A180';
    web3Emu.injectUserTransaction(fromAcc, selectedContract.address, 0.0, 'contract_call', methodName);

    setTimeout(() => {
      setExecutingMethod(null);
    }, 500);
  };

  return (
    <div className="flex flex-col lg:flex-row h-full w-full gap-3 p-3 overflow-hidden select-none font-mono text-xs">
      {/* Left List: Smart Contract Machines */}
      <div className="w-full lg:w-96 flex flex-col bg-[var(--sf-surface)] border border-[var(--sf-border)] overflow-hidden shrink-0">
        <div className="p-3 bg-[var(--sf-surface-elevated)] border-b border-[var(--sf-border)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-[var(--sf-accent)]" />
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs">COMPUTATIONAL MACHINES</span>
          </div>
          <span className="text-[10px] text-[var(--sf-text-dim)]">{contractList.length} DEPLOYED</span>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-[var(--sf-border-subtle)] scrollbar-thin">
          {contractList.map((c) => {
            const isSelected = selectedContract?.address === c.address;
            return (
              <div
                key={c.address}
                onClick={() => {
                  soundFx.playClick(940);
                  setSelectedContract(c);
                }}
                className={`p-3 cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[var(--sf-accent-subtle)] border-l-3 border-[var(--sf-accent)] text-[var(--sf-text)]'
                    : 'hover:bg-[var(--sf-surface-subtle)] text-[var(--sf-text-muted)]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[var(--sf-text)] text-sm">{c.name}</span>
                  <span className="text-[9px] px-1.5 py-0.2 bg-[var(--sf-accent-subtle)] text-[var(--sf-accent)] font-semibold uppercase">
                    ONLINE
                  </span>
                </div>

                <div className="flex items-center justify-between text-[10px] text-[var(--sf-text-dim)] mt-1.5 truncate">
                  <span className="truncate">{c.address}</span>
                  <span>{c.totalCalls} CALLS</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Selected Contract Machine Interface */}
      {selectedContract && (
        <div className="flex-1 flex flex-col gap-3 overflow-y-auto scrollbar-thin">
          {/* Top Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <SFDataField
              label="Machine Name"
              value={selectedContract.name.slice(0, 14)}
              subValue="EVM 2040 Bytecode"
            />
            <SFDataField
              label="Callable Methods"
              value={`${selectedContract.methods.length}`}
              unit="FUNCS"
              subValue="ABI Defined"
            />
            <SFDataField
              label="Storage Slots"
              value={`${selectedContract.storageSlots.length}`}
              unit="SLOTS"
              subValue="Persistent State"
            />
            <SFDataField
              label="Total Executions"
              value={`${selectedContract.totalCalls}`}
              unit="CALLS"
              subValue="State Mutations"
            />
          </div>

          {/* Sub Navigation Bar */}
          <div className="flex items-center gap-1 bg-[var(--sf-surface)] border border-[var(--sf-border)] p-1">
            <button
              onClick={() => setActiveTab('methods')}
              className={`px-3 py-1.5 text-xs uppercase font-semibold transition-colors ${
                activeTab === 'methods'
                  ? 'bg-[var(--sf-surface-elevated)] text-[var(--sf-accent)] border border-[var(--sf-accent)]/30'
                  : 'text-[var(--sf-text-dim)] hover:text-[var(--sf-text)]'
              }`}
            >
              METHODS ({selectedContract.methods.length})
            </button>
            <button
              onClick={() => setActiveTab('storage')}
              className={`px-3 py-1.5 text-xs uppercase font-semibold transition-colors ${
                activeTab === 'storage'
                  ? 'bg-[var(--sf-surface-elevated)] text-[var(--sf-accent)] border border-[var(--sf-accent)]/30'
                  : 'text-[var(--sf-text-dim)] hover:text-[var(--sf-text)]'
              }`}
            >
              STORAGE SLOTS ({selectedContract.storageSlots.length})
            </button>
            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1.5 text-xs uppercase font-semibold transition-colors ${
                activeTab === 'code'
                  ? 'bg-[var(--sf-surface-elevated)] text-[var(--sf-accent)] border border-[var(--sf-accent)]/30'
                  : 'text-[var(--sf-text-dim)] hover:text-[var(--sf-text)]'
              }`}
            >
              BYTECODE & SOURCE
            </button>
          </div>

          {/* Tab 1: Methods Sandboxing */}
          {activeTab === 'methods' && (
            <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
              <span className="font-bold text-[var(--sf-text)] uppercase text-xs border-b border-[var(--sf-border)] pb-2">
                INTERACTIVE METHOD DISPATCH SANDBOX
              </span>

              <div className="divide-y divide-[var(--sf-border-subtle)]">
                {selectedContract.methods.map((m) => (
                  <div key={m.name} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-[var(--sf-text)] text-sm">{m.name}()</span>
                        <span className={`text-[9px] px-1 py-0.2 uppercase ${
                          m.stateMutability === 'view' ? 'bg-[var(--sf-accent-subtle)] text-[var(--sf-accent)]' : 'bg-[var(--sf-green-subtle)] text-[var(--sf-green)]'
                        }`}>
                          {m.stateMutability}
                        </span>
                      </div>
                      <span className="text-[10px] text-[var(--sf-text-dim)] mt-0.5">
                        Inputs: {m.inputs.map(i => `${i.type} ${i.name}`).join(', ') || 'none'} → Returns: {m.outputs.map(o => o.type).join(', ') || 'void'}
                      </span>
                    </div>

                    <SFButton
                      size="sm"
                      variant="primary"
                      disabled={executingMethod === m.name}
                      onClick={() => handleRunMethod(m.name)}
                    >
                      {executingMethod === m.name ? 'EXECUTING...' : 'CALL METHOD ↵'}
                    </SFButton>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 2: Storage Slots */}
          {activeTab === 'storage' && (
            <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
              <span className="font-bold text-[var(--sf-text)] uppercase text-xs border-b border-[var(--sf-border)] pb-2 flex items-center gap-2">
                <Database className="w-3.5 h-3.5 text-[var(--sf-accent)]" />
                EVM PERSISTENT STORAGE LAYOUT SLOTS
              </span>

              <div className="divide-y divide-[var(--sf-border-subtle)]">
                {selectedContract.storageSlots.map((slot) => (
                  <div key={slot.slot} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <div className="flex flex-col">
                      <span className="font-bold text-[var(--sf-text)]">{slot.variableName} ({slot.type})</span>
                      <span className="text-[10px] text-[var(--sf-text-dim)] truncate max-w-xs">{slot.slot}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-mono text-[var(--sf-green)] font-semibold">{slot.value}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: Source Code */}
          {activeTab === 'code' && (
            <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2">
              <div className="flex items-center justify-between border-b border-[var(--sf-border)] pb-2">
                <span className="font-bold text-[var(--sf-text)] uppercase text-xs flex items-center gap-2">
                  <FileCode className="w-3.5 h-3.5 text-[var(--sf-accent)]" />
                  VERIFIED HIGH-INTEGRITY CONTRACT CODE
                </span>
                <span className="text-[10px] text-[var(--sf-text-dim)]">{selectedContract.compiler}</span>
              </div>
              <pre className="p-3 bg-[var(--sf-bg)] border border-[var(--sf-border-subtle)] text-[11px] text-[var(--sf-text-muted)] overflow-x-auto font-mono scrollbar-thin">
                {selectedContract.codeSnippet}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
