'use client';

import React, { useState } from 'react';
import { Web3Transaction, Web3Account, SmartContract } from '@/lib/types';
import { SFDataField } from '../ui/SFDataField';
import { SFButton } from '../ui/SFButton';
import { SFSignal } from '../ui/SFSignal';
import { web3Emu } from '@/lib/web3emu/engine';
import { soundFx } from '@/lib/audio/soundSystem';
import { 
  ArrowLeftRight, 
  Send, 
  CheckCircle2, 
  Clock, 
  Cpu, 
  Terminal, 
  ChevronRight,
  Sparkles,
  Layers
} from 'lucide-react';

interface TransactionsViewProps {
  transactions: Web3Transaction[];
  mempool: Web3Transaction[];
  accounts: Record<string, Web3Account>;
  contracts: Record<string, SmartContract>;
  selectedTx: Web3Transaction | null;
  onSelectTx: (tx: Web3Transaction) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  transactions,
  mempool,
  accounts,
  contracts,
  selectedTx,
  onSelectTx,
}) => {
  const [activeTx, setActiveTx] = useState<Web3Transaction>(selectedTx || transactions[0] || null);
  
  // Custom Transaction Injection state
  const [fromAccount, setFromAccount] = useState<string>(Object.keys(accounts)[0] || '');
  const [toTarget, setToTarget] = useState<string>(Object.keys(contracts)[0] || Object.keys(accounts)[1] || '');
  const [txValue, setTxValue] = useState<string>('1.5');
  const [isInjecting, setIsInjecting] = useState<boolean>(false);

  const lifecycleStages = [
    { id: 'created', label: 'CREATED' },
    { id: 'signed', label: 'SIGNED' },
    { id: 'submitted', label: 'SUBMITTED' },
    { id: 'mempool', label: 'MEMPOOL' },
    { id: 'executing', label: 'EXECUTING' },
    { id: 'block', label: 'BLOCK' },
    { id: 'final', label: 'FINAL' },
  ];

  const handleInjectTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fromAccount || !toTarget) return;

    setIsInjecting(true);
    soundFx.playConfirm();

    const newTx = web3Emu.injectUserTransaction(
      fromAccount,
      toTarget,
      parseFloat(txValue) || 0.5,
      contracts[toTarget] ? 'contract_call' : 'transfer',
      contracts[toTarget] ? 'swapExactTokensForTokens' : undefined
    );

    setActiveTx(newTx);
    setTimeout(() => setIsInjecting(false), 400);
  };

  const getStageIndex = (status: string) => {
    switch (status) {
      case 'created': return 0;
      case 'signed': return 1;
      case 'submitted': return 2;
      case 'mempool': return 3;
      case 'executing': return 4;
      case 'block': return 5;
      case 'final': return 6;
      default: return 6;
    }
  };

  const currentStageIdx = activeTx ? getStageIndex(activeTx.status) : 6;

  return (
    <div className="flex flex-col lg:flex-row h-full w-full gap-3 p-3 overflow-hidden select-none font-mono text-xs">
      {/* Left List: Mempool & Confirmed Transactions */}
      <div className="w-full lg:w-96 flex flex-col bg-[var(--sf-surface)] border border-[var(--sf-border)] overflow-hidden shrink-0">
        {/* Inject Transaction Header Panel */}
        <div className="p-3 bg-[var(--sf-surface-elevated)] border-b border-[var(--sf-border)] flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs flex items-center gap-1.5">
              <Send className="w-3.5 h-3.5 text-[var(--sf-accent)]" />
              INJECT VALUE DISPATCH
            </span>
            <span className="text-[10px] text-[var(--sf-text-dim)]">EVM PROTOCOL</span>
          </div>

          <form onSubmit={handleInjectTx} className="flex flex-col gap-2 mt-1">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[9px] text-[var(--sf-text-dim)] uppercase block">ORIGIN</label>
                <select
                  value={fromAccount}
                  onChange={(e) => setFromAccount(e.target.value)}
                  className="w-full bg-[var(--sf-bg)] border border-[var(--sf-border)] p-1 text-[10px] text-[var(--sf-text)] truncate font-mono focus:outline-none"
                >
                  {Object.values(accounts).map(a => (
                    <option key={a.address} value={a.address}>{a.label.slice(0, 16)}...</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[9px] text-[var(--sf-text-dim)] uppercase block">TARGET</label>
                <select
                  value={toTarget}
                  onChange={(e) => setToTarget(e.target.value)}
                  className="w-full bg-[var(--sf-bg)] border border-[var(--sf-border)] p-1 text-[10px] text-[var(--sf-text)] truncate font-mono focus:outline-none"
                >
                  {Object.values(contracts).map(c => (
                    <option key={c.address} value={c.address}>[MACHINE] {c.name.slice(0, 12)}</option>
                  ))}
                  {Object.values(accounts).map(a => (
                    <option key={a.address} value={a.address}>[VAULT] {a.label.slice(0, 12)}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="number"
                step="0.1"
                min="0.01"
                value={txValue}
                onChange={(e) => setTxValue(e.target.value)}
                placeholder="ETH Amount"
                className="w-24 bg-[var(--sf-bg)] border border-[var(--sf-border)] px-2 py-1 text-xs text-[var(--sf-text)] font-mono"
              />
              <SFButton type="submit" variant="primary" size="sm" className="flex-1">
                DISPATCH TX ↵
              </SFButton>
            </div>
          </form>
        </div>

        {/* Mempool Badge if pending */}
        {mempool.length > 0 && (
          <div className="px-3 py-1.5 bg-[var(--sf-amber-subtle)] border-b border-[var(--sf-amber)]/40 flex items-center justify-between text-[11px] text-[var(--sf-amber)]">
            <span className="font-semibold">{mempool.length} PENDING IN MEMPOOL</span>
            <span className="animate-pulse">PROCESSING...</span>
          </div>
        )}

        {/* Transactions Feed */}
        <div className="flex-1 overflow-y-auto divide-y divide-[var(--sf-border-subtle)] scrollbar-thin">
          {[...mempool, ...transactions].map((tx) => {
            const isSelected = activeTx?.hash === tx.hash;
            return (
              <div
                key={tx.hash}
                onClick={() => {
                  soundFx.playClick(920);
                  setActiveTx(tx);
                  onSelectTx(tx);
                }}
                className={`p-3 cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[var(--sf-accent-subtle)] border-l-3 border-[var(--sf-accent)] text-[var(--sf-text)]'
                    : 'hover:bg-[var(--sf-surface-subtle)] text-[var(--sf-text-muted)]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 truncate">
                    <span className={`w-2 h-2 rounded-full ${tx.status === 'mempool' ? 'bg-[var(--sf-amber)]' : tx.type === 'contract_call' ? 'bg-[var(--sf-accent)]' : 'bg-[var(--sf-green)]'}`} />
                    <span className="font-bold text-[var(--sf-text)] truncate">{tx.hash.slice(0, 14)}...</span>
                  </div>
                  <span className="font-bold text-[var(--sf-text)]">{tx.valueEth.toFixed(3)} ETH</span>
                </div>

                <div className="flex items-center justify-between text-[10px] text-[var(--sf-text-dim)] mt-1 truncate">
                  <span className="truncate">{tx.method || tx.type.toUpperCase()}</span>
                  <span className="uppercase text-[9px] px-1 py-0.2 bg-[var(--sf-border-subtle)]">{tx.status}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Selected Transaction Lifecycle & Opcode Traces */}
      {activeTx ? (
        <div className="flex-1 flex flex-col gap-3 overflow-y-auto scrollbar-thin">
          {/* Lifecycle State Machine Railway Indicator */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs border-b border-[var(--sf-border)] pb-2">
              TRANSACTION LIFECYCLE STATE MACHINE // 2040 TRANSIT
            </span>

            <div className="grid grid-cols-7 gap-1 text-center font-mono">
              {lifecycleStages.map((stage, idx) => {
                const isPassed = idx <= currentStageIdx;
                const isCurrent = idx === currentStageIdx;
                return (
                  <div
                    key={stage.id}
                    className={`py-2 px-1 flex flex-col items-center justify-center border transition-all ${
                      isCurrent
                        ? 'bg-[var(--sf-accent)] text-white border-[var(--sf-accent)] font-bold shadow-sm'
                        : isPassed
                        ? 'bg-[var(--sf-surface-elevated)] text-[var(--sf-text)] border-[var(--sf-border-strong)]'
                        : 'bg-[var(--sf-bg)] text-[var(--sf-text-dim)] border-[var(--sf-border-subtle)] opacity-40'
                    }`}
                  >
                    <span className="text-[10px] tracking-wider">{stage.label}</span>
                    <span className="text-[9px] mt-1 opacity-80">{isPassed ? '✓' : '—'}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Core Transaction Fields */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <SFDataField
              label="Value Transferred"
              value={`${activeTx.valueEth.toFixed(3)}`}
              unit="ETH"
              subValue="Asset Settlement"
            />
            <SFDataField
              label="Gas Limit / Used"
              value={`${activeTx.gasUsed.toLocaleString()}`}
              subValue={`${activeTx.gasPriceGwei} Gwei`}
            />
            <SFDataField
              label="Nonce"
              value={`#${activeTx.nonce}`}
              subValue="Account Sequencer"
            />
            <SFDataField
              label="Inclusion Block"
              value={activeTx.blockHeight ? `#${activeTx.blockHeight}` : 'MEMPOOL'}
              status={activeTx.blockHeight ? 'nominal' : 'warning'}
            />
          </div>

          {/* Addresses & Hashes */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">FROM SENDER</span>
                <span className="text-[11px] text-[var(--sf-text)] break-all select-all">{activeTx.from}</span>
              </div>
              <div>
                <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">TO RECIPIENT</span>
                <span className="text-[11px] text-[var(--sf-accent)] break-all select-all">{activeTx.to}</span>
              </div>
              <div className="md:col-span-2">
                <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">CANONICAL TX HASH</span>
                <span className="text-[11px] text-[var(--sf-text)] break-all select-all font-bold">{activeTx.hash}</span>
              </div>
            </div>
          </div>

          {/* EVM Opcode Execution Trace */}
          {activeTx.executionTrace && (
            <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2">
              <div className="flex items-center justify-between border-b border-[var(--sf-border)] pb-2">
                <span className="font-bold text-[var(--sf-text)] uppercase text-xs flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-[var(--sf-accent)]" />
                  EVM OPCODES & SUB-CALL EXECUTION TRACE
                </span>
                <span className="text-[10px] text-[var(--sf-text-dim)]">
                  {activeTx.executionTrace.steps.length} OPCODES EXECUTED
                </span>
              </div>

              <div className="divide-y divide-[var(--sf-border-subtle)] max-h-64 overflow-y-auto font-mono text-[11px] scrollbar-thin">
                {activeTx.executionTrace.steps.map((st) => (
                  <div key={st.pc} className="py-1.5 flex items-center justify-between hover:bg-[var(--sf-surface-elevated)] px-2">
                    <div className="flex items-center gap-3">
                      <span className="text-[var(--sf-text-dim)] w-8">[{st.pc}]</span>
                      <span className="font-bold text-[var(--sf-text)]">{st.op}</span>
                      {st.storageDiff && (
                        <span className="text-[var(--sf-green)] text-[10px]">
                          {st.storageDiff.key}: {st.storageDiff.prev} → {st.storageDiff.next}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-[var(--sf-text-dim)]">{st.gasCost} GAS</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
};
