'use client';

import React, { useState } from 'react';
import { SFButton } from '../ui/SFButton';
import { soundFx } from '@/lib/audio/soundSystem';
import { web3Emu } from '@/lib/web3emu/engine';
import { Terminal, Play, Send, Zap, Trash2, CheckCircle2 } from 'lucide-react';

export const DeveloperConsoleView: React.FC = () => {
  const [method, setMethod] = useState('eth_blockNumber');
  const [paramsStr, setParamsStr] = useState('[]');
  const [rpcResponse, setRpcResponse] = useState<string>('{\n  "jsonrpc": "2.0",\n  "result": "0x20e5",\n  "id": 1\n}');
  const [eventLogs, setEventLogs] = useState<string[]>([
    '[RPC] Engine initialized: SILICAFLUX EVM 2040 (London LSE Node Mesh)',
    '[MEMPOOL] 4 transactions verified and signed via Ed25519-2040 curve',
    '[MINER] Block #8421 sealed by Harwell Substation Node (Hash: 0x8f2d...b14e)',
    '[QUANT] RhinoQuant recalculated Gini Index (0.42) & Shannon Entropy (0.89)',
  ]);

  const handleExecuteRpc = (e: React.FormEvent) => {
    e.preventDefault();
    soundFx.playConfirm();

    let parsedParams = [];
    try {
      parsedParams = JSON.parse(paramsStr || '[]');
    } catch {
      parsedParams = [];
    }

    const res = web3Emu.handleRpcRequest(method, parsedParams);
    setRpcResponse(JSON.stringify(res, null, 2));

    setEventLogs(prev => [
      `[RPC_CALL] ${method}(${paramsStr}) → Status: 200 OK`,
      ...prev.slice(0, 40)
    ]);
  };

  const handleRunPresetScenario = (scenario: 'lse_arbitrage' | 'harwell_spike' | 'node_outage' | 'sovereign_dividend') => {
    web3Emu.runScenario(scenario);
    soundFx.playAlert();
    setEventLogs(prev => [
      `[SCENARIO_TRIGGERED] Executed simulation profile: ${scenario.toUpperCase()}`,
      ...prev.slice(0, 40)
    ]);
  };

  return (
    <div className="flex flex-col lg:flex-row h-full w-full gap-3 p-3 overflow-hidden select-none font-mono text-xs">
      {/* Left Column: Interactive JSON-RPC Terminal */}
      <div className="flex-1 flex flex-col bg-[var(--sf-surface)] border border-[var(--sf-border)] overflow-hidden">
        <div className="p-3 bg-[var(--sf-surface-elevated)] border-b border-[var(--sf-border)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[var(--sf-accent)]" />
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs">JSON-RPC 2.0 PROTOCOL INTERACTION</span>
          </div>
          <span className="text-[10px] text-[var(--sf-green)]">PORT 3000 / RPC ACTIVE</span>
        </div>

        {/* RPC Request Form */}
        <form onSubmit={handleExecuteRpc} className="p-4 border-b border-[var(--sf-border)] flex flex-col gap-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-[var(--sf-text-dim)] uppercase block mb-1">RPC METHOD</label>
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value)}
                className="w-full bg-[var(--sf-bg)] border border-[var(--sf-border)] p-1.5 text-xs text-[var(--sf-text)] font-mono focus:outline-none"
              >
                <option value="eth_blockNumber">eth_blockNumber</option>
                <option value="eth_getBalance">eth_getBalance</option>
                <option value="eth_getBlockByNumber">eth_getBlockByNumber</option>
                <option value="eth_estimateGas">eth_estimateGas</option>
                <option value="web3_clientVersion">web3_clientVersion</option>
                <option value="silica_networkTopology">silica_networkTopology</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-[var(--sf-text-dim)] uppercase block mb-1">PARAMS (JSON ARRAY)</label>
              <input
                type="text"
                value={paramsStr}
                onChange={(e) => setParamsStr(e.target.value)}
                placeholder='["latest", true]'
                className="w-full bg-[var(--sf-bg)] border border-[var(--sf-border)] p-1.5 text-xs text-[var(--sf-text)] font-mono focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <SFButton type="submit" variant="primary" size="sm">
              SEND JSON-RPC REQUEST ↵
            </SFButton>
          </div>
        </form>

        {/* RPC Response Payload Display */}
        <div className="flex-1 flex flex-col p-4 bg-[var(--sf-bg)] overflow-hidden">
          <div className="flex items-center justify-between pb-2 border-b border-[var(--sf-border-subtle)] text-[10px] text-[var(--sf-text-dim)]">
            <span>RESPONSE BUFFER</span>
            <span>FORMAT: APPLICATION/JSON</span>
          </div>
          <pre className="flex-1 overflow-auto text-[11px] text-[var(--sf-accent)] p-2 font-mono scrollbar-thin">
            {rpcResponse}
          </pre>
        </div>
      </div>

      {/* Right Column: Scenario Triggers & Live Log Stream */}
      <div className="w-full lg:w-96 flex flex-col gap-3 shrink-0">
        {/* Scenario Injectors */}
        <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2.5">
          <span className="font-bold text-xs text-[var(--sf-text)] uppercase border-b border-[var(--sf-border)] pb-2 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-[var(--sf-accent)]" />
            STRESS SCENARIO INJECTORS
          </span>

          <SFButton size="sm" variant="secondary" onClick={() => handleRunPresetScenario('lse_arbitrage')}>
            LSE Arbitrage Wave (8 Rapid Txs)
          </SFButton>
          <SFButton size="sm" variant="secondary" onClick={() => handleRunPresetScenario('harwell_spike')}>
            Harwell Satellite Congestion Spike
          </SFButton>
          <SFButton size="sm" variant="secondary" onClick={() => handleRunPresetScenario('node_outage')}>
            Canary Wharf Node Outage
          </SFButton>
          <SFButton size="sm" variant="secondary" onClick={() => handleRunPresetScenario('sovereign_dividend')}>
            Sovereign Sterling Dividend Injection
          </SFButton>
        </div>

        {/* Live Protocol Event Log Stream */}
        <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2 flex-1 overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--sf-border)] pb-2 text-[10px] text-[var(--sf-text-dim)]">
            <span className="font-bold text-[var(--sf-text)] uppercase text-xs">EVENT LOG STREAM</span>
            <button
              onClick={() => setEventLogs([])}
              className="hover:text-[var(--sf-text)] transition-colors"
              title="Clear Logs"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-[var(--sf-border-subtle)] text-[10px] scrollbar-thin">
            {eventLogs.map((log, idx) => (
              <div key={idx} className="py-1.5 text-[var(--sf-text-muted)] font-mono">
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
