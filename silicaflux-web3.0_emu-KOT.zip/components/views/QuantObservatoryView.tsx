'use client';

import React from 'react';
import { QuantMetrics, QuantVisualParameters } from '@/lib/types';
import { SFDataField } from '../ui/SFDataField';
import { SFGauge } from '../ui/SFGauge';
import { SFSignal } from '../ui/SFSignal';
import { BarChart3, Activity, PieChart, ShieldAlert, Cpu, TrendingUp } from 'lucide-react';

interface QuantObservatoryViewProps {
  quant: QuantMetrics;
  visualParams: QuantVisualParameters;
}

export const QuantObservatoryView: React.FC<QuantObservatoryViewProps> = ({
  quant,
  visualParams,
}) => {
  return (
    <div className="flex flex-col h-full w-full gap-3 p-3 overflow-y-auto scrollbar-thin select-none font-mono text-xs">
      {/* Top Banner */}
      <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-none bg-[var(--sf-accent-subtle)] border border-[var(--sf-accent)] flex items-center justify-center">
            <span className="font-bold text-sm text-[var(--sf-accent)]">R</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-[var(--sf-text)] uppercase">RHINOQUANT // R STATISTICAL ENGINE</span>
              <span className="text-[10px] px-1.5 py-0.2 bg-[var(--sf-accent)] text-white font-bold">2040 QUANT INTELLIGENCE</span>
            </div>
            <span className="text-[11px] text-[var(--sf-text-dim)]">
              Real-time statistical transformations driving Anglo-futurist visual parameters
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <SFSignal
            state={visualParams.anomalyAlertLevel === 'critical' ? 'danger' : visualParams.anomalyAlertLevel === 'elevated' ? 'caution' : 'clear'}
            label={`ANOMALY: ${visualParams.anomalyAlertLevel.toUpperCase()}`}
          />
        </div>
      </div>

      {/* Primary Quantitative Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <SFDataField
          label="Shannon Entropy"
          value={`${quant.networkEntropy}`}
          subValue="Node Traffic Equilibrium"
          status="nominal"
        />
        <SFDataField
          label="Gini Concentration"
          value={`${quant.accountGiniIndex}`}
          subValue="Wealth Distribution Index"
        />
        <SFDataField
          label="P95 Latency"
          value={`${quant.latencyP95}`}
          unit="MS"
          subValue="Packet Transit Threshold"
        />
        <SFDataField
          label="Multivariate Anomaly"
          value={`${(quant.anomalyScore * 100).toFixed(1)}%`}
          subValue={quant.anomalyScore > 0.4 ? 'Elevated Drift' : 'Nominal Baseline'}
          status={quant.anomalyScore > 0.4 ? 'warning' : 'nominal'}
        />
      </div>

      {/* Main Visual Intelligence Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Chart 1: Gas Price Kernel Density Estimation (KDE) */}
        <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[var(--sf-border)] pb-2">
            <span className="font-bold text-xs text-[var(--sf-text)] uppercase flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-[var(--sf-accent)]" />
              GAS PRICE PROBABILITY DENSITY (GAUSSIAN KDE)
            </span>
            <span className="text-[10px] text-[var(--sf-text-dim)]">BANDWIDTH: 1.5 GWEI</span>
          </div>

          <div className="h-40 flex items-end gap-1.5 pt-4">
            {quant.kdeDistribution.map((item, i) => {
              const maxDensity = Math.max(...quant.kdeDistribution.map(d => d.density)) || 0.1;
              const heightPercent = Math.min(100, (item.density / maxDensity) * 100);
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                  <div
                    className="w-full bg-[var(--sf-accent)] opacity-80 group-hover:opacity-100 transition-all duration-300"
                    style={{ height: `${Math.max(4, heightPercent)}%` }}
                  />
                  {i % 4 === 0 && (
                    <span className="text-[8px] text-[var(--sf-text-dim)]">{item.bin}g</span>
                  )}
                </div>
              );
            })}
          </div>
          <span className="text-[10px] text-[var(--sf-text-dim)] text-center">Gas Price (Gwei) Distribution across recent blocks</span>
        </div>

        {/* Chart 2: Lorenz Curve Wealth Inequality */}
        <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-[var(--sf-border)] pb-2">
            <span className="font-bold text-xs text-[var(--sf-text)] uppercase flex items-center gap-1.5">
              <PieChart className="w-3.5 h-3.5 text-[var(--sf-brass)]" />
              LORENZ CONCENTRATION CURVE (GINI: {quant.accountGiniIndex})
            </span>
            <span className="text-[10px] text-[var(--sf-text-dim)]">ASSET EQUILIBRIUM</span>
          </div>

          <div className="h-40 flex items-end gap-1 pt-4 px-2">
            {quant.lorenzCurve.map((item, i) => (
              <div key={i} className="flex-1 flex flex-col items-center h-full justify-end group">
                <div
                  className="w-full bg-[var(--sf-brass)] opacity-80 group-hover:opacity-100 transition-all duration-300"
                  style={{ height: `${Math.max(2, item.share * 100)}%` }}
                />
                {i % 2 === 0 && (
                  <span className="text-[8px] text-[var(--sf-text-dim)]">{item.percentile}%</span>
                )}
              </div>
            ))}
          </div>
          <span className="text-[10px] text-[var(--sf-text-dim)] text-center">Cumulative Population Share vs Cumulative Wealth Share</span>
        </div>
      </div>

      {/* Derived Visual Parameter Matrix */}
      <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
        <span className="font-bold text-xs text-[var(--sf-text)] uppercase border-b border-[var(--sf-border)] pb-2">
          R-DERIVED DYNAMIC GUI VISUAL PARAMETERS
        </span>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-2.5 bg-[var(--sf-bg)] border border-[var(--sf-border-subtle)]">
            <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">LINE THICKNESS</span>
            <span className="font-bold text-[var(--sf-text)] text-sm">{visualParams.lineThickness.toFixed(2)} px</span>
            <span className="text-[9px] text-[var(--sf-text-dim)] mt-0.5 block">Driven by Shannon Entropy</span>
          </div>

          <div className="p-2.5 bg-[var(--sf-bg)] border border-[var(--sf-border-subtle)]">
            <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">SIGNAL SPEED</span>
            <span className="font-bold text-[var(--sf-text)] text-sm">{visualParams.signalSpeedMultiplier.toFixed(2)}x</span>
            <span className="text-[9px] text-[var(--sf-text-dim)] mt-0.5 block">Driven by TPS / Latency Ratio</span>
          </div>

          <div className="p-2.5 bg-[var(--sf-bg)] border border-[var(--sf-border-subtle)]">
            <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">PARTICLE DENSITY</span>
            <span className="font-bold text-[var(--sf-text)] text-sm">{visualParams.particleDensity} Particles</span>
            <span className="text-[9px] text-[var(--sf-text-dim)] mt-0.5 block">Driven by Mempool Load</span>
          </div>

          <div className="p-2.5 bg-[var(--sf-bg)] border border-[var(--sf-border-subtle)]">
            <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">CENTRALITY INDEX</span>
            <span className="font-bold text-[var(--sf-text)] text-sm">{visualParams.topologicalCentrality}</span>
            <span className="text-[9px] text-[var(--sf-text-dim)] mt-0.5 block">Topological Convergence</span>
          </div>
        </div>
      </div>
    </div>
  );
};
