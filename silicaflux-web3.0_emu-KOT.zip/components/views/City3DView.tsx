'use client';

import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { Web3Block, Web3Account, SmartContract, Web3Transaction } from '@/lib/types';
import { SFButton } from '../ui/SFButton';
import { soundFx } from '@/lib/audio/soundSystem';
import { Eye, RotateCcw, Box, Building2, Cpu, ArrowLeftRight } from 'lucide-react';

interface City3DViewProps {
  blocks: Web3Block[];
  accounts: Record<string, Web3Account>;
  contracts: Record<string, SmartContract>;
  recentTxs: Web3Transaction[];
  onSelectBlock: (height: number) => void;
}

export const City3DView: React.FC<City3DViewProps> = ({
  blocks,
  accounts,
  contracts,
  recentTxs,
  onSelectBlock,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedEntity, setSelectedEntity] = useState<string | null>(null);
  const [cameraAngle, setCameraAngle] = useState<'iso' | 'top' | 'front'>('iso');

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x090b0e);
    scene.fog = new THREE.FogExp2(0x090b0e, 0.015);

    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    camera.position.set(40, 50, 65);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 2. Lights (Restrained Architectural Studio Lighting)
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0x388bfd, 1.4);
    directionalLight.position.set(30, 60, 40);
    scene.add(directionalLight);

    const pointLight = new THREE.PointLight(0x3fb950, 1.2, 50);
    pointLight.position.set(0, 15, 0);
    scene.add(pointLight);

    // 3. Ground Architectural Grid
    const gridHelper = new THREE.GridHelper(100, 50, 0x26303b, 0x141a22);
    scene.add(gridHelper);

    // 4. Create Wallets as Architectural Buildings
    const accountList = Object.values(accounts);
    accountList.forEach((acc, i) => {
      const angle = (i / accountList.length) * Math.PI * 2;
      const radius = 26;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const bHeight = Math.max(4, Math.min(22, (acc.balanceEth / 1000) * 3 + 4));

      const geometry = new THREE.BoxGeometry(4.5, bHeight, 4.5);
      const material = new THREE.MeshStandardMaterial({
        color: acc.type === 'treasury' ? 0xc9a96e : 0x1f252e,
        metalness: 0.8,
        roughness: 0.2,
        wireframe: false,
      });

      const building = new THREE.Mesh(geometry, material);
      building.position.set(x, bHeight / 2, z);
      scene.add(building);

      // Building Wireframe edges
      const edges = new THREE.EdgesGeometry(geometry);
      const lineMaterial = new THREE.LineBasicMaterial({ color: 0x3d4a59 });
      const wireframe = new THREE.LineSegments(edges, lineMaterial);
      building.add(wireframe);
    });

    // 5. Create Blocks as Monolithic Archives in Center Stack
    blocks.slice(0, 6).forEach((blk, idx) => {
      const bWidth = 7;
      const bDepth = 7;
      const bHeight = 2.5;
      const y = idx * 3.2 + 1.5;

      const geometry = new THREE.BoxGeometry(bWidth, bHeight, bDepth);
      const material = new THREE.MeshStandardMaterial({
        color: idx === 0 ? 0x388bfd : 0x171c23,
        metalness: 0.9,
        roughness: 0.1,
      });

      const blockMesh = new THREE.Mesh(geometry, material);
      blockMesh.position.set(0, y, 0);
      scene.add(blockMesh);

      const edges = new THREE.EdgesGeometry(geometry);
      const lineMaterial = new THREE.LineBasicMaterial({ color: idx === 0 ? 0xffffff : 0x388bfd });
      const wireframe = new THREE.LineSegments(edges, lineMaterial);
      blockMesh.add(wireframe);
    });

    // 6. Create Smart Contracts as Computational Towers
    const contractList = Object.values(contracts);
    contractList.forEach((c, idx) => {
      const x = (idx - 1) * 16;
      const z = -18;
      const tHeight = 14;

      const geometry = new THREE.CylinderGeometry(2, 3, tHeight, 6);
      const material = new THREE.MeshStandardMaterial({
        color: 0x101419,
        metalness: 0.7,
        roughness: 0.3,
      });

      const tower = new THREE.Mesh(geometry, material);
      tower.position.set(x, tHeight / 2, z);
      scene.add(tower);

      const edges = new THREE.EdgesGeometry(geometry);
      const lineMaterial = new THREE.LineBasicMaterial({ color: 0x388bfd });
      const wireframe = new THREE.LineSegments(edges, lineMaterial);
      tower.add(wireframe);
    });

    // 7. Rail Traffic Lines (Connecting Wallets, Towers & Blocks)
    const curvePoints = [
      new THREE.Vector3(-20, 0.2, 20),
      new THREE.Vector3(-10, 0.2, 0),
      new THREE.Vector3(0, 0.2, 0),
      new THREE.Vector3(15, 0.2, -10),
      new THREE.Vector3(20, 0.2, 18),
    ];
    const curve = new THREE.CatmullRomCurve3(curvePoints);
    const railGeo = new THREE.TubeGeometry(curve, 32, 0.25, 6, false);
    const railMat = new THREE.MeshBasicMaterial({ color: 0x3d4a59, wireframe: true });
    const railMesh = new THREE.Mesh(railGeo, railMat);
    scene.add(railMesh);

    // 8. Animation & Rotation Loop
    let angle = 0;
    let animId: number;
    const animate = () => {
      angle += 0.002;
      camera.position.x = Math.cos(angle) * 60;
      camera.position.z = Math.sin(angle) * 60;
      camera.lookAt(0, 8, 0);

      renderer.render(scene, camera);
      animId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container) container.innerHTML = '';
    };
  }, [blocks, accounts, contracts]);

  return (
    <div className="relative w-full h-full flex flex-col p-3 overflow-hidden select-none">
      {/* 3D Viewport Header */}
      <div className="absolute top-6 left-6 z-10 flex flex-col gap-1 bg-[var(--sf-surface-elevated)]/90 backdrop-blur-xs border border-[var(--sf-border)] p-3 font-mono text-xs max-w-sm">
        <div className="flex items-center gap-2">
          <Building2 className="w-4 h-4 text-[var(--sf-accent)]" />
          <span className="font-bold text-[var(--sf-text)] uppercase">WEB3 CITY METAPHOR // 2040</span>
        </div>
        <p className="text-[11px] text-[var(--sf-text-muted)] mt-1">
          Wallets become sovereign buildings. Blocks form the central monolithic archive stack. Smart contracts stand as computational towers.
        </p>

        {/* Legend */}
        <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-[var(--sf-border)] text-[10px]">
          <div className="flex items-center gap-1.5 text-[var(--sf-brass)]">
            <span className="w-2.5 h-2.5 bg-[var(--sf-brass)]" />
            <span>TREASURY VAULTS</span>
          </div>
          <div className="flex items-center gap-1.5 text-[var(--sf-accent)]">
            <span className="w-2.5 h-2.5 bg-[var(--sf-accent)]" />
            <span>BLOCK ARCHIVES</span>
          </div>
          <div className="flex items-center gap-1.5 text-[var(--sf-text-muted)]">
            <span className="w-2.5 h-2.5 bg-[var(--sf-border-strong)]" />
            <span>SMART TOWERS</span>
          </div>
          <div className="flex items-center gap-1.5 text-[var(--sf-green)]">
            <span className="w-2.5 h-2.5 bg-[var(--sf-green)]" />
            <span>RAIL TRAFFIC</span>
          </div>
        </div>
      </div>

      {/* Primary Three.js Stage */}
      <div 
        ref={mountRef} 
        className="flex-1 w-full h-full bg-[var(--sf-bg)] border border-[var(--sf-border)] cursor-grab active:cursor-grabbing min-h-[480px]"
      />
    </div>
  );
};
