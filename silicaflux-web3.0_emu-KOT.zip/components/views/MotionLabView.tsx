'use client';

import React, { useState, useEffect, useRef } from 'react';
import { SpringSimulator, KotlinMotionGrammar } from '@/lib/kotlinMotion/motionCore';
import { SFButton } from '../ui/SFButton';
import { SFDataField } from '../ui/SFDataField';
import { soundFx } from '@/lib/audio/soundSystem';
import { Zap, Play, RefreshCw, Sliders, Activity, Sparkles } from 'lucide-react';

export const MotionLabView: React.FC = () => {
  const [stiffness, setStiffness] = useState<number>(180);
  const [damping, setDamping] = useState<number>(20);
  const [mass, setMass] = useState<number>(1.0);
  const [activePrimitive, setActivePrimitive] = useState<string>('SSpring');
  
  // Simulated Motion Physics
  const [springPos, setSpringPos] = useState<number>(0);
  const [springVelocity, setSpringVelocity] = useState<number>(0);
  const [targetPos, setTargetPos] = useState<number>(0);
  const targetPosRef = useRef<number>(0);
  const currentPosRef = useRef<number>(0);
  const currentVelRef = useRef<number>(0);

  const primitives = [
    { id: 'SFade', label: 'SFade', desc: 'Alpha opacity transitions' },
    { id: 'SScale', label: 'SScale', desc: 'Dimensional expansion and contraction' },
    { id: 'STranslate', label: 'STranslate', desc: 'Cartesian spatial movement' },
    { id: 'SReveal', label: 'SReveal', desc: 'Clip-path architectural uncover' },
    { id: 'SExpand', label: 'SExpand', desc: 'Layout accordion dimension unfolding' },
    { id: 'SFlow', label: 'SFlow', desc: 'Particle river trajectory physics' },
    { id: 'SPulse', label: 'SPulse', desc: 'Electromagnetic rhythmic heartbeat' },
    { id: 'SSpring', label: 'SSpring', desc: 'Second-order harmonic spring oscillation' },
    { id: 'SInterrupt', label: 'SInterrupt', desc: 'Zero-latency velocity preserving interruption' },
  ];

  // Run Real-Time Spring Physics Loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = (time: number) => {
      const dt = Math.min((time - lastTime) / 1000, 0.05);
      lastTime = time;

      const spring = new SpringSimulator(stiffness, damping, mass);
      const next = spring.update(currentPosRef.current, currentVelRef.current, targetPosRef.current, dt);

      currentPosRef.current = next.position;
      currentVelRef.current = next.velocity;
      setSpringPos(next.position);
      setSpringVelocity(next.velocity);

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [stiffness, damping, mass]);

  const handleTriggerMotion = (primId: string) => {
    setActivePrimitive(primId);
    soundFx.playClick(1000);

    const nextTarget = primId === 'SInterrupt' 
      ? (targetPosRef.current > 100 ? 0 : 220)
      : (targetPosRef.current === 0 ? 180 : 0);

    targetPosRef.current = nextTarget;
    setTargetPos(nextTarget);
  };

  const handleReset = () => {
    targetPosRef.current = 0;
    setTargetPos(0);
    currentPosRef.current = 0;
    currentVelRef.current = 0;
    setSpringPos(0);
    setSpringVelocity(0);
    soundFx.playConfirm();
  };

  return (
    <div className="flex flex-col lg:flex-row h-full w-full gap-3 p-3 overflow-hidden select-none font-mono text-xs">
      {/* Left Column: Physics Controls & Primitives List */}
      <div className="w-full lg:w-96 flex flex-col gap-3 shrink-0 overflow-y-auto scrollbar-thin">
        {/* Header */}
        <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-[var(--sf-accent-subtle)] border border-[var(--sf-accent)] flex items-center justify-center font-bold text-[var(--sf-accent)]">
              KT
            </div>
            <div>
              <span className="font-bold text-sm text-[var(--sf-text)] uppercase block">
                KOTLIN MOTION GRAMMAR LAB
              </span>
              <span className="text-[10px] text-[var(--sf-text-dim)]">
                Second-Order Harmonic Spring Dynamics
              </span>
            </div>
          </div>
        </div>

        {/* Physics Tuning Sliders */}
        <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
          <span className="font-bold text-xs text-[var(--sf-text)] uppercase border-b border-[var(--sf-border)] pb-2 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-[var(--sf-accent)]" />
            SPRING CONSTANTS
          </span>

          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-[var(--sf-text-dim)]">STIFFNESS (k)</span>
              <span className="text-[var(--sf-text)] font-bold">{stiffness} N/m</span>
            </div>
            <input
              type="range"
              min="50"
              max="400"
              value={stiffness}
              onChange={(e) => setStiffness(Number(e.target.value))}
              className="accent-[var(--sf-accent)] cursor-pointer"
            />
          </div>

          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-[var(--sf-text-dim)]">DAMPING (c)</span>
              <span className="text-[var(--sf-text)] font-bold">{damping} Ns/m</span>
            </div>
            <input
              type="range"
              min="5"
              max="60"
              value={damping}
              onChange={(e) => setDamping(Number(e.target.value))}
              className="accent-[var(--sf-accent)] cursor-pointer"
            />
          </div>

          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-[var(--sf-text-dim)]">MASS (m)</span>
              <span className="text-[var(--sf-text)] font-bold">{mass.toFixed(1)} kg</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="3.0"
              step="0.1"
              value={mass}
              onChange={(e) => setMass(Number(e.target.value))}
              className="accent-[var(--sf-accent)] cursor-pointer"
            />
          </div>
        </div>

        {/* 9 Animation Grammar Primitives Selection */}
        <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-2">
          <span className="font-bold text-xs text-[var(--sf-text)] uppercase border-b border-[var(--sf-border)] pb-2">
            SELECT GRAMMAR PRIMITIVE ({primitives.length})
          </span>

          <div className="divide-y divide-[var(--sf-border-subtle)]">
            {primitives.map((prim) => {
              const isSelected = activePrimitive === prim.id;
              return (
                <div
                  key={prim.id}
                  onClick={() => handleTriggerMotion(prim.id)}
                  className={`py-2 px-2 cursor-pointer flex items-center justify-between transition-colors ${
                    isSelected
                      ? 'bg-[var(--sf-accent-subtle)] text-[var(--sf-accent)] font-semibold'
                      : 'hover:bg-[var(--sf-surface-elevated)] text-[var(--sf-text-muted)]'
                  }`}
                >
                  <div className="flex flex-col">
                    <span className="text-xs">{prim.label}</span>
                    <span className="text-[10px] text-[var(--sf-text-dim)]">{prim.desc}</span>
                  </div>
                  <Play className="w-3 h-3 shrink-0" />
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right Column: Visual Physics Stage & Telemetry */}
      <div className="flex-1 flex flex-col gap-3 overflow-hidden">
        {/* Telemetry Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <SFDataField
            label="Active Primitive"
            value={activePrimitive}
            subValue="Grammar Pipeline"
            status="nominal"
          />
          <SFDataField
            label="Displacement (x)"
            value={`${springPos.toFixed(1)}`}
            unit="PX"
            subValue={`Target: ${targetPos}px`}
          />
          <SFDataField
            label="Velocity (v)"
            value={`${springVelocity.toFixed(1)}`}
            unit="PX/S"
            subValue="Instantaneous"
          />
          <SFDataField
            label="Damping Ratio (ζ)"
            value={`${(damping / (2 * Math.sqrt(stiffness * mass))).toFixed(2)}`}
            subValue={damping / (2 * Math.sqrt(stiffness * mass)) < 1 ? 'Underdamped (Bouncy)' : 'Overdamped (Smooth)'}
          />
        </div>

        {/* Visual Animation Test Stage */}
        <div className="flex-1 bg-[var(--sf-surface)] border border-[var(--sf-border)] p-6 flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--sf-border)] pb-3">
            <span className="font-bold text-xs text-[var(--sf-text)] uppercase">
              REAL-TIME PHYSICAL ACTUATION STAGE
            </span>
            <SFButton size="sm" variant="outline" onClick={handleReset}>
              <RefreshCw className="w-3.5 h-3.5 mr-1" /> RESET STAGE
            </SFButton>
          </div>

          {/* Center Actuation Target */}
          <div className="flex-1 flex items-center justify-center relative my-8">
            {/* Guide Rail */}
            <div className="absolute w-3/4 h-0.5 bg-[var(--sf-border-strong)]" />

            {/* Moving Physical Monolith Pod */}
            <div
              className="w-28 h-28 bg-[var(--sf-surface-elevated)] border-2 border-[var(--sf-accent)] flex flex-col items-center justify-center p-2 relative shadow-lg"
              style={{
                transform: `translateX(${springPos - 90}px) scale(${activePrimitive === 'SScale' ? 1 + (springPos / 300) : 1}) rotate(${activePrimitive === 'SFlow' ? springPos * 0.2 : 0}deg)`,
                opacity: activePrimitive === 'SFade' ? Math.max(0.2, 1 - (springPos / 220)) : 1,
              }}
            >
              <div className="w-3 h-3 bg-[var(--sf-accent)] rotate-45 mb-2" />
              <span className="font-bold text-xs text-[var(--sf-text)]">{activePrimitive}</span>
              <span className="text-[9px] text-[var(--sf-text-dim)] mt-1">{springPos.toFixed(0)}px</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-[var(--sf-text-dim)] border-t border-[var(--sf-border)] pt-3">
            <span>DISPATCH INTERACTION: CLICK ANY PRIMITIVE ON THE LEFT</span>
            <span>VELOCITY PRESERVING INTERRUPT SUPPORTED</span>
          </div>
        </div>
      </div>
    </div>
  );
};
