'use client';

import React, { useState } from 'react';
import { Web3Account, SmartContract, Web3Block } from '@/lib/types';
import { SFDataField } from '../ui/SFDataField';
import { SFButton } from '../ui/SFButton';
import { soundFx } from '@/lib/audio/soundSystem';
import { Database, GitCompare, ArrowRight, ShieldCheck, Search } from 'lucide-react';

interface StateSpaceViewProps {
  accounts: Record<string, Web3Account>;
  contracts: Record<string, SmartContract>;
  latestBlock: Web3Block | null;
}

export const StateSpaceView: React.FC<StateSpaceViewProps> = ({
  accounts,
  contracts,
  latestBlock,
}) => {
  const [filterQuery, setFilterQuery] = useState('');
  const accountList = Object.values(accounts);

  const filtered = accountList.filter(a => 
    a.label.toLowerCase().includes(filterQuery.toLowerCase()) ||
    a.address.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full w-full gap-3 p-3 overflow-y-auto scrollbar-thin select-none font-mono text-xs">
      {/* Top Header Information */}
      <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <Database className="w-5 h-5 text-[var(--sf-accent)]" />
          <div>
            <span className="font-bold text-sm text-[var(--sf-text)] uppercase block">GLOBAL MERKLE STATE SPACE // 2040</span>
            <span className="text-[11px] text-[var(--sf-text-dim)]">State Root: {latestBlock?.stateRoot || '0x...'}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-[var(--sf-text-dim)]" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="FILTER STATE ADDRESSES..."
              className="pl-8 pr-3 py-1.5 bg-[var(--sf-bg)] border border-[var(--sf-border)] text-xs text-[var(--sf-text)] placeholder:text-[var(--sf-text-dim)] font-mono w-60 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* State Metric Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <SFDataField
          label="Total State Accounts"
          value={`${accountList.length}`}
          unit="LEAVES"
          subValue="Merkle Tree"
        />
        <SFDataField
          label="Contracts Deployed"
          value={`${Object.keys(contracts).length}`}
          unit="MACHINES"
          subValue="EVM Executables"
        />
        <SFDataField
          label="State Block Height"
          value={`#${latestBlock?.height || 8421}`}
          subValue="Canonical Tip"
        />
        <SFDataField
          label="Integrity Proof"
          value="VERIFIED"
          subValue="Zero Knowledge"
          status="nominal"
        />
      </div>

      {/* State Accounts & Storage Slots List */}
      <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
        <span className="font-bold text-[var(--sf-text)] uppercase text-xs border-b border-[var(--sf-border)] pb-2 flex items-center justify-between">
          <span>ACCOUNT STATE SNAPSHOTS ({filtered.length})</span>
          <span className="text-[10px] text-[var(--sf-text-dim)]">REAL-TIME PROPAGATION</span>
        </span>

        <div className="divide-y divide-[var(--sf-border-subtle)]">
          {filtered.map((acc) => (
            <div key={acc.address} className="py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[var(--sf-text)] text-sm">{acc.label}</span>
                  <span className={`text-[9px] px-1.5 py-0.2 uppercase font-semibold ${
                    acc.type === 'treasury' ? 'bg-[var(--sf-brass-subtle)] text-[var(--sf-brass)]' : 'bg-[var(--sf-border-subtle)] text-[var(--sf-text-dim)]'
                  }`}>
                    {acc.type}
                  </span>
                </div>
                <span className="text-[11px] text-[var(--sf-text-dim)] truncate mt-0.5 select-all">{acc.address}</span>
              </div>

              <div className="flex items-center gap-4 shrink-0 text-right">
                <div>
                  <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">BALANCE</span>
                  <span className="font-bold text-[var(--sf-green)] text-sm">{acc.balanceEth.toLocaleString()} ETH</span>
                </div>
                <div>
                  <span className="text-[10px] text-[var(--sf-text-dim)] uppercase block">NONCE</span>
                  <span className="text-xs text-[var(--sf-text)]">#{acc.nonce}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
