'use client';

import React, { useState } from 'react';
import { Web3Block, ProtocolSnapshot } from '@/lib/types';
import { SFDataField } from '../ui/SFDataField';
import { SFButton } from '../ui/SFButton';
import { web3Emu } from '@/lib/web3emu/engine';
import { soundFx } from '@/lib/audio/soundSystem';
import { History, Play, Rewind, FastForward, CheckCircle2, AlertCircle } from 'lucide-react';

interface TimeMachineViewProps {
  blocks: Web3Block[];
  latestHeight: number;
}

export const TimeMachineView: React.FC<TimeMachineViewProps> = ({
  blocks,
  latestHeight,
}) => {
  const minHeight = blocks.length > 0 ? blocks[blocks.length - 1].height : 8400;
  const maxHeight = latestHeight || 8421;

  const [scrubbedHeight, setScrubbedHeight] = useState<number>(maxHeight);
  const [snapshot, setSnapshot] = useState<ProtocolSnapshot | null>(null);

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10);
    setScrubbedHeight(val);
    const snap = web3Emu.getSnapshotForHeight(val);
    setSnapshot(snap);
    soundFx.playClick(600 + (val - minHeight) * 15);
  };

  const handleStepBack = () => {
    if (scrubbedHeight > minHeight) {
      const next = scrubbedHeight - 1;
      setScrubbedHeight(next);
      setSnapshot(web3Emu.getSnapshotForHeight(next));
      soundFx.playClick(750);
    }
  };

  const handleStepForward = () => {
    if (scrubbedHeight < maxHeight) {
      const next = scrubbedHeight + 1;
      setScrubbedHeight(next);
      setSnapshot(web3Emu.getSnapshotForHeight(next));
      soundFx.playClick(850);
    }
  };

  const handleResetToPresent = () => {
    setScrubbedHeight(maxHeight);
    setSnapshot(null);
    soundFx.playConfirm();
  };

  const isHistorical = scrubbedHeight < maxHeight;
  const activeBlock = snapshot?.latestBlock || blocks.find(b => b.height === scrubbedHeight) || blocks[0];

  return (
    <div className="flex flex-col h-full w-full gap-3 p-3 overflow-y-auto scrollbar-thin select-none font-mono text-xs">
      {/* Time Machine Header Scrubber */}
      <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[var(--sf-border)] pb-3">
          <div className="flex items-center gap-2.5">
            <History className="w-5 h-5 text-[var(--sf-accent)]" />
            <div>
              <span className="font-bold text-sm text-[var(--sf-text)] uppercase block">
                TIME MACHINE // HISTORICAL STATE RECONSTRUCTION
              </span>
              <span className="text-[11px] text-[var(--sf-text-dim)]">
                Scrub back through block heights to deterministically rebuild global protocol state
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isHistorical ? (
              <span className="px-2 py-1 bg-[var(--sf-amber-subtle)] text-[var(--sf-amber)] font-bold text-[10px] border border-[var(--sf-amber)]/40 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                HISTORICAL VIEW (BLOCK #{scrubbedHeight})
              </span>
            ) : (
              <span className="px-2 py-1 bg-[var(--sf-green-subtle)] text-[var(--sf-green)] font-bold text-[10px] border border-[var(--sf-green)]/40 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                CANONICAL TIP (PRESENT)
              </span>
            )}
            <SFButton size="sm" variant="outline" onClick={handleResetToPresent}>
              JUMP TO PRESENT ↵
            </SFButton>
          </div>
        </div>

        {/* The Time Machine Slider */}
        <div className="flex flex-col gap-2 pt-1">
          <div className="flex items-center justify-between text-[11px] font-bold">
            <span className="text-[var(--sf-text-dim)]">BLOCK #{minHeight} (EARLIEST STORED)</span>
            <span className="text-[var(--sf-accent)] text-sm">TARGET BLOCK: #{scrubbedHeight}</span>
            <span className="text-[var(--sf-text-dim)]">BLOCK #{maxHeight} (CANONICAL TIP)</span>
          </div>

          <input
            type="range"
            min={minHeight}
            max={maxHeight}
            value={scrubbedHeight}
            onChange={handleSliderChange}
            className="w-full accent-[var(--sf-accent)] cursor-pointer h-2 bg-[var(--sf-surface-elevated)] border border-[var(--sf-border)]"
          />

          <div className="flex items-center justify-center gap-3 mt-1">
            <SFButton size="sm" variant="secondary" onClick={handleStepBack} disabled={scrubbedHeight <= minHeight}>
              <Rewind className="w-3.5 h-3.5 mr-1" /> PREVIOUS BLOCK
            </SFButton>
            <SFButton size="sm" variant="secondary" onClick={handleStepForward} disabled={scrubbedHeight >= maxHeight}>
              NEXT BLOCK <FastForward className="w-3.5 h-3.5 ml-1" />
            </SFButton>
          </div>
        </div>
      </div>

      {/* Reconstructed State Snapshot for Selected Block */}
      {activeBlock && (
        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <SFDataField
              label="Block Height"
              value={`#${activeBlock.height}`}
              subValue="Reconstructed Height"
              status={isHistorical ? 'warning' : 'nominal'}
            />
            <SFDataField
              label="Transactions in Block"
              value={`${activeBlock.txCount}`}
              unit="TXs"
              subValue={`${activeBlock.sizeKb} KB Payload`}
            />
            <SFDataField
              label="Base Fee At Timestamp"
              value={`${activeBlock.baseFeeGwei}`}
              unit="GWEI"
              subValue="EIP-1559 Elastic"
            />
            <SFDataField
              label="Gas Limit Utilization"
              value={`${(activeBlock.gasRatio * 100).toFixed(1)}%`}
              subValue={`${activeBlock.gasUsed.toLocaleString()} Gas`}
            />
          </div>

          {/* Historical State Diffs Recorded in this Block */}
          <div className="bg-[var(--sf-surface)] border border-[var(--sf-border)] p-4 flex flex-col gap-3">
            <span className="font-bold text-xs text-[var(--sf-text)] uppercase border-b border-[var(--sf-border)] pb-2">
              HISTORICAL STATE MUTATIONS AT BLOCK #{activeBlock.height}
            </span>

            <div className="divide-y divide-[var(--sf-border-subtle)]">
              {activeBlock.stateDiffs.map((diff, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between">
                  <span className="text-[var(--sf-text-muted)] truncate max-w-sm">{diff.address}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-[var(--sf-text-dim)]">{diff.oldVal}</span>
                    <span className="text-[var(--sf-text-dim)]">→</span>
                    <span className="text-[var(--sf-green)] font-semibold">{diff.newVal}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
