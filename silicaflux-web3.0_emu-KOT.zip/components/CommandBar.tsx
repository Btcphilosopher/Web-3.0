'use client';

import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  X, 
  Compass, 
  Box, 
  ArrowLeftRight, 
  Cpu, 
  Wallet, 
  BarChart3, 
  Play, 
  AlertTriangle, 
  Activity, 
  Sparkles,
  Zap,
  Building2
} from 'lucide-react';
import { NavTab, ThemeMode, ViewDensity } from '@/lib/types';
import { web3Emu } from '@/lib/web3emu/engine';
import { soundFx } from '@/lib/audio/soundSystem';

interface CommandBarProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: NavTab) => void;
  onToggleTheme: () => void;
  onChangeDensity: (d: ViewDensity) => void;
}

export const CommandBar: React.FC<CommandBarProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onToggleTheme,
  onChangeDensity,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        inputRef.current?.focus();
        setQuery('');
        setSelectedIndex(0);
      }, 30);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        isOpen ? onClose() : undefined;
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const actions = [
    {
      category: 'NAVIGATION',
      items: [
        { id: 'nav_obs', label: 'Open Web3 Observatory (2D Spatial Mesh)', icon: <Compass className="w-4 h-4 text-[var(--sf-accent)]" />, action: () => onSelectTab('observatory') },
        { id: 'nav_city', label: 'Open Web3 City (3D Architectural Space)', icon: <Building2 className="w-4 h-4 text-[var(--sf-accent)]" />, action: () => onSelectTab('city') },
        { id: 'nav_blocks', label: 'Inspect Monolithic Blocks Archive', icon: <Box className="w-4 h-4 text-[var(--sf-accent)]" />, action: () => onSelectTab('blocks') },
        { id: 'nav_txs', label: 'Inspect Transactions & Mempool Lifecycle', icon: <ArrowLeftRight className="w-4 h-4 text-[var(--sf-accent)]" />, action: () => onSelectTab('transactions') },
        { id: 'nav_accounts', label: 'Inspect Accounts & Sovereign Vaults', icon: <Wallet className="w-4 h-4 text-[var(--sf-accent)]" />, action: () => onSelectTab('accounts') },
        { id: 'nav_contracts', label: 'Inspect Computational Smart Contract Machines', icon: <Cpu className="w-4 h-4 text-[var(--sf-accent)]" />, action: () => onSelectTab('contracts') },
        { id: 'nav_quant', label: 'Open Quant Lab (R RhinoQuant Visual Engine)', icon: <BarChart3 className="w-4 h-4 text-[var(--sf-accent)]" />, action: () => onSelectTab('quant') },
        { id: 'nav_motion', label: 'Open Motion Lab (Kotlin Physics & Grammar Playground)', icon: <Zap className="w-4 h-4 text-[var(--sf-accent)]" />, action: () => onSelectTab('motion_lab') },
      ]
    },
    {
      category: 'SIMULATION SCENARIOS',
      items: [
        {
          id: 'scen_arb',
          label: 'Run Scenario: LSE High-Frequency Arbitrage Wave (8 Rapid Txs)',
          icon: <Activity className="w-4 h-4 text-[var(--sf-green)]" />,
          action: () => {
            web3Emu.runScenario('lse_arbitrage');
            soundFx.playConfirm();
            onSelectTab('transactions');
          }
        },
        {
          id: 'scen_harwell',
          label: 'Run Scenario: Harwell Satellite Telemetry Congestion & Latency Spike',
          icon: <AlertTriangle className="w-4 h-4 text-[var(--sf-amber)]" />,
          action: () => {
            web3Emu.runScenario('harwell_spike');
            soundFx.playAlert();
            onSelectTab('observatory');
          }
        },
        {
          id: 'scen_outage',
          label: 'Run Scenario: Canary Wharf Validator Outage & Mesh Reconfiguration',
          icon: <AlertTriangle className="w-4 h-4 text-[var(--sf-red)]" />,
          action: () => {
            web3Emu.runScenario('node_outage');
            soundFx.playAlert();
            onSelectTab('observatory');
          }
        },
        {
          id: 'scen_dividend',
          label: 'Run Scenario: Sovereign Sterling Settlement Dividend Injection',
          icon: <Sparkles className="w-4 h-4 text-[var(--sf-brass)]" />,
          action: () => {
            web3Emu.runScenario('sovereign_dividend');
            soundFx.playBlockMined();
            onSelectTab('accounts');
          }
        }
      ]
    },
    {
      category: 'PREFERENCES & MODES',
      items: [
        { id: 'pref_theme', label: 'Toggle Obsidian (Dark) / Archive (Light) Theme', icon: <Sparkles className="w-4 h-4" />, action: onToggleTheme },
        { id: 'pref_eng', label: 'Set View Density: Engineering / Protocol Mode', icon: <Cpu className="w-4 h-4" />, action: () => onChangeDensity('engineering') },
        { id: 'pref_human', label: 'Set View Density: Human / Executive Mode', icon: <Wallet className="w-4 h-4" />, action: () => onChangeDensity('human') },
      ]
    }
  ];

  const flatItems = actions.flatMap(cat => 
    cat.items.filter(item => item.label.toLowerCase().includes(query.toLowerCase()))
  );

  const handleSelect = (item: { action: () => void }) => {
    soundFx.playClick(950);
    item.action();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/60 backdrop-blur-xs p-4 select-none animate-fadeIn">
      <div 
        className="w-full max-w-2xl bg-[var(--sf-surface)] border border-[var(--sf-border-strong)] shadow-2xl overflow-hidden font-mono"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3 border-b border-[var(--sf-border)] bg-[var(--sf-surface-elevated)]">
          <Search className="w-4 h-4 text-[var(--sf-text-muted)] mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="EXECUTE COMMAND, SEARCH STATE OR RUN SCENARIO..."
            className="w-full bg-transparent text-sm text-[var(--sf-text)] placeholder:text-[var(--sf-text-dim)] focus:outline-none uppercase font-mono tracking-wide"
          />
          <button
            onClick={onClose}
            className="p-1 text-[var(--sf-text-dim)] hover:text-[var(--sf-text)] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-[var(--sf-border-subtle)]">
          {flatItems.length === 0 ? (
            <div className="py-8 text-center text-xs text-[var(--sf-text-dim)] font-mono">
              NO MATCHING COMMANDS FOUND IN 2040 MESH
            </div>
          ) : (
            flatItems.map((item, index) => {
              const isSelected = index === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => handleSelect(item)}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`flex items-center justify-between px-3 py-2.5 cursor-pointer text-xs transition-colors ${
                    isSelected
                      ? 'bg-[var(--sf-accent-subtle)] text-[var(--sf-accent)] border-l-2 border-[var(--sf-accent)]'
                      : 'text-[var(--sf-text)] hover:bg-[var(--sf-surface-subtle)]'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate">
                    <span>{item.icon}</span>
                    <span className="truncate">{item.label}</span>
                  </div>
                  <span className="text-[10px] text-[var(--sf-text-dim)] shrink-0 ml-2">↵ EXECUTE</span>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Navigation Hints */}
        <div className="flex items-center justify-between px-4 py-2 bg-[var(--sf-bg)] border-t border-[var(--sf-border)] text-[10px] text-[var(--sf-text-dim)]">
          <div className="flex items-center gap-3">
            <span>↑↓ NAVIGATE</span>
            <span>↵ CONFIRM</span>
            <span>ESC DISMISS</span>
          </div>
          <span className="font-semibold text-[var(--sf-text-muted)]">SILICAFLUX COMMAND TERMINAL</span>
        </div>
      </div>
    </div>
  );
};
