'use client';

import React from 'react';
import { 
  Compass, 
  Box, 
  ArrowLeftRight, 
  Wallet, 
  Cpu, 
  Database, 
  BarChart3, 
  History, 
  Terminal, 
  Zap, 
  Building2 
} from 'lucide-react';
import { NavTab } from '@/lib/types';
import { soundFx } from '@/lib/audio/soundSystem';

interface NavigationProps {
  activeTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onChangeTab }) => {
  const tabs: { id: NavTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'observatory', label: 'Observatory', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'city', label: 'City 3D', icon: <Building2 className="w-3.5 h-3.5" /> },
    { id: 'blocks', label: 'Blocks', icon: <Box className="w-3.5 h-3.5" /> },
    { id: 'transactions', label: 'Transactions', icon: <ArrowLeftRight className="w-3.5 h-3.5" /> },
    { id: 'accounts', label: 'Accounts', icon: <Wallet className="w-3.5 h-3.5" /> },
    { id: 'contracts', label: 'Contracts', icon: <Cpu className="w-3.5 h-3.5" /> },
    { id: 'state', label: 'State Space', icon: <Database className="w-3.5 h-3.5" /> },
    { id: 'quant', label: 'Quant Lab', icon: <BarChart3 className="w-3.5 h-3.5" />, badge: 'R' },
    { id: 'time_machine', label: 'Time Machine', icon: <History className="w-3.5 h-3.5" /> },
    { id: 'developer', label: 'Developer', icon: <Terminal className="w-3.5 h-3.5" /> },
    { id: 'motion_lab', label: 'Motion Lab', icon: <Zap className="w-3.5 h-3.5" />, badge: 'KT' },
  ];

  const handleTabClick = (tabId: NavTab) => {
    soundFx.playClick(1050);
    onChangeTab(tabId);
  };

  return (
    <nav className="w-full bg-[#0D0D0D] border-b border-[#2A2A2A] px-4 py-1.5 overflow-x-auto scrollbar-none select-none">
      <div className="flex items-center gap-1.5 min-w-max">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              className={`relative flex items-center gap-2 px-3 py-1.5 text-[11px] font-mono uppercase tracking-wider transition-all duration-150 border cursor-pointer ${
                isActive
                  ? 'bg-[#1A1A1A] text-[#E4E4E4] border-[#3A3A3A] font-bold'
                  : 'bg-transparent text-[#666666] border-transparent hover:text-[#AAAAAA] hover:bg-[#141414]'
              }`}
            >
              {/* Active Indicator Top Accent */}
              {isActive && (
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-[#4A90E2]" />
              )}
              
              <span className={isActive ? 'text-[#4A90E2]' : 'text-[#666666]'}>
                {tab.icon}
              </span>
              
              <span>{tab.label}</span>

              {tab.badge && (
                <span className={`text-[9px] px-1 py-0.2 rounded-none font-bold ${
                  isActive ? 'bg-[#4A90E2] text-white' : 'bg-[#222222] text-[#666666]'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
