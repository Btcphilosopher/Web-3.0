// RHINOQUANT / R VISUAL BRIDGE - QUANTITATIVE VISUAL INTELLIGENCE
// Statistical distributions, time-series transformations, anomaly detection, and visual parameter derivations

import { QuantMetrics, QuantVisualParameters, Web3Account, Web3Block, Web3Transaction, NetworkNode } from '../types';

export class RhinoQuantEngine {
  // Compute Lorenz Curve and Gini Index
  public static computeGini(accounts: Web3Account[]): { gini: number; lorenz: { percentile: number; share: number }[] } {
    if (!accounts.length) return { gini: 0, lorenz: [] };

    const balances = accounts.map(a => Math.max(0, a.balanceEth)).sort((a, b) => a - b);
    const totalWealth = balances.reduce((acc, val) => acc + val, 0) || 1;
    const n = balances.length;

    let cumulativeSum = 0;
    let lorenzArea = 0;
    const lorenz: { percentile: number; share: number }[] = [{ percentile: 0, share: 0 }];

    for (let i = 0; i < n; i++) {
      cumulativeSum += balances[i];
      const p = (i + 1) / n;
      const share = cumulativeSum / totalWealth;
      lorenz.push({ percentile: Math.round(p * 100), share: Number(share.toFixed(4)) });
      lorenzArea += share * (1 / n);
    }

    // Gini coefficient = 1 - 2 * area under Lorenz curve
    const gini = Math.max(0, Math.min(1, 1 - 2 * lorenzArea));
    return { gini: Number(gini.toFixed(3)), lorenz };
  }

  // Kernel Density Estimation (KDE) approximation with Gaussian kernel
  public static computeKDE(values: number[], bins: number = 24): { bin: number; density: number }[] {
    if (!values.length) return [];
    const min = Math.min(...values);
    const max = Math.max(...values) || 1;
    const range = max - min || 1;
    const step = range / bins;
    const bandwidth = step * 1.5;

    const result: { bin: number; density: number }[] = [];

    for (let i = 0; i <= bins; i++) {
      const x = min + i * step;
      let densitySum = 0;

      for (const v of values) {
        const u = (x - v) / bandwidth;
        // Gaussian kernel
        const kernel = (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * u * u);
        densitySum += kernel;
      }

      const normalizedDensity = densitySum / (values.length * bandwidth);
      result.push({
        bin: Number(x.toFixed(1)),
        density: Number(normalizedDensity.toFixed(4)),
      });
    }

    return result;
  }

  // Network Shannon Entropy computation (node traffic balance)
  public static computeShannonEntropy(nodes: NetworkNode[]): number {
    const totalTps = nodes.reduce((sum, n) => sum + (n.status === 'online' ? n.tps : 0), 0) || 1;
    let entropy = 0;

    for (const node of nodes) {
      if (node.status === 'online' && node.tps > 0) {
        const p = node.tps / totalTps;
        entropy -= p * Math.log2(p);
      }
    }

    const maxEntropy = Math.log2(Math.max(1, nodes.length));
    const normalizedEntropy = maxEntropy > 0 ? entropy / maxEntropy : 1;
    return Number(normalizedEntropy.toFixed(3));
  }

  // Anomaly score calculation using multivariate Z-score
  public static computeAnomalyScore(
    recentTxs: Web3Transaction[],
    latestBlock: Web3Block | null,
    nodes: NetworkNode[]
  ): number {
    if (!latestBlock) return 0.05;

    const failedTxRatio = recentTxs.length > 0 
      ? recentTxs.filter(t => t.status === 'failed').length / recentTxs.length 
      : 0;

    const gasSurge = latestBlock.gasRatio > 0.85 ? (latestBlock.gasRatio - 0.85) * 4 : 0;
    
    const offlineNodes = nodes.filter(n => n.status !== 'online').length / Math.max(1, nodes.length);

    const score = (failedTxRatio * 0.4) + (gasSurge * 0.35) + (offlineNodes * 0.25);
    return Number(Math.max(0.02, Math.min(0.99, score)).toFixed(3));
  }

  // Calculate full quant metrics
  public static calculateMetrics(
    blocks: Web3Block[],
    txs: Web3Transaction[],
    accounts: Web3Account[],
    nodes: NetworkNode[],
    mempoolCount: number
  ): QuantMetrics {
    const latestBlock = blocks[0] || null;
    const latencies = nodes.map(n => n.latencyMs).sort((a, b) => a - b);
    
    const p50 = latencies[Math.floor(latencies.length * 0.5)] || 12;
    const p95 = latencies[Math.floor(latencies.length * 0.95)] || 38;
    const p99 = latencies[Math.floor(latencies.length * 0.99)] || 65;

    // Gas utilization list
    const gasRatios = blocks.slice(0, 15).map(b => Number((b.gasRatio * 100).toFixed(1)));
    const gasVol = gasRatios.length > 1
      ? Math.sqrt(gasRatios.reduce((acc, val) => acc + Math.pow(val - 50, 2), 0) / gasRatios.length) / 100
      : 0.15;

    // Gini
    const { gini, lorenz } = this.computeGini(accounts);

    // Entropy
    const entropy = this.computeShannonEntropy(nodes);

    // Anomaly score
    const anomaly = this.computeAnomalyScore(txs.slice(0, 50), latestBlock, nodes);

    // Gas value samples for KDE
    const gasSamples = txs.map(t => t.gasPriceGwei).filter(g => g > 0);
    const kde = this.computeKDE(gasSamples.length > 5 ? gasSamples : [18, 22, 25, 29, 31, 35, 42, 50], 16);

    // TPS History
    const histTps = blocks.slice(0, 10).reverse().map((b, i) => ({
      time: `B#${b.height}`,
      value: Math.round(b.txCount * 3.8 + (i % 3) * 4),
    }));

    const currentTps = nodes.reduce((sum, n) => sum + (n.status === 'online' ? n.tps : 0), 0);

    return {
      tpsCurrent: Math.round(currentTps),
      tpsAverage: 142,
      gasVolatility: Number(gasVol.toFixed(3)),
      latencyP50: p50,
      latencyP95: p95,
      latencyP99: p99,
      networkEntropy: entropy,
      accountGiniIndex: gini,
      anomalyScore: anomaly,
      activeValidators: nodes.filter(n => n.status === 'online').length,
      mempoolPressure: Math.min(1.0, mempoolCount / 80),
      blockTimeVariance: 0.24,
      histGasUtilization: gasRatios,
      histTps,
      kdeDistribution: kde,
      lorenzCurve: lorenz,
    };
  }

  // Derive GUI Visual Parameters from Quant Engine
  public static deriveVisualParameters(quant: QuantMetrics, latestBlock: Web3Block | null): QuantVisualParameters {
    const gasRatio = latestBlock ? latestBlock.gasRatio : 0.45;
    
    return {
      lineThickness: Math.max(1, Math.min(3.5, 1 + quant.networkEntropy * 2)),
      signalSpeedMultiplier: Math.max(0.7, Math.min(2.8, (quant.tpsCurrent / 120) * (50 / Math.max(20, quant.latencyP50)))),
      railGlowIntensity: Math.min(1.0, 0.2 + (quant.mempoolPressure * 0.8)),
      particleDensity: Math.round(Math.min(60, 10 + (quant.tpsCurrent / 5))),
      anomalyAlertLevel: quant.anomalyScore > 0.65 ? 'critical' : quant.anomalyScore > 0.35 ? 'elevated' : 'nominal',
      gasDialDegree: Math.round(gasRatio * 240), // 0 to 240 degrees
      topologicalCentrality: Number((1 - quant.networkEntropy).toFixed(3)),
    };
  }
}

export const rhinoQuant = {
  calculateMetrics: (
    blocks: Web3Block[],
    txs: Web3Transaction[],
    accounts: Record<string, Web3Account> | Web3Account[],
    nodes: NetworkNode[],
    mempoolCount: number = 0
  ): QuantMetrics => {
    const accountArr = Array.isArray(accounts) ? accounts : Object.values(accounts);
    return RhinoQuantEngine.calculateMetrics(blocks, txs, accountArr, nodes, mempoolCount);
  },
  deriveVisualParameters: (quant: QuantMetrics, latestBlock?: Web3Block | null): QuantVisualParameters => {
    return RhinoQuantEngine.deriveVisualParameters(quant, latestBlock || null);
  },
  computeGini: RhinoQuantEngine.computeGini,
  computeKDE: RhinoQuantEngine.computeKDE,
  computeShannonEntropy: RhinoQuantEngine.computeShannonEntropy,
  computeAnomalyScore: RhinoQuantEngine.computeAnomalyScore,
};

