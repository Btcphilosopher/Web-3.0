// SILICAFLUX WEB3EMU - AUTHORITATIVE PROTOCOL TRUTH ENGINE
// Full in-memory Web3 blockchain emulator with EVM execution traces, state diffs, mempool & time-machine snapshots

import { 
  Web3Block, 
  Web3Transaction, 
  Web3Account, 
  SmartContract, 
  NetworkNode, 
  ProtocolSnapshot, 
  StateDiffItem,
  ExecutionTrace 
} from '../types';

export class Web3EmuEngine {
  private blocks: Web3Block[] = [];
  private transactions: Web3Transaction[] = [];
  private mempool: Web3Transaction[] = [];
  private accounts: Record<string, Web3Account> = {};
  private contracts: Record<string, SmartContract> = {};
  private nodes: NetworkNode[] = [];
  private snapshots: ProtocolSnapshot[] = [];
  
  private isRunning: boolean = true;
  private simulationSpeed: number = 1.0; // 0.5x, 1.0x, 2.0x, 5.0x
  private blockIntervalMs: number = 4000;
  private timer: NodeJS.Timeout | null = null;
  private listeners: ((event: string, data?: unknown) => void)[] = [];

  constructor() {
    this.initializeGenesis();
    if (typeof window !== 'undefined') {
      this.startSimulation();
    }
  }

  public subscribe(cb: (event: string, data?: unknown) => void) {
    this.listeners.push(cb);
    return () => {
      this.listeners = this.listeners.filter(l => l !== cb);
    };
  }

  public on(targetEvent: string, cb: (data?: unknown) => void) {
    const handler = (event: string, data?: unknown) => {
      if (event === targetEvent) {
        cb(data);
      }
    };
    this.listeners.push(handler);
    return () => {
      this.listeners = this.listeners.filter(l => l !== handler);
    };
  }

  private emit(event: string, data?: unknown) {
    this.listeners.forEach(cb => cb(event, data));
  }

  private initializeGenesis() {
    // 1. Initial British Regional Infrastructure Nodes
    this.nodes = [
      {
        id: 'node_lse_01',
        name: 'LSE Central Signalling Relay',
        region: 'London Central (LSE)',
        ip: '194.105.240.12',
        status: 'online',
        latencyMs: 8,
        peers: ['node_canary_02', 'node_cambridge_03', 'node_oxford_05'],
        blocksValidated: 4208,
        tps: 48,
        x: 480,
        y: 320,
        z: 10,
      },
      {
        id: 'node_canary_02',
        name: 'Canary Wharf High-Density Terminal',
        region: 'Canary Wharf Financial',
        ip: '194.105.242.88',
        status: 'online',
        latencyMs: 11,
        peers: ['node_lse_01', 'node_cambridge_03', 'node_edinburgh_06'],
        blocksValidated: 3892,
        tps: 52,
        x: 620,
        y: 280,
        z: -15,
      },
      {
        id: 'node_cambridge_03',
        name: 'Cambridge Semiconductor Foundry Node',
        region: 'Cambridge Science Park',
        ip: '131.111.45.19',
        status: 'online',
        latencyMs: 14,
        peers: ['node_lse_01', 'node_harwell_04', 'node_oxford_05'],
        blocksValidated: 2940,
        tps: 34,
        x: 540,
        y: 160,
        z: 25,
      },
      {
        id: 'node_harwell_04',
        name: 'Harwell Satellite Telemetry Gateway',
        region: 'Harwell Space Cluster',
        ip: '193.62.112.5',
        status: 'online',
        latencyMs: 19,
        peers: ['node_cambridge_03', 'node_oxford_05'],
        blocksValidated: 2180,
        tps: 28,
        x: 340,
        y: 390,
        z: -5,
      },
      {
        id: 'node_oxford_05',
        name: 'Oxford Quantum Computing Validator',
        region: 'Oxford Physics',
        ip: '163.1.200.74',
        status: 'online',
        latencyMs: 12,
        peers: ['node_lse_01', 'node_harwell_04', 'node_edinburgh_06'],
        blocksValidated: 3120,
        tps: 41,
        x: 310,
        y: 240,
        z: 15,
      },
      {
        id: 'node_edinburgh_06',
        name: 'Edinburgh FinTech Scottish Mesh',
        region: 'Edinburgh FinTech',
        ip: '129.215.80.33',
        status: 'online',
        latencyMs: 22,
        peers: ['node_canary_02', 'node_oxford_05'],
        blocksValidated: 1950,
        tps: 26,
        x: 220,
        y: 110,
        z: -20,
      },
    ];

    // 2. Initial Accounts
    this.accounts = {
      '0x4A81b2C1A3F9D701E788B2c7d91e6b78E3f2A180': {
        address: '0x4A81b2C1A3F9D701E788B2c7d91e6b78E3f2A180',
        label: 'Bank of England Sovereign Settlement',
        type: 'treasury',
        balanceEth: 12500.45,
        nonce: 142,
        txCount: 489,
        tokens: [
          { symbol: 'dGBP', name: 'Digital Sterling Sovereign', balance: 54000000, decimals: 2, usdValue: 69120000, contractAddress: '0x71aD9991b2C1A3F9D701E788B2c7d91e6b78E3f1' },
          { symbol: 'AERO', name: 'Rolls-Royce Avionics Bond', balance: 120000, decimals: 18, usdValue: 3480000, contractAddress: '0x94fC2221b2C1A3F9D701E788B2c7d91e6b78E3f2' }
        ],
        isMonitored: true,
      },
      '0x889B9c2F5d8aE41F3C1A2b4e7D901234567890AB': {
        address: '0x889B9c2F5d8aE41F3C1A2b4e7D901234567890AB',
        label: 'London Stock Exchange Automated Pool',
        type: 'contract',
        balanceEth: 4820.80,
        nonce: 894,
        txCount: 2410,
        tokens: [
          { symbol: 'dGBP', name: 'Digital Sterling Sovereign', balance: 28400000, decimals: 2, usdValue: 36352000, contractAddress: '0x71aD9991b2C1A3F9D701E788B2c7d91e6b78E3f1' },
          { symbol: 'CHIP', name: 'Cambridge Wafer Yield', balance: 850000, decimals: 18, usdValue: 4250000, contractAddress: '0xb8eB3331b2C1A3F9D701E788B2c7d91e6b78E3f4' }
        ],
      },
      '0x19F02b4d8A7C6E5e3F1a2B4C5D6E7F8A9B0C1D2E': {
        address: '0x19F02b4d8A7C6E5e3F1a2B4C5D6E7F8A9B0C1D2E',
        label: 'British Rail Signalling Automation Fund',
        type: 'eoa',
        balanceEth: 840.12,
        nonce: 78,
        txCount: 312,
        tokens: [
          { symbol: 'RAIL', name: 'Network Rail Capacity Token', balance: 450000, decimals: 18, usdValue: 1350000, contractAddress: '0x94fC2221b2C1A3F9D701E788B2c7d91e6b78E3f2' }
        ],
      },
      '0x3E7B2c1D9F8A0E41b3c7A2F1E5D6C7B8A9012345': {
        address: '0x3E7B2c1D9F8A0E41b3c7A2F1E5D6C7B8A9012345',
        label: 'Harwell Deep Space Relay Node',
        type: 'validator',
        balanceEth: 2400.00,
        nonce: 55,
        txCount: 198,
        tokens: [],
      },
      '0x72aE5c9B1d4F8A3E2C1b0D7e6F5A4B3C2D1E0F9A': {
        address: '0x72aE5c9B1d4F8A3E2C1b0D7e6F5A4B3C2D1E0F9A',
        label: 'Dyson Autonomous Robotics Depot',
        type: 'eoa',
        balanceEth: 185.34,
        nonce: 29,
        txCount: 94,
        tokens: [
          { symbol: 'dGBP', name: 'Digital Sterling Sovereign', balance: 650000, decimals: 2, usdValue: 832000, contractAddress: '0x71aD9991b2C1A3F9D701E788B2c7d91e6b78E3f1' }
        ],
      },
    };

    // 3. Smart Contracts
    this.contracts = {
      '0x71aD9991b2C1A3F9D701E788B2c7d91e6b78E3f1': {
        address: '0x71aD9991b2C1A3F9D701E788B2c7d91e6b78E3f1',
        name: 'LSE_DigitalSterling_AMM_v4',
        compiler: 'Solidity 0.9.1 (2040 Anglo-EVM Edition)',
        owner: '0x4A81b2C1A3F9D701E788B2c7d91e6b78E3f2A180',
        totalCalls: 18492,
        methods: [
          { name: 'swapExactTokensForTokens', inputs: [{ name: 'amountIn', type: 'uint256' }, { name: 'minOut', type: 'uint256' }, { name: 'path', type: 'address[]' }], outputs: [{ name: 'amounts', type: 'uint256[]' }], stateMutability: 'nonpayable' },
          { name: 'getReserves', inputs: [], outputs: [{ name: 'reserveA', type: 'uint256' }, { name: 'reserveB', type: 'uint256' }, { name: 'blockTimestamp', type: 'uint32' }], stateMutability: 'view' },
          { name: 'syncSovereignSpread', inputs: [{ name: 'targetBps', type: 'uint16' }], outputs: [{ name: 'success', type: 'bool' }], stateMutability: 'nonpayable' }
        ],
        storageSlots: [
          { slot: '0x0000000000000000000000000000000000000000000000000000000000000000', variableName: '_reserve0', type: 'uint112', value: '2840000000' },
          { slot: '0x0000000000000000000000000000000000000000000000000000000000000001', variableName: '_reserve1', type: 'uint112', value: '4820800000000000000000' },
          { slot: '0x0000000000000000000000000000000000000000000000000000000000000002', variableName: '_spreadFeeBps', type: 'uint16', value: '15' }
        ],
        events: ['Swap(address indexed sender, uint256 amount0In, uint256 amount1Out)', 'Sync(uint112 reserve0, uint112 reserve1)'],
        codeSnippet: `// London Stock Exchange Automated Market Maker v4.0
contract LSE_DigitalSterling_AMM {
    uint112 private _reserve0;
    uint112 private _reserve1;
    uint16 private _spreadFeeBps = 15;
    
    function swapExactTokens(uint256 amountIn, uint256 minOut) external returns (uint256 amountOut) {
        require(amountIn > 0, "INVALID_IN");
        amountOut = (amountIn * _reserve1 * (10000 - _spreadFeeBps)) / (_reserve0 * 10000 + amountIn);
        require(amountOut >= minOut, "SLIPPAGE_EXCEEDED");
        _reserve0 += uint112(amountIn);
        _reserve1 -= uint112(amountOut);
        emit Swap(msg.sender, amountIn, amountOut);
    }
}`
      },
      '0x94fC2221b2C1A3F9D701E788B2c7d91e6b78E3f2': {
        address: '0x94fC2221b2C1A3F9D701E788B2c7d91e6b78E3f2',
        name: 'BritishRail_AutonomousSignalling',
        compiler: 'Vyper 0.4.8 (High-Integrity Rail Spec)',
        owner: '0x19F02b4d8A7C6E5e3F1a2B4C5D6E7F8A9B0C1D2E',
        totalCalls: 8934,
        methods: [
          { name: 'allocateSignalSlot', inputs: [{ name: 'trackSector', type: 'bytes32' }, { name: 'trainId', type: 'uint256' }], outputs: [{ name: 'slotGranted', type: 'bool' }], stateMutability: 'payable' },
          { name: 'getSectorCongestion', inputs: [{ name: 'sectorId', type: 'bytes32' }], outputs: [{ name: 'load', type: 'uint8' }], stateMutability: 'view' }
        ],
        storageSlots: [
          { slot: '0x0000000000000000000000000000000000000000000000000000000000000000', variableName: 'activeTrainSlots', type: 'uint256', value: '142' },
          { slot: '0x0000000000000000000000000000000000000000000000000000000000000001', variableName: 'railwayGridState', type: 'bytes32', value: '0x7f8841a0b3...clear' }
        ],
        events: ['SignalStateChanged(bytes32 indexed sector, uint8 newSignalState)', 'SlotDispatched(uint256 trainId)'],
        codeSnippet: `@external
@payable
def allocateSignalSlot(trackSector: bytes32, trainId: uint256) -> bool:
    assert msg.value >= self.slotTariff, "TARIFF_INSUFFICIENT"
    self.activeTrainSlots += 1
    log SignalStateChanged(trackSector, 1) # CLEAR_GREEN
    return True`
      },
      '0xb8eB3331b2C1A3F9D701E788B2c7d91e6b78E3f4': {
        address: '0xb8eB3331b2C1A3F9D701E788B2c7d91e6b78E3f4',
        name: 'Cambridge_Semiconductor_WaferVault',
        compiler: 'Solidity 0.9.1',
        owner: '0x889B9c2F5d8aE41F3C1A2b4e7D901234567890AB',
        totalCalls: 6241,
        methods: [
          { name: 'verifyWaferBatch', inputs: [{ name: 'batchHash', type: 'bytes32' }, { name: 'yieldPercent', type: 'uint16' }], outputs: [{ name: 'tokenBatchId', type: 'uint256' }], stateMutability: 'nonpayable' }
        ],
        storageSlots: [
          { slot: '0x0000000000000000000000000000000000000000000000000000000000000000', variableName: 'totalBatchesVerified', type: 'uint256', value: '840' }
        ],
        events: ['BatchMinted(uint256 indexed batchId, uint16 yieldPercent)'],
        codeSnippet: `contract Cambridge_Semiconductor_WaferVault {
    uint256 public totalBatchesVerified;
    function verifyWaferBatch(bytes32 batchHash, uint16 yieldPercent) external returns (uint256) {
        totalBatchesVerified++;
        emit BatchMinted(totalBatchesVerified, yieldPercent);
        return totalBatchesVerified;
    }
}`
      }
    };

    // 4. Initial Genesis Blocks
    const baseTimestamp = 1710000000000;
    const seededRandom = (seed: number) => {
      const x = Math.sin(seed) * 10000;
      return x - Math.floor(x);
    };

    let parentHash = '0x0000000000000000000000000000000000000000000000000000000000000000';
    for (let height = 8400; height <= 8421; height++) {
      const blockHash = '0x' + Array.from({ length: 64 }, (_, idx) => 
        Math.floor(seededRandom(height * 100 + idx) * 16).toString(16)
      ).join('');
      const txCount = Math.floor(8 + seededRandom(height * 7) * 16);
      const gasLimit = 30000000;
      const gasUsed = Math.floor(gasLimit * (0.35 + seededRandom(height * 13) * 0.45));
      const baseFeeGwei = Number((24 + Math.sin(height * 0.4) * 8).toFixed(1));

      const txHashes: string[] = [];
      for (let i = 0; i < txCount; i++) {
        const txHash = '0x' + Array.from({ length: 64 }, (_, idx) => 
          Math.floor(seededRandom(height * 1000 + i * 50 + idx) * 16).toString(16)
        ).join('');
        txHashes.push(txHash);

        const txObj: Web3Transaction = {
          hash: txHash,
          from: Object.keys(this.accounts)[i % Object.keys(this.accounts).length],
          to: Object.keys(this.contracts)[i % Object.keys(this.contracts).length] || Object.keys(this.accounts)[(i + 1) % Object.keys(this.accounts).length],
          valueEth: Number((seededRandom(height + i) * 4.5).toFixed(3)),
          gasPriceGwei: baseFeeGwei + Number((seededRandom(height * 3 + i) * 4).toFixed(1)),
          gasUsed: Math.floor(21000 + seededRandom(height * 5 + i) * 85000),
          gasLimit: 120000,
          nonce: 10 + i,
          timestamp: baseTimestamp - (8421 - height) * 4000 - i * 150,
          status: 'final',
          blockHeight: height,
          type: i % 3 === 0 ? 'contract_call' : 'transfer',
          method: i % 3 === 0 ? 'swapExactTokensForTokens' : undefined,
          executionTrace: this.generateSampleTrace(txHash)
        };
        this.transactions.unshift(txObj);
      }

      const diffs: StateDiffItem[] = [
        { address: '0x4A81b2C1A3F9D701E788B2c7d91e6b78E3f2A180', type: 'balance', oldVal: '12498.10 ETH', newVal: '12500.45 ETH' },
        { address: '0x71aD9991b2C1A3F9D701E788B2c7d91e6b78E3f1', type: 'storage', key: 'slot_0', oldVal: '2838500000', newVal: '2840000000' },
      ];

      const block: Web3Block = {
        height,
        hash: blockHash,
        parentHash,
        timestamp: baseTimestamp - (8421 - height) * 4000,
        txCount,
        txHashes,
        gasUsed,
        gasLimit,
        gasRatio: gasUsed / gasLimit,
        stateRoot: '0x' + Array.from({ length: 64 }, (_, idx) => 
          Math.floor(seededRandom(height * 200 + idx) * 16).toString(16)
        ).join(''),
        validator: this.nodes[height % this.nodes.length].id,
        validatorRegion: this.nodes[height % this.nodes.length].region,
        sizeKb: Number((48 + txCount * 1.8).toFixed(1)),
        stateDiffs: diffs,
        baseFeeGwei,
      };

      this.blocks.unshift(block);
      parentHash = blockHash;
      this.saveSnapshot(height);
    }
  }

  private generateSampleTrace(txHash: string): ExecutionTrace {
    return {
      txHash,
      gasConsumed: 64820,
      returnValue: '0x0000000000000000000000000000000000000000000000000000000000000001',
      steps: [
        { pc: 0, op: 'PUSH1 0x80', gasCost: 3, stack: ['0x80'] },
        { pc: 2, op: 'PUSH1 0x40', gasCost: 3, stack: ['0x40', '0x80'] },
        { pc: 4, op: 'MSTORE', gasCost: 6, stack: [], memory: '0x00...80' },
        { pc: 5, op: 'CALLVALUE', gasCost: 2, stack: ['0x00'] },
        { pc: 6, op: 'DUP1', gasCost: 3, stack: ['0x00', '0x00'] },
        { pc: 7, op: 'ISZERO', gasCost: 3, stack: ['0x01'] },
        { pc: 8, op: 'PUSH2 0x0010', gasCost: 3, stack: ['0x0010', '0x01'] },
        { pc: 11, op: 'JUMPI', gasCost: 10, stack: [] },
        { pc: 16, op: 'SLOAD (Slot 0)', gasCost: 2100, stack: ['0x000000000000000000000000a94e82b'] },
        { pc: 18, op: 'SSTORE (Slot 0)', gasCost: 5000, stack: [], storageDiff: { key: 'Slot 0 (Reserves)', prev: '2838500000', next: '2840000000' } },
        { pc: 24, op: 'LOG2 (Swap)', gasCost: 1800, stack: [] },
        { pc: 30, op: 'RETURN', gasCost: 0, stack: [] }
      ],
      subCalls: [
        { to: '0x71aD9991b2C1A3F9D701E788B2c7d91e6b78E3f1', value: '0.00 ETH', method: 'syncSovereignSpread(15)' }
      ],
      eventsEmitted: [
        { name: 'Swap', params: { amount0In: 150000, amount1Out: 24.8 } }
      ]
    };
  }

  private saveSnapshot(height: number) {
    if (this.blocks.length === 0) return;
    const snap: ProtocolSnapshot = {
      blockHeight: height,
      timestamp: Date.now(),
      blocks: JSON.parse(JSON.stringify(this.blocks.slice(0, 30))),
      accounts: JSON.parse(JSON.stringify(this.accounts)),
      contracts: JSON.parse(JSON.stringify(this.contracts)),
      mempool: JSON.parse(JSON.stringify(this.mempool)),
      totalTxs: this.transactions.length,
      latestBlock: JSON.parse(JSON.stringify(this.blocks[0])),
    };

    this.snapshots.push(snap);
    if (this.snapshots.length > 50) {
      this.snapshots.shift();
    }
  }

  public getSnapshotForHeight(height: number): ProtocolSnapshot | null {
    const found = this.snapshots.find(s => s.blockHeight === height);
    if (found) return found;
    // Fallback if exact snapshot wasn't kept
    const blk = this.blocks.find(b => b.height === height);
    if (blk) {
      return {
        blockHeight: height,
        timestamp: blk.timestamp,
        blocks: this.blocks.filter(b => b.height <= height),
        accounts: this.accounts,
        contracts: this.contracts,
        mempool: [],
        totalTxs: this.transactions.filter(t => (t.blockHeight || 0) <= height).length,
        latestBlock: blk,
      };
    }
    return null;
  }

  // Live Mining & Transaction Loop
  public startSimulation() {
    if (typeof window === 'undefined') return;
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => {
      if (this.isRunning) {
        this.stepSimulation();
      }
    }, Math.max(800, this.blockIntervalMs / this.simulationSpeed));
  }

  public stepSimulation() {
    // 1. Process Mempool or inject simulated transactions
    const txToIncludeCount = Math.min(this.mempool.length, 12);
    const includedTxs: Web3Transaction[] = [];

    if (txToIncludeCount > 0) {
      const pulled = this.mempool.splice(0, txToIncludeCount);
      pulled.forEach(tx => {
        tx.status = 'block';
        includedTxs.push(tx);
      });
    }

    // Generate 3-8 fresh network transactions
    const autoGenCount = Math.floor(4 + Math.random() * 6);
    const accountKeys = Object.keys(this.accounts);
    const contractKeys = Object.keys(this.contracts);

    for (let i = 0; i < autoGenCount; i++) {
      const fromAcc = accountKeys[Math.floor(Math.random() * accountKeys.length)];
      const isContractCall = Math.random() > 0.4;
      const toAcc = isContractCall 
        ? contractKeys[Math.floor(Math.random() * contractKeys.length)]
        : accountKeys[Math.floor(Math.random() * accountKeys.length)];

      const val = Number((Math.random() * 2.5).toFixed(3));
      const txHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      
      const newTx: Web3Transaction = {
        hash: txHash,
        from: fromAcc,
        to: toAcc,
        valueEth: val,
        gasPriceGwei: Number((22 + Math.random() * 14).toFixed(1)),
        gasUsed: Math.floor(21000 + Math.random() * 65000),
        gasLimit: 120000,
        nonce: (this.accounts[fromAcc]?.nonce || 0) + 1,
        timestamp: Date.now(),
        status: 'executing',
        type: isContractCall ? 'contract_call' : 'transfer',
        method: isContractCall ? 'swapExactTokensForTokens' : undefined,
        executionTrace: this.generateSampleTrace(txHash)
      };

      if (this.accounts[fromAcc]) {
        this.accounts[fromAcc].nonce += 1;
        this.accounts[fromAcc].txCount += 1;
        if (this.accounts[fromAcc].balanceEth >= val) {
          this.accounts[fromAcc].balanceEth -= val;
        }
      }
      if (this.accounts[toAcc]) {
        this.accounts[toAcc].balanceEth += val;
      }

      includedTxs.push(newTx);
      this.emit('TX_SUBMITTED', newTx);
    }

    // 2. Mine new Block
    const latestHeight = this.blocks.length > 0 ? this.blocks[0].height + 1 : 8422;
    const parentHash = this.blocks.length > 0 ? this.blocks[0].hash : '0x0';
    const blockHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const gasLimit = 30000000;
    const gasUsed = includedTxs.reduce((acc, t) => acc + t.gasUsed, 0) + Math.floor(gasLimit * 0.3);
    const validatorNode = this.nodes[latestHeight % this.nodes.length];
    
    includedTxs.forEach(t => {
      t.status = 'final';
      t.blockHeight = latestHeight;
      this.transactions.unshift(t);
    });

    // Update node validation stats
    if (validatorNode) {
      validatorNode.blocksValidated += 1;
      validatorNode.tps = Math.round(includedTxs.length * 3.4 + Math.random() * 10);
    }

    const stateDiffs: StateDiffItem[] = [
      {
        address: validatorNode ? validatorNode.ip : '0x4A81...',
        type: 'balance',
        oldVal: '+0.000 ETH',
        newVal: `+${(includedTxs.length * 0.012).toFixed(3)} ETH (Block Reward)`
      }
    ];

    const newBlock: Web3Block = {
      height: latestHeight,
      hash: blockHash,
      parentHash,
      timestamp: Date.now(),
      txCount: includedTxs.length,
      txHashes: includedTxs.map(t => t.hash),
      gasUsed,
      gasLimit,
      gasRatio: Math.min(0.98, gasUsed / gasLimit),
      stateRoot: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      validator: validatorNode?.id || 'node_lse_01',
      validatorRegion: validatorNode?.region || 'London Central (LSE)',
      sizeKb: Number((52 + includedTxs.length * 2.1).toFixed(1)),
      stateDiffs,
      baseFeeGwei: Number((24 + Math.sin(latestHeight * 0.2) * 6).toFixed(1))
    };

    this.blocks.unshift(newBlock);
    if (this.blocks.length > 80) this.blocks.pop();
    if (this.transactions.length > 200) this.transactions.pop();

    this.saveSnapshot(latestHeight);
    this.emit('BLOCK_CREATED', newBlock);
  }

  // Public Interaction Controls
  public injectUserTransaction(
    from: string,
    to: string,
    valueEth: number,
    type: 'transfer' | 'contract_call' = 'transfer',
    method?: string
  ): Web3Transaction {
    const txHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const tx: Web3Transaction = {
      hash: txHash,
      from,
      to,
      valueEth,
      gasPriceGwei: 28.5,
      gasUsed: 42000,
      gasLimit: 150000,
      nonce: (this.accounts[from]?.nonce || 0) + 1,
      timestamp: Date.now(),
      status: 'mempool',
      type,
      method,
      executionTrace: this.generateSampleTrace(txHash)
    };

    this.mempool.unshift(tx);
    this.emit('TX_SUBMITTED', tx);
    return tx;
  }

  public triggerNodeFailure(nodeId: string) {
    const node = this.nodes.find(n => n.id === nodeId);
    if (node) {
      node.status = node.status === 'offline' ? 'online' : 'offline';
      this.emit('NODE_STATUS_CHANGED', node);
    }
  }

  public setSimulationSpeed(speed: number) {
    this.simulationSpeed = speed;
    this.startSimulation();
    this.emit('SIM_CONFIG_CHANGED', { speed });
  }

  public toggleSimulation(running?: boolean) {
    this.isRunning = running !== undefined ? running : !this.isRunning;
    this.emit('SIM_CONFIG_CHANGED', { isRunning: this.isRunning });
  }

  public runScenario(scenarioId: string) {
    switch (scenarioId) {
      case 'lse_arbitrage':
        // Rapid injection of 8 high-value transactions
        for (let i = 0; i < 8; i++) {
          this.injectUserTransaction(
            '0x889B9c2F5d8aE41F3C1A2b4e7D901234567890AB',
            '0x71aD9991b2C1A3F9D701E788B2c7d91e6b78E3f1',
            Number((10 + i * 5.2).toFixed(2)),
            'contract_call',
            'swapExactTokensForTokens'
          );
        }
        break;

      case 'harwell_spike':
        const harwell = this.nodes.find(n => n.id === 'node_harwell_04');
        if (harwell) {
          harwell.status = 'congested';
          harwell.latencyMs = 124;
          this.emit('NODE_STATUS_CHANGED', harwell);
        }
        break;

      case 'node_outage':
        this.triggerNodeFailure('node_canary_02');
        break;

      case 'sovereign_dividend':
        this.injectUserTransaction(
          '0x4A81b2C1A3F9D701E788B2c7d91e6b78E3f2A180',
          '0x889B9c2F5d8aE41F3C1A2b4e7D901234567890AB',
          250.0,
          'transfer'
        );
        break;
    }
    this.emit('SCENARIO_RUN', scenarioId);
  }

  public handleRpcRequest(method: string, params: unknown[] = []) {
    switch (method) {
      case 'eth_blockNumber':
        return {
          jsonrpc: '2.0',
          result: '0x' + (this.blocks[0]?.height || 8421).toString(16),
          id: 1,
        };
      case 'eth_getBalance':
        const addr = (params[0] as string) || Object.keys(this.accounts)[0];
        const acc = this.accounts[addr];
        const balanceWei = (acc ? acc.balanceEth : 100) * 1e18;
        return {
          jsonrpc: '2.0',
          result: '0x' + Math.floor(balanceWei).toString(16),
          id: 1,
        };
      case 'eth_getBlockByNumber':
        const blk = this.blocks[0] || {};
        return {
          jsonrpc: '2.0',
          result: blk,
          id: 1,
        };
      case 'eth_estimateGas':
        return {
          jsonrpc: '2.0',
          result: '0x5208', // 21,000 gas
          id: 1,
        };
      case 'web3_clientVersion':
        return {
          jsonrpc: '2.0',
          result: 'SILICAFLUX/v3.0.0-AngloFuturist2040/linux-arm64/rust1.82',
          id: 1,
        };
      case 'silica_networkTopology':
        return {
          jsonrpc: '2.0',
          result: {
            nodes: this.nodes.length,
            activeValidators: this.nodes.filter(n => n.status === 'online').length,
            meshRegion: 'UK_SOVEREIGN_MESH',
            latencyP95Ms: 38,
          },
          id: 1,
        };
      default:
        return {
          jsonrpc: '2.0',
          error: { code: -32601, message: `Method ${method} not found` },
          id: 1,
        };
    }
  }

  // Getters
  public getBlocks() { return this.blocks; }
  public getLatestBlock() { return this.blocks[0] || { height: 8421, hash: '0x0', parentHash: '0x0', timestamp: Date.now(), txCount: 0, gasUsed: 0, gasLimit: 30000000, baseFeeGwei: 24, validator: 'London LSE', validatorRegion: 'London', sizeKb: 12, stateRoot: '0x0', gasRatio: 0.45, stateDiffs: [] }; }
  public getTransactions() { return this.transactions; }
  public getMempool() { return this.mempool; }
  public getAccounts() { return this.accounts; }
  public getContracts() { return this.contracts; }
  public getNodes() { return this.nodes; }
  public getSimulationState() {
    return {
      isRunning: this.isRunning,
      speed: this.simulationSpeed,
      latestHeight: this.blocks[0]?.height || 8421
    };
  }
}

// Global Singleton Instance
export const web3Emu = new Web3EmuEngine();
