// SILICAFLUX WEB3.0 - MASTER TYPE DEFINITIONS
// Anglo-Futurist 2040 GUI & Interaction System

export type ThemeMode = 'obsidian' | 'archive';
export type ViewDensity = 'human' | 'normal' | 'high' | 'engineering' | 'machine';
export type NavTab = 
  | 'observatory'
  | 'city'
  | 'blocks'
  | 'transactions'
  | 'accounts'
  | 'contracts'
  | 'state'
  | 'quant'
  | 'time_machine'
  | 'simulation'
  | 'developer'
  | 'motion_lab';

// -------------------------------------------------------------
// PROTOCOL DATA (WEB3EMU - AUTHORITATIVE TRUTH)
// -------------------------------------------------------------

export type TxLifecycleStatus = 
  | 'created'
  | 'signed'
  | 'submitted'
  | 'mempool'
  | 'executing'
  | 'block'
  | 'final'
  | 'failed';

export interface OpcodeStep {
  pc: number;
  op: string;
  gasCost: number;
  stack: string[];
  memory?: string;
  storageDiff?: { key: string; prev: string; next: string };
}

export interface ExecutionTrace {
  txHash: string;
  steps: OpcodeStep[];
  gasConsumed: number;
  returnValue: string;
  subCalls: { to: string; value: string; method: string }[];
  eventsEmitted: { name: string; params: Record<string, string | number> }[];
}

export interface Web3Transaction {
  hash: string;
  from: string;
  to: string;
  valueEth: number;
  gasPriceGwei: number;
  gasUsed: number;
  gasLimit: number;
  nonce: number;
  timestamp: number;
  status: TxLifecycleStatus;
  method?: string;
  data?: string;
  blockHeight?: number;
  executionTrace?: ExecutionTrace;
  error?: string;
  type: 'transfer' | 'contract_call' | 'contract_deploy' | 'liquidity_swap' | 'oracle_update';
}

export interface StateDiffItem {
  address: string;
  type: 'balance' | 'nonce' | 'storage';
  key?: string;
  oldVal: string;
  newVal: string;
}

export interface Web3Block {
  height: number;
  hash: string;
  parentHash: string;
  timestamp: number;
  txCount: number;
  txHashes: string[];
  gasUsed: number;
  gasLimit: number;
  gasRatio: number;
  stateRoot: string;
  validator: string;
  validatorRegion: string;
  sizeKb: number;
  stateDiffs: StateDiffItem[];
  baseFeeGwei: number;
}

export interface TokenBalance {
  symbol: string;
  name: string;
  balance: number;
  decimals: number;
  usdValue: number;
  contractAddress: string;
}

export interface Web3Account {
  address: string;
  label: string;
  type: 'eoa' | 'contract' | 'validator' | 'treasury';
  balanceEth: number;
  nonce: number;
  txCount: number;
  tokens: TokenBalance[];
  storage?: Record<string, string>;
  isMonitored?: boolean;
}

export interface ContractMethod {
  name: string;
  inputs: { name: string; type: string }[];
  outputs: { name: string; type: string }[];
  stateMutability: 'view' | 'nonpayable' | 'payable';
}

export interface SmartContract {
  address: string;
  name: string;
  compiler: string;
  methods: ContractMethod[];
  storageSlots: { slot: string; variableName: string; type: string; value: string }[];
  events: string[];
  owner: string;
  totalCalls: number;
  codeSnippet: string;
}

export interface NetworkNode {
  id: string;
  name: string;
  region: 'London Central (LSE)' | 'Canary Wharf Financial' | 'Cambridge Science Park' | 'Harwell Space Cluster' | 'Oxford Physics' | 'Edinburgh FinTech';
  ip: string;
  status: 'online' | 'congested' | 'offline' | 'reorganizing';
  latencyMs: number;
  peers: string[];
  blocksValidated: number;
  tps: number;
  x: number;
  y: number;
  z?: number;
}

export interface ProtocolSnapshot {
  blockHeight: number;
  timestamp: number;
  blocks: Web3Block[];
  accounts: Record<string, Web3Account>;
  contracts: Record<string, SmartContract>;
  mempool: Web3Transaction[];
  totalTxs: number;
  latestBlock: Web3Block;
}

// -------------------------------------------------------------
// QUANTITATIVE DATA (R ENGINE - RHINOQUANT)
// -------------------------------------------------------------

export interface QuantMetrics {
  tpsCurrent: number;
  tpsAverage: number;
  gasVolatility: number;
  latencyP50: number;
  latencyP95: number;
  latencyP99: number;
  networkEntropy: number;
  accountGiniIndex: number;
  anomalyScore: number; // 0.0 to 1.0
  activeValidators: number;
  mempoolPressure: number; // 0.0 to 1.0
  blockTimeVariance: number;
  histGasUtilization: number[];
  histTps: { time: string; value: number }[];
  kdeDistribution: { bin: number; density: number }[];
  lorenzCurve: { percentile: number; share: number }[];
}

export interface QuantVisualParameters {
  lineThickness: number;
  signalSpeedMultiplier: number;
  railGlowIntensity: number;
  particleDensity: number;
  anomalyAlertLevel: 'nominal' | 'elevated' | 'critical';
  gasDialDegree: number;
  topologicalCentrality: number;
}

// -------------------------------------------------------------
// MOTION DATA (KOTLIN MOTION ENGINE)
// -------------------------------------------------------------

export interface SpringPhysics {
  stiffness: number;
  damping: number;
  mass: number;
  velocity: number;
  position: number;
  target: number;
}

export interface MotionPrimitiveConfig {
  durationMs: number;
  delayMs?: number;
  easing?: 'spring' | 'cubicBezier' | 'decelerate' | 'anticipate' | 'linear';
  springConfig?: { stiffness: number; damping: number; mass: number };
}

export type KotlinGrammarType =
  | 'SFade'
  | 'SScale'
  | 'STranslate'
  | 'SRotate'
  | 'SBlur'
  | 'SReveal'
  | 'SExpand'
  | 'SCollapse'
  | 'SOrbit'
  | 'SFlow'
  | 'SPulse'
  | 'SSpring'
  | 'SStagger'
  | 'SSequence'
  | 'SParallel'
  | 'SInterrupt';

export interface VisualMovingSignal {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  txHash: string;
  value: number;
  progress: number; // 0 to 1
  speed: number;
  color: string;
  type: 'tx' | 'block' | 'event' | 'sync';
}
