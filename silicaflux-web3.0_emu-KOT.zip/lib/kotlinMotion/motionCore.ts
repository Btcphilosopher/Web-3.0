// SILICAFLUX MOTION CORE (KOTLIN MOTION ENGINE INTEGRATION)
// 2040 Physics, Spring Dynamics, and Composable Animation Grammar

import { KotlinGrammarType, SpringPhysics } from '../types';

export interface SpringConfig {
  stiffness: number; // k
  damping: number;   // c
  mass: number;      // m
}

export const PRESET_SPRINGS = {
  INSTANT: { stiffness: 450, damping: 35, mass: 1 },
  FAST: { stiffness: 320, damping: 28, mass: 1 },
  STANDARD: { stiffness: 210, damping: 22, mass: 1 },
  STRUCTURAL: { stiffness: 140, damping: 18, mass: 1.2 },
  CINEMATIC: { stiffness: 85, damping: 14, mass: 1.5 },
  RESONANT: { stiffness: 180, damping: 10, mass: 1 },
};

export class SpringSimulator {
  public stiffness: number;
  public damping: number;
  public mass: number;

  constructor(stiffness: number = 210, damping: number = 22, mass: number = 1.0) {
    this.stiffness = stiffness;
    this.damping = damping;
    this.mass = mass;
  }

  public update(currentPos: number, currentVel: number, targetPos: number, dt: number) {
    const displacement = currentPos - targetPos;
    const springForce = -this.stiffness * displacement;
    const dampingForce = -this.damping * currentVel;
    const totalForce = springForce + dampingForce;
    const acceleration = totalForce / Math.max(this.mass, 0.1);

    const newVelocity = currentVel + acceleration * dt;
    const newPosition = currentPos + newVelocity * dt;

    return {
      position: newPosition,
      velocity: newVelocity,
    };
  }
}

export class SpringEngine {
  public static step(state: SpringPhysics, dt: number): SpringPhysics {
    // F = -k * (x - target) - c * v
    const displacement = state.position - state.target;
    const springForce = -state.stiffness * displacement;
    const dampingForce = -state.damping * state.velocity;
    const totalForce = springForce + dampingForce;
    const acceleration = totalForce / Math.max(state.mass, 0.1);

    const newVelocity = state.velocity + acceleration * dt;
    const newPosition = state.position + newVelocity * dt;

    return {
      ...state,
      position: newPosition,
      velocity: newVelocity,
    };
  }

  public static isSettled(state: SpringPhysics, threshold: number = 0.001): boolean {
    return Math.abs(state.position - state.target) < threshold && Math.abs(state.velocity) < threshold;
  }
}

// Composable Kotlin Motion Grammar Model
export interface AnimationStep {
  type: KotlinGrammarType;
  params: Record<string, number | string | boolean>;
  durationMs: number;
}

export class KotlinMotionGrammar {
  public static createTransactionMotionSequence(status: string, importance: number = 1) {
    const steps: AnimationStep[] = [];
    
    switch (status) {
      case 'created':
      case 'signed':
        steps.push({
          type: 'SFade',
          params: { from: 0, to: 1, alpha: 0.9 },
          durationMs: 120,
        });
        steps.push({
          type: 'SScale',
          params: { from: 0.8, to: 1.0, overshoot: 1.05 },
          durationMs: 180,
        });
        break;

      case 'mempool':
        steps.push({
          type: 'SFlow',
          params: { trajectory: 'rail_transit', speed: 1.5 * importance },
          durationMs: 400,
        });
        steps.push({
          type: 'SPulse',
          params: { frequency: 1.2, intensity: 0.4 },
          durationMs: 300,
        });
        break;

      case 'executing':
        steps.push({
          type: 'SReveal',
          params: { direction: 'downward', opcodeStep: true },
          durationMs: 250,
        });
        steps.push({
          type: 'SSpring',
          params: { stiffness: 280, damping: 20 },
          durationMs: 350,
        });
        break;

      case 'block':
      case 'final':
        steps.push({
          type: 'SExpand',
          params: { expansionRatio: 1.15, structural: true },
          durationMs: 320,
        });
        steps.push({
          type: 'SStagger',
          params: { delayBetweenChildren: 25 },
          durationMs: 200,
        });
        break;

      case 'failed':
        steps.push({
          type: 'SInterrupt',
          params: { retarget: true, color: 'var(--sf-red)' },
          durationMs: 180,
        });
        break;

      default:
        steps.push({
          type: 'SFade',
          params: { from: 0, to: 1 },
          durationMs: 150,
        });
    }

    return steps;
  }

  // Procedural Motion Generator derived from R Quantitative Signals
  public static deriveProceduralMotion(data: {
    tps: number;
    gasVolatility: number;
    networkLatency: number;
    anomalyScore: number;
  }) {
    // Calculate dynamic spring & velocity parameters
    const dynamicStiffness = Math.max(120, Math.min(480, 240 + data.tps * 1.5));
    const dynamicDamping = Math.max(12, Math.min(36, 22 - data.gasVolatility * 15));
    const signalSpeed = Math.max(0.6, Math.min(3.2, 1.0 + (data.tps / 100) - (data.networkLatency / 800)));
    const alertPulseIntensity = Math.min(1.0, data.anomalyScore * 2.5);

    return {
      springConfig: {
        stiffness: dynamicStiffness,
        damping: dynamicDamping,
        mass: 1.0,
      },
      signalSpeed,
      alertPulseIntensity,
      transitionDuration: Math.round(300 / signalSpeed),
      railGlowOpacity: Math.min(0.9, 0.2 + (data.tps / 200)),
    };
  }
}
