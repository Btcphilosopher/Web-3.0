import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SILICAFLUX WEB3.0 — Anglo-Futurist 2040 GUI & Interaction System',
  description: 'Radically advanced 2040-style Anglo-futurist graphical operating environment for Web3.0 infrastructure.',
  openGraph: {
    title: 'SILICAFLUX WEB3.0 — Anglo-Futurist 2040 GUI & Interaction System',
    description: 'Radically advanced 2040-style Anglo-futurist graphical operating environment for Web3.0 infrastructure.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SILICAFLUX WEB3.0',
    description: 'Radically advanced 2040-style Anglo-futurist graphical operating environment for Web3.0 infrastructure.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Syne:wght@500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body
        className="min-h-screen bg-[var(--sf-bg)] text-[var(--sf-text)] antialiased selection:bg-[var(--sf-accent)] selection:text-white font-sans overflow-x-hidden"
        style={{ fontFamily: "'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif" }}
        suppressHydrationWarning
      >
        {children}
      </body>
    </html>
  );
}

