'use client';

import React, { useState, useEffect } from 'react';
import { 
  NavTab, 
  ThemeMode, 
  ViewDensity, 
  Web3Block, 
  Web3Transaction, 
  Web3Account, 
  SmartContract, 
  NetworkNode, 
  QuantMetrics, 
  QuantVisualParameters 
} from '@/lib/types';
import { web3Emu } from '@/lib/web3emu/engine';
import { rhinoQuant } from '@/lib/rhinoquant/rEngine';
import { Header } from '@/components/Header';
import { Navigation } from '@/components/Navigation';
import { CommandBar } from '@/components/CommandBar';
import { ObservatoryView } from '@/components/views/ObservatoryView';
import { City3DView } from '@/components/views/City3DView';
import { BlocksView } from '@/components/views/BlocksView';
import { TransactionsView } from '@/components/views/TransactionsView';
import { AccountsView } from '@/components/views/AccountsView';
import { ContractsView } from '@/components/views/ContractsView';
import { StateSpaceView } from '@/components/views/StateSpaceView';
import { QuantObservatoryView } from '@/components/views/QuantObservatoryView';
import { TimeMachineView } from '@/components/views/TimeMachineView';
import { DeveloperConsoleView } from '@/components/views/DeveloperConsoleView';
import { MotionLabView } from '@/components/views/MotionLabView';

export default function SilicaFluxApp() {
  const [theme, setTheme] = useState<ThemeMode>('obsidian');
  const [density, setDensity] = useState<ViewDensity>('normal');
  const [activeTab, setActiveTab] = useState<NavTab>('observatory');
  const [isCommandOpen, setIsCommandOpen] = useState<boolean>(false);

  // Authoritative Protocol & Quant State
  const [nodes, setNodes] = useState<NetworkNode[]>(web3Emu.getNodes());
  const [blocks, setBlocks] = useState<Web3Block[]>(web3Emu.getBlocks());
  const [transactions, setTransactions] = useState<Web3Transaction[]>(web3Emu.getTransactions());
  const [mempool, setMempool] = useState<Web3Transaction[]>(web3Emu.getMempool());
  const [accounts, setAccounts] = useState<Record<string, Web3Account>>(web3Emu.getAccounts());
  const [contracts, setContracts] = useState<Record<string, SmartContract>>(web3Emu.getContracts());
  const [latestHeight, setLatestHeight] = useState<number>(web3Emu.getLatestBlock().height);

  const [quant, setQuant] = useState<QuantMetrics>(() => 
    rhinoQuant.calculateMetrics(web3Emu.getBlocks(), web3Emu.getTransactions(), web3Emu.getAccounts(), web3Emu.getNodes())
  );
  const [visualParams, setVisualParams] = useState<QuantVisualParameters>(() =>
    rhinoQuant.deriveVisualParameters(quant)
  );

  const [selectedTx, setSelectedTx] = useState<Web3Transaction | null>(null);

  // Subscribe to real-time Web3EMU protocol events
  useEffect(() => {
    web3Emu.startSimulation();

    const handleStateUpdate = () => {
      const curBlocks = web3Emu.getBlocks();
      const curTxs = web3Emu.getTransactions();
      const curAccounts = web3Emu.getAccounts();
      const curNodes = web3Emu.getNodes();

      setBlocks([...curBlocks]);
      setTransactions([...curTxs]);
      setMempool([...web3Emu.getMempool()]);
      setAccounts({ ...curAccounts });
      setContracts({ ...web3Emu.getContracts() });
      setNodes([...curNodes]);
      setLatestHeight(web3Emu.getLatestBlock().height);

      // Trigger R RhinoQuant quantitative update
      const newQuant = rhinoQuant.calculateMetrics(curBlocks, curTxs, curAccounts, curNodes);
      const newVisual = rhinoQuant.deriveVisualParameters(newQuant);
      setQuant(newQuant);
      setVisualParams(newVisual);
    };

    const unsubBlock = web3Emu.on('BLOCK_CREATED', handleStateUpdate);
    const unsubTx = web3Emu.on('TX_SUBMITTED', handleStateUpdate);
    const unsubNode = web3Emu.on('NODE_STATUS_CHANGED', handleStateUpdate);
    const unsubState = web3Emu.on('STATE_CHANGED', handleStateUpdate);

    return () => {
      unsubBlock();
      unsubTx();
      unsubNode();
      unsubState();
    };
  }, [quant]);

  // Synchronize document theme class
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'archive') {
      root.classList.add('archive');
    } else {
      root.classList.remove('archive');
    }
  }, [theme]);

  const handleToggleTheme = () => {
    setTheme(prev => (prev === 'obsidian' ? 'archive' : 'obsidian'));
  };

  const handleSelectTx = (tx: Web3Transaction) => {
    setSelectedTx(tx);
    setActiveTab('transactions');
  };

  const handleSelectBlock = (height: number) => {
    setActiveTab('blocks');
  };

  const activeNodesCount = nodes.filter(n => n.status === 'online').length;

  return (
    <div className={`flex flex-col h-screen w-screen overflow-hidden bg-[var(--sf-bg)] text-[var(--sf-text)] density-${density}`}>
      {/* Precision British-Engineering Header */}
      <Header
        theme={theme}
        onToggleTheme={handleToggleTheme}
        density={density}
        onChangeDensity={setDensity}
        onOpenCommand={() => setIsCommandOpen(true)}
        latestHeight={latestHeight}
        activeNodesCount={activeNodesCount}
        anomalyLevel={visualParams.anomalyAlertLevel}
      />

      {/* Primary Navigation Strip */}
      <Navigation
        activeTab={activeTab}
        onChangeTab={setActiveTab}
      />

      {/* Main View Area */}
      <main className="flex-1 w-full overflow-hidden relative">
        {activeTab === 'observatory' && (
          <ObservatoryView
            nodes={nodes}
            latestBlock={blocks[0] || null}
            recentTxs={transactions}
            quant={quant}
            visualParams={visualParams}
            density={density}
            onSelectTx={handleSelectTx}
            onSelectBlock={handleSelectBlock}
          />
        )}

        {activeTab === 'city' && (
          <City3DView
            blocks={blocks}
            accounts={accounts}
            contracts={contracts}
            recentTxs={transactions}
            onSelectBlock={handleSelectBlock}
          />
        )}

        {activeTab === 'blocks' && (
          <BlocksView
            blocks={blocks}
            transactions={transactions}
            onSelectTx={handleSelectTx}
          />
        )}

        {activeTab === 'transactions' && (
          <TransactionsView
            transactions={transactions}
            mempool={mempool}
            accounts={accounts}
            contracts={contracts}
            selectedTx={selectedTx}
            onSelectTx={setSelectedTx}
          />
        )}

        {activeTab === 'accounts' && (
          <AccountsView
            accounts={accounts}
            transactions={transactions}
            onSelectTx={handleSelectTx}
          />
        )}

        {activeTab === 'contracts' && (
          <ContractsView
            contracts={contracts}
            onSelectTx={handleSelectTx}
          />
        )}

        {activeTab === 'state' && (
          <StateSpaceView
            accounts={accounts}
            contracts={contracts}
            latestBlock={blocks[0] || null}
          />
        )}

        {activeTab === 'quant' && (
          <QuantObservatoryView
            quant={quant}
            visualParams={visualParams}
          />
        )}

        {activeTab === 'time_machine' && (
          <TimeMachineView
            blocks={blocks}
            latestHeight={latestHeight}
          />
        )}

        {activeTab === 'developer' && (
          <DeveloperConsoleView />
        )}

        {activeTab === 'motion_lab' && (
          <MotionLabView />
        )}
      </main>

      {/* Bento Grid Status Footer */}
      <footer className="h-8 bg-[#151515] border-t border-[#2A2A2A] flex items-center px-6 justify-between text-[9px] font-mono text-[#888888] tracking-wider uppercase select-none shrink-0">
        <div>Kernel v8.44.1 // Architecture: Anglo-Futurist 2040</div>
        <div className="hidden sm:flex items-center space-x-6">
          <span className="text-[#00FF41]">Encrypted Tunnel: OK</span>
          <span>Signal Integrity: 99.98%</span>
          <span>Spatial Engine: WebGPU High</span>
          <span className="text-[#E4E4E4]">Height: #{latestHeight.toLocaleString()}</span>
        </div>
      </footer>

      {/* Omnipresent Command Palette ⌘K */}
      <CommandBar
        isOpen={isCommandOpen}
        onClose={() => setIsCommandOpen(false)}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setIsCommandOpen(false);
        }}
        onToggleTheme={handleToggleTheme}
        onChangeDensity={setDensity}
      />
    </div>
  );
}
