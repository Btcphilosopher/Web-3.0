package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid - Void Cyber Concept
val BentoBg = Color(0xFF030303)         // Minimal pure void black
val BentoTileBg = Color(0xFF0A0F15)     // Deep tile backing
val BentoTileOverlay = Color(0xFF00F0FF) // Alpha component tint
val BentoCyan = Color(0xFF00F0FF)       // Electric cyber cyan
val BentoAmber = Color(0xFFFFB300)      // High voltage amber warning
val BentoRed = Color(0xFFEF5350)        // Alert warning red
val BentoMuted = Color(0xFF5A788C)      // Subdued display readout slate
val BentoBorder = Color(0xFF00F0FF)     // Border cyan overlay
val BentoTextPrimary = Color(0xFFF0F9FF)// Pure clean ice white for content
val BentoTextSecondary = Color(0xFF00F0FF)// Cyber electric cyan reading
