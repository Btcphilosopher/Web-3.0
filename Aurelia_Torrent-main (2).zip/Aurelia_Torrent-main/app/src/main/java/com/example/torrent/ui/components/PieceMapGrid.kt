package com.example.torrent.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun PieceMapGrid(
    pieces: BooleanArray,
    streamModeOn: Boolean,
    activePlaybackPiece: Int,
    modifier: Modifier = Modifier
) {
    val totalPieces = pieces.size
    // Cap visual rendering counts at 128 items to avoid heavy lag, showing a representative mapped slice
    val gridLimit = 120
    val renderSliceCount = minOf(totalPieces, gridLimit)

    // Breathing timer animation for active sequential queue blinking
    val transition = rememberInfiniteTransition(label = "piece_blink")
    val amberBlinkAlpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blink"
    )

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SWARM PIECE MAP (REPRESENTATIVE SCAN)",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BentoCyan,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            )
            Text(
                text = "SCANNED: $renderSliceCount/$totalPieces PIECES",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BentoMuted,
                    fontFamily = FontFamily.Monospace
                )
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BentoBorder.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                .background(BentoTileBg, RoundedCornerShape(12.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            userScrollEnabled = false
        ) {
            items(renderSliceCount) { index ->
                val isDone = if (index < totalPieces) pieces[index] else false
                
                // Highlight block state colors
                val isStreamingWindow = streamModeOn && 
                        index >= activePlaybackPiece && 
                        index <= (activePlaybackPiece + 12).coerceAtMost(totalPieces - 1)

                val blockColor = when {
                    isDone -> BentoCyan // Neon Cyber-Cyan finished
                    isStreamingWindow -> BentoAmber // Active streaming buffer focus
                    else -> Color(0xFF161E2E) // Muted charcoal incomplete
                }

                val finalAlpha = if (isStreamingWindow && !isDone) amberBlinkAlpha else 1.0f

                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .alpha(finalAlpha)
                        .background(blockColor, RoundedCornerShape(2.dp))
                        .border(
                            width = 0.5.dp,
                            color = if (isStreamingWindow) BentoAmber else Color.White.copy(alpha = 0.05f),
                            shape = RoundedCornerShape(2.dp)
                        )
                )
            }
        }
    }
}

