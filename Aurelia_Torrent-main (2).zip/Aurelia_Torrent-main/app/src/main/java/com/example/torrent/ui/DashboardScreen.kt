package com.example.torrent.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.layout
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.torrent.engine.TorrentState
import com.example.torrent.model.PeerNode
import com.example.torrent.model.TorrentFile
import com.example.torrent.model.TorrentStatus
import com.example.torrent.ui.components.PieceMapGrid
import com.example.ui.theme.*
import com.example.torrent.ui.components.SwarmVisualizerCanvas
import com.example.torrent.ui.components.TransferRateChart
import com.example.torrent.ui.components.VideoPlayerWidget
import com.example.torrent.viewmodel.TorrentFilter
import com.example.torrent.viewmodel.TorrentViewModel
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: TorrentViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val torrents by viewModel.filteredTorrents.collectAsStateWithLifecycle()
    val selectedTorrent by viewModel.selectedTorrent.collectAsStateWithLifecycle()
    val currentFilter by viewModel.filter.collectAsStateWithLifecycle()

    val globalDlSpeed by viewModel.globalDownloadRate.collectAsStateWithLifecycle()
    val globalUlSpeed by viewModel.globalUploadRate.collectAsStateWithLifecycle()
    val storageUsedBytes by viewModel.totalDiskStorageBytes.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }

    // Display reactive outcome alerts
    LaunchedEffect(viewModel.successToast.value) {
        viewModel.successToast.value?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.successToast.value = null
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BentoBg),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            DashboardHeader(
                onAddClick = { showAddDialog = true },
                onGcClick = { viewModel.runGarbageCollector() }
            )
        }
    ) { innerPadding ->
        // Main container grid adapts to available screen sizing
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BentoBg)
        ) {
            val isExpanded = maxWidth > 800.dp

            if (isExpanded) {
                // Tablet Dual-Column cockpit layout
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Left column: Transfer Queue lists + Aggregated health stats
                    Column(
                        modifier = Modifier
                            .weight(1.1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PerformanceBanner(
                            dlSpeed = globalDlSpeed,
                            ulSpeed = globalUlSpeed,
                            storageBytes = storageUsedBytes
                        )

                        QueueFiltersTabs(
                            activeFilter = currentFilter,
                            onFilterSelect = { viewModel.setFilter(it) }
                        )

                        TorrentListCard(
                            torrents = torrents,
                            selectedHash = selectedTorrent?.infoHash,
                            onSelect = { viewModel.selectTorrent(it) },
                            onTogglePlay = { viewModel.togglePlayPause(it) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Right column: Selected torrent telemetry parameters + interactive swarms visualizers
                    Column(
                        modifier = Modifier
                            .weight(1.4f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (selectedTorrent != null) {
                            ActiveDetailCard(
                                torrent = selectedTorrent!!,
                                viewModel = viewModel
                            )
                        } else {
                            EmptyDetailPlaceholder()
                        }
                    }
                }
            } else {
                // Mobile stacked scrolling cockpit layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PerformanceBanner(
                        dlSpeed = globalDlSpeed,
                        ulSpeed = globalUlSpeed,
                        storageBytes = storageUsedBytes
                    )

                    QueueFiltersTabs(
                        activeFilter = currentFilter,
                        onFilterSelect = { viewModel.setFilter(it) }
                    )

                    TorrentListCard(
                        torrents = torrents,
                        selectedHash = selectedTorrent?.infoHash,
                        onSelect = { viewModel.selectTorrent(it) },
                        onTogglePlay = { viewModel.togglePlayPause(it) },
                        modifier = Modifier.heightIn(max = 280.dp)
                    )

                    if (selectedTorrent != null) {
                        ActiveDetailCard(
                            torrent = selectedTorrent!!,
                            viewModel = viewModel
                        )
                    } else {
                        EmptyDetailPlaceholder()
                    }
                }
            }
        }

        // Add magnet floating overlay modal dialog
        if (showAddDialog) {
            AddMagnetDialog(
                viewModel = viewModel,
                onDismiss = { showAddDialog = false }
            )
        }
    }
}

@Composable
fun DashboardHeader(
    onAddClick: () -> Unit,
    onGcClick: () -> Unit
) {
    // Elegant pulsing animation for network active status node
    val transition = rememberInfiniteTransition(label = "header_dot_pulse")
    val dotAlpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot_pulse"
    )

    Surface(
        color = BentoTileBg,
        border = BorderStroke(width = 1.dp, BentoBorder.copy(alpha = 0.20f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .alpha(dotAlpha)
                            .clip(RoundedCornerShape(4.dp))
                            .background(BentoCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AURELIA BT PRIMITIVE",
                        color = BentoTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                }
                Text(
                    text = "SOVEREIGN SYSTEM PROTOCOL CONSOLE // V3.0",
                    color = BentoCyan.copy(alpha = 0.7f),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Force Garbage Collection Action
                IconButton(
                    onClick = onGcClick,
                    modifier = Modifier
                        .size(40.dp)
                        .background(BentoAmber.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                        .border(1.dp, BentoAmber.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .testTag("storage_garbage_collect_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Trigger Garbage Collection",
                        tint = BentoAmber
                    )
                }

                // Add Magnet Action
                Button(
                    onClick = onAddClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BentoCyan.copy(alpha = 0.15f),
                        contentColor = BentoCyan
                    ),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, BentoCyan),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                    modifier = Modifier
                        .height(40.dp)
                        .testTag("add_torrent_submit_trigger")
                ) {
                    Icon(Icons.Default.AddLink, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "JOIN SWARM",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun PerformanceBanner(
    dlSpeed: Long,
    ulSpeed: Long,
    storageBytes: Long
) {
    Surface(
        color = BentoTileBg,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BentoBorder.copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Live Download
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = BentoCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "GLOBAL DOWNLOAD",
                        color = BentoMuted,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formatSpeedRaw(dlSpeed),
                    color = BentoCyan,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            VerticalDivider()

            // Live Upload
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = BentoAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "GLOBAL UPLOAD",
                        color = BentoMuted,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formatSpeedRaw(ulSpeed),
                    color = BentoAmber,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            VerticalDivider()

            // Active Cache Allocated
            Column(modifier = Modifier.weight(1.1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Storage,
                        contentDescription = null,
                        tint = BentoCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "SOVEREIGN STORAGE",
                        color = BentoMuted,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formatBytes(storageBytes),
                    color = BentoCyan,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun VerticalDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(34.dp)
            .background(BentoCyan.copy(alpha = 0.1f))
    )
}

@Composable
fun QueueFiltersTabs(
    activeFilter: TorrentFilter,
    onFilterSelect: (TorrentFilter) -> Unit
) {
    ScrollableTabRow(
        selectedTabIndex = activeFilter.ordinal,
        containerColor = Color.Transparent,
        contentColor = BentoCyan,
        edgePadding = 0.dp,
        divider = {},
        indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
                modifier = Modifier.tabIndicatorOffset(tabPositions[activeFilter.ordinal]),
                color = BentoCyan,
                height = 2.dp
            )
        },
        modifier = Modifier.fillMaxWidth()
    ) {
        TorrentFilter.values().forEach { filterVal ->
            val title = when (filterVal) {
                TorrentFilter.ALL -> "ALL CONTEXTS"
                TorrentFilter.ACTIVE -> "ACTIVE SWARMS"
                TorrentFilter.COMPLETED -> "VERIFIED & SEED"
                TorrentFilter.SOVEREIGN_PINNED -> "PINNED CHUNKS"
            }
            val tag = when (filterVal) {
                TorrentFilter.ALL -> "all"
                TorrentFilter.ACTIVE -> "active"
                TorrentFilter.COMPLETED -> "completed"
                TorrentFilter.SOVEREIGN_PINNED -> "pinned"
            }
            Tab(
                selected = activeFilter == filterVal,
                onClick = { onFilterSelect(filterVal) },
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("filter_tab_$tag"),
                text = {
                    Text(
                        text = title,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = if (activeFilter == filterVal) BentoCyan else BentoMuted
                    )
                }
            )
        }
    }
}

@Composable
fun TorrentListCard(
    torrents: List<TorrentState>,
    selectedHash: String?,
    onSelect: (String) -> Unit,
    onTogglePlay: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = BentoTileBg,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BentoBorder.copy(alpha = 0.15f)),
        modifier = modifier.fillMaxWidth()
    ) {
        if (torrents.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CloudQueue,
                        contentDescription = null,
                        tint = BentoMuted.copy(alpha = 0.4f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "NO RUNNING TORRENT SWARMS FOUND",
                        color = BentoMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Join a dynamic Web3 background peer swarm via magnet URL",
                        color = BentoMuted.copy(alpha = 0.7f),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(separatedLayoutPadding())
            ) {
                items(torrents, key = { it.infoHash }) { torrent ->
                    TorrentItemRow(
                        torrent = torrent,
                        isSelected = torrent.infoHash == selectedHash,
                        onRowClick = { onSelect(torrent.infoHash) },
                        onPlayToggle = { onTogglePlay(torrent.infoHash) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
fun TorrentItemRow(
    torrent: TorrentState,
    isSelected: Boolean,
    onRowClick: () -> Unit,
    onPlayToggle: () -> Unit
) {
    val bcolor = if (isSelected) BentoCyan.copy(alpha = 0.08f) else BentoBg
    val borderCol = if (isSelected) BentoCyan.copy(alpha = 0.5f) else BentoCyan.copy(alpha = 0.08f)

    Surface(
        color = bcolor,
        border = BorderStroke(1.dp, borderCol),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onRowClick() }
            .testTag("torrent_item_row_${torrent.infoHash}")
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Interactive Play Pause Action
            IconButton(
                onClick = onPlayToggle,
                modifier = Modifier
                    .size(36.dp)
                    .background(BentoCyan.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                    .testTag("play_pause_button_${torrent.infoHash}")
            ) {
                val iconVec = when (torrent.status) {
                    TorrentStatus.PAUSED -> Icons.Default.PlayArrow
                    else -> Icons.Default.Pause
                }
                Icon(
                    imageVector = iconVec,
                    contentDescription = "Control Play state",
                    tint = BentoCyan,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = torrent.name,
                        color = BentoTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = String.format(Locale.getDefault(), "%.1f%%", torrent.progress * 100f),
                        color = if (torrent.progress >= 1.0f) BentoCyan else BentoCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // High tech system horizontal progress track
                LinearProgressIndicator(
                    progress = { torrent.progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = getStatusColor(torrent.status),
                    trackColor = Color(0xFF161E2E)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Status Badge text
                    Text(
                        text = torrent.status.name,
                        color = getStatusColor(torrent.status),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )

                    // Transfer Rates
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (torrent.downloadSpeed > 0) {
                             Text(
                                 text = "↓ ${formatSpeedRaw(torrent.downloadSpeed)}",
                                 color = BentoCyan,
                                 fontSize = 9.sp,
                                 fontFamily = FontFamily.Monospace,
                                 fontWeight = FontWeight.Bold
                             )
                        }
                        if (torrent.uploadSpeed > 0) {
                             Text(
                                 text = "↑ ${formatSpeedRaw(torrent.uploadSpeed)}",
                                 color = BentoAmber,
                                 fontSize = 9.sp,
                                 fontFamily = FontFamily.Monospace,
                                 fontWeight = FontWeight.Bold
                             )
                        }
                        Text(
                            text = "PEERS: ${torrent.peers.size}",
                            color = BentoMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveDetailCard(
    torrent: TorrentState,
    viewModel: TorrentViewModel
) {
    var activeSubTab by remember { mutableStateOf(0) } // 0: Swarm Graph, 1: Play/Stream, 2: Files, 3: Specs/Metrics

    val listSubTabs = listOf("SWARM VISUALIZER", "CINEMA STREAM", "PIECES & FILES", "PEER TELEMETRY")

    Surface(
        color = BentoTileBg,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BentoBorder.copy(alpha = 0.20f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = torrent.name,
                        color = BentoTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "INFO HASH: ${torrent.infoHash}",
                        color = BentoMuted,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.8.sp
                    )
                }

                // Sovereignty Pinning Lock Button
                IconButton(
                    onClick = { viewModel.togglePin(torrent.infoHash, !torrent.isPinned) },
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            color = if (torrent.isPinned) BentoCyan.copy(alpha = 0.12f) else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            if (torrent.isPinned) BentoCyan else BentoCyan.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        .testTag("torrent_pin_toggle_${torrent.infoHash}")
                ) {
                    Icon(
                        imageVector = if (torrent.isPinned) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "Pin storage",
                        tint = if (torrent.isPinned) BentoCyan else BentoMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Highlight progress telemetry bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SWARM STABILITY SCORE: ${torrent.healthScore}/100",
                    color = if (torrent.healthScore > 50) BentoCyan else BentoAmber,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${formatBytes(torrent.downloadedBytes)} / ${formatBytes(torrent.totalSize)}",
                    color = BentoTextPrimary.copy(alpha = 0.8f),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Dynamic Progress Indicator
            val animatedProgress by animateFloatAsState(targetValue = torrent.progress, label = "progress")
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = getStatusColor(torrent.status),
                trackColor = Color(0xFF161E2E)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Sub Tab headers
            TabRow(
                selectedTabIndex = activeSubTab,
                containerColor = BentoBg,
                contentColor = BentoCyan,
                divider = {},
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubTab]),
                        color = BentoCyan,
                        height = 2.dp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
            ) {
                listSubTabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = activeSubTab == idx,
                        onClick = { activeSubTab = idx },
                        modifier = Modifier.testTag("detail_subtab_$idx")
                    ) {
                        Text(
                            text = title,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.5.sp,
                            color = if (activeSubTab == idx) BentoCyan else BentoMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Sub Tab panels rendering
            when (activeSubTab) {
                0 -> {
                    // Swarm Visualizer
                    Column {
                        Text(
                            text = "REAL-TIME SWARM CLUSTER VISUALIZER",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = BentoMuted,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                                .border(1.dp, BentoCyan.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                .background(Color(0xFF010204))
                        ) {
                            SwarmVisualizerCanvas(
                                peers = torrent.peers,
                                downloadSpeedBps = torrent.downloadSpeed,
                                uploadSpeedBps = torrent.uploadSpeed
                            )
                        }
                    }
                }
                1 -> {
                    // Cinema stream interactive override
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "PROGRESSIVE MEDIA STREAMING PLAYER",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = BentoMuted
                                )
                                Text(
                                    text = "Sovereign Web3 video stream engine protocol active.",
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = BentoMuted.copy(alpha = 0.6f)
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "STREAM MODE",
                                    color = if (torrent.streamModeOn) BentoCyan else BentoMuted,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Switch(
                                    checked = torrent.streamModeOn,
                                    onCheckedChange = { viewModel.toggleStreamingMode(torrent.infoHash, it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = BentoCyan,
                                        checkedTrackColor = BentoCyan.copy(alpha = 0.2f)
                                    ),
                                    modifier = Modifier
                                        .scaleAxis(0.7f)
                                        .testTag("playback_stream_mode_checkbox")
                                )
                            }
                        }

                        if (torrent.streamModeOn) {
                            VideoPlayerWidget(
                                torrentName = torrent.name,
                                infoHash = torrent.infoHash,
                                totalPieces = torrent.pieces.size,
                                piecesState = torrent.pieces,
                                activePieceIndex = torrent.activePlaybackPiece,
                                onSeekPiece = { viewModel.setStreamingFocusPiece(torrent.infoHash, it) }
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .border(1.dp, BentoCyan.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                    .background(BentoTileBg)
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.TvOff,
                                        contentDescription = null,
                                        tint = BentoAmber.copy(alpha = 0.7f),
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "SEQUENTIAL OVERRIDE PLAYBACK DISABLED",
                                        color = BentoAmber,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "Toggle Streaming Mode active to force sequential pieces priority and unlock live media preview frame buffers.",
                                        color = BentoMuted.copy(alpha = 0.8f),
                                        fontSize = 8.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Pieces Map + Content File structures
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        PieceMapGrid(
                            pieces = torrent.pieces,
                            streamModeOn = torrent.streamModeOn,
                            activePlaybackPiece = torrent.activePlaybackPiece
                        )

                        Text(
                            text = "METADATA PAYLOAD CONTENTS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = BentoMuted
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BentoCyan.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                .background(BentoTileBg)
                                .padding(6.dp)
                        ) {
                            torrent.fileList.forEach { f ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = getFileIcon(f.path),
                                            contentDescription = null,
                                            tint = BentoCyan,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = f.path.substringAfter("/"),
                                            color = BentoTextPrimary.copy(alpha = 0.9f),
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = formatBytes(f.size),
                                            color = BentoMuted,
                                            fontSize = 9.5.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = String.format(Locale.getDefault(), "%.0f%% Verified", f.progress * 100f),
                                            color = if (f.progress >= 1f) BentoCyan else BentoAmber,
                                            fontSize = 9.5.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // Analytics Transfer Monitor Speed Charts + Peer list
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        TransferRateChart(
                            downloadHistory = torrent.downloadHistory,
                            uploadHistory = torrent.uploadHistory
                        )

                        Text(
                            text = "CONNECTED PEERS SWARM STACK (${torrent.peers.size})",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = BentoMuted
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BentoCyan.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                .background(BentoTileBg),
                            verticalArrangement = Arrangement.spacedBy(1.dp)
                        ) {
                            torrent.peers.take(5).forEach { p ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(BentoTileBg)
                                        .padding(horizontal = 8.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "[${p.countryCode}] ${p.ip}",
                                                color = BentoTextPrimary,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = p.clientName,
                                                color = BentoMuted,
                                                fontSize = 8.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                        Text(
                                            text = "Latency: ${p.latencyMs}ms // Dur: ${p.connectionDurationSec}s",
                                            color = BentoMuted.copy(alpha = 0.7f),
                                            fontSize = 8.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(
                                            text = "↓ ${formatSpeedRaw(p.downloadSpeed)}",
                                            color = BentoCyan,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "↑ ${formatSpeedRaw(p.uploadSpeed)}",
                                            color = BentoAmber,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Delete Torrent card controllers
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(
                onClick = { viewModel.deleteTorrent(torrent.infoHash, true) },
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFEF5350)
                ),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color(0xFFEF5350).copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("purge_torrent_control_button")
            ) {
                Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "PURGE DISTRIBUTED TORRENT INDEX FROM DISK",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun EmptyDetailPlaceholder() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .border(1.dp, BentoBorder.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
            .background(BentoTileBg)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Explore,
                tint = BentoCyan.copy(alpha = 0.4f),
                contentDescription = null,
                modifier = Modifier.size(54.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "SELECT ACTIVE SWARM CONTEXT",
                color = BentoTextPrimary,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Select a running torrent node from the queue list to inspect real-time p2p coordinates, cryptographic piece verifier mappings, streaming pipelines, and download charts.",
                color = BentoMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.5.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun AddMagnetDialog(
    viewModel: TorrentViewModel,
    onDismiss: () -> Unit
) {
    var magnetText by remember { mutableStateOf(TextFieldValue("")) }
    var isPinnedChecked by remember { mutableStateOf(false) }

    val errorMsg by viewModel.magnetInputError

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "JOIN DISTRIBUTED SWARM PROTOCOL",
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = BentoTextPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Input a secure BitTorrent magnet link. Aurelia joins Kademlia DHT node connections, fetches Swarm metadata, and downloads distributed packets.",
                    fontSize = 10.5.sp,
                    fontFamily = FontFamily.Monospace,
                    color = BentoMuted
                )

                OutlinedTextField(
                    value = magnetText,
                    onValueChange = { magnetText = it },
                    placeholder = {
                        Text(
                            "magnet:?xt=urn:btih:hash...",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = BentoMuted.copy(alpha = 0.5f)
                        )
                    },
                    isError = errorMsg != null,
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = BentoTextPrimary),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoCyan,
                        unfocusedBorderColor = BentoCyan.copy(alpha = 0.3f),
                        cursorColor = BentoCyan,
                        errorBorderColor = Color(0xFFEF5350)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_torrent_input_field")
                )

                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        color = Color(0xFFEF5350),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = isPinnedChecked,
                        onCheckedChange = { isPinnedChecked = it },
                        colors = CheckboxDefaults.colors(checkedColor = BentoCyan),
                        modifier = Modifier.testTag("pin_on_create_checkbox")
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(
                            "PIN TORRENT (Sovereign Guard)",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = BentoTextPrimary
                        )
                        Text(
                            "Prevents automatic background cache cleanups on device.",
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = BentoMuted
                        )
                    }
                }
            }
        },
        containerColor = BentoTileBg,
        confirmButton = {
            Button(
                onClick = {
                    viewModel.addNewMagnet(magnetText.text, isPinnedChecked)
                    if (viewModel.magnetInputError.value == null) {
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BentoCyan.copy(alpha = 0.2f),
                    contentColor = BentoCyan
                ),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, BentoCyan),
                modifier = Modifier.testTag("add_torrent_submit_overlay")
            ) {
                Text("ESTABLISH CONTEXT", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("add_torrent_dismiss_button")
            ) {
                Text(
                    "ABORT CONNECT",
                    color = BentoMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    )
}

// Utility styling scale adapter modifier
private fun Modifier.scaleAxis(scale: Float) = this.then(
    Modifier.layout { measurable, constraints ->
        val placeable = measurable.measure(constraints)
        layout((placeable.width * scale).toInt(), (placeable.height * scale).toInt()) {
            placeable.place(0, 0)
        }
    }
)

private fun getStatusColor(status: TorrentStatus): Color {
    return when (status) {
        TorrentStatus.INITIALIZING, TorrentStatus.METADATA_FETCH -> BentoMuted
        TorrentStatus.DHT_PEER_DISCOVERY, TorrentStatus.CONNECTING -> BentoCyan
        TorrentStatus.DOWNLOADING -> BentoCyan
        TorrentStatus.STREAM_BUFFERING -> BentoAmber
        TorrentStatus.SEEDING, TorrentStatus.COMPLETED -> BentoCyan
        TorrentStatus.PAUSED -> Color(0xFF94A3B8)
        TorrentStatus.VERIFYING -> BentoAmber
    }
}

private fun getFileIcon(path: String): ImageVector {
    return when {
        path.endsWith(".mp4") || path.endsWith(".mkv") -> Icons.Default.Movie
        path.endsWith(".mp3") || path.endsWith(".wav") -> Icons.Default.AudioFile
        path.endsWith(".json") || path.endsWith(".txt") -> Icons.Default.Description
        else -> Icons.Default.InsertDriveFile
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format(Locale.getDefault(), "%.1f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

private fun formatSpeedRaw(bytesPerSec: Long): String {
    val kb = bytesPerSec / 1024.0
    val mb = kb / 1024.0
    return when {
        mb >= 1.0 -> String.format(Locale.getDefault(), "%.1f MB/s", mb)
        kb >= 1.0 -> String.format(Locale.getDefault(), "%.1f KB/s", kb)
        else -> "$bytesPerSec B/s"
    }
}

private fun separatedLayoutPadding(): androidx.compose.ui.unit.Dp {
    return 10.dp
}
