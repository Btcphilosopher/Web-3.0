package com.example.torrent.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VideoPlayerWidget(
    torrentName: String,
    infoHash: String,
    totalPieces: Int,
    piecesState: BooleanArray,
    activePieceIndex: Int,
    onSeekPiece: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(false) }
    var playbackProgress by remember { mutableStateOf(0.15f) } // starts 15% in
    var bufferedProgress by remember { mutableStateOf(0.40f) }

    // Synchronize media playback timer
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isPlaying) {
                delay(200)
                playbackProgress = (playbackProgress + 0.005f).let { if (it > 1.0f) 0.0f else it }
                // Bind playback progress to active sequential piece index
                val currentPiece = (playbackProgress * totalPieces).toInt().coerceIn(0, totalPieces - 1)
                if (currentPiece != activePieceIndex) {
                    onSeekPiece(currentPiece)
                }

                // Buffer status calculations
                val doneCount = piecesState.count { it }
                bufferedProgress = (doneCount.toFloat() / totalPieces)
            }
        }
    }

    // Interactive custom cosmos canvas representing video frame scans
    val transition = rememberInfiniteTransition(label = "video_frames")
    val cosmicOrbitAngle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(isPlaying.let { if (it) 6000 else 24000 }, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle"
    )

    val signalPulse by transition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(isPlaying.let { if (it) 1100 else 3000 }, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, BentoBorder.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
            .background(BentoTileBg, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        // Space frame player canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF010204))
                .border(1.dp, BentoCyan.copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2
                val cy = size.height / 2

                // Draw background radial matrix
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(BentoCyan.copy(alpha = 0.08f * signalPulse), Color.Transparent),
                        center = Offset(cx, cy),
                        radius = size.width * 0.6f
                    )
                )

                // Render vector orbits representing cinematic scan loops
                val steps = 6
                for (i in 1..steps) {
                    val scale = i * 22f * signalPulse
                    val baseAngle = cosmicOrbitAngle + (i * 15)
                    val arad = Math.toRadians(baseAngle.toDouble())
                    val x = cx + scale * cos(arad).toFloat()
                    val y = cy + scale * sin(arad).toFloat()

                    drawCircle(
                        color = BentoCyan.copy(alpha = (1.0f - (i.toFloat() / steps)) * 0.35f),
                        radius = scale,
                        center = Offset(cx, cy),
                        style = Stroke(width = 1f)
                    )

                    drawCircle(
                        color = BentoCyan.copy(alpha = (1.0f - (i.toFloat() / steps)) * 0.9f),
                        radius = 3.5f,
                        center = Offset(x, y)
                    )
                }

                // Render coordinate scope reticle lines
                drawLine(
                    color = BentoCyan.copy(alpha = 0.12f),
                    start = Offset(cx - 50f, cy),
                    end = Offset(cx + 50f, cy),
                    strokeWidth = 1f
                )
                drawLine(
                    color = BentoCyan.copy(alpha = 0.12f),
                    start = Offset(cx, cy - 50f),
                    end = Offset(cx, cy + 50f),
                    strokeWidth = 1f
                )
            }

            // Foreground floating status labels
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Badge(
                        containerColor = BentoAmber.copy(alpha = 0.15f),
                        contentColor = BentoAmber
                    ) {
                        Text(
                            text = "AURELIA CINEMA ENGINE",
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "FRAME BLOCK: $activePieceIndex / $totalPieces",
                        color = BentoCyan.copy(alpha = 0.82f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (!isPlaying) {
                    IconButton(
                        onClick = { isPlaying = true },
                        modifier = Modifier
                            .size(48.dp)
                            .align(Alignment.CenterHorizontally)
                            .background(BentoCyan.copy(alpha = 0.2f), RoundedCornerShape(24.dp))
                            .border(1.dp, BentoCyan, RoundedCornerShape(24.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = BentoCyan
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = torrentName,
                        color = BentoTextPrimary.copy(alpha = 0.75f),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1
                    )
                    Text(
                        text = if (isPlaying) "STREAMING ACTIVE" else "BUFFER PAUSED",
                        color = if (isPlaying) BentoCyan else BentoAmber,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Seeking controls & Buffer Map Indicator
        val pieceIndexForPlayback = (playbackProgress * totalPieces).toInt().coerceIn(0, totalPieces - 1)
        val pieceIsDownloaded = piecesState[pieceIndexForPlayback]

        Slider(
            value = playbackProgress,
            onValueChange = {
                playbackProgress = it
                val chosenPiece = (it * totalPieces).toInt().coerceIn(0, totalPieces - 1)
                onSeekPiece(chosenPiece)
            },
            colors = SliderDefaults.colors(
                thumbColor = if (pieceIsDownloaded) BentoCyan else BentoAmber,
                activeTrackColor = BentoCyan,
                inactiveTrackColor = Color(0xFF161E2E)
            ),
            modifier = Modifier.height(32.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "TIMELINE SECONDS: ${(playbackProgress * 120).toInt()}s",
                color = BentoMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = if (pieceIsDownloaded) "PIECE CACHED (STABLE PLAYBACK)" else "BUFFERING UNRESOLVED BLOCK...",
                color = if (pieceIsDownloaded) BentoCyan else BentoAmber,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Playback Action bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    playbackProgress = (playbackProgress - 0.05f).coerceAtLeast(0f)
                },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FastRewind,
                    contentDescription = "Skip Back",
                    tint = BentoMuted
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            IconButton(
                onClick = { isPlaying = !isPlaying },
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = if (isPlaying) BentoAmber.copy(alpha = 0.15f) else BentoCyan.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .border(
                        1.dp,
                        if (isPlaying) BentoAmber else BentoCyan,
                        RoundedCornerShape(24.dp)
                    )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Toggle play pause",
                    tint = if (isPlaying) BentoAmber else BentoCyan
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            IconButton(
                onClick = {
                    playbackProgress = (playbackProgress + 0.05f).coerceAtMost(1.0f)
                },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FastForward,
                    contentDescription = "Skip Forwards",
                    tint = BentoMuted
                )
            }
        }
    }
}

