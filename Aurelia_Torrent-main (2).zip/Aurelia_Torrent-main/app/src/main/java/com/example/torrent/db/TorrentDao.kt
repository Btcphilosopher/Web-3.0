package com.example.torrent.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.torrent.model.TorrentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TorrentDao {
    @Query("SELECT * FROM torrents ORDER BY dateAdded DESC")
    fun getAllTorrents(): Flow<List<TorrentEntity>>

    @Query("SELECT * FROM torrents WHERE infoHash = :infoHash LIMIT 1")
    suspend fun getTorrentByHash(infoHash: String): TorrentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTorrent(torrent: TorrentEntity)

    @Update
    suspend fun updateTorrent(torrent: TorrentEntity)

    @Query("DELETE FROM torrents WHERE infoHash = :infoHash")
    suspend fun deleteTorrent(infoHash: String)

    @Query("UPDATE torrents SET isPinned = :isPinned WHERE infoHash = :infoHash")
    suspend fun updatePinStatus(infoHash: String, isPinned: Boolean)

    @Query("SELECT SUM(sizeInBytes) FROM torrents")
    fun getTotalStorageUsed(): Flow<Long?>
}
