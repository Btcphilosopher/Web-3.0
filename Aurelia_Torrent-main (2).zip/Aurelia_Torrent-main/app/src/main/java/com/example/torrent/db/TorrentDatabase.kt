package com.example.torrent.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.torrent.model.TorrentEntity

@Database(entities = [TorrentEntity::class], version = 1, exportSchema = false)
abstract class TorrentDatabase : RoomDatabase() {
    abstract fun torrentDao(): TorrentDao

    companion object {
        @Volatile
        private var INSTANCE: TorrentDatabase? = null

        fun getDatabase(context: Context): TorrentDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TorrentDatabase::class.java,
                    "aurelia_torrent_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
