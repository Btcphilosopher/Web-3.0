package com.example.torrent.viewmodel

import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.torrent.engine.TorrentEngine
import com.example.torrent.engine.TorrentState
import com.example.torrent.model.TorrentStatus
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class TorrentFilter {
    ALL,
    ACTIVE,
    COMPLETED,
    SOVEREIGN_PINNED
}

class TorrentViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = TorrentEngine.getInstance(application)

    // Filter type for dashboard tabs
    private val _filter = MutableStateFlow(TorrentFilter.ALL)
    val filter: StateFlow<TorrentFilter> = _filter.asStateFlow()

    // Currently selected torrent in the detail panel
    private val _selectedTorrentHash = MutableStateFlow<String?>(null)
    val selectedTorrentHash: StateFlow<String?> = _selectedTorrentHash.asStateFlow()

    // List of logs received from WebSocket simulation pipeline
    private val _systemLogs = MutableStateFlow<List<String>>(emptyList())
    val systemLogs: StateFlow<List<String>> = _systemLogs.asStateFlow()

    // Magnet links error/success toast message holders
    var magnetInputError = mutableStateOf<String?>(null)
    var successToast = mutableStateOf<String?>(null)

    // Flow of filtered torrent lists
    val filteredTorrents: StateFlow<List<TorrentState>> = combine(
        engine.activeTorrents,
        _filter
    ) { torrentsMap, currentFilter ->
        val list = torrentsMap.values.toList()

        // Set default selection if none is active or selected torrent is removed
        if (_selectedTorrentHash.value == null && list.isNotEmpty()) {
            _selectedTorrentHash.value = list.first().infoHash
        } else if (_selectedTorrentHash.value != null && !torrentsMap.containsKey(_selectedTorrentHash.value)) {
            _selectedTorrentHash.value = if (list.isNotEmpty()) list.first().infoHash else null
        }

        when (currentFilter) {
            TorrentFilter.ALL -> list
            TorrentFilter.ACTIVE -> list.filter {
                it.status == TorrentStatus.DOWNLOADING || 
                it.status == TorrentStatus.STREAM_BUFFERING || 
                it.status == TorrentStatus.CONNECTING ||
                it.status == TorrentStatus.METADATA_FETCH
            }
            TorrentFilter.COMPLETED -> list.filter {
                it.status == TorrentStatus.COMPLETED || it.status == TorrentStatus.SEEDING
            }
            TorrentFilter.SOVEREIGN_PINNED -> list.filter { it.isPinned }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Direct access to active selected torrent state
    val selectedTorrent: StateFlow<TorrentState?> = combine(
        engine.activeTorrents,
        _selectedTorrentHash
    ) { torrentMap, hash ->
        if (hash == null) null else torrentMap[hash]
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Live global performance indicators
    val globalDownloadRate: StateFlow<Long> = engine.globalDownloadSpeed
    val globalUploadRate: StateFlow<Long> = engine.globalUploadSpeed
    val totalDiskStorageBytes: StateFlow<Long> = engine.totalStorageUsed
        .map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    init {
        // Collect telemetry events and display in logs
        viewModelScope.launch {
            engine.telemetryEvents.collect { jsonString ->
                // Clean and display events nicely
                val cleanLog = parseTelemetryJsonToLog(jsonString)
                _systemLogs.update { list -> (listOf(cleanLog) + list).take(40) }
            }
        }
    }

    private fun parseTelemetryJsonToLog(json: String): String {
        // Simple manual parsing to avoid Moshi boilerplate overhead in logger stream
        return try {
            val typeStr = json.substringAfter("\"type\":\"").substringBefore("\"")
            val hashStr = json.substringAfter("\"hash\":\"").substringBefore("\"").take(8)
            val msgStr = json.substringAfter("\"message\":\"").substringBefore("\"")
            "[$typeStr] Swarm#$hashStr - $msgStr"
        } catch (e: Exception) {
            "Telemetry Update: $json"
        }
    }

    fun setFilter(newFilter: TorrentFilter) {
        _filter.value = newFilter
    }

    fun selectTorrent(hash: String) {
        _selectedTorrentHash.value = hash
    }

    fun addNewMagnet(magnet: String, isPinned: Boolean) {
        if (magnet.isBlank()) {
            magnetInputError.value = "Magnet string is empty."
            return
        }
        viewModelScope.launch {
            val result = engine.addTorrentFromMagnet(magnet, isPinned)
            result.onSuccess { hash ->
                magnetInputError.value = null
                _selectedTorrentHash.value = hash
                successToast.value = "Swarm connection initialized."
            }.onFailure { err ->
                magnetInputError.value = err.message ?: "Failed to parse magnet link."
                successToast.value = null
            }
        }
    }

    fun togglePlayPause(hash: String) {
        viewModelScope.launch {
            val active = engine.activeTorrents.value[hash] ?: return@launch
            if (active.status == TorrentStatus.PAUSED) {
                engine.resumeTorrent(hash)
            } else {
                engine.pauseTorrent(hash)
            }
        }
    }

    fun togglePin(hash: String, isPinned: Boolean) {
        viewModelScope.launch {
            engine.togglePin(hash, isPinned)
        }
    }

    fun deleteTorrent(hash: String, deleteDiskBlocks: Boolean) {
        viewModelScope.launch {
            engine.removeTorrent(hash, deleteDiskBlocks)
            if (_selectedTorrentHash.value == hash) {
                _selectedTorrentHash.value = null
            }
        }
    }

    fun toggleStreamingMode(hash: String, streamOn: Boolean) {
        viewModelScope.launch {
            engine.toggleStreamingMode(hash, streamOn)
        }
    }

    fun setStreamingFocusPiece(hash: String, pieceIdx: Int) {
        engine.updatePlaybackPiece(hash, pieceIdx)
    }

    fun runGarbageCollector() {
        viewModelScope.launch {
            val freedCount = engine.triggerGarbageCollection()
            successToast.value = "GC Complete. Freed unpinned cache on $freedCount nodes."
        }
    }

    fun clearLogs() {
        _systemLogs.value = emptyList()
    }
}
