package com.example.torrent.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.torrent.model.PeerNode
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SwarmVisualizerCanvas(
    peers: List<PeerNode>,
    downloadSpeedBps: Long,
    uploadSpeedBps: Long,
    modifier: Modifier = Modifier
) {
    // Selected peer state inside canvas
    var selectedPeerId by remember { mutableStateOf<String?>(null) }
    
    // Smooth infinite animation timer for signal pulses and rotating orbits
    val transition = rememberInfiniteTransition(label = "swarm_pulses")
    
    val pulseRatio by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    val rotateAngle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(40000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val blinkState by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutOption),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blinking"
    )

    // Derived states of parsed coordinates on canvas
    val nodeCoordinates = remember { mutableStateMapOf<String, Offset>() }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(peers) {
                detectTapGestures { offset ->
                    var clickedPeer: String? = null
                    nodeCoordinates.forEach { (peerId, coord) ->
                        // 24dp hit radius
                        if ((offset - coord).getDistance() < 50f) {
                            clickedPeer = peerId
                        }
                    }
                    selectedPeerId = if (clickedPeer == selectedPeerId) null else clickedPeer
                }
            }
    ) {
        val width = size.width
        val height = size.height
        val cx = width / 2
        val cy = height / 2
        val center = Offset(cx, cy)

        // 1. Draw concentric telemetry grid lines
        val maxRadius = (minOf(width, height) / 2) * 0.9f
        val radSteps = listOf(0.3f, 0.6f, 0.9f)
        radSteps.forEach { step ->
            drawCircle(
                color = BentoCyan.copy(alpha = 0.08f),
                radius = maxRadius * step,
                center = center,
                style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 15f)))
            )
        }

        // 2. Draw compass axes (0 deg, 90 deg, etc.)
        val linesColor = BentoCyan.copy(alpha = 0.15f)
        drawLine(linesColor, Offset(cx - maxRadius, cy), Offset(cx + maxRadius, cy), strokeWidth = 1f)
        drawLine(linesColor, Offset(cx, cy - maxRadius), Offset(cx, cy + maxRadius), strokeWidth = 1f)

        // 3. Draw connected peer lines and pulse links
        peers.forEachIndexed { idx, peer ->
            // Distribute peers in orbit based on index + rotational offset
            val baseAngle = (idx * (360f / maxOf(peers.size, 1))) + rotateAngle
            val angleRad = Math.toRadians(baseAngle.toDouble())
            
            // Orbit distance depends slightly on latency (high latency node = outer edge)
            val orbitRadiusRatio = 0.25f + ((peer.latencyMs.toFloat() / 320f) * 0.6f).coerceIn(0f, 0.65f)
            val pRadius = maxRadius * orbitRadiusRatio
            val px = cx + pRadius * cos(angleRad).toFloat()
            val py = cy + pRadius * sin(angleRad).toFloat()
            val peerOffset = Offset(px, py)

            // Cache coordinate for tap gestures
            nodeCoordinates[peer.id] = peerOffset

            val linkSelected = selectedPeerId == peer.id
            val lineColor = when {
                linkSelected -> BentoAmber // Deep Amber
                peer.downloadSpeed > 2_000_000 -> BentoCyan // High speed Cyan
                else -> BentoCyan.copy(alpha = 0.45f)
            }

            // Draw line link from core browser center to peer
            drawLine(
                color = lineColor.copy(alpha = if (linkSelected) 0.9f else 0.45f),
                start = center,
                end = peerOffset,
                strokeWidth = if (linkSelected) 3f else 1.2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 18f), phase = pulseRatio * 60f)
            )

            // Draw flowing data packet pulses along the dash path
            // Download pulse: flowing from peer to center (cyan)
            if (peer.downloadSpeed > 0) {
                val dlLoc = Offset(
                    px + (cx - px) * pulseRatio,
                    py + (cy - py) * pulseRatio
                )
                drawCircle(
                    color = BentoCyan,
                    radius = 4f + (peer.downloadSpeed.toFloat() / 2_000_000f).coerceIn(1f, 5f),
                    center = dlLoc
                )
            }

            // Upload pulse: flowing from center out to peer (amber)
            if (peer.uploadSpeed > 0) {
                val ulRatio = (pulseRatio + 0.5f).let { if (it > 1f) it - 1f else it }
                val ulLoc = Offset(
                    cx + (px - cx) * ulRatio,
                    cy + (py - cy) * ulRatio
                )
                drawCircle(
                    color = BentoAmber,
                    radius = 3.5f + (peer.uploadSpeed.toFloat() / 300_000f).coerceIn(1f, 4f),
                    center = ulLoc
                )
            }
        }

        // 4. Draw orbiting peer node markers
        peers.forEach { peer ->
            val coord = nodeCoordinates[peer.id] ?: return@forEach
            val isSelected = selectedPeerId == peer.id

            // Peer ring node representation
            drawCircle(
                color = if (isSelected) BentoAmber else BentoCyan,
                radius = if (isSelected) 8f.dp.toPx() else 5f.dp.toPx(),
                center = coord,
                style = Stroke(width = 2.dp.toPx())
            )
            drawCircle(
                color = if (isSelected) BentoAmber.copy(alpha = 0.9f) else BentoCyan.copy(alpha = 0.7f),
                radius = if (isSelected) 4f.dp.toPx() else 2.5f.dp.toPx(),
                center = coord
            )

            // Draw micro labels for country and speeds
            if (isSelected) {
                // Highlight geographical label
                drawCircle(
                    color = BentoAmber.copy(alpha = 0.15f),
                    radius = 18f.dp.toPx(),
                    center = coord
                )
            }
        }

        // 5. Draw center Core Browser Node ("Sovereign Aurelia core")
        drawCircle(
            color = BentoCyan.copy(alpha = 0.15f * blinkState),
            radius = 28f.dp.toPx(),
            center = center
        )
        drawCircle(
            color = BentoCyan,
            radius = 12f.dp.toPx(),
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )
        drawCircle(
            color = BentoTileBg,
            radius = 10f.dp.toPx(),
            center = center
        )
        drawCircle(
            color = BentoCyan,
            radius = 5f.dp.toPx(),
            center = center
        )
    }
}

private val EaseInOutOption = Easing { fraction ->
    if (fraction < 0.5f) {
        2f * fraction * fraction
    } else {
        1f - (-2f * fraction + 2f) * (-2f * fraction + 2f) / 2f
    }
}
