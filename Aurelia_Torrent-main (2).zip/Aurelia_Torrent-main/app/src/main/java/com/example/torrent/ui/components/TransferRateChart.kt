package com.example.torrent.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TransferRateChart(
    downloadHistory: List<Long>,
    uploadHistory: List<Long>,
    modifier: Modifier = Modifier
) {
    // Standard visual boundaries
    val pointsCount = 15
    val dlList = downloadHistory.takeLast(pointsCount).padStartWithZeros(pointsCount)
    val ulList = uploadHistory.takeLast(pointsCount).padStartWithZeros(pointsCount)

    val maxDl = dlList.maxOrNull() ?: 1L
    val maxUl = ulList.maxOrNull() ?: 1L
    val maxSpeed = maxOf(maxDl, maxUl, 1_000_000L) // Minimum cap scale 1 MB/s

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "TRANSFER TELEMETRY TIMELINE",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BentoCyan,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            )
            Text(
                text = "MAX SCALE: ${formatSpeed(maxSpeed)}",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BentoMuted,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .border(1.dp, BentoBorder.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                .background(BentoTileBg, RoundedCornerShape(12.dp))
        ) {
            val width = size.width
            val height = size.height
            val paddingBottom = 10f
            val paddingTop = 15f
            val graphHeight = height - paddingTop - paddingBottom

            // 1. Draw horizontal division grid lines
            val divisions = 4
            for (i in 0..divisions) {
                val y = paddingTop + (graphHeight * (i.toFloat() / divisions))
                drawLine(
                    color = BentoCyan.copy(alpha = 0.05f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
            }

            // Draw vertical division markers representing 1-second ticks
            val xStep = width / (pointsCount - 1)
            for (i in 0 until pointsCount) {
                val x = i * xStep
                drawLine(
                    color = BentoCyan.copy(alpha = 0.04f),
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1f
                )
            }

            // 2. Plot Download Speed Path (Cyan neon)
            val dlPath = Path()
            val dlAreaPath = Path()
            dlAreaPath.moveTo(0f, height)

            dlList.forEachIndexed { idx, speed ->
                val x = idx * xStep
                // Invert y: speed ratio on 0-to-1 mapped against height
                val ratio = speed.toFloat() / maxSpeed.toFloat()
                val y = height - paddingBottom - (ratio * graphHeight)

                if (idx == 0) {
                    dlPath.moveTo(x, y)
                    dlAreaPath.lineTo(x, y)
                } else {
                    dlPath.lineTo(x, y)
                    dlAreaPath.lineTo(x, y)
                }

                if (idx == dlList.lastIndex) {
                    dlAreaPath.lineTo(x, height)
                    dlAreaPath.close()
                }
            }

            // Fill area gradient for DL path
            drawPath(
                path = dlAreaPath,
                brush = Brush.verticalGradient(
                    colors = listOf(BentoCyan.copy(alpha = 0.15f), Color.Transparent),
                    startY = paddingTop,
                    endY = height
                )
            )

            // Draw DL stroke lines
            drawPath(
                path = dlPath,
                color = BentoCyan,
                style = Stroke(width = 2.5f.dp.toPx())
            )

            // 3. Plot Upload Speed Path (Amber neon)
            val ulPath = Path()
            val ulAreaPath = Path()
            ulAreaPath.moveTo(0f, height)

            ulList.forEachIndexed { idx, speed ->
                val x = idx * xStep
                val ratio = speed.toFloat() / maxSpeed.toFloat()
                val y = height - paddingBottom - (ratio * graphHeight)

                if (idx == 0) {
                    ulPath.moveTo(x, y)
                    ulAreaPath.lineTo(x, y)
                } else {
                    ulPath.lineTo(x, y)
                    ulAreaPath.lineTo(x, y)
                }

                if (idx == ulList.lastIndex) {
                    ulAreaPath.lineTo(x, height)
                    ulAreaPath.close()
                }
            }

            // Fill area gradient for UL path
            drawPath(
                path = ulAreaPath,
                brush = Brush.verticalGradient(
                    colors = listOf(BentoAmber.copy(alpha = 0.12f), Color.Transparent),
                    startY = paddingTop,
                    endY = height
                )
            )

            // Draw UL stroke lines
            drawPath(
                path = ulPath,
                color = BentoAmber,
                style = Stroke(width = 1.8f.dp.toPx())
            )
        }
    }
}

// Helper to pad short timeline logs
private fun List<Long>.padStartWithZeros(size: Int): List<Long> {
    if (this.size >= size) return this
    val paddingList = List(size - this.size) { 0L }
    return paddingList + this
}

// Convert bytes/sec speed into human readable text
private fun formatSpeed(bytesPerSec: Long): String {
    val kb = bytesPerSec / 1024.0
    val mb = kb / 1024.0
    return when {
        mb >= 1.0 -> String.format(Locale.getDefault(), "%.1f MB/s", mb)
        kb >= 1.0 -> String.format(Locale.getDefault(), "%.1f KB/s", kb)
        else -> "$bytesPerSec B/s"
    }
}
