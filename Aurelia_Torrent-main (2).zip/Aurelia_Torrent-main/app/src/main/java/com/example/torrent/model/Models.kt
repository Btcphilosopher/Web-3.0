package com.example.torrent.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TorrentStatus {
    INITIALIZING,
    METADATA_FETCH,
    DHT_PEER_DISCOVERY,
    CONNECTING,
    DOWNLOADING,
    STREAM_BUFFERING,
    SEEDING,
    PAUSED,
    VERIFYING,
    COMPLETED
}

data class TorrentFile(
    val path: String,
    val size: Long,
    val progress: Float = 0.0f,
    val isPriority: Boolean = true
)

@Entity(tableName = "torrents")
data class TorrentEntity(
    @PrimaryKey val infoHash: String,
    val name: String,
    val sizeInBytes: Long,
    val pieceSize: Int,
    val magnetUrl: String,
    val dateAdded: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false, // Saved in permanent distributed storage cache
    val fileListJson: String // Serialized List<TorrentFile>
)

data class PeerNode(
    val id: String,
    val ip: String,
    val countryCode: String,
    val lat: Float,
    val lng: Float,
    val latencyMs: Int,
    var downloadSpeed: Long, // bps
    var uploadSpeed: Long, // bps
    val piecesContributed: Int,
    var currentPieceIndex: Int = -1,
    val clientName: String = "Aurelia/1.0",
    var connectionDurationSec: Long = 0,
    val isChokedByUs: Boolean = false,
    val isChokingUs: Boolean = false,
    var isConnected: Boolean = true,
    var connectionPercent: Float = 0f // Line animation percent
)
