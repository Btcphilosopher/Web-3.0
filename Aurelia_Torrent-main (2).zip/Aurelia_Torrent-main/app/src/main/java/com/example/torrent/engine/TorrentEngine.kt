package com.example.torrent.engine

import android.content.Context
import android.util.Log
import com.example.torrent.db.TorrentDao
import com.example.torrent.db.TorrentDatabase
import com.example.torrent.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.net.URLDecoder
import java.security.MessageDigest
import kotlin.random.Random

// Represents the snapshot of a live torrent being executed in memory
data class TorrentState(
    val infoHash: String,
    val name: String,
    val totalSize: Long,
    val pieceSize: Int,
    var status: TorrentStatus,
    var progress: Float,
    var downloadedBytes: Long,
    var uploadedBytes: Long,
    var downloadSpeed: Long, // bytes/sec
    var uploadSpeed: Long, // bytes/sec
    var peers: List<PeerNode>,
    val pieces: BooleanArray, // representing pieces
    var isPinned: Boolean,
    var fileList: List<TorrentFile>,
    val magnetUrl: String,
    var healthScore: Int,
    val downloadHistory: List<Long>,
    val uploadHistory: List<Long>,
    var dhtNodesCount: Int = 184,
    var trackerStatus: String = "Working [udp://tracker.coppersurfer.tk:6969]",
    var streamModeOn: Boolean = false,
    var activePlaybackPiece: Int = 0,
    var garbageCollected: Boolean = false
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as TorrentState
        if (infoHash != other.infoHash) return false
        return true
    }

    override fun hashCode(): Int = infoHash.hashCode()
}

class TorrentEngine private constructor(private val context: Context) {

    private val db = TorrentDatabase.getDatabase(context)
    private val dao = db.torrentDao()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val fileAdapter = moshi.adapter<List<TorrentFile>>(
        Types.newParameterizedType(List::class.java, TorrentFile::class.java)
    )

    // Observable stream of all active/stored torrent states
    private val _activeTorrents = MutableStateFlow<Map<String, TorrentState>>(emptyMap())
    val activeTorrents: StateFlow<Map<String, TorrentState>> = _activeTorrents.asStateFlow()

    // Global dashboard metrics
    val globalDownloadSpeed = _activeTorrents.map { map ->
        map.values.sumOf { if (it.status == TorrentStatus.DOWNLOADING || it.status == TorrentStatus.STREAM_BUFFERING) it.downloadSpeed else 0L }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000), 0L)

    val globalUploadSpeed = _activeTorrents.map { map ->
        map.values.sumOf { if (it.status == TorrentStatus.SEEDING || it.status == TorrentStatus.DOWNLOADING) it.uploadSpeed else 0L }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalStorageUsed = dao.getTotalStorageUsed().stateIn(scope, SharingStarted.WhileSubscribed(5000), 0L)

    // Event pipeline for WebSockets / Native IPC Simulation
    private val _telemetryEvents = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val telemetryEvents: SharedFlow<String> = _telemetryEvents.asSharedFlow()

    private var engineLoopJob: Job? = null

    init {
        // Initialize from Database and run background engine clock
        scope.launch {
            dao.getAllTorrents().collect { entities ->
                val currentMap = _activeTorrents.value.toMutableMap()
                entities.forEach { entity ->
                    if (!currentMap.containsKey(entity.infoHash)) {
                        // Restore torrent entity to in-memory running state
                        val files = try {
                            fileAdapter.fromJson(entity.fileListJson) ?: emptyList()
                        } catch (e: Exception) {
                            emptyList()
                        }
                        // Create status and completion matrix
                        val numPieces = Math.ceil(entity.sizeInBytes.toDouble() / entity.pieceSize).toInt()
                        val piecesArray = BooleanArray(numPieces)
                        // Assume restored state starts at 0 or pause, we'll mark some downloaded
                        val state = TorrentState(
                            infoHash = entity.infoHash,
                            name = entity.name,
                            totalSize = entity.sizeInBytes,
                            pieceSize = entity.pieceSize,
                            status = TorrentStatus.PAUSED,
                            progress = 0f,
                            downloadedBytes = 0L,
                            uploadedBytes = 0L,
                            downloadSpeed = 0L,
                            uploadSpeed = 0L,
                            peers = generateMockPeers(),
                            pieces = piecesArray,
                            isPinned = entity.isPinned,
                            fileList = files,
                            magnetUrl = entity.magnetUrl,
                            healthScore = Random.nextInt(75, 99),
                            downloadHistory = List(15) { 0L },
                            uploadHistory = List(15) { 0L }
                        )
                        currentMap[entity.infoHash] = state
                    } else {
                        // Update pinned status if it changed in Database
                        val cached = currentMap[entity.infoHash]
                        if (cached != null && cached.isPinned != entity.isPinned) {
                            currentMap[entity.infoHash] = cached.copy(isPinned = entity.isPinned)
                        }
                    }
                }
                // Filter out deleted
                val dbHashes = entities.map { it.infoHash }.toSet()
                currentMap.keys.filter { it !in dbHashes }.forEach { currentMap.remove(it) }

                _activeTorrents.value = currentMap
            }
        }

        // Add typical high-speed sovereign network default seeds on first run to enrich user sandbox
        scope.launch {
            delay(1000)
            if (_activeTorrents.value.isEmpty()) {
                loadPreConfiguredSeeds()
            }
        }

        startEngineLoop()
    }

    private fun startEngineLoop() {
        engineLoopJob?.cancel()
        engineLoopJob = scope.launch {
            while (isActive) {
                delay(1000) // Ticks once per second
                val copyMap = _activeTorrents.value.toMutableMap()
                var updated = false

                copyMap.forEach { (infoHash, torrent) ->
                    if (torrent.status == TorrentStatus.PAUSED || torrent.status == TorrentStatus.COMPLETED) {
                        // Keep connection history ticking but speeds zeroed
                        if (torrent.downloadSpeed > 0 || torrent.uploadSpeed > 0) {
                            val nextHistDL = (torrent.downloadHistory + 0L).takeLast(15)
                            val nextHistUL = (torrent.uploadHistory + 0L).takeLast(15)
                            copyMap[infoHash] = torrent.copy(
                                downloadSpeed = 0,
                                uploadSpeed = 0,
                                downloadHistory = nextHistDL,
                                uploadHistory = nextHistUL
                            )
                            updated = true
                        }
                        return@forEach
                    }

                    updated = true

                    // Progress State Machine Transition
                    when (torrent.status) {
                        TorrentStatus.INITIALIZING -> {
                            torrent.status = TorrentStatus.METADATA_FETCH
                            emitEvent("torrent_status_changed", infoHash, "METADATA_FETCH")
                        }
                        TorrentStatus.METADATA_FETCH -> {
                            torrent.status = TorrentStatus.DHT_PEER_DISCOVERY
                            emitEvent("torrent_status_changed", infoHash, "DHT_PEER_DISCOVERY")
                        }
                        TorrentStatus.DHT_PEER_DISCOVERY -> {
                            torrent.status = TorrentStatus.CONNECTING
                            emitEvent("torrent_status_changed", infoHash, "CONNECTING")
                        }
                        TorrentStatus.CONNECTING -> {
                            torrent.status = if (torrent.streamModeOn) TorrentStatus.STREAM_BUFFERING else TorrentStatus.DOWNLOADING
                            emitEvent("torrent_status_changed", infoHash, torrent.status.name)
                        }
                        TorrentStatus.DOWNLOADING, TorrentStatus.STREAM_BUFFERING -> {
                            // Run adaptive piece completion based on PIECE PICKER
                            val totalPieces = torrent.pieces.size
                            val completedCount = torrent.pieces.count { it }

                            if (completedCount >= totalPieces) {
                                torrent.status = TorrentStatus.SEEDING
                                torrent.progress = 1.0f
                                torrent.downloadedBytes = torrent.totalSize
                                torrent.downloadSpeed = 0
                                emitEvent("torrent_completed", infoHash, "SEEDING")
                            } else {
                                // Simulate piecewise acquisition
                                val stepSize = if (torrent.streamModeOn) 3 else Random.nextInt(1, 5)
                                var piecesFetchedThisTick = 0

                                if (torrent.streamModeOn) {
                                    // SEQUENTIAL OVERRIDE: Prioritize early indices around the activePlaybackPiece window (+10 sliding buffer)
                                    val startIdx = torrent.activePlaybackPiece
                                    val endIdx = (startIdx + 12).coerceAtMost(totalPieces - 1)
                                    for (i in startIdx..endIdx) {
                                        if (!torrent.pieces[i]) {
                                            torrent.pieces[i] = true
                                            piecesFetchedThisTick++
                                            emitEvent("piece_completed", infoHash, "Sequential piece $i verified")
                                            if (piecesFetchedThisTick >= stepSize) break
                                        }
                                    }
                                } else {
                                    // RAREST-FIRST SELECTION: Pick arbitrary uncompleted pieces throughout the swarm
                                    // Peers have distributed parts, find a random index to simulate rarest distribution
                                    for (attempt in 0..10) {
                                        val randIdx = Random.nextInt(totalPieces)
                                        if (!torrent.pieces[randIdx]) {
                                            // Cryptographically Verify piece checksum (simulation block verification)
                                            val expectedHashStr = sha256("Aurelia_Seed_Piece_$randIdx")
                                            if (expectedHashStr.isNotEmpty()) {
                                                torrent.pieces[randIdx] = true
                                                piecesFetchedThisTick++
                                                emitEvent("piece_completed", infoHash, "Verified chunk $randIdx cryptographic SHA-256 integrity.")
                                                if (piecesFetchedThisTick >= stepSize) break
                                            }
                                        }
                                    }
                                }

                                // Update downloaded sizes
                                val currentDlCount = torrent.pieces.count { it }
                                torrent.progress = currentDlCount.toFloat() / totalPieces
                                torrent.downloadedBytes = (torrent.totalSize * torrent.progress).toLong()

                                // Simulate downloading performance variables
                                val reliabilityMult = if (torrent.streamModeOn) 0.85f else 1.1f
                                val connectedPeers = torrent.peers.filter { it.isConnected }
                                var tickDlSpeed = connectedPeers.sumOf { it.downloadSpeed }
                                if (tickDlSpeed == 0L && connectedPeers.isNotEmpty()) {
                                    // Inject speed dynamically
                                    tickDlSpeed = Random.nextLong(2_000_000, 15_000_000)
                                }
                                torrent.downloadSpeed = (tickDlSpeed * reliabilityMult).toLong()
                                torrent.uploadSpeed = Random.nextLong(100_000, 2_000_000)
                            }
                        }
                        TorrentStatus.SEEDING -> {
                            torrent.downloadSpeed = 0
                            torrent.uploadSpeed = Random.nextLong(800_000, 3_500_000)
                            torrent.progress = 1.0f
                            torrent.downloadedBytes = torrent.totalSize
                        }
                        else -> {}
                    }

                    // Pulse speed telemetry records
                    val nextHistDL = (torrent.downloadHistory + torrent.downloadSpeed).takeLast(15)
                    val nextHistUL = (torrent.uploadHistory + torrent.uploadSpeed).takeLast(15)

                    // Refresh active peer nodes (tick connections, scores, durations)
                    val updatedPeers = torrent.peers.map { p ->
                        if (p.isConnected) {
                            val currentDuration = p.connectionDurationSec + 1
                            var dl = p.downloadSpeed
                            var ul = p.uploadSpeed
                            if (torrent.status == TorrentStatus.DOWNLOADING || torrent.status == TorrentStatus.STREAM_BUFFERING) {
                                dl = (p.downloadSpeed + Random.nextLong(-200_000, 200_000)).coerceIn(100_000, 5_000_000)
                                ul = (p.uploadSpeed + Random.nextLong(-50_000, 50_000)).coerceIn(50_000, 800_000)
                            }
                            // Line pulse speed completion percentage animation helper
                            val linePercent = (p.connectionPercent + 0.1f).let { if (it > 1.0f) 0.0f else it }
                            p.copy(
                                connectionDurationSec = currentDuration,
                                downloadSpeed = dl,
                                uploadSpeed = ul,
                                connectionPercent = linePercent
                            )
                        } else p
                    }

                    // Update local file completion rates
                    val compiledFiles = torrent.fileList.map { f ->
                        val parts = f.path.split("/")
                        // Mock file internal completion
                        val randFactor = if (torrent.status == TorrentStatus.COMPLETED || torrent.status == TorrentStatus.SEEDING) 1.0f 
                                         else (torrent.progress * Random.nextFloat() * 1.5f).coerceIn(0f, 1f)
                        val computedProgress = if (torrent.status == TorrentStatus.COMPLETED) 1f else randFactor
                        f.copy(progress = computedProgress)
                    }

                    // Pack state back in table mapping
                    copyMap[infoHash] = torrent.copy(
                        downloadHistory = nextHistDL,
                        uploadHistory = nextHistUL,
                        peers = updatedPeers,
                        fileList = compiledFiles,
                        healthScore = (70 + (torrent.peers.count { it.isConnected } * 3)).coerceIn(10, 100)
                    )
                }

                if (updated) {
                    _activeTorrents.value = copyMap
                }
            }
        }
    }

    // Handles native magnet parsing & inserts as active item
    suspend fun addTorrentFromMagnet(magnetUrl: String, isPinned: Boolean = false): Result<String> {
        if (!magnetUrl.startsWith("magnet:?")) {
            return Result.failure(Exception("Invalid magnet URI - missing 'magnet:?' protocol prefix."))
        }

        return withContext(Dispatchers.Default) {
            try {
                // Parse xt parameter (urn:btih:)
                val xtIndex = magnetUrl.indexOf("xt=urn:btih:")
                if (xtIndex == -1) {
                    throw Exception("No BitTorrent Info Hash (BTIH) xt parameter found in magnet URI.")
                }
                var infoHashEnd = magnetUrl.indexOf("&", xtIndex)
                if (infoHashEnd == -1) infoHashEnd = magnetUrl.length
                val infoHashUrlEncoded = magnetUrl.substring(xtIndex + 12, infoHashEnd).trim().uppercase()
                val infoHash = URLDecoder.decode(infoHashUrlEncoded, "UTF-8")

                // Ensure it is 40 character hexadecimal or appropriate length
                if (infoHash.length < 20) {
                    throw Exception("Decoded info hash is too short to represent a standard SHA-1/SHA-256 BitTorrent identifier.")
                }

                // Extract dn parameter (display name)
                var dnEnd = magnetUrl.length
                val dnIndex = magnetUrl.indexOf("dn=")
                val name = if (dnIndex != -1) {
                    var endOfName = magnetUrl.indexOf("&", dnIndex)
                    if (endOfName == -1) endOfName = magnetUrl.length
                    val encodedName = magnetUrl.substring(dnIndex + 3, endOfName)
                    try {
                        URLDecoder.decode(encodedName, "UTF-8")
                    } catch (e: Exception) {
                        "Decoded_Magnet_Metadata"
                    }
                } else {
                    "Sovereign_Swarm_$infoHash"
                }

                // Create a simulated list of files in the torrent
                val randomFiles = generateFilesForName(name)
                val totalBytes = randomFiles.sumOf { it.size }
                val pieceSize = 524288 // 512 KB
                val fileListJson = fileAdapter.toJson(randomFiles)

                val entity = TorrentEntity(
                    infoHash = infoHash,
                    name = name,
                    sizeInBytes = totalBytes,
                    pieceSize = pieceSize,
                    magnetUrl = magnetUrl,
                    isPinned = isPinned,
                    fileListJson = fileListJson
                )

                // Save persistent index in Room DB
                dao.insertTorrent(entity)

                // Construct running memory state
                val numPieces = Math.ceil(totalBytes.toDouble() / pieceSize).toInt()
                val piecesArray = BooleanArray(numPieces)

                val state = TorrentState(
                    infoHash = infoHash,
                    name = name,
                    totalSize = totalBytes,
                    pieceSize = pieceSize,
                    status = TorrentStatus.INITIALIZING,
                    progress = 0f,
                    downloadedBytes = 0L,
                    uploadedBytes = 0L,
                    downloadSpeed = 0L,
                    uploadSpeed = 0L,
                    peers = generateMockPeers(),
                    pieces = piecesArray,
                    isPinned = isPinned,
                    fileList = randomFiles,
                    magnetUrl = magnetUrl,
                    healthScore = 80,
                    downloadHistory = List(15) { 0L },
                    uploadHistory = List(15) { 0L }
                )

                val current = _activeTorrents.value.toMutableMap()
                current[infoHash] = state
                _activeTorrents.value = current

                emitEvent("torrent_started", infoHash, "Sovereign client joined swarm tracker successfully.")

                Result.success(infoHash)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    fun pauseTorrent(infoHash: String) {
        val current = _activeTorrents.value.toMutableMap()
        val torrent = current[infoHash] ?: return
        current[infoHash] = torrent.copy(
            status = TorrentStatus.PAUSED,
            downloadSpeed = 0L,
            uploadSpeed = 0L
        )
        _activeTorrents.value = current
        emitEvent("torrent_paused", infoHash, "Active piece acquisition paused by user.")
    }

    fun resumeTorrent(infoHash: String) {
        val current = _activeTorrents.value.toMutableMap()
        val torrent = current[infoHash] ?: return
        current[infoHash] = torrent.copy(
            status = TorrentStatus.DOWNLOADING
        )
        _activeTorrents.value = current
        emitEvent("torrent_resumed", infoHash, "Piece queue and rarest-first active loops re-awakened.")
    }

    suspend fun removeTorrent(infoHash: String, deleteFiles: Boolean) {
        withContext(Dispatchers.Default) {
            val current = _activeTorrents.value.toMutableMap()
            current.remove(infoHash)
            _activeTorrents.value = current

            dao.deleteTorrent(infoHash)
            emitEvent("torrent_removed", infoHash, "Torrent purged. Disk blocks released: $deleteFiles")
        }
    }

    suspend fun togglePin(infoHash: String, isPinned: Boolean) {
        withContext(Dispatchers.Default) {
            val current = _activeTorrents.value.toMutableMap()
            val torrent = current[infoHash] ?: return@withContext
            current[infoHash] = torrent.copy(isPinned = isPinned)
            _activeTorrents.value = current

            dao.updatePinStatus(infoHash, isPinned)
            emitEvent("torrent_pinned", infoHash, "Content distributed lock status set to $isPinned")
        }
    }

    fun toggleStreamingMode(infoHash: String, streamModeOn: Boolean) {
        val current = _activeTorrents.value.toMutableMap()
        val torrent = current[infoHash] ?: return
        val currentStatus = if (torrent.status == TorrentStatus.DOWNLOADING || torrent.status == TorrentStatus.STREAM_BUFFERING) {
            if (streamModeOn) TorrentStatus.STREAM_BUFFERING else TorrentStatus.DOWNLOADING
        } else torrent.status

        current[infoHash] = torrent.copy(
            streamModeOn = streamModeOn,
            status = currentStatus
        )
        _activeTorrents.value = current
        emitEvent("torrent_stream_mode_toggled", infoHash, "Streaming override prioritisation: $streamModeOn")
    }

    fun updatePlaybackPiece(infoHash: String, pieceIdx: Int) {
        val current = _activeTorrents.value.toMutableMap()
        val torrent = current[infoHash] ?: return
        current[infoHash] = torrent.copy(activePlaybackPiece = pieceIdx)
        _activeTorrents.value = current
    }

    // Storage Garbage Collector
    suspend fun triggerGarbageCollection(): Int {
        return withContext(Dispatchers.Default) {
            val current = _activeTorrents.value.toMutableMap()
            var gcCount = 0
            current.forEach { (hash, torrent) ->
                // Garbage Collect inactive, completed torrents that are UNPINNED
                if (!torrent.isPinned && (torrent.status == TorrentStatus.SEEDING || torrent.status == TorrentStatus.COMPLETED)) {
                    // Mark as garbage collected in state to simulate released cash blocks
                    current[hash] = torrent.copy(
                        status = TorrentStatus.PAUSED,
                        downloadedBytes = 0L,
                        progress = 0f,
                        pieces = BooleanArray(torrent.pieces.size),
                        garbageCollected = true
                    )
                    gcCount++
                    emitEvent("storage_garbage_collected", hash, "Released unpinned cache blocks of ${torrent.name}")
                }
            }
            _activeTorrents.value = current
            gcCount
        }
    }

    private fun emitEvent(type: String, hash: String, message: String) {
        scope.launch {
            _telemetryEvents.emit("""{"type":"$type","hash":"$hash","message":"$message","timestamp":${System.currentTimeMillis()}}""")
        }
    }

    private fun generateFilesForName(name: String): List<TorrentFile> {
        return listOf(
            TorrentFile(path = "$name/content_index.json", size = 24_000L),
            TorrentFile(path = "$name/media_stream.mp4", size = 1_420_000_000L),
            TorrentFile(path = "$name/manifest_v2.0.txt", size = 432_000L),
            TorrentFile(path = "$name/artwork_cover.png", size = 5_200_000L)
        )
    }

    private suspend fun loadPreConfiguredSeeds() {
        val default1 = "magnet:?xt=urn:btih:6fdc6d7a4f91bb8191ec4d974467dbe4fd63009d&dn=Cosmic_Ocean_Cinema_1080p.mp4"
        addTorrentFromMagnet(default1, isPinned = true)

        val default2 = "magnet:?xt=urn:btih:3e7a02b6e828d098e9b418ff8e3a2b0270a316df&dn=Aurelia_Web3_Sovereign_Manifesto.mp3"
        addTorrentFromMagnet(default2, isPinned = false)

        // Make the Web3 Manifesto complete so the user starts with 1 finished element on screen
        delay(100)
        val copyMap = _activeTorrents.value.toMutableMap()
        copyMap.values.find { it.name.contains("Manifesto") }?.let { torrent ->
            torrent.pieces.fill(true)
            copyMap[torrent.infoHash] = torrent.copy(
                status = TorrentStatus.SEEDING,
                progress = 1.0f,
                downloadedBytes = torrent.totalSize
            )
        }
        _activeTorrents.value = copyMap
    }

    private fun generateMockPeers(): List<PeerNode> {
        val countries = listOf("US", "DE", "IS", "SG", "CH", "NL", "JA", "AU")
        val ips = listOf(
            "142.250.190.46", "216.58.212.142", "185.190.140.23",
            "103.4.96.12", "46.137.240.59", "74.125.19.147",
            "172.217.18.110", "198.51.100.22"
        )
        val clientNames = listOf(
            "Aurelia/1.0", "uTorrent/3.5.5", "qBittorrent/4.6.2",
            "Transmission/4.0.3", "Deluge/2.1.1", "BiglyBT/3.5.0"
        )
        return List(12) { idx ->
            PeerNode(
                id = sha256("Peer_$idx").take(16).lowercase(),
                ip = ips[idx % ips.size] + ":" + (6881 + idx),
                countryCode = countries[idx % countries.size],
                lat = (30f + Random.nextFloat() * 30f) * (if (idx % 2 == 0) 1 else -1),
                lng = (10f + Random.nextFloat() * 120f) * (if (idx % 3 == 0) 1 else -1),
                latencyMs = Random.nextInt(20, 310),
                downloadSpeed = Random.nextLong(200_000, 3_500_000),
                uploadSpeed = Random.nextLong(30_000, 450_000),
                piecesContributed = Random.nextInt(12, 180),
                clientName = clientNames[idx % clientNames.size]
            )
        }
    }

    private fun sha256(input: String): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(input.toByteArray())
            digest.fold("") { str, it -> str + "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: TorrentEngine? = null

        fun getInstance(context: Context): TorrentEngine {
            return INSTANCE ?: synchronized(this) {
                val instance = TorrentEngine(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
