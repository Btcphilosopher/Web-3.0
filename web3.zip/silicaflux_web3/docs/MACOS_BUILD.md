# macOS Build Instructions

## Development run

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install PySide6 qasync
python main.py
```

PySide6's macOS wheels bundle their own Qt/WebEngine frameworks; no
Homebrew Qt install is needed or recommended (mixing a system Qt with
PySide6's bundled one is a common source of crashes).

## Building a distributable `.app` bundle

SilicaFlux ships as a standard PySide6 desktop app, so the standard
PySide6 packaging tool — `pyside6-deploy` (bundles `PyInstaller` under
the hood) — packages it directly:

```bash
pip install pyside6-deploy   # included with recent PySide6, or: pip install PySide6-Deploy
pyside6-deploy main.py \
    --name "SilicaFlux Web3.0" \
    --icon assets/silicaflux.icns \
    --extra-modules silicaflux
```

This produces `SilicaFlux Web3.0.app` in `dist/`. Notes:

- `--extra-modules silicaflux` ensures PyInstaller's import scanner picks
  up every dynamically-imported subsystem (the CLIs and the runtime
  manager import several modules lazily/by string — see
  `docs/RUNTIME_API.md`'s note on `__main__` re-imports); without it,
  some runtime adapters may silently fail to import inside the bundled
  app even though they work from source.
- The bundled app is a normal, unsigned macOS application. For
  distribution outside your own machine you'll additionally need to code
  sign and notarize it with an Apple Developer ID:

  ```bash
  codesign --deep --force --options runtime \
      --sign "Developer ID Application: Your Name (TEAMID)" \
      "dist/SilicaFlux Web3.0.app"

  xcrun notarytool submit "dist/SilicaFlux Web3.0.app" \
      --apple-id you@example.com --team-id TEAMID --password APP_SPECIFIC_PASSWORD \
      --wait

  xcrun stapler staple "dist/SilicaFlux Web3.0.app"
  ```

- If you want R or Rust operations to work from the bundled app without
  the end user installing anything, either bundle a compiled Rust binary
  under `Contents/Resources` and point `RustBinaryRegistry.register()` at
  it with a path resolved relative to the app bundle, or leave R/Rust as
  opt-in "if installed" runtimes (the default) — `sfx-browser
  diagnostics` inside the packaged app will report their real
  availability either way, never a fabricated one.

## Manual PyInstaller alternative

If you'd rather drive PyInstaller directly instead of `pyside6-deploy`:

```bash
pip install pyinstaller
pyinstaller --windowed --name "SilicaFlux Web3.0" \
    --icon assets/silicaflux.icns \
    --collect-all PySide6 \
    --hidden-import silicaflux.runtimes.python_runtime \
    --hidden-import silicaflux.runtimes.r_runtime \
    --hidden-import silicaflux.runtimes.rust_runtime \
    --hidden-import silicaflux.runtimes.wasm_runtime \
    --hidden-import silicaflux.runtimes.javascript_runtime \
    main.py
```

`--collect-all PySide6` is required so QtWebEngine's resource files
(locales, `qwebchannel.js`, the Chromium subprocess binary itself) are
included — leaving it out is the most common cause of a packaged app
whose WebEngine views never load anything.
