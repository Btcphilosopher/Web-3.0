# SilicaFlux Runtime API Reference

## JavaScript-facing API: `window.silicaflux`

Available on every page in the SilicaFlux browser (ordinary websites
included — they just never call it).

```js
const response = await window.silicaflux.request({
  runtime: "python" | "javascript" | "r" | "rust" | "wasm" | "web3" | "internal",
  operation: "<registered operation name>",
  payload: { /* JSON-serialisable */ },
  destination: "engine",       // optional
  priority: "normal",          // optional: critical|interactive|realtime|normal|background|bulk
  timeout_s: 30.0              // optional
});
// response: { ok: bool, packet_id: string|null, result: any, error: string|null, latency_ms: number }
```

- `runtime: "web3"` operations: `connect`, `accounts`, `disconnect`,
  `sign_message`, `send_transaction`, `permissions` — see
  `silicaflux.web3.dapp_bridge.DAppBridge`.
- `runtime: "internal"` is reserved for `sfx://` pages and refused for
  any other origin.
- Every other runtime goes through the packet fabric and requires the
  origin to hold (or be grantable) the capability
  `<runtime>.<operation>`, falling back to `<runtime>.execute` /
  `<runtime>.compute` when no specific mapping is configured — see
  `SilicaFluxEngine.capability_map` and `docs/SECURITY.md`.

## Python: the headless engine

```python
from silicaflux.core.bootstrap import build_headless_context

ctx = await build_headless_context(profile="default", approve_all=True)
# ctx: HeadlessContext — engine, policy, cache_manager, runtime_manager,
#      telemetry, identity_manager, wallet, dapp_bridge, dashboard,
#      history, bookmarks, downloads_store, http_client, download_manager,
#      session, ai_manager, db, audit, settings, profile_dir
await ctx.shutdown()
```

This is what both CLIs (`silicaflux.cli`, `silicaflux.dev_cli`) and
`silicaflux.browser.launcher` (GUI) build on — the same real engine,
storage and security stack, with or without a display attached.

### Submitting a packet directly

```python
from silicaflux.core.packet import SFXPacket, SecurityContext

packet = SFXPacket(
    source="my-app", destination="engine", runtime="python",
    operation="analytics", payload={"values": [1, 2, 3]},
    security_context=SecurityContext(origin="https://trusted-app.example"),
)
result = await ctx.engine.request(packet)   # -> SFXPacket, terminal state
print(result.state, result.result, result.error)
```

### Registering a Python operation

```python
ctx.runtime_manager.python_registry.register(
    "my_operation", "my_package.my_module", "my_function"
)
```

`my_function(payload: dict) -> Any` runs in an isolated worker process —
see `silicaflux.runtimes.python_runtime.PythonWorkerPool`.

**Important:** whatever module runs as `__main__` (a script invoked with
`python script.py`, or a `-m package.module` / installed console-script
entry point) is re-imported by every spawned worker under Python's
`multiprocessing` "spawn" start method. Keep heavy imports
(`silicaflux.core.bootstrap` and everything it pulls in) inside functions
in any file that might become `__main__` in a process that also uses the
Python runtime — see the note at the top of `silicaflux/cli.py`,
`silicaflux/dev_cli.py` and `examples/sfx_app/run_demo.py`.

### Registering an R operation

```python
from pathlib import Path
ctx.runtime_manager.r_registry.register("stats", Path("analysis.R"), "run_stats")
```

`analysis.R` must define an R function `run_stats(payload)` (payload
arrives as a parsed list via `jsonlite`); requires `Rscript` +
`jsonlite` installed. `ctx.runtime_manager.availability()` reports
`unavailable` with the reason otherwise.

### Registering a Rust operation

```python
from pathlib import Path
# from a pre-built binary:
ctx.runtime_manager.rust_registry.register("hash", Path("./my_binary"))
# or build a crate once and cache the path:
ctx.runtime_manager.rust_registry.register_source("hash", Path("./my_crate"))
```

The binary must read one JSON object from stdin and write one JSON object
to stdout, exit 0 on success — see `examples/rust_compute/src/main.rs`
for a complete, dependency-free reference implementation (SHA-256).

### Registering a WASM operation

```python
ctx.runtime_manager.wasm_registry.register_wat("add", wat_source, "add")
# or, from compiled bytes:
ctx.runtime_manager.wasm_registry.register_bytes("add", wasm_bytes, "add")
```

Calling convention: `payload = {"args": [...]}` maps to the exported
function's positional arguments; the result is wrapped as
`{"result": <value>}`.

## CLI reference

### `sfx-browser` / `silicaflux-browser`

```
sfx-browser [--url URL] [--private] [--profile NAME] [--profile-dir DIR] [--dev]
sfx-browser open <url>
sfx-browser inspect                    # full engine/runtime/cache snapshot (JSON)
sfx-browser network                    # DNS cache, resource cache, performance summary
sfx-browser cache                      # every cache tier's stats
sfx-browser workers                    # worker pool status + runtime availability
sfx-browser identity create|list       # local Ed25519 identities
sfx-browser permissions list|grant|revoke <origin> [<capability>]
sfx-browser web3 accounts|connect <origin> <address>
sfx-browser compute --runtime R --operation OP --payload '<json>'
sfx-browser benchmark [name] [--iterations N]
sfx-browser telemetry
sfx-browser diagnostics
```

### `sfx-runtime` (runtime inspection)

```
sfx-runtime status | workers | packets [--limit N] | telemetry
```

### `silicaflux-dev` (SFX application workflow)

```
silicaflux-dev create <name> [--dir DIR]
silicaflux-dev inspect <app-dir>
silicaflux-dev run <app-dir> [--operation NAME]
silicaflux-dev test <app-dir>
silicaflux-dev profile <app-dir> [--iterations N]
silicaflux-dev build <app-dir>
silicaflux-dev package <app-dir> [--out PATH]
```

## Manifest shape (`manifest.json`)

```json
{
  "app_id": "my-app",
  "name": "My App",
  "version": "0.1.0",
  "description": "…",
  "entry": "app.html",
  "backend": "backend.py",
  "operations": [
    { "name": "hello", "runtime": "python", "function": "hello" }
  ],
  "capabilities": ["python.execute"]
}
```
