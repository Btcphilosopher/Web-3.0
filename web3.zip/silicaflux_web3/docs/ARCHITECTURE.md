# SilicaFlux Web3.0 — Architecture

## 1. The big picture

```
                      WEB
                       │
             HTML / CSS / JS
                       │
                       ▼
              BROWSER RENDERER            (silicaflux.browser — PySide6/QtWebEngine)
                       │
                       ▼
              SILICAFLUX BRIDGE           (silicaflux.api.bridge)
                       │
         ┌─────────────┼─────────────┬────────────┐
         ▼             ▼             ▼            ▼
      PYTHON           R           RUST      JAVASCRIPT      (silicaflux.runtimes)
         │             │             │            │
         └─────────────┴─────────────┴────────────┘
                       │
                     WASM                          (silicaflux.runtimes.wasm_runtime)
                       │
                       ▼
                  CPU / GPU / NPU                  (silicaflux.ai — honest, no fabricated acceleration)
```

An ordinary website never touches any of this: it loads in a normal
`QWebEngineView`, gets normal HTML/CSS/JS/WASM/WebGL/localStorage/cookies,
and works exactly like it would in any modern Chromium-based browser. A
*SilicaFlux application* is the same HTML/CSS/JS, plus calls to
`window.silicaflux.request(...)` that reach the packet fabric below. The
architecture is explicitly designed so the first case never depends on
the second (spec section 38).

## 2. The packet fabric

Every unit of SilicaFlux work is an `SFXPacket`
(`silicaflux.core.packet`): identity, routing, payload, priority, a
security context, and a full lifecycle history —

```
CREATED → QUEUED → ROUTED → EXECUTING → (STREAMING) → COMPLETED | FAILED | CANCELLED
```

Illegal transitions raise `IllegalPacketTransition`, so a packet's audit
trail is always trustworthy: if it reads `COMPLETED`, it really did pass
through `EXECUTING`. `SFXPacket.to_dict()` is what the developer tools
"SilicaFlux" panel and `sfx-runtime packets` render.

The fabric has four cooperating pieces, each independently testable and
independently swappable:

| Piece | Module | Job |
|---|---|---|
| Scheduler | `silicaflux.core.scheduler` | Orders queued packets by priority (`CRITICAL` → `BULK`), with a light "avoid the currently-slow runtime" bias from historical execution latency. |
| Router | `silicaflux.core.router` | Maps `packet.runtime` to a registered `RuntimeAdapter`; fails cleanly (`NoRouteError`) for an unknown or currently-unavailable runtime. |
| Engine | `silicaflux.core.engine` | Owns the dispatch loop: authorizes (via `SecurityPolicy`) → schedules → routes → executes, with bounded concurrency, retries, and telemetry recording. |
| Workers | `silicaflux.core.workers`, `silicaflux.runtimes.*` | The actual runtime adapters (Python/R/Rust/WASM/JavaScript) that do the work — see section 4. |

## 3. Execution graph

For a SilicaFlux application that's more than one call,
`silicaflux.core.graph.ExecutionGraph` represents the whole computation as
a DAG of typed `Node`s, each targeting a runtime:

```
INPUT → TASK → PYTHON → R → RUST/WASM → PYTHON → JAVASCRIPT → HTML
```

The graph resolves dependencies, runs independent nodes concurrently
(bounded by `max_parallel`), retries a node up to its own `max_retries`,
propagates a failed node's failure to its dependents (marked `SKIPPED`,
never silently run with garbage inputs), and can skip a node entirely via
`silicaflux.cache.computation_cache.ComputationCache` when its
`(function, resolved_inputs)` hash has already been computed.
`ExecutionGraph.to_dict()` is a ready-made payload for a future graph
visualisation UI.

## 4. Multi-language runtime adapters

Every adapter subclasses `silicaflux.runtimes.base.RuntimeAdapter` and
implements exactly `is_available()` and `run(packet)`; the base class
handles packet state transitions and turns any uncaught exception into a
clean `FAILED` packet, uniformly, so **one bad packet or one crashed
runtime never takes the engine down** (spec: "the browser must remain
stable if a runtime crashes").

- **Python** (`python_runtime.py`) — a pool of `multiprocessing`
  (`spawn` context) worker processes. An operation must be pre-registered
  as an importable `module:function` (`PythonFunctionRegistry`); packet
  payload is never `eval`'d or `exec`'d. Each worker gets CPU/memory
  resource limits (`silicaflux.security.sandbox`) and a parent-side
  wall-clock timeout; a worker that overruns is killed and replaced
  without losing the pool.
- **R** (`r_runtime.py`) — subprocess isolation via `Rscript`. An
  operation is a registered `(script_path, function_name)` pair, invoked
  through a small JSON-in/JSON-out bridge script — never string-formatted
  into an R expression. Reports `RuntimeUnavailable` with a clear message
  when `Rscript` isn't on `PATH`, rather than pretending to support R.
- **Rust** (`rust_runtime.py`) — capability-scoped compiled binaries
  speaking JSON-over-stdio. `RustBinaryRegistry.register_source()` can
  build a Cargo crate once and cache the binary path; only registered
  binaries are ever invoked. See `examples/rust_compute/` for a real,
  dependency-free SHA-256 implementation used by the demo pipeline.
- **WebAssembly** (`wasm_runtime.py`) — `wasmtime`, when installed.
  Modules are registered ahead of time (raw bytes or WAT compiled via
  `wasmtime.wat2wasm`); compiled modules are cached by content hash
  (`silicaflux.cache.wasm_cache`). **Both the `wasmtime` import and the
  `Engine()` are lazy** — see the "known interaction" note in
  `docs/SECURITY.md`/README for why.
- **JavaScript** (`javascript_runtime.py`) — the mirror image of the JS
  bridge: lets Python-side code call *into* a page's JS context through a
  registered async "channel" (backed by `page.runJavaScript()` in the
  real browser). No second JS engine is embedded.

`silicaflux.runtimes.manager.RuntimeManager` constructs all five,
respects the enable/disable flags in `RuntimeSettings`, and reports
per-runtime availability with a human-readable reason
(`RuntimeManager.availability()`).

## 5. The JavaScript ↔ SilicaFlux bridge

`silicaflux.api.bridge.SilicaFluxBridge` is the single method
(`request`/`request_dict`) every `window.silicaflux.request({...})` call
reaches. On the browser side, `silicaflux.browser.page.BrowserPage` wires
a `QWebChannel` object into every tab and injects a small shim script
(`_BRIDGE_SHIM_JS`, plus Qt's own `qwebchannel.js`) at
`DocumentCreation`/`MainWorld`, so `window.silicaflux` exists before any
page script runs — on every page, including ones that never call it. The
origin passed to the bridge always comes from the tab's actual current
URL (`BrowserPage.current_origin`), never from the JS payload.

`runtime: "web3"` is routed directly to `silicaflux.web3.dapp_bridge.DAppBridge`
rather than through the packet fabric (wallet state is in-process UI
state, not a runtime-dispatched computation). `runtime: "internal"` is
reserved for `sfx://` pages talking to the browser's own chrome backend
(the `sfx://runtime` dashboard, `apps` listing, ...) and is refused for
any non-`sfx://` origin.

## 6. sfx:// protocol

`silicaflux.browser.sfx_protocol` registers a custom `QWebEngineUrlScheme`
and installs a `QWebEngineUrlSchemeHandler` on every profile.
`silicaflux.browser.sfx_pages` renders `sfx://home`, `apps`, `runtime`,
`wallet`, `settings`, `developer` as plain HTML/CSS/JS — `sfx://runtime`
polls `window.silicaflux.request({runtime: "internal", operation:
"dashboard"})` every 1.5s for a live view of packets, workers, cache and
system load, using the exact same bridge any other SilicaFlux application
uses.

## 7. Storage, cache, networking, telemetry, Web3

See `RUNTIME_API.md` for the full module-by-module API reference;
`SECURITY.md` for the capability/permission model, sandboxing and the
Web3 identity/key-storage design; `README.md` for the project layout and
how to run everything.

## 8. What's real vs. adapter-only

Per the spec's own instruction ("where an external runtime is
unavailable, implement a clean adapter with graceful detection... rather
than pretending"):

- **Real, fully working, tested**: packet fabric, scheduler, router,
  engine, execution graph, all six cache tiers, SQLite storage, the HTTP
  client (pooling/retry/DNS-cache/streaming downloads), the Python
  runtime (real process isolation, real timeout/crash recovery), the WASM
  runtime (real `wasmtime` execution), the Rust runtime (a real compiled
  binary demo), the security/capability layer, Web3 identity (real
  Ed25519 signing, encrypted-at-rest keys) and P2P retrieval (real
  content-addressed loopback transport), the local AI engine (a real,
  small, honestly-documented native model), the GUI shell.
- **Honest adapter-only (by design, not by omission)**: the R runtime
  reports `unavailable` unless `Rscript` is on `PATH` — R is not
  installed in most CI/container environments and this repository does
  not pretend otherwise. GPU/NPU acceleration reports `unavailable`
  unless a real accelerator adapter is registered via
  `AIManager.register_hardware()` — no hardware acceleration is faked.
