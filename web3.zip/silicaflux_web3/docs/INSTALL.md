# Installation

## Requirements

- Python 3.11+ (developed and tested on 3.11; 3.12+ recommended per the
  original spec and works identically — nothing here uses a 3.12-only
  feature).
- A C compiler is **not** required — every pinned dependency ships
  prebuilt wheels for common platforms.

## 1. Headless core (no GUI toolkit needed)

Everything except `silicaflux.browser` — the packet fabric, storage,
cache, networking, runtimes, security, Web3, AI, telemetry, both CLIs —
works with just:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Verify:

```bash
python -m pytest                      # full test suite
python -m silicaflux.cli diagnostics  # runtime/system report
python examples/sfx_app/run_demo.py   # the full multi-runtime pipeline demo
```

## 2. Desktop GUI (PySide6 + QtWebEngine)

The GUI needs PySide6 with the WebEngine addon and (on Linux) a handful
of system libraries QtWebEngine's Chromium needs at runtime.

```bash
pip install PySide6 qasync
```

On Debian/Ubuntu, if you see errors like `libEGL.so.1: cannot open shared
object file`:

```bash
sudo apt-get install --no-install-recommends \
    libegl1 libgl1 libopengl0 libxkbcommon0 libnss3 \
    libxcomposite1 libxdamage1 libxrandr2 libxtst6 libasound2t64 libxshmfence1
```

On macOS and Windows, the PySide6 wheel bundles everything QtWebEngine
needs; no extra system packages are required.

Run it:

```bash
python main.py
# or, once installed (see below):
sfx-browser
sfx-browser --url https://example.com
sfx-browser --private
```

### Headless/offscreen environments

If you're running in a container or CI without a display:

```bash
export QT_QPA_PLATFORM=offscreen
export QTWEBENGINE_DISABLE_SANDBOX=1   # only inside an already-sandboxed CI container
python main.py
```

Chromium's own multi-process startup handshake can be slower and
occasionally flaky under software rendering with no GPU/dbus available —
this is a property of the constrained environment, not of SilicaFlux; a
normal desktop with a real display and GPU does not exhibit this.

## 3. Optional runtimes

- **R**: install R (<https://www.r-project.org/>) and the `jsonlite`
  package (`install.packages("jsonlite")`); `Rscript` must be on `PATH`.
  Verify with `sfx-browser diagnostics` — the `r` runtime entry reports
  `available: true/false` and, if `false`, why.
- **Rust**: install the Rust toolchain (<https://rustup.rs/>) if you want
  to build `examples/rust_compute` or register your own Rust operations
  via `RustBinaryRegistry.register_source()`. Not required just to run
  the browser — Rust operations are opt-in per application.
- **WASM**: `wasmtime` is in `requirements.txt` and installs automatically.
- **AI (tensors)**: `numpy` is in `requirements.txt`; the local AI engine
  itself has no other dependency (the bundled demo model is
  dependency-free pure Python).

## 4. Editable install (registers the console scripts)

```bash
pip install -e .
```

This registers `sfx-browser`, `silicaflux-browser`, `sfx-runtime` and
`silicaflux-dev` as real commands on your `PATH` (see `pyproject.toml`).

## 5. Building the Rust demo binary

```bash
cd examples/rust_compute
cargo build --release
```

Produces `target/release/sfx_rust_compute`, used by
`examples/sfx_app/run_demo.py` and `silicaflux/tests/test_runtimes.py`
(that specific test is skipped, not failed, if the binary isn't built).
