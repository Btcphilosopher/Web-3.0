# SilicaFlux Web3.0 — Security Model

## Principles

1. **Deny by default.** A webpage gets *nothing* implicitly — no
   filesystem, no shell, no Python/R/Rust runtime, no wallet, no raw
   network sockets. Every capability is requested individually, and every
   decision defaults to denial on any error, unknown capability name, or
   missing approval.
2. **Origin isolation.** Every capability grant, cache entry, and packet
   is scoped to an origin (`silicaflux.security.origins.parse_origin`,
   the standard scheme+host+port model). A malformed URL collapses to an
   opaque `"null"` origin, which is never trusted with anything.
3. **Capability tokens, not ambient authority.** A granted capability is
   a signed, time-bounded `CapabilityToken`
   (`silicaflux.security.capabilities`), verifiable
   (`SecurityPolicy.verify`) and revocable
   (`SecurityPolicy.revoke`/`revoke_all`). Nothing downstream trusts a
   bare boolean; every runtime call re-verifies its token.
4. **Process isolation for untrusted execution.** Python operations run
   in `multiprocessing` (spawn) worker processes with CPU/memory resource
   limits (`silicaflux.security.sandbox`) and a parent-side timeout. R and
   Rust run as subprocesses. WASM runs inside `wasmtime`'s own sandboxed
   linear memory. None of these share the browser's own process memory.
5. **Never eval/exec untrusted code.** The Python, R and Rust adapters
   never take "code" from a packet's payload — only a *pre-registered*
   `module:function` / script path / binary path selects what runs; the
   payload is purely data.

## The capability request flow

```
Application
   │
   ▼
Capability Request           SilicaFluxBridge.request(origin, runtime, operation, payload)
   │
   ▼
Policy Engine                 SecurityPolicy._decide()
   │
   ▼
User Approval                 approval_callback(origin, capability, scope)
   │
   ▼
Capability Token               CapabilityToken (signed, TTL-bounded)
   │
   ▼
Resource                       the runtime adapter / Web3 wallet / filesystem sandbox
```

`SecurityPolicy` supports three policy modes:

- **`deny`** — nothing is ever auto-granted, full lockdown/kiosk profile.
- **`prompt`** (the default) — unknown origin/capability pairs are routed
  to `approval_callback`; with no callback wired (e.g. a headless
  context), the default is deny.
- **`allow`** — non-dangerous capabilities are auto-granted; capabilities
  in the always-prompt set (`wallet.sign`, `identity`,
  `filesystem.write`, `camera`, `microphone`, `geolocation`) still
  require explicit approval regardless of policy. Intended for local
  development profiles only.

`sfx://` origins are implicitly trusted (the browser's own chrome —
`sfx://runtime`, `sfx://wallet`, etc.) so the internal dashboard and
wallet UI work without a capability prompt on every load; ordinary web
origins are never in this set.

Every decision — granted, denied, revoked — is written to
`silicaflux.security.audit.AuditLogger`, persisted to SQLite via
`Database.record_audit_entry`, and visible via `sfx-browser diagnostics`
and the developer tools.

## Sandboxing detail

`silicaflux.security.sandbox.apply_worker_limits` applies `RLIMIT_CPU`
and (best-effort) `RLIMIT_AS` inside a freshly-spawned Python worker
process, before it processes a single job. On platforms without POSIX
`resource` (Windows), this degrades gracefully to relying on the parent's
wall-clock timeout as the primary guard — the child is killed and
replaced if it doesn't respond in time either way.

`silicaflux.storage.filesystem.SandboxedFilesystem` is the only sanctioned
way anything in SilicaFlux touches the local filesystem: every path is
resolved and checked against the sandbox root, and any attempt to escape
it (`../../etc/passwd`) raises `FilesystemAccessDenied` unconditionally —
independent of whatever capability check already happened upstream.

## Web3 identity and key storage

`silicaflux.web3.identity` uses `cryptography`'s Ed25519 implementation —
no home-grown cryptography. Private key material:

- is generated in-process and never transmitted anywhere;
- is encrypted at rest (PBKDF2-HMAC-SHA256 → Fernet/AES) before it ever
  touches disk — `KeyManager._persist` never writes raw key bytes;
- is never logged — `KeyManager.generate`/`unlock` log only the public
  fingerprint;
- must be explicitly `unlock()`-ed with the correct passphrase before any
  signature can be produced; `SignatureManager` never asks for or
  transports the passphrase itself, keeping "prove who I am" separate
  from "authorize this action".

`silicaflux.web3.wallet.Wallet` never signs a transaction or message
without going through `approval_prompt` — there is no code path that
skips it (`WalletApprovalDenied` is raised otherwise), and a page must
first be explicitly `connect()`-ed to an account (via the DApp permission
flow, `silicaflux.web3.permissions.DAppPermissionManager`) before it can
even request a signature.

## Downloads

`silicaflux.networking.downloads.DownloadManager` never executes or opens
a downloaded file — the closest it comes is computing a SHA-256 so the
user (or an app with `filesystem.read`) can verify integrity themselves.

## Known interaction: WASM + QtWebEngine in the same process

`wasmtime`'s JIT execution engine installs process-wide trap-handling
signal handlers (`SIGSEGV`/`SIGBUS`, used to catch WebAssembly
linear-memory out-of-bounds access) as a side effect of `import wasmtime`
itself — before any `Engine()` is even constructed. During development,
this was observed to interfere with QtWebEngine's own Chromium-side
signal handling when both are loaded in the same process under a
constrained/offscreen rendering environment. `silicaflux.runtimes.wasm_runtime`
therefore imports `wasmtime` lazily (via `importlib.util.find_spec` for
availability checks, and a real `import wasmtime` only once a WASM packet
is actually executed) so a browser session that never touches WASM never
pays this cost. This is a defensive measure, not a proven root cause; if
you observe unusual browser-tab behaviour immediately after a WASM-heavy
workload, it's worth knowing this exists.

## What SilicaFlux deliberately does not do

- No plaintext private key storage, ever.
- No capability that defaults to "allow" for an untrusted web origin.
- No `eval`/`exec` of payload data in any runtime adapter.
- No disabled certificate verification anywhere in
  `silicaflux.networking.client.HTTPClient` — there is no parameter that
  turns it off.
- No automatic execution of downloaded content.
- No P2P networking, camera, microphone, or geolocation access without an
  explicit, per-origin capability grant.
