"""Backend operations for the SilicaFlux Dashboard Demo application.

Each function is process-isolated: it runs in its own worker under
:mod:`silicaflux.runtimes.python_runtime`, never inside the browser's own
process. Registered by name in ``manifest.json``.
"""

from __future__ import annotations

import hashlib
import statistics


def analytics_summary(payload: dict) -> dict:
    values = [float(v) for v in payload.get("values", [])]
    if not values:
        return {"count": 0}
    return {
        "count": len(values),
        "mean": statistics.fmean(values),
        "stdev": statistics.pstdev(values) if len(values) > 1 else 0.0,
        "min": min(values),
        "max": max(values),
    }


def fibonacci(payload: dict) -> int:
    n = int(payload.get("n", 10))
    a, b = 0, 1
    for _ in range(max(0, n)):
        a, b = b, a + b
    return a


def sha256_of(payload: dict) -> str:
    return hashlib.sha256(str(payload.get("text", "")).encode()).hexdigest()
