#!/usr/bin/env python3
"""Headless runner for the SilicaFlux Dashboard Demo application.

Exercises the exact pipeline ``app.html``/``app.js`` drive through
``window.silicaflux.request(...)`` — HTML/JS -> SilicaFlux bridge ->
Python -> Rust -> WASM -> cache -> Web3 identity -> result — from the
terminal, so the whole architecture can be demonstrated and verified
without a display or PySide6 installed.

Run from the repository root:

    python3 examples/sfx_app/run_demo.py

To see the same application in the real browser instead:

    sfx-browser open file://$(pwd)/examples/sfx_app/app.html
"""

from __future__ import annotations

# NOTE ON IMPORTS: silicaflux.core.bootstrap (and the whole engine graph it
# pulls in — httpx, cryptography, psutil, ...) is imported lazily inside
# main(), not here at module level. This file runs as __main__, and
# Python's multiprocessing "spawn" start method (used by
# silicaflux.runtimes.python_runtime for process isolation) re-imports
# whatever module is __main__ inside every worker it launches; keeping
# this top level light means a spawned worker doesn't pay that whole
# import graph's cost a second time. See the identical note in
# silicaflux/cli.py.

import asyncio
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT))

APP_DIR = Path(__file__).resolve().parent
RUST_BINARY = REPO_ROOT / "examples" / "rust_compute" / "target" / "release" / "sfx_rust_compute"

_ADD_WAT = """
(module
  (func $add (param $a i32) (param $b i32) (result i32)
    local.get $a
    local.get $b
    i32.add)
  (export "add" (func $add)))
"""

TRUSTED_ORIGIN = "https://silicaflux-dashboard-demo.local"


def _section(title: str) -> None:
    print(f"\n\033[36m== {title} ==\033[0m")


async def main() -> None:
    from silicaflux.api.bridge import SilicaFluxBridge
    from silicaflux.core.bootstrap import build_headless_context

    manifest = json.loads((APP_DIR / "manifest.json").read_text())
    print(f"Loaded SFX application: {manifest['name']} v{manifest['version']}")

    ctx = await build_headless_context(profile="demo", profile_dir=None, approve_all=True)
    try:
        for op in manifest["operations"]:
            ctx.runtime_manager.python_registry.register(op["name"], "examples.sfx_app.backend", op["function"])

        if RUST_BINARY.exists():
            ctx.runtime_manager.rust_registry.register("sha256", RUST_BINARY)
        else:
            print(f"(note: {RUST_BINARY} not built — run `cargo build --release` in examples/rust_compute)")

        ctx.runtime_manager.wasm_registry.register_wat("add", _ADD_WAT, "add")

        identity = ctx.identity_manager.create_identity("demo-passphrase")
        account = ctx.wallet.create_account(identity)
        ctx.wallet.approval_prompt = lambda req: True
        bridge = SilicaFluxBridge(ctx.engine, dapp_bridge=ctx.dapp_bridge)

        _section("1. HTML -> JS -> SilicaFlux -> Python (analytics_summary)")
        r1 = await bridge.request_dict(TRUSTED_ORIGIN, {"runtime": "python", "operation": "analytics", "payload": {"values": [4, 8, 15, 16, 23, 42]}, "timeout_s": 30.0})
        print(json.dumps(r1, indent=2))

        _section("2. SilicaFlux -> Rust (compiled SHA-256 binary, JSON over stdio)")
        if RUST_BINARY.exists():
            r2 = await bridge.request(TRUSTED_ORIGIN, "rust", "sha256", {"text": "silicaflux web3"})
            print(json.dumps(r2.to_dict(), indent=2))
        else:
            print("skipped (binary not built)")

        _section("3. SilicaFlux -> WASM (wasmtime-compiled module)")
        r3 = await bridge.request(TRUSTED_ORIGIN, "wasm", "add", {"args": [19, 23]})
        print(json.dumps(r3.to_dict(), indent=2))

        _section("4. Result cached (second identical call is a cache hit)")
        ctx.cache_manager.resources.store(
            "https://api.example.com/pipeline-result", json.dumps(r1["result"]).encode(),
            "application/json", TRUSTED_ORIGIN, max_age_s=60,
        )
        hit = ctx.cache_manager.resources.lookup("https://api.example.com/pipeline-result")
        print(f"cache hit: {hit is not None}, stats: {ctx.cache_manager.resources.stats.to_dict()}")

        _section("5. SilicaFlux -> Web3 identity (connect + sign, never exposing the private key)")
        connect = await bridge.request_dict(TRUSTED_ORIGIN, {"runtime": "web3", "operation": "connect", "payload": {"address": account.address}})
        print(json.dumps(connect, indent=2))
        signed = await bridge.request_dict(
            TRUSTED_ORIGIN,
            {"runtime": "web3", "operation": "sign_message", "payload": {"address": account.address, "message": "dashboard login"}},
        )
        print(json.dumps(signed, indent=2))

        _section("6. Back to the HTML dashboard: full runtime status")
        print(json.dumps(ctx.dashboard.snapshot()["engine"], indent=2))

    finally:
        await ctx.shutdown()

    print("\n\033[32mPipeline complete: HTML -> JS -> SilicaFlux -> Python -> Rust -> WASM -> cache -> Web3 -> HTML\033[0m")


if __name__ == "__main__":
    asyncio.run(main())
