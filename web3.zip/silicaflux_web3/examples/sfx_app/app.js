// SilicaFlux Dashboard Demo — every function below is the SAME
// window.silicaflux.request({...}) call the JS bridge (silicaflux.api.bridge)
// exposes to any page; only `runtime` / `operation` / `payload` change.

function show(id, ok, data) {
  const el = document.getElementById(id);
  el.textContent = JSON.stringify(data, null, 2);
  el.previousElementSibling && el.previousElementSibling.classList
    ? null
    : null;
}

async function call(runtime, operation, payload, outId) {
  const out = document.getElementById(outId);
  out.textContent = "running…";
  try {
    const response = await window.silicaflux.request({ runtime, operation, payload });
    out.textContent = JSON.stringify(response, null, 2);
    return response;
  } catch (err) {
    out.textContent = "ERROR: " + err;
    throw err;
  }
}

async function runAnalytics() {
  const values = document.getElementById("values").value.split(",").map(Number);
  await call("python", "analytics", { values }, "out-analytics");
}

async function runWasm() {
  const a = Number(document.getElementById("wasm-a").value);
  const b = Number(document.getElementById("wasm-b").value);
  await call("wasm", "add", { args: [a, b] }, "out-wasm");
}

async function runRust() {
  const text = document.getElementById("rust-text").value;
  await call("rust", "sha256", { text }, "out-rust");
}

async function connectWallet() {
  await call("web3", "connect", {}, "out-web3");
}

async function signMessage() {
  const accounts = await window.silicaflux.request({ runtime: "web3", operation: "accounts", payload: {} });
  const address = accounts.result && accounts.result.accounts && accounts.result.accounts[0];
  if (!address) {
    document.getElementById("out-web3").textContent = "Connect a wallet first.";
    return;
  }
  await call("web3", "sign_message", { address, message: "SilicaFlux demo login " + Date.now() }, "out-web3");
}
