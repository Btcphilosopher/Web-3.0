"""Runtime router: registration, routing, availability, failure paths."""

from __future__ import annotations

import pytest

from silicaflux.core.packet import PacketState, SFXPacket
from silicaflux.core.router import NoRouteError, RuntimeRouter


class _FakeAdapter:
    def __init__(self, name: str, available: bool = True) -> None:
        self.name = name
        self._available = available

    def is_available(self) -> bool:
        return self._available

    async def execute(self, packet):
        return packet


def test_register_and_resolve():
    router = RuntimeRouter()
    adapter = _FakeAdapter("python")
    router.register(adapter)
    assert router.resolve("python") is adapter


def test_resolve_unknown_runtime_raises():
    router = RuntimeRouter()
    with pytest.raises(NoRouteError):
        router.resolve("nonexistent")


def test_route_marks_packet_routed():
    router = RuntimeRouter()
    router.register(_FakeAdapter("python"))
    packet = SFXPacket(source="a", destination="b", runtime="python", operation="op")
    packet.transition(PacketState.QUEUED)
    router.route(packet)
    assert packet.state == PacketState.ROUTED


def test_route_unavailable_runtime_fails_packet():
    router = RuntimeRouter()
    router.register(_FakeAdapter("r", available=False))
    packet = SFXPacket(source="a", destination="b", runtime="r", operation="op")
    packet.transition(PacketState.QUEUED)
    with pytest.raises(NoRouteError):
        router.route(packet)
    assert packet.state == PacketState.FAILED
    assert "unavailable" in packet.error


def test_available_runtimes_excludes_unavailable():
    router = RuntimeRouter()
    router.register(_FakeAdapter("python", available=True))
    router.register(_FakeAdapter("r", available=False))
    assert router.available_runtimes() == ["python"]
    assert set(router.all_runtimes()) == {"python", "r"}


def test_unregister_removes_route():
    router = RuntimeRouter()
    router.register(_FakeAdapter("python"))
    router.unregister("python")
    with pytest.raises(NoRouteError):
        router.resolve("python")


def test_describe_reports_availability_map():
    router = RuntimeRouter()
    router.register(_FakeAdapter("python", available=True))
    router.register(_FakeAdapter("wasm", available=False))
    assert router.describe() == {"python": True, "wasm": False}
