"""Runtime adapters: real process-isolated Python execution (incl.
timeout/crash recovery), real WASM execution via wasmtime, and honest
unavailable-state reporting for R/Rust when their tooling isn't present."""

from __future__ import annotations

import pytest

from silicaflux.core.packet import SFXPacket
from silicaflux.runtimes.python_runtime import PythonFunctionRegistry, PythonRuntimeAdapter
from silicaflux.runtimes.r_runtime import RFunctionRegistry, RRuntimeAdapter
from silicaflux.runtimes.rust_runtime import RustBinaryRegistry, RustRuntimeAdapter
from silicaflux.runtimes.wasm_runtime import WASMModuleRegistry, WASMRuntimeAdapter

_ADD_WAT = """
(module
  (func $add (param $a i32) (param $b i32) (result i32)
    local.get $a
    local.get $b
    i32.add)
  (export "add" (func $add)))
"""


@pytest.fixture
def python_adapter():
    registry = PythonFunctionRegistry()
    registry.register("analytics", "silicaflux.runtimes.sample_functions", "analytics_summary")
    registry.register("slow", "silicaflux.runtimes.sample_functions", "slow_operation")
    adapter = PythonRuntimeAdapter(registry=registry, default_timeout_s=3.0)
    yield adapter
    adapter.pool.shutdown()


async def test_python_runtime_executes_registered_operation(python_adapter):
    packet = SFXPacket(source="t", destination="e", runtime="python", operation="analytics", payload={"values": [1, 2, 3]})
    result = await python_adapter.execute(packet)
    assert result.state.value == "completed"
    assert result.result["mean"] == 2.0


async def test_python_runtime_rejects_unregistered_operation(python_adapter):
    packet = SFXPacket(source="t", destination="e", runtime="python", operation="not_registered", payload={})
    result = await python_adapter.execute(packet)
    assert result.state.value == "failed"
    assert "not registered" in result.error or "no python function" in result.error


async def test_python_runtime_timeout_then_recovers(python_adapter):
    slow_packet = SFXPacket(
        source="t", destination="e", runtime="python", operation="slow",
        payload={"seconds": 10}, metadata={"timeout_s": 0.5},
    )
    result = await python_adapter.execute(slow_packet)
    assert result.state.value == "failed"
    assert "timed out" in result.error

    # the pool must have replaced the stuck worker and stay usable
    follow_up = SFXPacket(source="t", destination="e", runtime="python", operation="analytics", payload={"values": [5]})
    result2 = await python_adapter.execute(follow_up)
    assert result2.state.value == "completed"


def test_wasm_runtime_availability_matches_wasmtime_install():
    adapter = WASMRuntimeAdapter()
    # wasmtime is a declared dependency for this test environment.
    assert adapter.is_available() is True


async def test_wasm_runtime_executes_real_module():
    registry = WASMModuleRegistry()
    registry.register_wat("add", _ADD_WAT, "add")
    adapter = WASMRuntimeAdapter(registry=registry)
    packet = SFXPacket(source="t", destination="e", runtime="wasm", operation="add", payload={"args": [10, 32]})
    result = await adapter.execute(packet)
    assert result.state.value == "completed"
    assert result.result == {"result": 42}


async def test_wasm_runtime_unregistered_operation_fails_cleanly():
    adapter = WASMRuntimeAdapter(registry=WASMModuleRegistry())
    packet = SFXPacket(source="t", destination="e", runtime="wasm", operation="missing", payload={})
    result = await adapter.execute(packet)
    assert result.state.value == "failed"


def test_r_runtime_reports_honest_unavailable_state():
    adapter = RRuntimeAdapter(registry=RFunctionRegistry())
    # This CI environment does not have R installed; the adapter must say
    # so rather than pretending to support it.
    if adapter.is_available():
        pytest.skip("R is installed in this environment; availability check not exercised")
    assert adapter.is_available() is False


def test_rust_runtime_unavailable_with_no_registered_binaries():
    adapter = RustRuntimeAdapter(registry=RustBinaryRegistry())
    assert adapter.is_available() is False


async def test_rust_runtime_executes_real_compiled_binary():
    import shutil
    from pathlib import Path

    binary = Path(__file__).resolve().parents[2] / "examples" / "rust_compute" / "target" / "release" / "sfx_rust_compute"
    if not binary.exists():
        pytest.skip("example Rust binary not built (run `cargo build --release` in examples/rust_compute)")

    registry = RustBinaryRegistry()
    registry.register("sha256", binary)
    adapter = RustRuntimeAdapter(registry=registry)
    packet = SFXPacket(source="t", destination="e", runtime="rust", operation="sha256", payload={"text": "silicaflux"})
    result = await adapter.execute(packet)
    assert result.state.value == "completed"
    import hashlib

    assert result.result["sha256"] == hashlib.sha256(b"silicaflux").hexdigest()
