"""Networking: cache-aware fetch, retries, DNS caching, downloads,
request prioritisation — using httpx.MockTransport, no real network I/O."""

from __future__ import annotations

import httpx
import pytest

from silicaflux.cache.resource_cache import ResourceCache
from silicaflux.networking.client import HTTPClient, RetryPolicy
from silicaflux.networking.cookies import Cookie, CookieManager
from silicaflux.networking.scheduler import NetworkRequest, NetworkScheduler, ResourceType


def _mock_transport(handler):
    return httpx.MockTransport(handler)


async def test_fetch_caches_and_serves_from_cache():
    calls = {"n": 0}

    def handler(request):
        calls["n"] += 1
        return httpx.Response(200, json={"ok": True}, headers={"cache-control": "max-age=60"})

    client = HTTPClient(resource_cache=ResourceCache(), transport=_mock_transport(handler))
    r1 = await client.fetch("https://api.example.com/data")
    r2 = await client.fetch("https://api.example.com/data")
    assert r1.from_cache is False
    assert r2.from_cache is True
    assert calls["n"] == 1
    await client.aclose()


async def test_fetch_retries_on_5xx_then_succeeds():
    calls = {"n": 0}

    def handler(request):
        calls["n"] += 1
        if calls["n"] < 3:
            return httpx.Response(503)
        return httpx.Response(200, content=b"ok")

    client = HTTPClient(retry_policy=RetryPolicy(max_retries=3, backoff_base_s=0.001), transport=_mock_transport(handler))
    result = await client.fetch("https://api.example.com/flaky", use_cache=False)
    assert result.status_code == 200
    assert calls["n"] == 3
    await client.aclose()


async def test_fetch_reports_error_after_exhausting_retries():
    def handler(request):
        raise httpx.ConnectError("connection refused", request=request)

    client = HTTPClient(retry_policy=RetryPolicy(max_retries=1, backoff_base_s=0.001), transport=_mock_transport(handler))
    result = await client.fetch("https://unreachable.example/", use_cache=False)
    assert not result.ok
    assert result.error is not None
    await client.aclose()


def test_cookie_manager_blocks_third_party_when_configured():
    manager = CookieManager(block_third_party=True)
    manager.set(Cookie(name="sid", value="abc", domain="tracker.example"))
    same_site = manager.get_for_request("https://tracker.example/pixel", document_url="https://tracker.example/page")
    cross_site = manager.get_for_request("https://tracker.example/pixel", document_url="https://news.example/page")
    assert len(same_site) == 1
    assert len(cross_site) == 0


def test_cookie_manager_allows_first_party_by_default():
    manager = CookieManager(block_third_party=False)
    manager.set(Cookie(name="sid", value="abc", domain="example.com"))
    cookies = manager.get_for_request("https://example.com/page")
    assert len(cookies) == 1


def test_network_scheduler_prioritises_document_over_image():
    scheduler = NetworkScheduler()
    scheduler.submit(NetworkRequest("r1", "https://a.com/img.png", ResourceType.IMAGE, is_active_tab=False))
    scheduler.submit(NetworkRequest("r2", "https://a.com/index.html", ResourceType.DOCUMENT, user_initiated=True))
    batch = scheduler.next_batch(2)
    assert batch[0].request_id == "r2"


def test_network_scheduler_respects_per_host_concurrency_limit():
    scheduler = NetworkScheduler(max_concurrent_per_host=1)
    scheduler.submit(NetworkRequest("r1", "https://a.com/1", ResourceType.IMAGE))
    scheduler.submit(NetworkRequest("r2", "https://a.com/2", ResourceType.IMAGE))
    batch = scheduler.next_batch(5)
    assert len(batch) == 1  # second request to same host deferred


async def test_download_manager_streams_and_verifies(tmp_path):
    from silicaflux.networking.downloads import DownloadManager

    payload = b"X" * 5000

    def handler(request):
        return httpx.Response(200, content=payload)

    client = HTTPClient(transport=_mock_transport(handler))
    manager = DownloadManager(client, tmp_path)
    record = manager.start("https://example.com/file.bin", filename="file.bin")
    await manager._tasks[record.id]
    assert record.status == "completed"
    assert record.received_bytes == len(payload)
    assert record.sha256 is not None
    await client.aclose()
