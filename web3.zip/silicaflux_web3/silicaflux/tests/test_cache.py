"""Cache subsystem: content-addressing, resource freshness/invalidation,
computation memoization, module/WASM caches, API response TTLs."""

from __future__ import annotations

import asyncio
import time

from silicaflux.cache import CacheManager
from silicaflux.cache.content_cache import ContentCache, content_hash
from silicaflux.cache.resource_cache import ResourceCache


def test_content_addressing_dedupes_identical_bytes():
    cache = ContentCache()
    h1 = cache.put(b"hello")
    h2 = cache.put(b"hello")
    assert h1 == h2 == content_hash(b"hello")
    assert cache.size() == 1


def test_content_cache_hit_miss_stats():
    cache = ContentCache()
    digest = cache.put(b"data")
    assert cache.get(digest) == b"data"
    assert cache.get("nonexistent" * 4) is None
    assert cache.stats.hits == 1
    assert cache.stats.misses == 1


def test_resource_cache_freshness_and_expiry():
    cache = ResourceCache()
    cache.store("https://example.com/a.js", b"1", "text/javascript", "https://example.com", max_age_s=60)
    hit = cache.lookup("https://example.com/a.js")
    assert hit is not None
    meta, data = hit
    assert data == b"1"
    assert meta.is_fresh()


def test_resource_cache_expired_entry_misses():
    cache = ResourceCache()
    cache.store("https://example.com/a.js", b"1", "text/javascript", "https://example.com", max_age_s=0.001)
    time.sleep(0.01)
    assert cache.lookup("https://example.com/a.js") is None


def test_resource_cache_dependency_invalidation():
    cache = ResourceCache()
    cache.store("https://example.com/style.css", b"css", "text/css", "https://example.com", max_age_s=60)
    cache.store(
        "https://example.com/index.html", b"html", "text/html", "https://example.com",
        max_age_s=60, depends_on=["https://example.com/style.css"],
    )
    cache.invalidate("https://example.com/style.css")
    assert cache.lookup("https://example.com/index.html") is None


async def test_computation_cache_memoize_skips_recompute():
    manager = CacheManager()
    calls = {"n": 0}

    async def compute():
        calls["n"] += 1
        return 42

    r1 = await manager.computation.memoize("fn", {"x": 1}, compute)
    r2 = await manager.computation.memoize("fn", {"x": 1}, compute)
    assert r1 == r2 == 42
    assert calls["n"] == 1


def test_module_cache_avoids_recompile():
    manager = CacheManager()
    calls = {"n": 0}

    def compile_fn(src):
        calls["n"] += 1
        return compile(src, "<m>", "exec")

    manager.modules.get_or_compile("python", b"x = 1", compile_fn)
    manager.modules.get_or_compile("python", b"x = 1", compile_fn)
    assert calls["n"] == 1


def test_api_response_cache_respects_ttl():
    manager = CacheManager()
    key = manager.api_responses.make_key("GET", "https://api.example.com/data")
    manager.api_responses.set(key, 200, {"ok": True}, {}, ttl_s=0.001)
    time.sleep(0.01)
    assert manager.api_responses.get(key) is None


def test_cache_manager_stats_aggregate_across_tiers():
    manager = CacheManager()
    manager.content.put(b"x")
    manager.content.get(content_hash(b"x"))
    stats = manager.stats()
    assert "totals" in stats
    assert stats["totals"]["hits"] >= 1
