"""Packet scheduler: priority ordering, expiry, feedback loop."""

from __future__ import annotations

from silicaflux.core.packet import PacketPriority, PacketState, SFXPacket
from silicaflux.core.scheduler import Scheduler


def _packet(priority: PacketPriority, ttl: float = 30.0) -> SFXPacket:
    return SFXPacket(source="a", destination="b", runtime="python", operation="op", priority=priority, ttl=ttl)


def test_critical_serviced_before_bulk():
    scheduler = Scheduler()
    scheduler.submit(_packet(PacketPriority.BULK))
    scheduler.submit(_packet(PacketPriority.CRITICAL))
    batch = scheduler.next_batch(2)
    assert [p.priority for p in batch] == [PacketPriority.CRITICAL, PacketPriority.BULK]


def test_fifo_within_same_priority():
    scheduler = Scheduler()
    first = _packet(PacketPriority.NORMAL)
    second = _packet(PacketPriority.NORMAL)
    scheduler.submit(first)
    scheduler.submit(second)
    batch = scheduler.next_batch(2)
    assert [p.packet_id for p in batch] == [first.packet_id, second.packet_id]


def test_submit_transitions_created_to_queued():
    scheduler = Scheduler()
    packet = _packet(PacketPriority.NORMAL)
    scheduler.submit(packet)
    assert packet.state == PacketState.QUEUED


def test_expired_packet_marked_failed_and_skipped():
    scheduler = Scheduler()
    packet = _packet(PacketPriority.NORMAL, ttl=0.001)
    scheduler.submit(packet)
    import time

    time.sleep(0.01)
    batch = scheduler.next_batch(5)
    assert batch == []
    assert packet.state == PacketState.FAILED
    assert packet.error == "ttl_expired_in_queue"


def test_cancel_removes_from_queue():
    scheduler = Scheduler()
    packet = _packet(PacketPriority.NORMAL)
    scheduler.submit(packet)
    assert scheduler.cancel(packet.packet_id)
    assert len(scheduler) == 0
    assert packet.state == PacketState.CANCELLED


def test_record_execution_biases_future_ordering():
    scheduler = Scheduler()
    scheduler.record_execution("slow_runtime", duration_ms=5000)
    stats = scheduler.stats()
    assert stats["runtime_avg_latency_ms"]["slow_runtime"] == 5000


def test_peek_does_not_remove():
    scheduler = Scheduler()
    packet = _packet(PacketPriority.NORMAL)
    scheduler.submit(packet)
    assert scheduler.peek().packet_id == packet.packet_id
    assert len(scheduler) == 1
