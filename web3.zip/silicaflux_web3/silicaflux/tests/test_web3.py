"""Web3 layer: identity/signing (real Ed25519), encrypted-at-rest keys,
wallet approval gating, and P2P content-addressed retrieval."""

from __future__ import annotations

import pytest

from silicaflux.security.policy import SecurityPolicy
from silicaflux.web3.dapp_bridge import DAppBridge, DAppBridgeError
from silicaflux.web3.identity import IdentityError, IdentityManager
from silicaflux.web3.p2p import LoopbackTransport, Peer, PeerNetwork
from silicaflux.web3.permissions import DAppPermissionManager
from silicaflux.web3.wallet import Wallet, WalletApprovalDenied


@pytest.fixture
def identity_manager(tmp_path) -> IdentityManager:
    return IdentityManager(tmp_path)


def test_signature_roundtrip_and_tamper_detection(identity_manager):
    identity = identity_manager.create_identity("passphrase123")
    signature = identity_manager.signatures.sign(identity.identity_id, b"hello")
    assert identity_manager.signatures.verify(identity.public_key_b64, b"hello", signature)
    assert not identity_manager.signatures.verify(identity.public_key_b64, b"tampered", signature)


def test_content_signing_and_verification(identity_manager):
    identity = identity_manager.create_identity("passphrase123")
    envelope = identity_manager.verifier.sign_content(identity.identity_id, b"resource bytes")
    assert identity_manager.verifier.verify_content(b"resource bytes", identity.public_key_b64, envelope["signature"])
    assert not identity_manager.verifier.verify_content(b"different bytes", identity.public_key_b64, envelope["signature"])


def test_private_key_never_appears_in_stored_envelope(identity_manager, tmp_path):
    identity = identity_manager.create_identity("passphrase123")
    key_file = (tmp_path / f"{identity.identity_id}.key").read_text()
    assert "-----BEGIN" not in key_file  # not a raw PEM; it's ciphertext + salt only


def test_unlock_requires_correct_passphrase(identity_manager):
    identity = identity_manager.create_identity("correct-passphrase")
    fresh = IdentityManager(identity_manager.keys.storage_dir)
    with pytest.raises(IdentityError):
        fresh.unlock(identity.identity_id, "wrong-passphrase")
    restored = fresh.unlock(identity.identity_id, "correct-passphrase")
    assert restored.public_key_b64 == identity.public_key_b64


def test_key_rotation_produces_new_identity(identity_manager):
    old = identity_manager.create_identity("pw")
    new = identity_manager.keys.rotate(old.identity_id, "pw")
    assert new.identity_id != old.identity_id


def test_wallet_signing_requires_approval(identity_manager):
    identity = identity_manager.create_identity("pw")
    wallet = Wallet(identity_manager, approval_prompt=lambda req: False)
    account = wallet.create_account(identity)
    wallet.connect("https://dapp.example", account.address, approved=True)
    with pytest.raises(WalletApprovalDenied):
        wallet.sign_message("https://dapp.example", account.address, "hello")


def test_wallet_signing_succeeds_when_approved(identity_manager):
    identity = identity_manager.create_identity("pw")
    wallet = Wallet(identity_manager, approval_prompt=lambda req: True)
    account = wallet.create_account(identity)
    wallet.connect("https://dapp.example", account.address, approved=True)
    signature = wallet.sign_message("https://dapp.example", account.address, "hello")
    assert identity_manager.signatures.verify(identity.public_key_b64, b"hello", signature)


def test_unconnected_origin_cannot_sign(identity_manager):
    identity = identity_manager.create_identity("pw")
    wallet = Wallet(identity_manager, approval_prompt=lambda req: True)
    account = wallet.create_account(identity)
    with pytest.raises(WalletApprovalDenied):
        wallet.sign_message("https://evil.example", account.address, "hello")


async def test_dapp_bridge_full_flow(identity_manager):
    identity = identity_manager.create_identity("pw")
    wallet = Wallet(identity_manager, approval_prompt=lambda req: True)
    account = wallet.create_account(identity)
    policy = SecurityPolicy(default_policy="allow")
    permissions = DAppPermissionManager(policy, wallet)
    bridge = DAppBridge(wallet, permissions, default_address=account.address)

    connect_result = await bridge.handle("connect", "https://dapp.example", {})
    assert connect_result["accounts"] == [account.address]

    sign_result = await bridge.handle("sign_message", "https://dapp.example", {"address": account.address, "message": "nonce"})
    assert identity_manager.signatures.verify(identity.public_key_b64, b"nonce", sign_result["signature"])

    with pytest.raises(DAppBridgeError):
        await bridge.handle("sign_message", "https://evil.example", {"address": account.address, "message": "x"})


async def test_p2p_content_retrieval_verifies_integrity():
    transport = LoopbackTransport()
    publisher = PeerNetwork(transport, Peer("publisher", "loopback://p"))
    consumer = PeerNetwork(transport, Peer("consumer", "loopback://c"))
    publisher.enable()
    consumer.enable()

    content_id = await publisher.publish(b"distributed content")
    transport._seed("publisher", content_id, b"distributed content")

    resource = await consumer.resolve(content_id)
    assert resource.verified
    assert resource.data == b"distributed content"
    assert resource.retrieved_from == "publisher"


async def test_p2p_resolve_from_local_cache_first():
    transport = LoopbackTransport()
    network = PeerNetwork(transport, Peer("solo", "loopback://s"))
    content_id = await network.publish(b"local only")
    resource = await network.resolve(content_id)
    assert resource.retrieved_from is None  # served from local cache, no network hop


async def test_p2p_disabled_by_default_for_remote_fetch():
    transport = LoopbackTransport()
    network = PeerNetwork(transport, Peer("disabled", "loopback://d"))
    with pytest.raises(PermissionError):
        await network.resolve("some-content-id-not-in-local-cache")
