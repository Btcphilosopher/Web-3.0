"""SilicaFlux test suite. Run with ``pytest`` from the project root."""
