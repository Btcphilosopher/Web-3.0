"""Execution graph: dependency resolution, parallelism, cycles, retries,
failure propagation, and computation-cache integration."""

from __future__ import annotations

import asyncio

import pytest

from silicaflux.cache.computation_cache import ComputationCache
from silicaflux.core.graph import ExecutionGraph, GraphCycleError, Node, NodeState


async def _double(node, inputs):
    return inputs["x"] * 2


async def test_linear_dependency_chain_resolves():
    graph = ExecutionGraph()
    graph.add_task("a", "python", "double", inputs={"x": 2})
    graph.add_task("b", "python", "double", inputs={"x": {"$ref": "a"}}, depends_on=["a"])
    nodes = await graph.run(_double)
    assert nodes["a"].result == 4
    assert nodes["b"].result == 8
    assert nodes["a"].state == NodeState.COMPLETED
    assert nodes["b"].state == NodeState.COMPLETED


async def test_independent_nodes_run_in_parallel():
    started = []

    async def slow_marker(node, inputs):
        started.append(node.id)
        await asyncio.sleep(0.05)
        return node.id

    graph = ExecutionGraph(max_parallel=4)
    graph.add_task("x", "python", "f")
    graph.add_task("y", "python", "f")
    import time

    start = time.perf_counter()
    await graph.run(slow_marker)
    elapsed = time.perf_counter() - start
    assert elapsed < 0.09  # ran concurrently, not 0.1s serially
    assert set(started) == {"x", "y"}


def test_cycle_detection():
    graph = ExecutionGraph()
    graph.add_task("a", "python", "f", depends_on=["b"])
    graph.add_task("b", "python", "f", depends_on=["a"])
    with pytest.raises(GraphCycleError):
        graph.validate()


def test_unknown_dependency_raises():
    graph = ExecutionGraph()
    graph.add_task("a", "python", "f", depends_on=["missing"])
    with pytest.raises(ValueError):
        graph.validate()


async def test_failure_propagates_to_dependents():
    async def fail(node, inputs):
        if node.id == "a":
            raise RuntimeError("boom")
        return "should not run"

    graph = ExecutionGraph()
    graph.add_task("a", "python", "f")
    graph.add_task("b", "python", "f", depends_on=["a"])
    nodes = await graph.run(fail)
    assert nodes["a"].state == NodeState.FAILED
    assert nodes["b"].state == NodeState.SKIPPED


async def test_retries_before_permanent_failure():
    attempts = {"n": 0}

    async def flaky(node, inputs):
        attempts["n"] += 1
        if attempts["n"] < 3:
            raise RuntimeError("transient")
        return "ok"

    graph = ExecutionGraph()
    graph.add_task("a", "python", "f", max_retries=3)
    nodes = await graph.run(flaky)
    assert nodes["a"].state == NodeState.COMPLETED
    assert nodes["a"].result == "ok"
    assert nodes["a"].retry_count == 2


async def test_computation_cache_skips_recompute():
    calls = {"n": 0}

    async def counted(node, inputs):
        calls["n"] += 1
        return inputs["x"]

    cache = ComputationCache()
    graph = ExecutionGraph()
    graph.add_task("a", "python", "f", inputs={"x": 1}, cache_policy="default")
    await graph.run(counted, cache=cache)

    graph2 = ExecutionGraph()
    graph2.add_task("a", "python", "f", inputs={"x": 1}, cache_policy="default")
    nodes2 = await graph2.run(counted, cache=cache)
    assert calls["n"] == 1  # second run hit the cache, function not called again
    assert nodes2["a"].result == 1


def test_to_dict_produces_visualisation_payload():
    graph = ExecutionGraph(graph_id="demo")
    graph.add_task("a", "python", "f")
    graph.add_task("b", "python", "f", depends_on=["a"])
    payload = graph.to_dict()
    assert payload["graph_id"] == "demo"
    assert len(payload["nodes"]) == 2
    assert payload["edges"] == [{"from": "a", "to": "b"}]
