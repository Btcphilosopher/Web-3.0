"""Smart address-bar classification and tab navigation history."""

from __future__ import annotations

from silicaflux.core.navigation import AddressKind, NavigationManager, classify_input
from silicaflux.core.tabs import TabManager


def test_https_url_classified_as_url():
    result = classify_input("https://example.com")
    assert result.kind == AddressKind.HTTPS_URL
    assert result.normalized_url == "https://example.com"


def test_bare_domain_gets_https_scheme():
    result = classify_input("example.com")
    assert result.kind == AddressKind.BARE_DOMAIN
    assert result.normalized_url == "https://example.com"


def test_localhost_gets_http_scheme():
    result = classify_input("localhost:8080")
    assert result.kind == AddressKind.LOCALHOST
    assert result.normalized_url == "http://localhost:8080"


def test_ip_address_recognized():
    result = classify_input("192.168.1.1")
    assert result.kind == AddressKind.IP_ADDRESS


def test_sfx_internal_passthrough():
    result = classify_input("sfx://runtime")
    assert result.kind == AddressKind.SFX_INTERNAL
    assert result.normalized_url == "sfx://runtime"


def test_about_blank_passthrough():
    result = classify_input("about:blank")
    assert result.kind == AddressKind.ABOUT
    assert result.normalized_url == "about:blank"


def test_search_query_for_non_url_text():
    result = classify_input("bitcoin")
    assert result.kind == AddressKind.SEARCH_QUERY
    assert "bitcoin" in result.normalized_url


def test_search_query_with_spaces():
    result = classify_input("best pizza near me")
    assert result.kind == AddressKind.SEARCH_QUERY


def test_navigation_manager_back_forward():
    nav = NavigationManager()
    nav.navigate("https://a.com")
    nav.navigate("https://b.com")
    assert nav.can_go_back()
    assert not nav.can_go_forward()
    entry = nav.go_back()
    assert entry.url == "https://a.com"
    assert nav.can_go_forward()
    entry = nav.go_forward()
    assert entry.url == "https://b.com"


def test_navigation_forward_history_discarded_on_new_navigation():
    nav = NavigationManager()
    nav.navigate("https://a.com")
    nav.navigate("https://b.com")
    nav.go_back()
    nav.navigate("https://c.com")
    assert not nav.can_go_forward()
    assert [e.url for e in nav.entries()] == ["https://a.com", "https://c.com"]


def test_tab_manager_open_close_restore():
    manager = TabManager()
    tab = manager.new_tab("https://example.com")
    assert manager.active_tab.tab_id == tab.tab_id
    manager.close_tab(tab.tab_id)
    assert manager.get(tab.tab_id) is None
    restored = manager.restore_closed_tab()
    assert restored.url == "https://example.com"


def test_tab_manager_duplicate_and_pin():
    manager = TabManager()
    tab = manager.new_tab("https://example.com")
    manager.pin(tab.tab_id, True)
    duplicate = manager.duplicate_tab(tab.tab_id)
    assert duplicate.pinned
    assert duplicate.tab_id != tab.tab_id


def test_private_tabs_not_restorable():
    manager = TabManager()
    tab = manager.new_tab("https://example.com", private=True)
    manager.close_tab(tab.tab_id)
    assert manager.restore_closed_tab() is None
