"""Local AI engine: verified model registration, capability-gated
inference, honest hardware availability reporting."""

from __future__ import annotations

import pytest

from silicaflux.ai.manager import AIManager, CapabilityDenied, HardwareUnavailable
from silicaflux.ai.registry import ModelIntegrityError, ModelRegistry
from silicaflux.security.policy import SecurityPolicy


@pytest.fixture
def registry() -> ModelRegistry:
    reg = ModelRegistry()
    reg.register_native(
        model_id="sentiment-demo",
        version="1.0.0",
        predict_target="silicaflux.ai.sample_models:sentiment_predict",
        input_schema={"text": "string"},
        output_schema={"score": "float", "label": "string"},
    )
    return reg


async def test_inference_returns_expected_shape(registry):
    manager = AIManager(registry=registry, security_policy=SecurityPolicy(default_policy="allow"))
    result = await manager.predict("https://trusted.example", "sentiment-demo", {"text": "this is great"})
    assert result.model_id == "sentiment-demo"
    assert result.output["label"] == "positive"
    manager.shutdown()


async def test_inference_denied_without_capability(registry):
    manager = AIManager(registry=registry, security_policy=SecurityPolicy(default_policy="deny"))
    with pytest.raises(CapabilityDenied):
        await manager.predict("https://untrusted.example", "sentiment-demo", {"text": "x"})
    manager.shutdown()


async def test_gpu_required_model_refuses_on_cpu_only_host(registry):
    registry.register_native(
        model_id="gpu-only",
        version="1.0.0",
        predict_target="silicaflux.ai.sample_models:sentiment_predict",
        input_schema={}, output_schema={},
        hardware_requirement="gpu",
    )
    manager = AIManager(registry=registry, security_policy=SecurityPolicy(default_policy="allow"))
    with pytest.raises(HardwareUnavailable):
        await manager.predict("https://trusted.example", "gpu-only", {})
    manager.shutdown()


def test_hardware_report_is_honest_not_fabricated():
    manager = AIManager()
    report = manager.hardware_report()
    assert report["cpu"] is True
    assert report["gpu"] is False
    assert report["npu"] is False
    manager.shutdown()


def test_model_registration_rejects_hash_mismatch(tmp_path):
    model_path = tmp_path / "model.bin"
    model_path.write_bytes(b"real model weights")
    registry = ModelRegistry()
    with pytest.raises(ModelIntegrityError):
        registry.register_from_file(
            "bad-model", "1.0", "onnx", model_path, expected_hash="0" * 64,
            hardware_requirement="cpu", input_schema={}, output_schema={}, predict_target="x:y",
        )
