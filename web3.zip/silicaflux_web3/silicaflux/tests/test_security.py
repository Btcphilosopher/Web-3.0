"""Security layer: capability policy, origin isolation, sandboxing, and
the "fail closed by default" guarantee."""

from __future__ import annotations

from silicaflux.security.capabilities import UnknownCapability, validate_capability_name
from silicaflux.security.origins import parse_origin, same_origin
from silicaflux.security.permissions import PermissionManager
from silicaflux.security.policy import SecurityPolicy
from silicaflux.security.sandbox import ResourceLimits, apply_worker_limits


def test_unknown_origin_denied_by_default():
    policy = SecurityPolicy(default_policy="prompt")
    token = policy.authorize("https://untrusted.example", "python.execute")
    assert token is None


def test_explicit_approval_grants_capability():
    policy = SecurityPolicy(default_policy="prompt", approval_callback=lambda o, c, s: True)
    token = policy.authorize("https://trusted.example", "python.analytics")
    assert token is not None
    assert policy.verify(token)


def test_deny_policy_ignores_approval_callback():
    policy = SecurityPolicy(default_policy="deny", approval_callback=lambda o, c, s: True)
    token = policy.authorize("https://anything.example", "python.execute")
    assert token is None


def test_sfx_internal_origins_implicitly_trusted():
    policy = SecurityPolicy(default_policy="deny")
    token = policy.authorize("sfx://runtime", "wallet.sign")
    assert token is not None


def test_dangerous_capability_always_prompts_even_under_allow_policy():
    calls = []

    def approval(origin, cap, scope):
        calls.append(cap)
        return True

    policy = SecurityPolicy(default_policy="allow", approval_callback=approval)
    policy.authorize("https://app.example", "wallet.sign")
    assert "wallet.sign" in calls


def test_revoke_invalidates_token():
    policy = SecurityPolicy(default_policy="allow")
    token = policy.authorize("https://app.example", "python.execute")
    assert policy.verify(token)
    policy.revoke("https://app.example", "python.execute")
    assert not policy.verify(token)


def test_revoke_all_clears_every_grant():
    policy = SecurityPolicy(default_policy="allow")
    policy.authorize("https://app.example", "python.execute")
    policy.authorize("https://app.example", "network.fetch")
    n = policy.revoke_all("https://app.example")
    assert n == 2
    assert policy.grants_for("https://app.example") == []


def test_unknown_capability_name_rejected():
    try:
        validate_capability_name("filesystem.rm_rf_root")
        assert False, "should have raised"
    except UnknownCapability:
        pass


def test_permission_manager_persists_grants(tmp_path):
    class FakeStore:
        def __init__(self):
            self.rows = []

        def save_permission(self, origin, capability, granted):
            self.rows.append((origin, capability, granted))

        def load_permissions(self):
            return self.rows

    policy = SecurityPolicy(default_policy="allow")
    store = FakeStore()
    manager = PermissionManager(policy, persistence=store)
    manager.request("https://app.example", "python.execute")
    assert ("https://app.example", "python.execute", True) in store.rows


def test_parse_origin_normalizes_scheme_host_port():
    origin = parse_origin("https://Example.com:8443/some/path?q=1")
    assert str(origin) == "https://example.com:8443"


def test_same_origin_ignores_path():
    assert same_origin("https://example.com/a", "https://example.com/b")
    assert not same_origin("https://example.com", "https://other.com")


def test_malformed_url_is_opaque_null_origin():
    origin = parse_origin("not a url")
    assert origin.scheme == "null"


def _apply_limits_child() -> None:
    apply_worker_limits(ResourceLimits(cpu_seconds=5.0, memory_mb=256))


def test_resource_limits_apply_without_crashing():
    # RLIMIT_CPU/RLIMIT_AS are process-wide and irreversible for the
    # calling process, so this must run in a throwaway child — applying
    # them to the pytest process itself would CPU-cap the whole test run.
    # The target must be a module-level function: spawn pickles it by
    # import path, and a local/nested function isn't picklable.
    import multiprocessing as mp

    ctx = mp.get_context("spawn")
    proc = ctx.Process(target=_apply_limits_child)
    proc.start()
    proc.join(timeout=10)
    assert proc.exitcode == 0
