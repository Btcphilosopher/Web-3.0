"""SQLite-backed storage: history, bookmarks, sessions, downloads,
permissions, telemetry, and the sandboxed filesystem."""

from __future__ import annotations

import pytest

from silicaflux.storage.bookmarks import BookmarksStore
from silicaflux.storage.database import Database
from silicaflux.storage.downloads_store import DownloadRecord, DownloadsStore
from silicaflux.storage.filesystem import FilesystemAccessDenied, SandboxedFilesystem
from silicaflux.storage.history import HistoryStore
from silicaflux.storage.permissions_store import PermissionsStore
from silicaflux.storage.settings import SettingsStore


@pytest.fixture
def db(tmp_path) -> Database:
    database = Database(tmp_path / "test.sqlite3")
    yield database
    database.close()


async def test_history_visit_increments_count(db):
    store = HistoryStore(db)
    await store.visit("https://example.com", "Example")
    await store.visit("https://example.com", "Example")
    results = await store.search()
    assert results[0].visit_count == 2


async def test_history_search_filters_by_query(db):
    store = HistoryStore(db)
    await store.visit("https://example.com", "Example")
    await store.visit("https://other.com", "Other")
    results = await store.search("example")
    assert len(results) == 1
    assert results[0].url == "https://example.com"


async def test_history_delete_and_clear(db):
    store = HistoryStore(db)
    await store.visit("https://example.com")
    entries = await store.search()
    await store.delete(entries[0].id)
    assert await store.search() == []
    await store.visit("https://a.com")
    await store.visit("https://b.com")
    await store.clear()
    assert await store.search() == []


async def test_bookmarks_crud(db):
    store = BookmarksStore(db)
    bid = await store.add("https://example.com", "Example", "Work")
    bookmarks = await store.list()
    assert bookmarks[0].id == bid
    await store.edit(bid, title="Renamed")
    bookmarks = await store.list()
    assert bookmarks[0].title == "Renamed"
    await store.remove(bid)
    assert await store.list() == []


async def test_bookmarks_export_import_roundtrip(db):
    store = BookmarksStore(db)
    await store.add("https://a.com", "A")
    exported = await store.export_json()
    store2 = BookmarksStore(Database(db.path.parent / "second.sqlite3"))
    count = await store2.import_json(exported)
    assert count == 1
    imported = await store2.list()
    assert imported[0].url == "https://a.com"
    store2.db.close()


def test_session_save_and_load_roundtrip(db):
    tabs = [{"url": "https://example.com", "title": "Example", "pinned": True}]
    db.save_session("default", tabs)
    loaded = db.load_session("default")
    assert len(loaded) == 1
    assert loaded[0]["url"] == "https://example.com"
    assert loaded[0]["pinned"] == 1


async def test_downloads_store_persists_record(db):
    store = DownloadsStore(db)
    record = DownloadRecord.new("https://example.com/f.zip", "f.zip", "/tmp/f.zip")
    record.status = "completed"
    record.received_bytes = 100
    await store.save(record)
    history = await store.history()
    assert history[0]["status"] == "completed"


def test_permissions_store_roundtrip(db):
    store = PermissionsStore(db)
    store.save_permission("https://example.com", "python.execute", True)
    perms = store.load_permissions()
    assert ("https://example.com", "python.execute", True) in perms


async def test_settings_store_flattens_nested_dict(db):
    store = SettingsStore(db)
    await store.sync_from({"appearance": {"theme": "dark"}})
    assert await store.get("appearance.theme") == "dark"


def test_sandboxed_filesystem_blocks_traversal(tmp_path):
    fs = SandboxedFilesystem(tmp_path / "sandbox")
    fs.write_text("safe.txt", "hello")
    assert fs.read_text("safe.txt") == "hello"
    with pytest.raises(FilesystemAccessDenied):
        fs.resolve("../../../etc/passwd")


async def test_audit_log_persists_via_sink(db):
    from silicaflux.security.audit import AuditLogger

    audit = AuditLogger(sink=db)
    audit.record("https://example.com", "python.execute", "granted")
    entries = await db.audit_entries()
    assert entries[0]["origin"] == "https://example.com"
    assert entries[0]["outcome"] == "granted"
