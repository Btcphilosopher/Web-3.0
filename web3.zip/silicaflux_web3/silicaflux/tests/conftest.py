"""Shared pytest fixtures for the SilicaFlux test suite."""

from __future__ import annotations

import pytest

from silicaflux.core.bootstrap import HeadlessContext, build_headless_context


@pytest.fixture
async def ctx(tmp_path) -> HeadlessContext:
    """A fully-wired headless engine context (real storage, real security,
    real runtimes, real Web3 layer) rooted at a fresh temp profile
    directory, with capability approval auto-granted so tests don't need
    to wire a UI approval prompt."""
    context = await build_headless_context(profile="test", profile_dir=str(tmp_path), approve_all=True)
    try:
        yield context
    finally:
        await context.shutdown()
