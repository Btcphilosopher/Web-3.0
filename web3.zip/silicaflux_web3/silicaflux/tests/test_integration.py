"""End-to-end integration tests: the full headless engine (real storage,
real security, real Python runtime, real Web3, real telemetry) exercised
through the same JS-facing bridge a browser tab would call."""

from __future__ import annotations

from silicaflux.api.bridge import SilicaFluxBridge


async def test_engine_boots_with_python_and_wasm_available(ctx):
    status = ctx.engine.status()
    assert status["running"] is True
    assert status["runtimes"]["python"] is True
    assert status["runtimes"]["wasm"] is True


async def test_bridge_python_roundtrip(ctx):
    bridge = SilicaFluxBridge(ctx.engine, dapp_bridge=ctx.dapp_bridge)
    response = await bridge.request_dict(
        "https://trusted-app.example",
        {"runtime": "python", "operation": "analytics", "payload": {"values": [10, 20, 30]}},
    )
    assert response["ok"] is True
    assert response["result"]["mean"] == 20.0


async def test_bridge_denies_capability_for_untrusted_origin(tmp_path):
    from silicaflux.core.bootstrap import build_headless_context

    # approve_all=False -> default "prompt" policy with no approval callback -> deny
    strict_ctx = await build_headless_context(profile="strict", profile_dir=str(tmp_path), approve_all=False)
    try:
        bridge = SilicaFluxBridge(strict_ctx.engine, dapp_bridge=strict_ctx.dapp_bridge)
        response = await bridge.request_dict(
            "https://random-website.example",
            {"runtime": "python", "operation": "analytics", "payload": {}},
        )
        assert response["ok"] is False
    finally:
        await strict_ctx.shutdown()


async def test_bridge_web3_connect_flow(ctx):
    identity = ctx.identity_manager.create_identity("test-pass")
    account = ctx.wallet.create_account(identity)
    ctx.wallet.approval_prompt = lambda req: True
    bridge = SilicaFluxBridge(ctx.engine, dapp_bridge=ctx.dapp_bridge)
    response = await bridge.request_dict(
        "https://dapp.example",
        {"runtime": "web3", "operation": "connect", "payload": {"address": account.address}},
    )
    assert response["ok"] is True
    assert account.address in response["result"]["accounts"]


async def test_bridge_rejects_unknown_runtime(ctx):
    bridge = SilicaFluxBridge(ctx.engine, dapp_bridge=ctx.dapp_bridge)
    response = await bridge.request_dict("https://app.example", {"runtime": "cobol", "operation": "x", "payload": {}})
    assert response["ok"] is False
    assert "unknown runtime" in response["error"]


async def test_dashboard_snapshot_reflects_packet_history(ctx):
    bridge = SilicaFluxBridge(ctx.engine, dapp_bridge=ctx.dapp_bridge)
    await bridge.request_dict(
        "https://trusted-app.example",
        {"runtime": "python", "operation": "echo", "payload": {"n": 1}},
    )
    snapshot = ctx.dashboard.snapshot()
    assert len(snapshot["recent_packets"]) >= 1
    assert snapshot["engine"]["runtimes"]["python"] is True


async def test_history_and_bookmarks_wired_into_same_database(ctx):
    await ctx.history.visit("https://example.com", "Example")
    await ctx.bookmarks.add("https://example.com", "Example")
    assert (await ctx.history.search())[0].url == "https://example.com"
    assert (await ctx.bookmarks.list())[0].url == "https://example.com"


async def test_cache_manager_records_real_hits(ctx):
    ctx.cache_manager.resources.store("https://example.com/a.js", b"1", "text/javascript", "https://example.com", max_age_s=60)
    hit1 = ctx.cache_manager.resources.lookup("https://example.com/a.js")
    hit2 = ctx.cache_manager.resources.lookup("https://example.com/a.js")
    assert hit1 is not None and hit2 is not None
    assert ctx.cache_manager.resources.stats.hits == 2
