"""Packet state machine: legal/illegal transitions, timing, retries."""

from __future__ import annotations

import time

import pytest

from silicaflux.core.packet import IllegalPacketTransition, PacketPriority, PacketState, SFXPacket, SecurityContext


def test_packet_created_with_history_entry():
    packet = SFXPacket(source="a", destination="b", runtime="python", operation="op")
    assert packet.state == PacketState.CREATED
    assert len(packet.history) == 1
    assert packet.history[0].state == PacketState.CREATED


def test_legal_transition_chain_completes():
    packet = SFXPacket(source="a", destination="b", runtime="python", operation="op")
    packet.transition(PacketState.QUEUED)
    packet.transition(PacketState.ROUTED)
    packet.transition(PacketState.EXECUTING)
    packet.transition(PacketState.COMPLETED)
    assert packet.state == PacketState.COMPLETED
    assert packet.state.is_terminal


def test_illegal_transition_raises():
    packet = SFXPacket(source="a", destination="b", runtime="python", operation="op")
    with pytest.raises(IllegalPacketTransition):
        packet.transition(PacketState.COMPLETED)


def test_terminal_state_has_no_further_transitions():
    packet = SFXPacket(source="a", destination="b", runtime="python", operation="op")
    packet.transition(PacketState.QUEUED)
    packet.transition(PacketState.ROUTED)
    packet.transition(PacketState.EXECUTING)
    packet.transition(PacketState.FAILED)
    with pytest.raises(IllegalPacketTransition):
        packet.transition(PacketState.QUEUED)


def test_priority_weights_order_critical_first():
    weights = [p.weight for p in PacketPriority]
    assert weights == sorted(weights)
    assert PacketPriority.CRITICAL.weight < PacketPriority.BULK.weight


def test_is_expired_respects_ttl():
    packet = SFXPacket(source="a", destination="b", runtime="python", operation="op", ttl=0.01)
    assert not packet.is_expired(now=packet.timestamp)
    assert packet.is_expired(now=packet.timestamp + 1.0)


def test_queue_and_execution_time_measured():
    packet = SFXPacket(source="a", destination="b", runtime="python", operation="op")
    packet.transition(PacketState.QUEUED)
    time.sleep(0.01)
    packet.transition(PacketState.ROUTED)
    time.sleep(0.01)
    packet.transition(PacketState.EXECUTING)
    time.sleep(0.01)
    packet.transition(PacketState.COMPLETED)
    assert packet.queue_time() > 0
    assert packet.execution_time() > 0
    assert packet.total_latency() >= packet.queue_time() + packet.execution_time() - 0.001


def test_retry_bookkeeping():
    packet = SFXPacket(source="a", destination="b", runtime="python", operation="op", max_retries=2)
    assert packet.can_retry()
    packet.retry_count = 2
    assert not packet.can_retry()


def test_to_dict_is_json_safe():
    packet = SFXPacket(
        source="a",
        destination="b",
        runtime="python",
        operation="op",
        security_context=SecurityContext(origin="https://example.com"),
    )
    data = packet.to_dict()
    assert data["source"] == "a"
    assert data["priority"] == "normal"
    assert data["state"] == "created"
