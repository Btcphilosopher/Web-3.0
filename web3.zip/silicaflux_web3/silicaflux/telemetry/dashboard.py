"""The data backing ``sfx://runtime`` (spec section 27) and the developer
tools "Runtime Monitor" tab: one aggregation point pulling live figures
from the engine, cache tiers, telemetry system, tab manager and wallet —
everything the internal systems dashboard needs to render, with no
subsystem needing to know the dashboard exists.
"""

from __future__ import annotations

from typing import Any, Optional

from silicaflux.telemetry.manager import TelemetryManager


class RuntimeDashboard:
    def __init__(
        self,
        engine: Any,
        telemetry: TelemetryManager,
        cache_manager: Optional[Any] = None,
        tab_manager: Optional[Any] = None,
        wallet: Optional[Any] = None,
        network_performance: Optional[Any] = None,
    ) -> None:
        self.engine = engine
        self.telemetry = telemetry
        self.cache_manager = cache_manager
        self.tab_manager = tab_manager
        self.wallet = wallet
        self.network_performance = network_performance

    def snapshot(self) -> dict:
        system = self.telemetry.system_snapshot().to_dict()
        engine_status = self.engine.status()
        data = {
            "system": system,
            "engine": engine_status,
            "runtimes": engine_status.get("runtimes", {}),
            "workers": engine_status.get("workers", {}),
            "recent_packets": self.engine.recent_packets(limit=50),
        }
        if self.cache_manager is not None:
            data["cache"] = self.cache_manager.stats()
        if self.tab_manager is not None:
            data["tabs"] = {
                "count": len(self.tab_manager),
                "active": self.tab_manager.active_tab.tab_id if self.tab_manager.active_tab else None,
            }
        if self.wallet is not None:
            data["web3"] = {"connected_origins": len(getattr(self.wallet, "_connections", {}))}
        if self.network_performance is not None:
            data["network"] = self.network_performance.summary()
        data["hints"] = self.telemetry.optimisation_hints(
            cache_stats=data.get("cache"), scheduler_stats=engine_status.get("scheduler")
        )
        return data
