"""Performance telemetry: metrics, tracing, real system snapshots,
benchmarking, and the aggregation feeding ``sfx://runtime``."""

from __future__ import annotations

from silicaflux.telemetry.dashboard import RuntimeDashboard
from silicaflux.telemetry.manager import Benchmark, PerformanceProfile, TelemetryManager
from silicaflux.telemetry.metrics import Metric, MetricRegistry, MetricType
from silicaflux.telemetry.tracing import Span, Trace, Tracer

__all__ = [
    "RuntimeDashboard",
    "Benchmark",
    "PerformanceProfile",
    "TelemetryManager",
    "Metric",
    "MetricRegistry",
    "MetricType",
    "Span",
    "Trace",
    "Tracer",
]
