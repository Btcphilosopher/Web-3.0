"""TelemetryManager: the single sink every subsystem reports into, and the
source the developer tools / ``sfx-runtime telemetry`` / ``sfx://runtime``
dashboard read from.

Real measurements only (spec section 20/33: "generate real measurements
rather than simulated performance claims") — CPU/memory come from
``psutil`` when installed (it is a declared dependency, see
``requirements.txt``), packet/network/cache timings come from the actual
:class:`~silicaflux.core.packet.SFXPacket` history and
:class:`~silicaflux.networking.performance.PerformanceMonitor`, nothing is
synthesised.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.telemetry.metrics import MetricRegistry
from silicaflux.telemetry.tracing import Tracer

logger = get_logger("telemetry.manager")

try:
    import psutil

    _PSUTIL_AVAILABLE = True
except ImportError:  # pragma: no cover
    psutil = None  # type: ignore[assignment]
    _PSUTIL_AVAILABLE = False


@dataclass
class PerformanceProfile:
    """A point-in-time system snapshot, the unit
    :meth:`TelemetryManager.system_snapshot` returns and
    :class:`Benchmark` results are compared against."""

    timestamp: float
    cpu_percent: Optional[float]
    memory_percent: Optional[float]
    memory_used_mb: Optional[float]
    process_count: Optional[int]
    available: bool

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "cpu_percent": self.cpu_percent,
            "memory_percent": self.memory_percent,
            "memory_used_mb": self.memory_used_mb,
            "process_count": self.process_count,
            "available": self.available,
        }


@dataclass
class Benchmark:
    name: str
    started_at: float
    finished_at: Optional[float] = None
    iterations: int = 0
    durations_ms: list[float] = field(default_factory=list)

    def record(self, duration_ms: float) -> None:
        self.iterations += 1
        self.durations_ms.append(duration_ms)

    def finish(self) -> "Benchmark":
        self.finished_at = time.time()
        return self

    def summary(self) -> dict:
        import statistics

        if not self.durations_ms:
            return {"name": self.name, "iterations": 0}
        ordered = sorted(self.durations_ms)
        total_s = (self.finished_at or time.time()) - self.started_at
        return {
            "name": self.name,
            "iterations": self.iterations,
            "total_s": round(total_s, 4),
            "throughput_per_s": round(self.iterations / total_s, 2) if total_s > 0 else None,
            "mean_ms": round(statistics.mean(ordered), 4),
            "min_ms": round(ordered[0], 4),
            "max_ms": round(ordered[-1], 4),
            "p50_ms": round(ordered[len(ordered) // 2], 4),
            "p95_ms": round(ordered[int(len(ordered) * 0.95)], 4) if len(ordered) > 1 else round(ordered[0], 4),
        }


class TelemetryManager:
    def __init__(self, database: Optional[Any] = None) -> None:
        self.metrics = MetricRegistry()
        self.tracer = Tracer()
        self.database = database  # silicaflux.storage.database.Database, optional persistence sink
        self._benchmarks: dict[str, Benchmark] = {}

    # -- packet fabric integration (called by silicaflux.core.engine) ---
    def record_packet(self, packet: Any, duration_ms: float) -> None:
        self.metrics.counter("packets_total", tags={"runtime": packet.runtime, "state": packet.state.value})
        self.metrics.histogram("packet_execution_ms", duration_ms, tags={"runtime": packet.runtime})
        queue_time = packet.queue_time()
        if queue_time is not None:
            self.metrics.histogram("packet_queue_ms", queue_time * 1000, tags={"runtime": packet.runtime})
        if self.database is not None:
            self._persist_metric("packet_execution_ms", duration_ms, {"runtime": packet.runtime})

    def _persist_metric(self, name: str, value: float, tags: dict) -> None:
        import asyncio

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.database.record_metric(name, value, tags))
        except RuntimeError:
            pass  # no running loop (e.g. called from sync context); skip persistence

    # -- system snapshot --------------------------------------------
    def system_snapshot(self) -> PerformanceProfile:
        if not _PSUTIL_AVAILABLE:
            return PerformanceProfile(time.time(), None, None, None, None, available=False)
        vm = psutil.virtual_memory()
        return PerformanceProfile(
            timestamp=time.time(),
            cpu_percent=psutil.cpu_percent(interval=None),
            memory_percent=vm.percent,
            memory_used_mb=round(vm.used / (1024 * 1024), 1),
            process_count=len(psutil.pids()),
            available=True,
        )

    # -- benchmarking -------------------------------------------------
    def start_benchmark(self, name: str) -> Benchmark:
        bench = Benchmark(name, started_at=time.time())
        self._benchmarks[name] = bench
        return bench

    def get_benchmark(self, name: str) -> Optional[Benchmark]:
        return self._benchmarks.get(name)

    def list_benchmarks(self) -> list[dict]:
        return [b.summary() for b in self._benchmarks.values()]

    # -- safe, advisory optimisation hints ---------------------------
    def optimisation_hints(self, cache_stats: Optional[dict] = None, scheduler_stats: Optional[dict] = None) -> list[str]:
        """Advisory-only suggestions (spec section 20: never override
        security policy, never silently change behaviour). These are
        strings for a human or the developer tools to act on, not
        instructions this method executes itself."""
        hints: list[str] = []
        if cache_stats:
            totals = cache_stats.get("totals", cache_stats)
            hit_rate = totals.get("hit_rate", 1.0)
            if hit_rate < 0.5 and totals.get("hits", 0) + totals.get("misses", 0) > 20:
                hints.append(f"cache hit rate is low ({hit_rate:.0%}); consider raising max_age_s for stable resources")
        if scheduler_stats:
            queue_length = scheduler_stats.get("queue_length", 0)
            if queue_length > 50:
                hints.append(f"scheduler queue is deep ({queue_length}); consider increasing worker pool size")
        snapshot = self.system_snapshot()
        if snapshot.available and snapshot.memory_percent and snapshot.memory_percent > 90:
            hints.append("system memory usage is above 90%; consider lowering per-worker memory limits")
        return hints

    def snapshot(self) -> dict:
        return {
            "system": self.system_snapshot().to_dict(),
            "metrics": self.metrics.snapshot(),
            "recent_traces": self.tracer.recent(20),
            "benchmarks": self.list_benchmarks(),
        }
