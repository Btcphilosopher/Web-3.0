"""Lightweight tracing: a :class:`Trace` groups the :class:`Span`s
produced while handling one logical operation (typically one
``trace_id`` shared by a chain of :class:`~silicaflux.core.packet.SFXPacket`
objects as work hops between runtimes), so the developer tools can render
a waterfall — "this page load's execution graph spent 40ms in Python,
then 12ms in Rust, then 3ms serialising back to JS" — instead of a flat
list of unrelated timings.
"""

from __future__ import annotations

import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Iterator, Optional


@dataclass
class Span:
    span_id: str
    name: str
    start: float
    end: Optional[float] = None
    tags: dict = field(default_factory=dict)
    parent_span_id: Optional[str] = None

    def finish(self) -> None:
        self.end = time.time()

    @property
    def duration_ms(self) -> Optional[float]:
        if self.end is None:
            return None
        return (self.end - self.start) * 1000

    def to_dict(self) -> dict:
        return {
            "span_id": self.span_id,
            "name": self.name,
            "start": self.start,
            "duration_ms": self.duration_ms,
            "tags": self.tags,
            "parent_span_id": self.parent_span_id,
        }


@dataclass
class Trace:
    trace_id: str
    spans: list[Span] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def start_span(self, name: str, parent_span_id: Optional[str] = None, **tags) -> Span:
        span = Span(uuid.uuid4().hex[:12], name, time.time(), tags=tags, parent_span_id=parent_span_id)
        self.spans.append(span)
        return span

    def to_dict(self) -> dict:
        return {"trace_id": self.trace_id, "created_at": self.created_at, "spans": [s.to_dict() for s in self.spans]}

    def total_duration_ms(self) -> Optional[float]:
        finished = [s for s in self.spans if s.end is not None]
        if not finished:
            return None
        return (max(s.end for s in finished) - min(s.start for s in finished)) * 1000


class Tracer:
    def __init__(self, history_limit: int = 200) -> None:
        self._traces: dict[str, Trace] = {}
        self._order: list[str] = []
        self._history_limit = history_limit

    def trace(self, trace_id: Optional[str] = None) -> Trace:
        trace_id = trace_id or uuid.uuid4().hex
        if trace_id not in self._traces:
            self._traces[trace_id] = Trace(trace_id)
            self._order.append(trace_id)
            if len(self._order) > self._history_limit:
                oldest = self._order.pop(0)
                self._traces.pop(oldest, None)
        return self._traces[trace_id]

    @contextmanager
    def span(self, trace_id: str, name: str, parent_span_id: Optional[str] = None, **tags) -> Iterator[Span]:
        span = self.trace(trace_id).start_span(name, parent_span_id, **tags)
        try:
            yield span
        finally:
            span.finish()

    def get(self, trace_id: str) -> Optional[Trace]:
        return self._traces.get(trace_id)

    def recent(self, limit: int = 50) -> list[dict]:
        return [self._traces[tid].to_dict() for tid in self._order[-limit:]]
