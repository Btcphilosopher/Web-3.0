"""The metric primitives the rest of the telemetry system builds on:
counters, gauges and histograms, each keyed by name plus an optional tag
set (so ``packet_latency_ms{runtime=python}`` and
``packet_latency_ms{runtime=r}`` are tracked separately).
"""

from __future__ import annotations

import statistics
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class MetricType(str, Enum):
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"


@dataclass
class Metric:
    name: str
    metric_type: MetricType
    tags: dict[str, str] = field(default_factory=dict)
    #: counter/gauge: single running value. histogram: bounded sample list.
    value: float = 0.0
    samples: list[float] = field(default_factory=list)
    max_samples: int = 1000
    updated_at: float = field(default_factory=time.time)

    def record(self, amount: float = 1.0) -> None:
        self.updated_at = time.time()
        if self.metric_type == MetricType.COUNTER:
            self.value += amount
        elif self.metric_type == MetricType.GAUGE:
            self.value = amount
        else:  # HISTOGRAM
            self.samples.append(amount)
            if len(self.samples) > self.max_samples:
                self.samples.pop(0)
            self.value = amount

    def summary(self) -> dict:
        base = {"name": self.name, "type": self.metric_type.value, "tags": self.tags, "updated_at": self.updated_at}
        if self.metric_type == MetricType.HISTOGRAM:
            if not self.samples:
                return {**base, "count": 0}
            ordered = sorted(self.samples)
            return {
                **base,
                "count": len(ordered),
                "min": ordered[0],
                "max": ordered[-1],
                "mean": round(statistics.mean(ordered), 4),
                "p50": _percentile(ordered, 50),
                "p95": _percentile(ordered, 95),
                "p99": _percentile(ordered, 99),
            }
        return {**base, "value": self.value}


def _percentile(ordered: list[float], pct: float) -> float:
    if not ordered:
        return 0.0
    k = (len(ordered) - 1) * (pct / 100)
    f, c = int(k), min(int(k) + 1, len(ordered) - 1)
    if f == c:
        return round(ordered[f], 4)
    return round(ordered[f] + (ordered[c] - ordered[f]) * (k - f), 4)


class MetricRegistry:
    def __init__(self) -> None:
        self._metrics: dict[tuple, Metric] = {}

    def _key(self, name: str, tags: dict[str, str]) -> tuple:
        return (name, tuple(sorted(tags.items())))

    def _get_or_create(self, name: str, metric_type: MetricType, tags: Optional[dict[str, str]] = None) -> Metric:
        tags = tags or {}
        key = self._key(name, tags)
        if key not in self._metrics:
            self._metrics[key] = Metric(name, metric_type, tags)
        return self._metrics[key]

    def counter(self, name: str, amount: float = 1.0, tags: Optional[dict[str, str]] = None) -> None:
        self._get_or_create(name, MetricType.COUNTER, tags).record(amount)

    def gauge(self, name: str, value: float, tags: Optional[dict[str, str]] = None) -> None:
        self._get_or_create(name, MetricType.GAUGE, tags).record(value)

    def histogram(self, name: str, value: float, tags: Optional[dict[str, str]] = None) -> None:
        self._get_or_create(name, MetricType.HISTOGRAM, tags).record(value)

    def snapshot(self) -> list[dict]:
        return [m.summary() for m in self._metrics.values()]

    def get(self, name: str, tags: Optional[dict[str, str]] = None) -> Optional[Metric]:
        tags = tags or {}
        for metric_type in MetricType:
            key = self._key(name, tags)
            if key in self._metrics:
                return self._metrics[key]
        return None
