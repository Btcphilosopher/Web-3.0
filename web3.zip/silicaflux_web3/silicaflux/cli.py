"""``sfx-browser`` / ``silicaflux-browser`` — the SilicaFlux Web3.0 CLI.

    sfx-browser                    launch the GUI
    sfx-browser --url https://example.com
    sfx-browser --private
    sfx-browser open <url>
    sfx-browser inspect
    sfx-browser network
    sfx-browser cache
    sfx-browser workers
    sfx-browser identity create|list
    sfx-browser permissions list|grant|revoke
    sfx-browser web3 accounts|connect
    sfx-browser compute --runtime python --operation analytics --payload '{"values":[1,2,3]}'
    sfx-browser benchmark [name]
    sfx-browser telemetry
    sfx-browser diagnostics

Every subcommand except ``start``/``open`` runs entirely headless (no
PySide6 import), driven by :mod:`silicaflux.core.bootstrap`, so
``sfx-browser inspect`` works in a container with no GUI toolkit
installed at all.

NOTE ON IMPORTS: this module deliberately does *not* import
:mod:`silicaflux.core.bootstrap` (or anything it pulls in — httpx,
cryptography, psutil, ...) at module level. When Python's
``multiprocessing`` "spawn" start method (used by
:mod:`silicaflux.runtimes.python_runtime` for process-isolated execution)
launches a worker, the child process re-imports whatever module was run
as ``__main__`` — which, for ``python -m silicaflux.cli`` or an installed
``sfx-browser`` console script, is this file. A heavy module-level import
graph here would make every single spawned worker pay that cost again,
which is slow and, in constrained/throttled environments, can stall the
worker handshake outright. Every command instead imports
``build_headless_context`` lazily, inside its own function body — see
:func:`with_context`.
"""

from __future__ import annotations

import asyncio
import json
import sys
from functools import wraps
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

import click

from silicaflux.core.logging_setup import configure_logging

if TYPE_CHECKING:
    from silicaflux.core.bootstrap import HeadlessContext


def _run(coro):
    return asyncio.run(coro)


def with_context(f):
    """Decorator: builds a :class:`HeadlessContext`, passes it as the
    first positional argument, and always shuts it down cleanly —
    including on an exception, so a failed command never leaks worker
    processes or open database handles."""

    @wraps(f)
    def wrapper(*args, **kwargs):
        profile = kwargs.pop("profile")
        profile_dir = kwargs.pop("profile_dir")
        approve_all = kwargs.pop("approve_all", True)

        async def runner():
            from silicaflux.core.bootstrap import build_headless_context  # see module docstring: kept lazy on purpose

            ctx = await build_headless_context(profile=profile, profile_dir=profile_dir, approve_all=approve_all)
            try:
                await f(ctx, *args, **kwargs)
            finally:
                await ctx.shutdown()

        _run(runner())

    return wrapper


def _print_json(data: Any) -> None:
    click.echo(json.dumps(data, indent=2, default=str))


profile_option = click.option("--profile", default="default", show_default=True, help="Browser profile name")
profile_dir_option = click.option("--profile-dir", default=None, help="Override the profile storage directory")


@click.group(invoke_without_command=True)
@click.option("--url", default=None, help="URL to open in the initial tab")
@click.option("--private", is_flag=True, help="Open in a private profile")
@click.option("--new-window", is_flag=True, help="(reserved) force a new window")
@profile_option
@profile_dir_option
@click.option("--dev", is_flag=True, help="Start with developer tools open")
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging")
@click.pass_context
def cli(ctx: click.Context, url, private, new_window, profile, profile_dir, dev, verbose) -> None:
    """SilicaFlux Web3.0 — a Python-first Web3 browser platform."""
    import logging

    configure_logging(level=logging.DEBUG if verbose else logging.INFO)
    ctx.obj = {"url": url, "private": private, "profile": profile, "profile_dir": profile_dir, "dev": dev}
    if ctx.invoked_subcommand is None:
        _launch_gui(url, private, profile, profile_dir, dev)


def _launch_gui(url, private, profile, profile_dir, dev) -> None:
    try:
        from silicaflux.browser.launcher import main as gui_main
    except ImportError as exc:
        click.echo(
            "The GUI requires PySide6 with the WebEngine addon: pip install PySide6\n"
            f"(import failed: {exc})",
            err=True,
        )
        raise SystemExit(1)
    argv = []
    if url:
        argv += ["--url", url]
    if private:
        argv.append("--private")
    if profile:
        argv += ["--profile", profile]
    if profile_dir:
        argv += ["--profile-dir", profile_dir]
    if dev:
        argv.append("--dev")
    raise SystemExit(gui_main(argv))


@cli.command("open")
@click.argument("url")
@click.pass_context
def open_cmd(ctx: click.Context, url: str) -> None:
    """Open URL in a (new) browser window."""
    obj = ctx.obj
    _launch_gui(url, obj["private"], obj["profile"], obj["profile_dir"], obj["dev"])


@cli.command()
@profile_option
@profile_dir_option
@with_context
async def inspect(ctx: HeadlessContext) -> None:
    """Print a full engine status snapshot (runtimes, workers, queue)."""
    _print_json(ctx.dashboard.snapshot())


@cli.command()
@profile_option
@profile_dir_option
@with_context
async def network(ctx: HeadlessContext) -> None:
    """Show network performance/cache summary."""
    _print_json(
        {
            "resource_cache": ctx.cache_manager.resources.stats.to_dict(),
            "dns_cache": ctx.http_client.dns_cache.snapshot(),
            "performance": ctx.http_client.performance.summary(),
        }
    )


@cli.command()
@profile_option
@profile_dir_option
@with_context
async def cache(ctx: HeadlessContext) -> None:
    """Show cache statistics across every tier."""
    _print_json(ctx.cache_manager.stats())


@cli.command()
@profile_option
@profile_dir_option
@with_context
async def workers(ctx: HeadlessContext) -> None:
    """Show runtime worker pool status."""
    _print_json(
        {
            "summary": ctx.engine.worker_registry.summary(),
            "workers": [w.to_dict() for w in ctx.engine.worker_registry.all()],
            "runtimes": [vars(a) for a in ctx.runtime_manager.availability()],
        }
    )


@cli.group()
def identity() -> None:
    """Manage Web3 identities (local keypairs)."""


@identity.command("create")
@click.option("--passphrase", prompt=True, hide_input=True, confirmation_prompt=True)
@profile_option
@profile_dir_option
@with_context
async def identity_create(ctx: HeadlessContext, passphrase: str) -> None:
    """Generate a new Ed25519 identity, encrypted at rest."""
    identity = ctx.identity_manager.create_identity(passphrase)
    account = ctx.wallet.create_account(identity)
    _print_json({"identity": identity.to_dict(), "account": account.to_dict()})


@identity.command("list")
@profile_option
@profile_dir_option
@with_context
async def identity_list(ctx: HeadlessContext) -> None:
    """List known identities in this profile."""
    _print_json(ctx.identity_manager.list_identities())


@cli.group()
def permissions() -> None:
    """Inspect and manage per-origin capability grants."""


@permissions.command("list")
@click.argument("origin")
@profile_option
@profile_dir_option
@with_context
async def permissions_list(ctx: HeadlessContext, origin: str) -> None:
    _print_json([t.to_dict() for t in ctx.policy.grants_for(origin)])


@permissions.command("grant")
@click.argument("origin")
@click.argument("capability")
@profile_option
@profile_dir_option
@with_context
async def permissions_grant(ctx: HeadlessContext, origin: str, capability: str) -> None:
    token = ctx.policy.authorize(origin, capability)
    _print_json({"granted": token is not None, "token": token.to_dict() if token else None})


@permissions.command("revoke")
@click.argument("origin")
@click.argument("capability")
@profile_option
@profile_dir_option
@with_context
async def permissions_revoke(ctx: HeadlessContext, origin: str, capability: str) -> None:
    ok = ctx.policy.revoke(origin, capability)
    _print_json({"revoked": ok})


@cli.group()
def web3() -> None:
    """Web3 wallet operations."""


@web3.command("accounts")
@profile_option
@profile_dir_option
@with_context
async def web3_accounts(ctx: HeadlessContext) -> None:
    _print_json([a.to_dict() for a in ctx.wallet.list_accounts()])


@web3.command("connect")
@click.argument("origin")
@click.argument("address")
@profile_option
@profile_dir_option
@with_context
async def web3_connect(ctx: HeadlessContext, origin: str, address: str) -> None:
    accounts = await ctx.dapp_permissions.request_accounts(origin, address)
    _print_json({"origin": origin, "connected_accounts": accounts})


@cli.command()
@click.option("--runtime", required=True, type=click.Choice(["python", "r", "rust", "wasm", "javascript"]))
@click.option("--operation", required=True)
@click.option("--payload", default="{}", help="JSON payload")
@click.option("--origin", default="sfx://cli", help="Origin to attribute the packet to (sfx:// origins are trusted)")
@profile_option
@profile_dir_option
@with_context
async def compute(ctx: HeadlessContext, runtime: str, operation: str, payload: str, origin: str) -> None:
    """Submit one ad-hoc packet directly to the engine and print the result."""
    from silicaflux.core.packet import SFXPacket, SecurityContext

    try:
        payload_obj = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise click.ClickException(f"--payload is not valid JSON: {exc}")

    packet = SFXPacket(
        source="cli",
        destination="engine",
        runtime=runtime,
        operation=operation,
        payload=payload_obj,
        security_context=SecurityContext(origin=origin),
    )
    result = await ctx.engine.request(packet)
    _print_json(result.to_dict())


@cli.command()
@click.argument("name", default="packet_roundtrip")
@click.option("--iterations", default=100, show_default=True)
@profile_option
@profile_dir_option
@with_context
async def benchmark(ctx: HeadlessContext, name: str, iterations: int) -> None:
    """Run a named benchmark from the built-in suite."""
    from silicaflux.benchmarks.bench_suite import BENCHMARKS

    if name not in BENCHMARKS:
        raise click.ClickException(f"unknown benchmark '{name}'. Available: {', '.join(BENCHMARKS)}")
    result = await BENCHMARKS[name](ctx, iterations)
    _print_json(result)


@cli.command()
@profile_option
@profile_dir_option
@with_context
async def telemetry(ctx: HeadlessContext) -> None:
    """Print the telemetry system's current snapshot."""
    _print_json(ctx.telemetry.snapshot())


@cli.command()
@profile_option
@profile_dir_option
@with_context
async def diagnostics(ctx: HeadlessContext) -> None:
    """Full system diagnostic report: runtimes, storage, security, disk."""
    import platform
    import shutil as _shutil

    disk = _shutil.disk_usage(ctx.profile_dir)
    report = {
        "python_version": sys.version,
        "platform": platform.platform(),
        "profile_dir": str(ctx.profile_dir),
        "disk_free_mb": round(disk.free / (1024 * 1024), 1),
        "runtimes": [vars(a) for a in ctx.runtime_manager.availability()],
        "security_policy": ctx.settings.security.model_dump(),
        "cache": ctx.cache_manager.stats()["totals"],
        "system": ctx.telemetry.system_snapshot().to_dict(),
    }
    _print_json(report)


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
