"""A sandboxed filesystem abstraction.

Nothing in the runtime layer or a Web3 application ever touches
:mod:`pathlib`/:mod:`open` directly against the host filesystem — every
read/write goes through a :class:`SandboxedFilesystem` rooted at a
specific directory (a profile's downloads folder, its cache directory, an
SFX application's private storage area). Path traversal outside that root
is rejected unconditionally, independent of whatever capability check
already happened in :mod:`silicaflux.security`.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterator

from silicaflux.core.logging_setup import get_logger

logger = get_logger("storage.filesystem")


class FilesystemAccessDenied(PermissionError):
    pass


class SandboxedFilesystem:
    def __init__(self, root: Path) -> None:
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def resolve(self, relative_path: str) -> Path:
        candidate = (self.root / relative_path).resolve()
        try:
            candidate.relative_to(self.root)
        except ValueError:
            raise FilesystemAccessDenied(f"'{relative_path}' escapes sandbox root {self.root}")
        return candidate

    def read_bytes(self, relative_path: str) -> bytes:
        return self.resolve(relative_path).read_bytes()

    def write_bytes(self, relative_path: str, data: bytes) -> Path:
        path = self.resolve(relative_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def read_text(self, relative_path: str, encoding: str = "utf-8") -> str:
        return self.resolve(relative_path).read_text(encoding=encoding)

    def write_text(self, relative_path: str, text: str, encoding: str = "utf-8") -> Path:
        path = self.resolve(relative_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding=encoding)
        return path

    def exists(self, relative_path: str) -> bool:
        try:
            return self.resolve(relative_path).exists()
        except FilesystemAccessDenied:
            return False

    def delete(self, relative_path: str) -> None:
        path = self.resolve(relative_path)
        if path.is_dir():
            for child in path.iterdir():
                pass
            path.rmdir()
        elif path.exists():
            path.unlink()

    def list_dir(self, relative_path: str = ".") -> Iterator[str]:
        base = self.resolve(relative_path)
        if not base.exists():
            return iter(())
        return (str(p.relative_to(self.root)) for p in base.iterdir())

    def size_bytes(self, relative_path: str) -> int:
        return self.resolve(relative_path).stat().st_size
