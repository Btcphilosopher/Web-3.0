"""Typed history API over :class:`silicaflux.storage.database.Database`."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from silicaflux.storage.database import Database


@dataclass
class HistoryEntry:
    id: int
    url: str
    title: str
    visited_at: float
    visit_count: int


class HistoryStore:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def visit(self, url: str, title: str = "") -> None:
        await self.db.add_history(url, title)

    async def search(self, query: str = "", limit: int = 100) -> list[HistoryEntry]:
        rows = await self.db.search_history(query, limit)
        return [HistoryEntry(**r) for r in rows]

    async def delete(self, entry_id: int) -> None:
        await self.db.delete_history_entry(entry_id)

    async def clear(self) -> None:
        await self.db.clear_history()
