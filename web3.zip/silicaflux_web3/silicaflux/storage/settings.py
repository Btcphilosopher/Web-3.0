"""Mirrors :class:`silicaflux.core.config.Settings` into SQLite so the
developer tools and CLI can query individual keys without parsing the
whole ``settings.json`` file."""

from __future__ import annotations

from typing import Any

from silicaflux.storage.database import Database


class SettingsStore:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def sync_from(self, settings_dict: dict[str, Any]) -> None:
        for key, value in _flatten(settings_dict).items():
            await self.db.set_setting(key, value)

    async def get(self, key: str, default: Any = None) -> Any:
        return await self.db.get_setting(key, default)


def _flatten(d: dict, prefix: str = "") -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in d.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            out.update(_flatten(value, full_key))
        else:
            out[full_key] = value
    return out
