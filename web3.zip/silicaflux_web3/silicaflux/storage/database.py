"""SQLite-backed storage for everything the spec calls out: history,
bookmarks, settings, sessions, downloads, permissions, runtime telemetry
and SFX application metadata (spec section 22).

:class:`Database` is a thin, asyncio-friendly wrapper: the underlying
``sqlite3`` connection is synchronous (and only usable from one thread),
so every public method runs the actual query via ``asyncio.to_thread`` —
callers get a coroutine-based API without the engine needing a separate
database process or an extra dependency like ``aiosqlite``.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Iterable, Optional

from silicaflux.core.logging_setup import get_logger

logger = get_logger("storage.database")

SCHEMA = """
CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT NOT NULL,
    title TEXT DEFAULT '',
    visited_at REAL NOT NULL,
    visit_count INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_history_url ON history(url);
CREATE INDEX IF NOT EXISTS idx_history_visited_at ON history(visited_at);

CREATE TABLE IF NOT EXISTS bookmarks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT NOT NULL,
    title TEXT DEFAULT '',
    folder TEXT DEFAULT 'Bookmarks Bar',
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bookmarks_folder ON bookmarks(folder);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    profile TEXT NOT NULL,
    tab_index INTEGER NOT NULL,
    url TEXT NOT NULL,
    title TEXT DEFAULT '',
    pinned INTEGER DEFAULT 0,
    saved_at REAL NOT NULL,
    PRIMARY KEY (profile, tab_index)
);

CREATE TABLE IF NOT EXISTS downloads (
    id TEXT PRIMARY KEY,
    url TEXT NOT NULL,
    filename TEXT NOT NULL,
    destination TEXT NOT NULL,
    total_bytes INTEGER,
    received_bytes INTEGER DEFAULT 0,
    status TEXT NOT NULL,
    sha256 TEXT,
    started_at REAL NOT NULL,
    finished_at REAL
);

CREATE TABLE IF NOT EXISTS permissions (
    origin TEXT NOT NULL,
    capability TEXT NOT NULL,
    granted INTEGER NOT NULL,
    updated_at REAL NOT NULL,
    PRIMARY KEY (origin, capability)
);

CREATE TABLE IF NOT EXISTS telemetry_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    metric TEXT NOT NULL,
    value REAL NOT NULL,
    timestamp REAL NOT NULL,
    tags_json TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_telemetry_metric ON telemetry_events(metric, timestamp);

CREATE TABLE IF NOT EXISTS sfx_apps (
    app_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    manifest_json TEXT NOT NULL,
    installed_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp REAL NOT NULL,
    origin TEXT NOT NULL,
    action TEXT NOT NULL,
    outcome TEXT NOT NULL,
    detail_json TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_audit_origin ON audit_log(origin, timestamp);
"""


class Database:
    """One SQLite connection per profile. Not thread-safe on its own —
    all access is funneled through :meth:`_run`, which serialises calls
    onto a single worker thread so concurrent ``await db.xxx()`` calls
    from asyncio never race on the same ``sqlite3.Connection``.
    """

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._conn.commit()
        logger.info(f"database opened at {self.path}")

    async def _run(self, fn, *args) -> Any:
        return await asyncio.to_thread(self._run_sync, fn, *args)

    def _run_sync(self, fn, *args) -> Any:
        with self._lock:
            return fn(self._conn, *args)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # -- history -------------------------------------------------------
    async def add_history(self, url: str, title: str = "") -> None:
        def op(conn: sqlite3.Connection) -> None:
            row = conn.execute("SELECT id, visit_count FROM history WHERE url = ?", (url,)).fetchone()
            now = time.time()
            if row:
                conn.execute(
                    "UPDATE history SET title=?, visited_at=?, visit_count=? WHERE id=?",
                    (title or "", now, row["visit_count"] + 1, row["id"]),
                )
            else:
                conn.execute(
                    "INSERT INTO history (url, title, visited_at, visit_count) VALUES (?,?,?,1)",
                    (url, title or "", now),
                )
            conn.commit()

        await self._run(op)

    async def search_history(self, query: str = "", limit: int = 100) -> list[dict]:
        def op(conn: sqlite3.Connection) -> list[dict]:
            if query:
                rows = conn.execute(
                    "SELECT * FROM history WHERE url LIKE ? OR title LIKE ? ORDER BY visited_at DESC LIMIT ?",
                    (f"%{query}%", f"%{query}%", limit),
                ).fetchall()
            else:
                rows = conn.execute("SELECT * FROM history ORDER BY visited_at DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

        return await self._run(op)

    async def delete_history_entry(self, entry_id: int) -> None:
        await self._run(lambda conn: (conn.execute("DELETE FROM history WHERE id=?", (entry_id,)), conn.commit()))

    async def clear_history(self) -> None:
        await self._run(lambda conn: (conn.execute("DELETE FROM history"), conn.commit()))

    # -- bookmarks ------------------------------------------------------
    async def add_bookmark(self, url: str, title: str = "", folder: str = "Bookmarks Bar") -> int:
        def op(conn: sqlite3.Connection) -> int:
            cur = conn.execute(
                "INSERT INTO bookmarks (url, title, folder, created_at) VALUES (?,?,?,?)",
                (url, title, folder, time.time()),
            )
            conn.commit()
            return cur.lastrowid

        return await self._run(op)

    async def remove_bookmark(self, bookmark_id: int) -> None:
        await self._run(lambda conn: (conn.execute("DELETE FROM bookmarks WHERE id=?", (bookmark_id,)), conn.commit()))

    async def update_bookmark(self, bookmark_id: int, **fields: Any) -> None:
        if not fields:
            return
        cols = ", ".join(f"{k}=?" for k in fields)
        values = list(fields.values()) + [bookmark_id]

        def op(conn: sqlite3.Connection) -> None:
            conn.execute(f"UPDATE bookmarks SET {cols} WHERE id=?", values)
            conn.commit()

        await self._run(op)

    async def list_bookmarks(self, folder: Optional[str] = None, query: str = "") -> list[dict]:
        def op(conn: sqlite3.Connection) -> list[dict]:
            sql = "SELECT * FROM bookmarks WHERE 1=1"
            params: list[Any] = []
            if folder:
                sql += " AND folder=?"
                params.append(folder)
            if query:
                sql += " AND (url LIKE ? OR title LIKE ?)"
                params.extend([f"%{query}%", f"%{query}%"])
            sql += " ORDER BY created_at DESC"
            return [dict(r) for r in conn.execute(sql, params).fetchall()]

        return await self._run(op)

    # -- settings mirror --------------------------------------------
    async def set_setting(self, key: str, value: Any) -> None:
        def op(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO settings(key, value_json, updated_at) VALUES (?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at",
                (key, json.dumps(value), time.time()),
            )
            conn.commit()

        await self._run(op)

    async def get_setting(self, key: str, default: Any = None) -> Any:
        def op(conn: sqlite3.Connection) -> Any:
            row = conn.execute("SELECT value_json FROM settings WHERE key=?", (key,)).fetchone()
            return json.loads(row["value_json"]) if row else default

        return await self._run(op)

    # -- sessions -----------------------------------------------------
    def save_session(self, profile: str, tabs: Iterable[dict]) -> None:
        """Synchronous by design: called from
        :meth:`silicaflux.core.session.BrowserSessionManager.save`, which
        is not necessarily running inside the asyncio loop (e.g. on
        interpreter shutdown)."""

        def op(conn: sqlite3.Connection, tabs_list: list[dict]) -> None:
            conn.execute("DELETE FROM sessions WHERE profile=?", (profile,))
            now = time.time()
            for idx, tab in enumerate(tabs_list):
                conn.execute(
                    "INSERT INTO sessions (profile, tab_index, url, title, pinned, saved_at) VALUES (?,?,?,?,?,?)",
                    (profile, idx, tab.get("url", ""), tab.get("title", ""), int(tab.get("pinned", False)), now),
                )
            conn.commit()

        self._run_sync(op, list(tabs))

    def load_session(self, profile: str) -> list[dict]:
        def op(conn: sqlite3.Connection) -> list[dict]:
            rows = conn.execute(
                "SELECT * FROM sessions WHERE profile=? ORDER BY tab_index ASC", (profile,)
            ).fetchall()
            return [dict(r) for r in rows]

        return self._run_sync(op)

    # -- downloads ------------------------------------------------------
    async def upsert_download(self, record: dict) -> None:
        def op(conn: sqlite3.Connection) -> None:
            conn.execute(
                """INSERT INTO downloads
                   (id, url, filename, destination, total_bytes, received_bytes, status, sha256, started_at, finished_at)
                   VALUES (:id, :url, :filename, :destination, :total_bytes, :received_bytes, :status, :sha256, :started_at, :finished_at)
                   ON CONFLICT(id) DO UPDATE SET
                     received_bytes=excluded.received_bytes,
                     status=excluded.status,
                     sha256=excluded.sha256,
                     finished_at=excluded.finished_at""",
                record,
            )
            conn.commit()

        await self._run(op)

    async def list_downloads(self, limit: int = 200) -> list[dict]:
        def op(conn: sqlite3.Connection) -> list[dict]:
            rows = conn.execute("SELECT * FROM downloads ORDER BY started_at DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

        return await self._run(op)

    # -- permissions ------------------------------------------------
    def save_permission(self, origin: str, capability: str, granted: bool) -> None:
        def op(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO permissions(origin, capability, granted, updated_at) VALUES (?,?,?,?) "
                "ON CONFLICT(origin, capability) DO UPDATE SET granted=excluded.granted, updated_at=excluded.updated_at",
                (origin, capability, int(granted), time.time()),
            )
            conn.commit()

        self._run_sync(op)

    def load_permissions(self) -> list[tuple[str, str, bool]]:
        def op(conn: sqlite3.Connection) -> list[tuple[str, str, bool]]:
            rows = conn.execute("SELECT origin, capability, granted FROM permissions").fetchall()
            return [(r["origin"], r["capability"], bool(r["granted"])) for r in rows]

        return self._run_sync(op)

    # -- telemetry ------------------------------------------------------
    async def record_metric(self, metric: str, value: float, tags: Optional[dict] = None) -> None:
        def op(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO telemetry_events (metric, value, timestamp, tags_json) VALUES (?,?,?,?)",
                (metric, value, time.time(), json.dumps(tags or {})),
            )
            conn.commit()

        await self._run(op)

    async def query_metrics(self, metric: str, since: Optional[float] = None, limit: int = 1000) -> list[dict]:
        def op(conn: sqlite3.Connection) -> list[dict]:
            sql = "SELECT * FROM telemetry_events WHERE metric=?"
            params: list[Any] = [metric]
            if since is not None:
                sql += " AND timestamp >= ?"
                params.append(since)
            sql += " ORDER BY timestamp DESC LIMIT ?"
            params.append(limit)
            return [dict(r) for r in conn.execute(sql, params).fetchall()]

        return await self._run(op)

    # -- sfx applications -----------------------------------------------
    async def register_app(self, app_id: str, name: str, manifest: dict) -> None:
        def op(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO sfx_apps(app_id, name, manifest_json, installed_at) VALUES (?,?,?,?) "
                "ON CONFLICT(app_id) DO UPDATE SET name=excluded.name, manifest_json=excluded.manifest_json",
                (app_id, name, json.dumps(manifest), time.time()),
            )
            conn.commit()

        await self._run(op)

    async def list_apps(self) -> list[dict]:
        def op(conn: sqlite3.Connection) -> list[dict]:
            rows = conn.execute("SELECT * FROM sfx_apps ORDER BY installed_at DESC").fetchall()
            out = []
            for r in rows:
                d = dict(r)
                d["manifest"] = json.loads(d.pop("manifest_json"))
                out.append(d)
            return out

        return await self._run(op)

    # -- audit log (sink for silicaflux.security.audit.AuditLogger) -----
    def record_audit_entry(self, entry: Any) -> None:
        def op(conn: sqlite3.Connection) -> None:
            conn.execute(
                "INSERT INTO audit_log (timestamp, origin, action, outcome, detail_json) VALUES (?,?,?,?,?)",
                (entry.timestamp, entry.origin, entry.action, entry.outcome, json.dumps(entry.detail, default=str)),
            )
            conn.commit()

        self._run_sync(op)

    async def audit_entries(self, origin: Optional[str] = None, limit: int = 200) -> list[dict]:
        def op(conn: sqlite3.Connection) -> list[dict]:
            if origin:
                rows = conn.execute(
                    "SELECT * FROM audit_log WHERE origin=? ORDER BY timestamp DESC LIMIT ?", (origin, limit)
                ).fetchall()
            else:
                rows = conn.execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

        return await self._run(op)
