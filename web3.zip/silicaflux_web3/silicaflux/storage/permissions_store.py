"""Durable capability grant/denial log backing
:class:`silicaflux.security.permissions.PermissionManager`."""

from __future__ import annotations

from silicaflux.storage.database import Database


class PermissionsStore:
    """Duck-type target for ``PermissionManager(persistence=...)``: exposes
    the synchronous ``save_permission``/``load_permissions`` pair the
    security layer expects (kept synchronous since permission decisions
    happen on the hot path of a capability request, not inside an awaited
    context in every caller)."""

    def __init__(self, db: Database) -> None:
        self.db = db

    def save_permission(self, origin: str, capability: str, granted: bool) -> None:
        self.db.save_permission(origin, capability, granted)

    def load_permissions(self) -> list[tuple[str, str, bool]]:
        return self.db.load_permissions()
