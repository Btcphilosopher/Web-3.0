"""Typed bookmarks API over :class:`silicaflux.storage.database.Database`."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from silicaflux.storage.database import Database


@dataclass
class Bookmark:
    id: int
    url: str
    title: str
    folder: str
    created_at: float


class BookmarksStore:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def add(self, url: str, title: str = "", folder: str = "Bookmarks Bar") -> int:
        return await self.db.add_bookmark(url, title, folder)

    async def remove(self, bookmark_id: int) -> None:
        await self.db.remove_bookmark(bookmark_id)

    async def edit(self, bookmark_id: int, **fields) -> None:
        await self.db.update_bookmark(bookmark_id, **fields)

    async def list(self, folder: Optional[str] = None, query: str = "") -> list[Bookmark]:
        rows = await self.db.list_bookmarks(folder, query)
        return [Bookmark(**r) for r in rows]

    async def folders(self) -> list[str]:
        rows = await self.db.list_bookmarks()
        return sorted({r["folder"] for r in [b.__dict__ for b in await self.list()]})

    async def export_json(self) -> list[dict]:
        return [b.__dict__ for b in await self.list()]

    async def import_json(self, entries: list[dict]) -> int:
        count = 0
        for entry in entries:
            await self.add(entry["url"], entry.get("title", ""), entry.get("folder", "Bookmarks Bar"))
            count += 1
        return count
