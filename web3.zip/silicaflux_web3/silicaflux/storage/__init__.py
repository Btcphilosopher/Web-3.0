"""SQLite-backed persistence: history, bookmarks, settings, sessions,
downloads, permissions, telemetry and SFX application metadata, plus a
sandboxed filesystem abstraction."""

from __future__ import annotations

from silicaflux.storage.bookmarks import Bookmark, BookmarksStore
from silicaflux.storage.database import Database
from silicaflux.storage.downloads_store import DownloadRecord, DownloadsStore
from silicaflux.storage.filesystem import FilesystemAccessDenied, SandboxedFilesystem
from silicaflux.storage.history import HistoryEntry, HistoryStore
from silicaflux.storage.permissions_store import PermissionsStore
from silicaflux.storage.settings import SettingsStore

__all__ = [
    "Database",
    "HistoryStore",
    "HistoryEntry",
    "BookmarksStore",
    "Bookmark",
    "DownloadsStore",
    "DownloadRecord",
    "PermissionsStore",
    "SettingsStore",
    "SandboxedFilesystem",
    "FilesystemAccessDenied",
]
