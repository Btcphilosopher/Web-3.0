"""Persistence for the download manager
(:mod:`silicaflux.networking.downloads`); the manager owns live progress
state in memory, this store is the durable record shown in
``sfx://downloads`` and survived across restarts."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

from silicaflux.storage.database import Database


@dataclass
class DownloadRecord:
    id: str
    url: str
    filename: str
    destination: str
    status: str  # queued | downloading | paused | completed | cancelled | failed
    total_bytes: Optional[int] = None
    received_bytes: int = 0
    sha256: Optional[str] = None
    started_at: float = field(default_factory=time.time)
    finished_at: Optional[float] = None

    @classmethod
    def new(cls, url: str, filename: str, destination: str) -> "DownloadRecord":
        return cls(id=uuid.uuid4().hex, url=url, filename=filename, destination=destination, status="queued")

    def as_row(self) -> dict:
        return {
            "id": self.id,
            "url": self.url,
            "filename": self.filename,
            "destination": self.destination,
            "total_bytes": self.total_bytes,
            "received_bytes": self.received_bytes,
            "status": self.status,
            "sha256": self.sha256,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
        }


class DownloadsStore:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def save(self, record: DownloadRecord) -> None:
        await self.db.upsert_download(record.as_row())

    async def history(self, limit: int = 200) -> list[dict]:
        return await self.db.list_downloads(limit)
