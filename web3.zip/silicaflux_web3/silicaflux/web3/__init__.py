"""Web3 abstraction layer: decentralised identity/cryptography, a
chain-agnostic wallet with explicit-approval signing, DApp permissions,
the JS-facing DApp bridge, and an opt-in peer-to-peer resource layer."""

from __future__ import annotations

from silicaflux.web3.dapp_bridge import DAppBridge, DAppBridgeError
from silicaflux.web3.identity import Identity, IdentityManager, KeyManager, SignatureManager, ContentVerifier
from silicaflux.web3.p2p import DistributedResource, Peer, PeerNetwork, Provider
from silicaflux.web3.permissions import DAppPermissionManager
from silicaflux.web3.wallet import Account, TransactionRequest, Wallet, WalletApprovalDenied

__all__ = [
    "DAppBridge",
    "DAppBridgeError",
    "Identity",
    "IdentityManager",
    "KeyManager",
    "SignatureManager",
    "ContentVerifier",
    "DistributedResource",
    "Peer",
    "PeerNetwork",
    "Provider",
    "DAppPermissionManager",
    "Account",
    "TransactionRequest",
    "Wallet",
    "WalletApprovalDenied",
]
