"""Decentralised identity and cryptography (spec Phase 6).

Built entirely on :mod:`cryptography` (a well-audited, established
library) — no algorithm here is home-grown. Ed25519 is used for identity
keypairs (fast, small, misuse-resistant signatures with no parameter
choices to get wrong). Private key material:

* is generated in-process and never transmitted anywhere;
* is encrypted at rest with a passphrase-derived key (PBKDF2-HMAC-SHA256
  -> Fernet/AES) before it ever touches disk;
* is never written to a log line — :class:`KeyManager` takes care to log
  only public fingerprints, never key bytes, even at DEBUG level.

This module has no blockchain-specific code in it on purpose: a keypair
and a signature are a general cryptographic identity primitive, and
:mod:`silicaflux.web3.wallet` layers network-specific address formats on
top without this module needing to know what a "chain ID" is.
"""

from __future__ import annotations

import base64
import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from cryptography.exceptions import InvalidSignature
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from silicaflux.core.logging_setup import get_logger

logger = get_logger("web3.identity")

_PBKDF2_ITERATIONS = 390_000


class IdentityError(RuntimeError):
    pass


def _derive_fernet_key(passphrase: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=_PBKDF2_ITERATIONS)
    return base64.urlsafe_b64encode(kdf.derive(passphrase.encode("utf-8")))


@dataclass
class Identity:
    """A public identity: a fingerprint and public key, never the private
    key. Safe to log, display, and hand to a webpage that only needs to
    know "who" — never "how to sign as who"."""

    identity_id: str
    public_key_b64: str
    created_at: float

    def to_dict(self) -> dict:
        return {"identity_id": self.identity_id, "public_key": self.public_key_b64, "created_at": self.created_at}


def _fingerprint(public_bytes: bytes) -> str:
    import hashlib

    return hashlib.sha256(public_bytes).hexdigest()[:32]


class KeyManager:
    """Generates, encrypts-at-rest, loads and rotates Ed25519 keypairs.

    Each identity's private key is stored as its own encrypted file:
    ``<storage_dir>/<identity_id>.key`` — PBKDF2-derived Fernet encryption
    keyed by a passphrase the caller supplies (typically derived from the
    OS keychain or a profile-unlock passphrase; SilicaFlux itself does not
    prescribe where that passphrase comes from).
    """

    def __init__(self, storage_dir: Path) -> None:
        self.storage_dir = storage_dir
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self._loaded: dict[str, Ed25519PrivateKey] = {}

    def generate(self, passphrase: str) -> Identity:
        private_key = Ed25519PrivateKey.generate()
        public_bytes = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
        )
        identity_id = _fingerprint(public_bytes)
        self._persist(identity_id, private_key, passphrase)
        self._loaded[identity_id] = private_key
        logger.info(f"generated identity {identity_id}")  # fingerprint only, never key material
        return Identity(identity_id, base64.b64encode(public_bytes).decode(), time.time())

    def _key_path(self, identity_id: str) -> Path:
        return self.storage_dir / f"{identity_id}.key"

    def _persist(self, identity_id: str, private_key: Ed25519PrivateKey, passphrase: str) -> None:
        salt = os.urandom(16)
        fernet = Fernet(_derive_fernet_key(passphrase, salt))
        raw = private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        token = fernet.encrypt(raw)
        envelope = {"salt": base64.b64encode(salt).decode(), "token": token.decode()}
        self._key_path(identity_id).write_text(json.dumps(envelope))
        # raw key bytes never leave this function's scope; the envelope
        # written to disk is the only durable copy, and it's ciphertext.

    def unlock(self, identity_id: str, passphrase: str) -> Identity:
        path = self._key_path(identity_id)
        if not path.exists():
            raise IdentityError(f"unknown identity '{identity_id}'")
        envelope = json.loads(path.read_text())
        salt = base64.b64decode(envelope["salt"])
        fernet = Fernet(_derive_fernet_key(passphrase, salt))
        try:
            raw = fernet.decrypt(envelope["token"].encode())
        except InvalidToken as exc:
            raise IdentityError("incorrect passphrase") from exc
        private_key = Ed25519PrivateKey.from_private_bytes(raw)
        self._loaded[identity_id] = private_key
        public_bytes = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
        )
        return Identity(identity_id, base64.b64encode(public_bytes).decode(), path.stat().st_mtime)

    def lock(self, identity_id: str) -> None:
        self._loaded.pop(identity_id, None)

    def rotate(self, old_identity_id: str, passphrase: str) -> Identity:
        """Generate a fresh identity and mark the old one retired. Callers
        that hold signed resources under the old identity should re-sign
        important ones — key rotation does not retroactively re-sign
        anything, by design (that would require exposing history this
        module doesn't track)."""
        if old_identity_id in self._loaded:
            self.lock(old_identity_id)
        retired_marker = self._key_path(old_identity_id).with_suffix(".retired")
        retired_marker.write_text(json.dumps({"retired_at": time.time()}))
        logger.info(f"identity {old_identity_id} retired; generating replacement")
        return self.generate(passphrase)

    def _require_loaded(self, identity_id: str) -> Ed25519PrivateKey:
        if identity_id not in self._loaded:
            raise IdentityError(f"identity '{identity_id}' is locked; call unlock() first")
        return self._loaded[identity_id]

    def public_key_of(self, identity_id: str) -> bytes:
        key = self._require_loaded(identity_id)
        return key.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)


class SignatureManager:
    """Produces and verifies Ed25519 signatures. Signing always requires
    the identity to be unlocked in :class:`KeyManager` (i.e. the
    passphrase was already supplied) — this module never asks for or
    handles a passphrase itself, keeping "prove who I am" and "authorize
    this specific action" as separate steps."""

    def __init__(self, key_manager: KeyManager) -> None:
        self.key_manager = key_manager

    def sign(self, identity_id: str, message: bytes) -> str:
        private_key = self.key_manager._require_loaded(identity_id)
        signature = private_key.sign(message)
        return base64.b64encode(signature).decode()

    def verify(self, public_key_b64: str, message: bytes, signature_b64: str) -> bool:
        try:
            public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key_b64))
            public_key.verify(base64.b64decode(signature_b64), message)
            return True
        except (InvalidSignature, ValueError):
            return False


class ContentVerifier:
    """Ties :class:`SignatureManager` to content hashing so a resource can
    be distributed with a detached signature and verified by any holder
    of the signer's public key — used by :mod:`silicaflux.web3.p2p` for
    trusting content fetched from an untrusted peer."""

    def __init__(self, signatures: SignatureManager) -> None:
        self.signatures = signatures

    def sign_content(self, identity_id: str, content: bytes) -> dict:
        from silicaflux.cache.content_cache import content_hash

        digest = content_hash(content)
        signature = self.signatures.sign(identity_id, digest.encode())
        return {"content_hash": digest, "signature": signature}

    def verify_content(self, content: bytes, public_key_b64: str, signature_b64: str) -> bool:
        from silicaflux.cache.content_cache import content_hash

        digest = content_hash(content)
        return self.signatures.verify(public_key_b64, digest.encode(), signature_b64)


class IdentityManager:
    """Top-level façade combining key management, signing and
    verification, plus the registry of identities the current profile
    knows about."""

    def __init__(self, storage_dir: Path) -> None:
        self.keys = KeyManager(storage_dir)
        self.signatures = SignatureManager(self.keys)
        self.verifier = ContentVerifier(self.signatures)
        self._identities: dict[str, Identity] = {}

    def create_identity(self, passphrase: str) -> Identity:
        identity = self.keys.generate(passphrase)
        self._identities[identity.identity_id] = identity
        return identity

    def unlock(self, identity_id: str, passphrase: str) -> Identity:
        identity = self.keys.unlock(identity_id, passphrase)
        self._identities[identity_id] = identity
        return identity

    def list_identities(self) -> list[dict]:
        return [i.to_dict() for i in self._identities.values()]
