"""Wallet abstraction: chain-agnostic accounts built on
:mod:`silicaflux.web3.identity`, with an explicit-approval gate on every
signature and transaction request (spec sections 6/17).

Deliberately blockchain-agnostic: :class:`Wallet` knows about "networks"
as opaque string identifiers (``"ethereum-mainnet"``, ``"local-devnet"``,
whatever a future :class:`silicaflux.web3.dapp_bridge` chain adapter
registers) and produces addresses via a pluggable
:class:`AddressFormatter` rather than hard-coding any one chain's address
scheme. No transaction is ever broadcast by this module — signing and
"submission" are separate concerns; a real chain adapter would take a
signed transaction from here and hand it to that chain's RPC.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Callable, Optional, Protocol

from silicaflux.core.logging_setup import get_logger
from silicaflux.web3.identity import Identity, IdentityManager

logger = get_logger("web3.wallet")


class AddressFormatter(Protocol):
    def __call__(self, public_key_b64: str) -> str: ...


def default_address_formatter(public_key_b64: str) -> str:
    """A simple, chain-agnostic address: ``sfx1<fingerprint>``. A real
    Ethereum/Bitcoin/Solana adapter would derive its own native address
    format from the same public key and register that formatter instead."""
    import base64
    import hashlib

    digest = hashlib.sha256(base64.b64decode(public_key_b64)).hexdigest()
    return f"sfx1{digest[:40]}"


@dataclass
class Account:
    identity_id: str
    address: str
    network: str

    def to_dict(self) -> dict:
        return {"identity_id": self.identity_id, "address": self.address, "network": self.network}


@dataclass
class TransactionRequest:
    request_id: str
    origin: str
    network: str
    to: str
    value: str
    data: str = ""
    created_at: float = field(default_factory=time.time)
    status: str = "pending"  # pending | approved | rejected | signed

    def to_dict(self) -> dict:
        return {
            "request_id": self.request_id,
            "origin": self.origin,
            "network": self.network,
            "to": self.to,
            "value": self.value,
            "data": self.data,
            "status": self.status,
        }


class WalletApprovalDenied(RuntimeError):
    pass


ApprovalPrompt = Callable[[TransactionRequest], bool]
"""``(request) -> approved?`` — supplied by the UI layer. Defaults to
always-deny, matching "never sign without explicit user approval"."""


def _deny_all(_: TransactionRequest) -> bool:
    return False


class Wallet:
    def __init__(
        self,
        identity_manager: IdentityManager,
        address_formatter: AddressFormatter = default_address_formatter,
        approval_prompt: Optional[ApprovalPrompt] = None,
    ) -> None:
        self.identity_manager = identity_manager
        self.address_formatter = address_formatter
        self.approval_prompt = approval_prompt or _deny_all
        self._accounts: dict[str, Account] = {}
        #: origin -> set of account addresses the user connected that origin to.
        self._connections: dict[str, set[str]] = {}

    def create_account(self, identity: Identity, network: str = "sfx-default") -> Account:
        account = Account(identity.identity_id, self.address_formatter(identity.public_key_b64), network)
        self._accounts[account.address] = account
        return account

    def list_accounts(self) -> list[Account]:
        return list(self._accounts.values())

    def get_account(self, address: str) -> Optional[Account]:
        return self._accounts.get(address)

    # -- DApp connection flow (spec: Website -> Identity Request -> User
    # Approval -> Capability -> Signed Operation) ------------------------
    def connect(self, origin: str, address: str, approved: bool) -> bool:
        if address not in self._accounts:
            raise ValueError(f"unknown account address '{address}'")
        if not approved:
            logger.info(f"wallet connection denied for origin '{origin}'")
            return False
        self._connections.setdefault(origin, set()).add(address)
        logger.info(f"wallet connected: origin='{origin}' address='{address}'")
        return True

    def disconnect(self, origin: str, address: Optional[str] = None) -> None:
        if address is None:
            self._connections.pop(origin, None)
        else:
            self._connections.get(origin, set()).discard(address)

    def connected_accounts(self, origin: str) -> list[str]:
        return sorted(self._connections.get(origin, set()))

    def is_connected(self, origin: str, address: str) -> bool:
        return address in self._connections.get(origin, set())

    # -- signing / transactions -------------------------------------
    def request_transaction(self, origin: str, network: str, to: str, value: str, data: str = "") -> TransactionRequest:
        return TransactionRequest(uuid.uuid4().hex, origin, network, to, value, data)

    def approve_and_sign(self, request: TransactionRequest, address: str) -> str:
        """Prompt for approval (via ``approval_prompt``) and, only if
        approved, sign the transaction with the account's identity. Raises
        :class:`WalletApprovalDenied` otherwise — there is no code path in
        this class that signs without going through the prompt."""
        if not self.is_connected(request.origin, address):
            raise WalletApprovalDenied(f"origin '{request.origin}' is not connected to account '{address}'")
        account = self._accounts[address]
        approved = self.approval_prompt(request)
        if not approved:
            request.status = "rejected"
            raise WalletApprovalDenied(f"user rejected transaction request {request.request_id}")
        request.status = "approved"
        message = f"{request.network}|{request.to}|{request.value}|{request.data}".encode()
        signature = self.identity_manager.signatures.sign(account.identity_id, message)
        request.status = "signed"
        logger.info(f"transaction {request.request_id} signed by {address}")
        return signature

    def sign_message(self, origin: str, address: str, message: str) -> str:
        if not self.is_connected(origin, address):
            raise WalletApprovalDenied(f"origin '{origin}' is not connected to account '{address}'")
        account = self._accounts[address]
        fake_request = TransactionRequest(uuid.uuid4().hex, origin, account.network, address, "0", data=message)
        if not self.approval_prompt(fake_request):
            raise WalletApprovalDenied("user rejected message signature request")
        return self.identity_manager.signatures.sign(account.identity_id, message.encode())
