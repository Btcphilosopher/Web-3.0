"""Decentralised (peer-to-peer) resource layer — spec Phase 7.

    URL -> ContentIdentifier -> local cache -> peer discovery
        -> resource retrieval -> integrity verification -> browser

This module defines the abstractions (:class:`Peer`, :class:`Provider`,
:class:`Transport`) without committing to any one P2P protocol (libp2p,
BitTorrent, IPFS's bitswap, ...) — a real transport plugs in by
implementing :class:`Transport`. The bundled :class:`LoopbackTransport` is
a fully-working *local* implementation (peers are other
:class:`PeerNetwork` instances in the same process/tests) good enough to
exercise the whole retrieval pipeline end-to-end without a real network
stack; it is not a substitute for an actual P2P protocol implementation.

P2P networking is opt-in: :class:`PeerNetwork` does nothing until
explicitly started, and every lookup requires the ``p2p`` capability from
:mod:`silicaflux.security.policy`, same as any other capability. Nothing
here binds a local network service or exposes local resources by default.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional, Protocol

from silicaflux.cache.content_cache import ContentCache, content_hash
from silicaflux.core.logging_setup import get_logger

logger = get_logger("web3.p2p")

ContentID = str  # a sha256 content hash, see silicaflux.cache.content_cache.content_hash


@dataclass
class Peer:
    peer_id: str
    address: str  # transport-specific: could be a multiaddr, host:port, anything
    reputation: float = 0.5  # 0..1, updated by successful/failed transfers
    last_seen: float = field(default_factory=time.time)


@dataclass
class Provider:
    peer: Peer
    content_id: ContentID
    announced_at: float = field(default_factory=time.time)


@dataclass
class DistributedResource:
    content_id: ContentID
    size: int
    data: bytes
    retrieved_from: Optional[str]  # peer_id, or None if served from local cache
    verified: bool


class Transport(Protocol):
    """What a real P2P protocol adapter must implement. Kept intentionally
    narrow — discovery and fetch — so a libp2p or IPFS-backed transport is
    a small adapter, not a rewrite of this module."""

    async def find_providers(self, content_id: ContentID, limit: int = 10) -> list[Provider]: ...

    async def fetch(self, provider: Provider, timeout_s: float) -> bytes: ...

    async def announce(self, content_id: ContentID, peer: Peer) -> None: ...


class LoopbackTransport:
    """An in-memory transport connecting :class:`PeerNetwork` instances
    that share this object — useful for tests, demos, and single-machine
    multi-profile setups. A real deployment replaces this with a network
    transport, not with more of this class."""

    def __init__(self) -> None:
        self._announcements: dict[ContentID, list[Provider]] = {}
        self._blobs: dict[str, dict[ContentID, bytes]] = {}  # peer_id -> content -> bytes

    async def announce(self, content_id: ContentID, peer: Peer) -> None:
        self._announcements.setdefault(content_id, []).append(Provider(peer, content_id))

    def _seed(self, peer_id: str, content_id: ContentID, data: bytes) -> None:
        self._blobs.setdefault(peer_id, {})[content_id] = data

    async def find_providers(self, content_id: ContentID, limit: int = 10) -> list[Provider]:
        return self._announcements.get(content_id, [])[:limit]

    async def fetch(self, provider: Provider, timeout_s: float) -> bytes:
        blob = self._blobs.get(provider.peer.peer_id, {}).get(provider.content_id)
        if blob is None:
            raise ConnectionError(f"peer '{provider.peer.peer_id}' has no data for {provider.content_id}")
        return blob


class PeerNetwork:
    """Coordinates local cache, peer discovery and integrity verification
    for one profile's opt-in P2P participation."""

    def __init__(
        self,
        transport: Transport,
        local_peer: Peer,
        cache: Optional[ContentCache] = None,
        *,
        bandwidth_limit_bytes_s: Optional[int] = None,
        connect_timeout_s: float = 5.0,
    ) -> None:
        self.transport = transport
        self.local_peer = local_peer
        self.cache = cache or ContentCache(name="p2p_cache")
        self.bandwidth_limit_bytes_s = bandwidth_limit_bytes_s
        self.connect_timeout_s = connect_timeout_s
        self._enabled = False

    def enable(self) -> None:
        self._enabled = True
        logger.info(f"P2P networking enabled for peer '{self.local_peer.peer_id}'")

    def disable(self) -> None:
        self._enabled = False

    async def publish(self, data: bytes) -> ContentID:
        """Make ``data`` available to the network under its content hash,
        after storing it in the local cache."""
        digest = self.cache.put(data)
        if self._enabled:
            await self.transport.announce(digest, self.local_peer)
        return digest

    async def resolve(self, content_id: ContentID, max_providers: int = 5) -> DistributedResource:
        """Content-addressed retrieval: local cache first, then peer
        discovery + fetch + integrity verification (spec's pipeline)."""
        cached = self.cache.get(content_id)
        if cached is not None:
            return DistributedResource(content_id, len(cached), cached, retrieved_from=None, verified=True)

        if not self._enabled:
            raise PermissionError("P2P networking is disabled for this profile; call enable() to opt in")

        providers = sorted(
            await self.transport.find_providers(content_id, limit=max_providers),
            key=lambda p: -p.peer.reputation,
        )
        last_error: Optional[Exception] = None
        for provider in providers:
            try:
                data = await self.transport.fetch(provider, timeout_s=self.connect_timeout_s)
            except Exception as exc:
                last_error = exc
                provider.peer.reputation = max(0.0, provider.peer.reputation - 0.1)
                continue
            verified = content_hash(data) == content_id
            if not verified:
                logger.warning(f"peer '{provider.peer.peer_id}' returned corrupt data for {content_id}")
                provider.peer.reputation = max(0.0, provider.peer.reputation - 0.3)
                continue
            provider.peer.reputation = min(1.0, provider.peer.reputation + 0.05)
            self.cache.put(data)
            return DistributedResource(content_id, len(data), data, provider.peer.peer_id, verified=True)

        raise LookupError(f"no provider could satisfy content {content_id}" + (f" ({last_error})" if last_error else ""))
