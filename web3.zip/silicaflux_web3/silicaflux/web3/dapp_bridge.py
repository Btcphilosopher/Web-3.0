"""The DApp bridge: the concrete JS-facing surface of the Web3 layer,
mounted under the ``web3`` namespace of :mod:`silicaflux.api.bridge`
(so a page calls ``silicaflux.request({runtime: "web3", operation:
"connect", ...})`` and this class is what actually runs). Every method
here is safe to expose directly to page-originated calls: each one
re-derives its own authorization from the origin string it's given rather
than trusting anything else about the caller.
"""

from __future__ import annotations

from typing import Any, Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.web3.permissions import DAppPermissionManager
from silicaflux.web3.wallet import Wallet, WalletApprovalDenied

logger = get_logger("web3.dapp_bridge")


class DAppBridgeError(RuntimeError):
    pass


class DAppBridge:
    def __init__(self, wallet: Wallet, permissions: DAppPermissionManager, default_address: Optional[str] = None) -> None:
        self.wallet = wallet
        self.permissions = permissions
        #: which account a `connect` call offers when the page doesn't
        #: specify one — set by the browser chrome to "the currently
        #: unlocked wallet's active account".
        self.default_address = default_address

    async def handle(self, operation: str, origin: str, payload: dict) -> Any:
        """Single dispatch entry point — this is what
        :mod:`silicaflux.api.bridge` calls for ``runtime: "web3"``
        packets, so the whole Web3 surface is reachable through one
        capability-checked path instead of five separately-wired methods."""
        handler = {
            "connect": self.connect,
            "accounts": self.accounts,
            "disconnect": self.disconnect,
            "sign_message": self.sign_message,
            "send_transaction": self.send_transaction,
            "permissions": self.get_permissions,
        }.get(operation)
        if handler is None:
            raise DAppBridgeError(f"unknown web3 operation '{operation}'")
        return await handler(origin, payload)

    async def connect(self, origin: str, payload: dict) -> dict:
        address = payload.get("address") or self.default_address
        if not address:
            raise DAppBridgeError("no wallet account available to connect")
        accounts = await self.permissions.request_accounts(origin, address)
        return {"accounts": accounts}

    async def accounts(self, origin: str, payload: dict) -> dict:
        return {"accounts": self.wallet.connected_accounts(origin)}

    async def disconnect(self, origin: str, payload: dict) -> dict:
        self.permissions.revoke(origin)
        return {"disconnected": True}

    async def sign_message(self, origin: str, payload: dict) -> dict:
        address = payload.get("address")
        message = payload.get("message", "")
        if not address:
            raise DAppBridgeError("'address' is required")
        try:
            signature = self.wallet.sign_message(origin, address, message)
        except WalletApprovalDenied as exc:
            raise DAppBridgeError(str(exc)) from exc
        return {"signature": signature}

    async def send_transaction(self, origin: str, payload: dict) -> dict:
        address = payload.get("address")
        if not address:
            raise DAppBridgeError("'address' is required")
        request = self.wallet.request_transaction(
            origin,
            network=payload.get("network", "sfx-default"),
            to=payload.get("to", ""),
            value=payload.get("value", "0"),
            data=payload.get("data", ""),
        )
        try:
            signature = self.wallet.approve_and_sign(request, address)
        except WalletApprovalDenied as exc:
            raise DAppBridgeError(str(exc)) from exc
        return {"request": request.to_dict(), "signature": signature}

    async def get_permissions(self, origin: str, payload: dict) -> dict:
        return self.permissions.permissions_for(origin)
