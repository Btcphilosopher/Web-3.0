"""DApp-facing permission flow: the Web3-specific layer on top of
:mod:`silicaflux.security.policy`'s general capability system.

Where :class:`silicaflux.security.permissions.PermissionManager` answers
"can this origin call python.analytics", :class:`DAppPermissionManager`
answers the Web3-specific question a page actually asks: "which accounts,
if any, is this origin allowed to see and act as" — the same shape as the
``eth_requestAccounts`` / ``wallet_getPermissions`` flow familiar from
other Web3 browsers, without committing to any single chain's JSON-RPC
method names.
"""

from __future__ import annotations

from typing import Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.security.policy import SecurityPolicy
from silicaflux.web3.wallet import Wallet

logger = get_logger("web3.permissions")


class DAppPermissionManager:
    def __init__(self, policy: SecurityPolicy, wallet: Wallet) -> None:
        self.policy = policy
        self.wallet = wallet

    async def request_accounts(self, origin: str, address: str) -> list[str]:
        """The DApp-facing entry point for "connect my wallet". Requires
        the ``wallet.connect`` capability (routed through the normal
        policy engine, so it can be auto-denied, prompted, or
        auto-allowed exactly like any other capability) *and* a
        wallet-level approval before an address becomes visible to the
        origin."""
        token = self.policy.authorize(origin, "wallet.connect")
        if token is None:
            logger.info(f"wallet.connect capability denied for '{origin}'")
            return []
        approved = self.wallet.connect(origin, address, approved=True)
        return self.wallet.connected_accounts(origin) if approved else []

    def revoke(self, origin: str) -> None:
        self.wallet.disconnect(origin)
        self.policy.revoke(origin, "wallet.connect")
        self.policy.revoke(origin, "wallet.sign")

    def permissions_for(self, origin: str) -> dict:
        return {
            "origin": origin,
            "accounts": self.wallet.connected_accounts(origin),
            "capabilities": [t.capability for t in self.policy.grants_for(origin) if t.capability.startswith("wallet.") or t.capability.startswith("identity")],
        }
