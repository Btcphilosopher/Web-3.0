"""The toolbar: back / forward / reload / home / smart address bar / new
tab, styled as a compact, modern browser chrome (spec section 4/29 —
rounded controls, restrained animation, dark/light aware via the app-wide
stylesheet in :mod:`silicaflux.browser.window`).
"""

from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QSizePolicy, QToolButton, QWidget

from silicaflux.core.navigation import AddressKind, classify_input


class AddressBar(QLineEdit):
    """A QLineEdit that understands the difference between a URL, a bare
    domain, localhost/an IP address, an ``sfx://`` address and a search
    query (spec section 6) and shows a small visual hint accordingly."""

    submitted = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setPlaceholderText("Search or enter a website address")
        self.setClearButtonEnabled(True)
        self.returnPressed.connect(self._on_return)
        self.textChanged.connect(self._on_text_changed)
        self.setObjectName("addressBar")

    def _on_return(self) -> None:
        text = self.text().strip()
        if text:
            self.submitted.emit(text)

    def _on_text_changed(self, text: str) -> None:
        classified = classify_input(text) if text else None
        if classified is None:
            self.setProperty("addressKind", "")
        else:
            self.setProperty("addressKind", classified.kind.value)
        self.style().unpolish(self)
        self.style().polish(self)

    def set_url(self, url: str) -> None:
        if not self.hasFocus():
            self.setText(url)


class NavigationBar(QWidget):
    backClicked = Signal()
    forwardClicked = Signal()
    reloadClicked = Signal()
    homeClicked = Signal()
    newTabClicked = Signal()
    navigateRequested = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("navigationBar")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(4)

        self.back_button = self._tool_button("←", "Back")
        self.forward_button = self._tool_button("→", "Forward")
        self.reload_button = self._tool_button("↻", "Reload")
        self.home_button = self._tool_button("⌂", "Home")
        self.new_tab_button = self._tool_button("+", "New Tab")

        self.address_bar = AddressBar(self)
        self.address_bar.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        for widget in (self.back_button, self.forward_button, self.reload_button, self.home_button):
            layout.addWidget(widget)
        layout.addWidget(self.address_bar, 1)
        layout.addWidget(self.new_tab_button)

        self.back_button.clicked.connect(self.backClicked.emit)
        self.forward_button.clicked.connect(self.forwardClicked.emit)
        self.reload_button.clicked.connect(self.reloadClicked.emit)
        self.home_button.clicked.connect(self.homeClicked.emit)
        self.new_tab_button.clicked.connect(self.newTabClicked.emit)
        self.address_bar.submitted.connect(self.navigateRequested.emit)

    def _tool_button(self, text: str, tooltip: str) -> QToolButton:
        button = QToolButton(self)
        button.setText(text)
        button.setToolTip(tooltip)
        button.setAutoRaise(True)
        button.setObjectName("navButton")
        return button

    def set_navigation_state(self, can_go_back: bool, can_go_forward: bool) -> None:
        self.back_button.setEnabled(can_go_back)
        self.forward_button.setEnabled(can_go_forward)

    def set_url(self, url: str) -> None:
        self.address_bar.set_url(url)
