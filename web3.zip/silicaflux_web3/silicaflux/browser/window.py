"""``MainWindow`` — the top-level browser window: toolbar, tab strip,
menu actions for bookmarks/downloads/history/settings/developer
tools/Web3, and the app-wide light/dark stylesheet (spec sections 4/29).

This module wires together every headless subsystem built elsewhere in
the package with the Qt widgets that make it visible; it deliberately
contains very little logic of its own — almost everything here is one line
connecting a Qt signal to a call on an already-tested, toolkit-independent
object (:class:`~silicaflux.core.tabs.TabManager`,
:class:`~silicaflux.api.bridge.SilicaFluxBridge`, etc.).
"""

from __future__ import annotations

import asyncio
from typing import Any, Optional

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import QMainWindow, QMenu, QMessageBox, QToolBar, QVBoxLayout, QWidget

from silicaflux.api.bridge import SilicaFluxBridge
from silicaflux.browser import sfx_pages
from silicaflux.browser.bookmarks_ui import BookmarksPanel
from silicaflux.browser.downloads_ui import DownloadsPanel
from silicaflux.browser.history_ui import HistoryPanel
from silicaflux.browser.navigation_bar import NavigationBar
from silicaflux.browser.profiles import ProfileManager
from silicaflux.browser.sfx_protocol import SFXSchemeHandler, register_sfx_scheme
from silicaflux.browser.tabs import BrowserTabWidget
from silicaflux.core.logging_setup import get_logger
from silicaflux.core.session import BrowserSessionManager

logger = get_logger("browser.window")

_STYLESHEET = """
QMainWindow, QDialog { background: #0b0d12; }
QWidget#navigationBar { background: #12151c; border-bottom: 1px solid #1f2430; }
QLineEdit#addressBar {
  background: #171b24; border: 1px solid #262c3a; border-radius: 10px;
  padding: 7px 12px; color: #e8eaf0; font-size: 13px; selection-background-color: #6ee7ff;
}
QLineEdit#addressBar:focus { border-color: #6ee7ff; }
QLineEdit#addressBar[addressKind="sfx_internal"] { border-color: #a78bfa; }
QToolButton#navButton { color: #e8eaf0; padding: 6px 10px; border-radius: 8px; font-size: 14px; }
QToolButton#navButton:hover { background: #1c2130; }
QTabWidget::pane { border: 0; }
QTabBar::tab {
  background: #12151c; color: #8b93a7; padding: 7px 16px; border-top-left-radius: 8px; border-top-right-radius: 8px;
  margin-right: 2px;
}
QTabBar::tab:selected { background: #1c2130; color: #e8eaf0; }
QMenuBar { background: #0b0d12; color: #e8eaf0; }
QMenuBar::item:selected { background: #1c2130; }
QMenu { background: #12151c; color: #e8eaf0; border: 1px solid #1f2430; }
QMenu::item:selected { background: #1c2130; }
"""


class MainWindow(QMainWindow):
    def __init__(
        self,
        session: BrowserSessionManager,
        bridge: SilicaFluxBridge,
        profile_manager: ProfileManager,
        runtime_dashboard: Any,
        history_store: Any = None,
        bookmarks_store: Any = None,
        download_manager: Any = None,
        wallet: Any = None,
        homepage: str = "sfx://home",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("SilicaFlux Web3.0")
        self.resize(1280, 820)
        self.setStyleSheet(_STYLESHEET)

        self.session = session
        self.bridge = bridge
        self.profile_manager = profile_manager
        self.runtime_dashboard = runtime_dashboard
        self.history_store = history_store
        self.bookmarks_store = bookmarks_store
        self.download_manager = download_manager
        self.wallet = wallet
        self.homepage = homepage

        central = QWidget(self)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.nav_bar = NavigationBar(self)
        self.tabs = BrowserTabWidget(
            session.tabs,
            bridge,
            profile_manager.get("default"),
            profile_manager.private,
            self,
        )
        layout.addWidget(self.nav_bar)
        layout.addWidget(self.tabs, 1)
        self.setCentralWidget(central)

        self._build_menu()
        self._wire_signals()
        self._restore_or_open_homepage()

    def _restore_or_open_homepage(self) -> None:
        """Restoring a session must go through :meth:`BrowserTabWidget.open_tab`
        (never :meth:`TabManager.new_tab` directly) so every restored tab
        gets a real ``QWebEngineView`` — that 1:1 mapping is
        :class:`~silicaflux.browser.tabs.BrowserTabWidget`'s whole job, so
        this is the one place restoration is allowed to happen for the
        GUI. :class:`~silicaflux.core.session.BrowserSessionManager.restore_or_start`
        stays the right call for headless/CLI use."""
        rows: list[dict] = []
        if self.session.session_store is not None:
            try:
                rows = self.session.session_store.load_session(self.session.profile)
            except Exception:
                logger.exception("failed to load persisted session; opening homepage instead")
        if rows:
            for i, row in enumerate(rows):
                self.tabs.open_tab(row.get("url", self.homepage), background=(i > 0))
        else:
            self.tabs.open_tab(self.homepage)

    # -- construction helpers --------------------------------------------
    def _build_menu(self) -> None:
        toolbar = QToolBar("SilicaFlux", self)
        toolbar.setMovable(False)
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, toolbar)

        bookmarks_action = QAction("★ Bookmarks", self)
        bookmarks_action.triggered.connect(self.open_bookmarks)
        downloads_action = QAction("⬇ Downloads", self)
        downloads_action.triggered.connect(self.open_downloads)
        history_action = QAction("🕘 History", self)
        history_action.triggered.connect(self.open_history)
        settings_action = QAction("⚙ Settings", self)
        settings_action.triggered.connect(lambda: self.navigate_active("sfx://settings"))
        devtools_action = QAction("🛠 Developer", self)
        devtools_action.triggered.connect(self.open_devtools)
        web3_action = QAction("◆ Web3", self)
        web3_action.triggered.connect(lambda: self.navigate_active("sfx://wallet"))

        for action in (bookmarks_action, downloads_action, history_action, settings_action, web3_action, devtools_action):
            toolbar.addAction(action)

        new_tab_shortcut = QAction(self)
        new_tab_shortcut.setShortcut(QKeySequence.StandardKey.AddTab)
        new_tab_shortcut.triggered.connect(lambda: self.tabs.open_tab(self.homepage))
        self.addAction(new_tab_shortcut)

        close_tab_shortcut = QAction(self)
        close_tab_shortcut.setShortcut(QKeySequence.StandardKey.Close)
        close_tab_shortcut.triggered.connect(lambda: self.tabs.close_tab_by_id(self.session.tabs.active_tab.tab_id) if self.session.tabs.active_tab else None)
        self.addAction(close_tab_shortcut)

    def _wire_signals(self) -> None:
        self.nav_bar.backClicked.connect(self._go_back)
        self.nav_bar.forwardClicked.connect(self._go_forward)
        self.nav_bar.reloadClicked.connect(self._reload)
        self.nav_bar.homeClicked.connect(lambda: self.navigate_active(self.homepage))
        self.nav_bar.newTabClicked.connect(lambda: self.tabs.open_tab(self.homepage))
        self.nav_bar.navigateRequested.connect(self.navigate_active)

        self.tabs.activeUrlChanged.connect(self._on_active_url_changed)
        self.tabs.activeTitleChanged.connect(lambda title: self.setWindowTitle(f"{title} — SilicaFlux Web3.0" if title else "SilicaFlux Web3.0"))
        self.tabs.currentChanged.connect(self._update_nav_state)

    # -- navigation ----------------------------------------------------
    def navigate_active(self, raw_input: str) -> None:
        tab = self.session.tabs.active_tab
        if tab is None:
            self.tabs.open_tab(raw_input)
            return
        self.tabs.navigate(tab.tab_id, raw_input)

    def _go_back(self) -> None:
        view = self.tabs.current_view()
        if view is not None:
            view.back()

    def _go_forward(self) -> None:
        view = self.tabs.current_view()
        if view is not None:
            view.forward()

    def _reload(self) -> None:
        view = self.tabs.current_view()
        if view is not None:
            view.reload()

    def _on_active_url_changed(self, url: str) -> None:
        self.nav_bar.set_url(url)
        self._update_nav_state()

    def _update_nav_state(self, *_args) -> None:
        tab = self.session.tabs.active_tab
        if tab is not None:
            self.nav_bar.set_navigation_state(tab.navigation.can_go_back(), tab.navigation.can_go_forward())

    # -- panels -------------------------------------------------------
    def open_bookmarks(self) -> None:
        if self.bookmarks_store is None:
            return
        panel = BookmarksPanel(self.bookmarks_store, on_navigate=self.navigate_active, parent=self)
        panel.show()

    def open_downloads(self) -> None:
        if self.download_manager is None:
            return
        panel = DownloadsPanel(self.download_manager, parent=self)
        panel.show()

    def open_history(self) -> None:
        if self.history_store is None:
            return
        panel = HistoryPanel(self.history_store, on_navigate=self.navigate_active, parent=self)
        panel.show()

    def open_devtools(self) -> None:
        self.navigate_active("sfx://developer")

    # -- shutdown -------------------------------------------------------
    def closeEvent(self, event) -> None:  # noqa: N802 - Qt override
        self.session.save()
        super().closeEvent(event)


def build_sfx_page_provider(bookmarks_store: Any, wallet: Any):
    """Returns the ``page_provider`` callable :class:`SFXSchemeHandler`
    needs. Kept as a free function (rather than a MainWindow method) so it
    has no Qt-widget dependency — the internal pages are pure HTML
    generation, see :mod:`silicaflux.browser.sfx_pages`."""

    def provider(host: str) -> str:
        page = host or "home"
        if page not in sfx_pages.PAGES:
            return sfx_pages.PAGES["home"]({})
        ctx: dict = {}
        if page == "wallet" and wallet is not None:
            ctx["accounts"] = [a.to_dict() for a in getattr(wallet, "_accounts", {}).values()]
        return sfx_pages.PAGES[page](ctx)

    return provider
