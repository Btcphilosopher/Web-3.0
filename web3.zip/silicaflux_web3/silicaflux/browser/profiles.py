"""Browser profiles: each maps to its own on-disk storage directory (its
own SQLite database, downloads folder, and a persistent
``QWebEngineProfile`` with its own cookie jar/HTTP cache), plus one
special off-the-record profile for private browsing that persists
nothing.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtWebEngineCore import QWebEngineProfile

from silicaflux.core.logging_setup import get_logger

logger = get_logger("browser.profiles")


class ProfileManager:
    def __init__(self, base_dir: Path) -> None:
        self.base_dir = base_dir
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self._profiles: dict[str, QWebEngineProfile] = {}
        self._private_profile: Optional[QWebEngineProfile] = None

    def profile_dir(self, name: str) -> Path:
        d = self.base_dir / name
        d.mkdir(parents=True, exist_ok=True)
        return d

    def get(self, name: str = "default") -> QWebEngineProfile:
        if name not in self._profiles:
            profile_dir = self.profile_dir(name)
            profile = QWebEngineProfile(name)
            profile.setPersistentStoragePath(str(profile_dir / "webengine"))
            profile.setCachePath(str(profile_dir / "cache"))
            profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
            profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies)
            self._profiles[name] = profile
            logger.info(f"created persistent profile '{name}' at {profile_dir}")
        return self._profiles[name]

    def private(self) -> QWebEngineProfile:
        if self._private_profile is None:
            # Constructing a QWebEngineProfile with no name/parent yields
            # an off-the-record profile: nothing is written to disk, and
            # its cookie jar/cache vanish when the object is destroyed.
            self._private_profile = QWebEngineProfile()
            logger.info("created off-the-record private profile")
        return self._private_profile

    def names(self) -> list[str]:
        return list(self._profiles.keys())
