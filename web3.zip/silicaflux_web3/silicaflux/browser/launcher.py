"""SilicaFlux Web3.0 — desktop browser launcher.

Wires every headless subsystem (packet fabric, security, storage, cache,
networking, runtimes, Web3, telemetry) to the PySide6/QtWebEngine GUI
shell and runs the event loop. Requires ``PySide6`` with the WebEngine
addon installed (``pip install PySide6``) — see ``docs/INSTALL.md``.
Everything this file wires together is independently importable and
testable without PySide6; see :mod:`silicaflux.cli` for a GUI-free way to
exercise the same engine.

Two things call into this module: the top-level ``main.py`` (so ``python
main.py`` / a packaged desktop launcher works without needing the CLI
entry point installed) and ``sfx-browser start`` /
:mod:`silicaflux.cli`. Both just call :func:`main`.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="sfx-browser", description="SilicaFlux Web3.0 desktop browser")
    parser.add_argument("url", nargs="?", default=None, help="URL to open in the initial tab")
    parser.add_argument("--new-window", action="store_true", help="(reserved) force a new window/session")
    parser.add_argument("--private", action="store_true", help="open the initial tab in a private profile")
    parser.add_argument("--url", dest="url_flag", default=None, help="URL to open (equivalent to the positional arg)")
    parser.add_argument("--profile", default="default", help="profile name (default: 'default')")
    parser.add_argument("--profile-dir", default=None, help="override the profile storage directory")
    parser.add_argument("--dev", action="store_true", help="start with the developer tools tab open")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(sys.argv[1:] if argv is None else argv)

    # Custom URL schemes (sfx://) must be registered before QApplication exists.
    from silicaflux.browser.sfx_protocol import register_sfx_scheme

    register_sfx_scheme()

    from PySide6.QtWidgets import QApplication
    import qasync

    app = QApplication(sys.argv)
    app.setApplicationName("SilicaFlux Web3.0")
    app.setOrganizationName("SilicaFlux")

    # SilicaFlux's engine, storage and networking layers are all
    # asyncio-native, while QtWebEngine needs Qt's own event loop pumping
    # frequently and reliably (its renderer-process IPC is sensitive to
    # exactly how the loop is driven). `qasync` runs one loop that is both
    # a real Qt event loop and a real asyncio event loop, so `await` works
    # everywhere (including inside Qt slots, via `asyncio.ensure_future`)
    # without a second thread or a manual bridge.
    loop = qasync.QEventLoop(app)
    asyncio.set_event_loop(loop)

    async def start() -> None:
        window = await _build_window(args)
        window.show()

    with loop:
        loop.create_task(start())
        loop.run_forever()
    return 0


async def _build_window(args: argparse.Namespace):
    from silicaflux.browser.profiles import ProfileManager
    from silicaflux.browser.sfx_protocol import SFXSchemeHandler
    from silicaflux.browser.window import MainWindow, build_sfx_page_provider
    from silicaflux.api.bridge import SilicaFluxBridge
    from silicaflux.cache import CacheManager
    from silicaflux.config.defaults import DEFAULT_PROFILE_DIR
    from silicaflux.core.config import ConfigurationSystem
    from silicaflux.core.engine import SilicaFluxEngine
    from silicaflux.core.session import BrowserSessionManager
    from silicaflux.networking.client import HTTPClient
    from silicaflux.networking.downloads import DownloadManager
    from silicaflux.runtimes.manager import RuntimeManager
    from silicaflux.security.audit import AuditLogger
    from silicaflux.security.permissions import PermissionManager
    from silicaflux.security.policy import SecurityPolicy
    from silicaflux.storage.bookmarks import BookmarksStore
    from silicaflux.storage.database import Database
    from silicaflux.storage.downloads_store import DownloadsStore
    from silicaflux.storage.history import HistoryStore
    from silicaflux.storage.permissions_store import PermissionsStore
    from silicaflux.telemetry.dashboard import RuntimeDashboard
    from silicaflux.telemetry.manager import TelemetryManager
    from silicaflux.web3.dapp_bridge import DAppBridge
    from silicaflux.web3.identity import IdentityManager
    from silicaflux.web3.permissions import DAppPermissionManager
    from silicaflux.web3.wallet import Wallet

    profile_dir = Path(args.profile_dir) if args.profile_dir else DEFAULT_PROFILE_DIR
    profile_dir = profile_dir if profile_dir.name == args.profile else profile_dir / args.profile
    profile_dir.mkdir(parents=True, exist_ok=True)

    config = ConfigurationSystem(profile_dir)
    settings = config.settings

    db = Database(profile_dir / "silicaflux.sqlite3")
    history_store = HistoryStore(db)
    bookmarks_store = BookmarksStore(db)
    downloads_store = DownloadsStore(db)
    permissions_store = PermissionsStore(db)

    audit = AuditLogger(sink=db)
    policy = SecurityPolicy(default_policy=settings.security.default_capability_policy, audit=audit)
    PermissionManager(policy, persistence=permissions_store)

    cache_manager = CacheManager(cache_dir=profile_dir / "cache")

    runtime_manager = RuntimeManager(
        python_enabled=settings.runtimes.python_enabled,
        r_enabled=settings.runtimes.r_enabled,
        rust_enabled=settings.runtimes.rust_enabled,
        wasm_enabled=settings.runtimes.wasm_enabled,
        javascript_enabled=settings.runtimes.javascript_bridge_enabled,
    )
    from silicaflux.runtimes.sample_functions import analytics_summary  # noqa: F401 - ensures module import path resolves

    runtime_manager.python_registry.register("analytics", "silicaflux.runtimes.sample_functions", "analytics_summary")
    runtime_manager.python_registry.register("fib", "silicaflux.runtimes.sample_functions", "fibonacci")
    runtime_manager.python_registry.register("hash", "silicaflux.runtimes.sample_functions", "sha256_of")

    telemetry = TelemetryManager(database=db)
    engine = SilicaFluxEngine(
        router=runtime_manager.router,
        security_policy=policy,
        worker_registry=runtime_manager.worker_registry,
        telemetry=telemetry,
    )
    await engine.start()

    identity_manager = IdentityManager(profile_dir / "identity")
    wallet = Wallet(identity_manager, approval_prompt=lambda req: True)  # GUI approval dialog wiring is a TODO hook point
    dapp_permissions = DAppPermissionManager(policy, wallet)
    dapp_bridge = DAppBridge(wallet, dapp_permissions)

    dashboard = RuntimeDashboard(engine, telemetry, cache_manager=cache_manager, wallet=wallet)

    async def internal_handler(operation: str, payload: dict):
        if operation == "dashboard":
            return dashboard.snapshot()
        if operation == "apps":
            return {"apps": await db.list_apps()}
        raise ValueError(f"unknown internal operation '{operation}'")

    bridge = SilicaFluxBridge(engine, dapp_bridge=dapp_bridge, internal_handler=internal_handler)

    http_client = HTTPClient(resource_cache=cache_manager.resources)
    download_manager = DownloadManager(http_client, Path(settings.downloads.directory), store=downloads_store)

    profile_manager = ProfileManager(profile_dir / "profiles")
    page_provider = build_sfx_page_provider(bookmarks_store, wallet)
    profile_manager.get("default").installUrlSchemeHandler(b"sfx", SFXSchemeHandler(page_provider))
    profile_manager.private().installUrlSchemeHandler(b"sfx", SFXSchemeHandler(page_provider))

    # Session restoration for the GUI happens inside MainWindow (it must
    # create a real QWebEngineView for every restored tab, which
    # BrowserSessionManager's own restore_or_start() cannot do since it
    # only knows about the headless TabManager — see MainWindow.__init__).
    session = BrowserSessionManager(profile=args.profile, session_store=db)

    window = MainWindow(
        session=session,
        bridge=bridge,
        profile_manager=profile_manager,
        runtime_dashboard=dashboard,
        history_store=history_store,
        bookmarks_store=bookmarks_store,
        download_manager=download_manager,
        wallet=wallet,
        homepage=settings.homepage,
    )

    start_url = args.url_flag or args.url
    if start_url:
        window.navigate_active(start_url)

    return window
