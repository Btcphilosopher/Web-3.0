"""The Downloads panel: queue, progress, pause/resume/cancel, history —
backed by :class:`silicaflux.networking.downloads.DownloadManager`."""

from __future__ import annotations

import asyncio

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QAbstractItemView, QDialog, QHBoxLayout, QLabel, QProgressBar, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget

from silicaflux.networking.downloads import DownloadManager


class DownloadsPanel(QDialog):
    _COLUMNS = ["File", "Status", "Progress", "Actions"]

    def __init__(self, manager: DownloadManager, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Downloads")
        self.resize(640, 360)
        self.manager = manager

        layout = QVBoxLayout(self)
        self.table = QTableWidget(0, len(self._COLUMNS), self)
        self.table.setHorizontalHeaderLabels(self._COLUMNS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(500)
        self.refresh()

    def refresh(self) -> None:
        rows = self.manager.active_downloads()
        self.table.setRowCount(len(rows))
        for i, row in enumerate(rows):
            self.table.setItem(i, 0, QTableWidgetItem(row["filename"]))
            self.table.setItem(i, 1, QTableWidgetItem(row["status"]))

            progress = QProgressBar()
            total = row.get("total_bytes") or 0
            if total:
                progress.setRange(0, total)
                progress.setValue(min(row["received_bytes"], total))
            else:
                progress.setRange(0, 0)  # indeterminate
            self.table.setCellWidget(i, 2, progress)

            actions = QWidget()
            layout = QHBoxLayout(actions)
            layout.setContentsMargins(0, 0, 0, 0)
            download_id = row["id"]
            if row["status"] == "downloading":
                btn = QPushButton("Pause")
                btn.clicked.connect(lambda _, did=download_id: self.manager.pause(did))
            elif row["status"] == "paused":
                btn = QPushButton("Resume")
                btn.clicked.connect(lambda _, did=download_id: self.manager.resume(did))
            else:
                btn = QPushButton("—")
                btn.setEnabled(False)
            cancel = QPushButton("Cancel")
            cancel.clicked.connect(lambda _, did=download_id: self.manager.cancel(did))
            layout.addWidget(btn)
            layout.addWidget(cancel)
            self.table.setCellWidget(i, 3, actions)
