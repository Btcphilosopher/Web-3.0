"""``BrowserTabWidget`` — the visible tab strip, backed one-to-one by
:class:`silicaflux.core.tabs.TabManager`. Every Qt tab index maps to
exactly one headless :class:`~silicaflux.core.tabs.Tab` record; this
class's whole job is keeping that mapping honest as tabs open, close,
reorder and load.
"""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QUrl, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWebEngineCore import QWebEngineProfile
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import QTabWidget

from silicaflux.api.bridge import SilicaFluxBridge
from silicaflux.browser.page import BrowserPage
from silicaflux.core.logging_setup import get_logger
from silicaflux.core.tabs import LoadState, Tab, TabManager

logger = get_logger("browser.tabs")


class BrowserTabWidget(QTabWidget):
    activeUrlChanged = Signal(str)
    activeTitleChanged = Signal(str)
    loadProgressChanged = Signal(int)

    def __init__(
        self,
        tab_manager: TabManager,
        bridge: SilicaFluxBridge,
        default_profile: QWebEngineProfile,
        private_profile_factory,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.tab_manager = tab_manager
        self.bridge = bridge
        self.default_profile = default_profile
        self.private_profile_factory = private_profile_factory

        self.setTabsClosable(True)
        self.setMovable(True)
        self.setDocumentMode(True)

        self._views: dict[str, QWebEngineView] = {}

        self.tabCloseRequested.connect(self._on_tab_close_requested)
        self.currentChanged.connect(self._on_current_changed)

    # -- tab lifecycle, mirroring TabManager -----------------------------
    def open_tab(self, url: str = "sfx://home", *, private: bool = False, background: bool = False) -> Tab:
        tab = self.tab_manager.new_tab(url, private=private, background=background)
        profile = self.private_profile_factory() if private else self.default_profile
        page = BrowserPage(self.bridge, profile=profile, parent=self)
        view = QWebEngineView(self)
        view.setPage(page)

        page.titleChanged.connect(lambda title, tid=tab.tab_id: self._on_title_changed(tid, title))
        page.iconChanged.connect(lambda icon, tid=tab.tab_id: self._on_icon_changed(tid, icon))
        page.urlChanged.connect(lambda url_, tid=tab.tab_id: self._on_url_changed(tid, url_))
        page.loadStarted.connect(lambda tid=tab.tab_id: self._on_load_started(tid))
        page.loadFinished.connect(lambda ok, tid=tab.tab_id: self._on_load_finished(tid, ok))
        page.sfxLoadProgress.connect(self.loadProgressChanged.emit)

        self._views[tab.tab_id] = view
        index = self.addTab(view, "New Tab" if not private else "Private Tab")
        if not background:
            self.setCurrentIndex(index)
        self.navigate(tab.tab_id, url)
        return tab

    def navigate(self, tab_id: str, raw_input: str) -> None:
        from silicaflux.core.navigation import classify_input

        classified = classify_input(raw_input)
        self.tab_manager.navigate(tab_id, classified.normalized_url)
        view = self._views.get(tab_id)
        if view is not None:
            view.load(QUrl(classified.normalized_url))

    def close_tab_by_id(self, tab_id: str) -> None:
        index = self._index_of(tab_id)
        if index is not None:
            self._close_index(index)

    def duplicate_current(self) -> Optional[Tab]:
        current = self.tab_manager.active_tab
        if current is None:
            return None
        return self.open_tab(current.url, private=current.private)

    def restore_closed(self) -> Optional[Tab]:
        tab = self.tab_manager.restore_closed_tab()
        if tab is None:
            return None
        profile = self.private_profile_factory() if tab.private else self.default_profile
        page = BrowserPage(self.bridge, profile=profile, parent=self)
        view = QWebEngineView(self)
        view.setPage(page)
        self._views[tab.tab_id] = view
        index = self.addTab(view, tab.title)
        self.setCurrentIndex(index)
        self.navigate(tab.tab_id, tab.url)
        return tab

    # -- Qt signal handlers -----------------------------------------
    def _index_of(self, tab_id: str) -> Optional[int]:
        view = self._views.get(tab_id)
        if view is None:
            return None
        return self.indexOf(view)

    def _on_tab_close_requested(self, index: int) -> None:
        self._close_index(index)

    def _close_index(self, index: int) -> None:
        view = self.widget(index)
        tab_id = next((tid for tid, v in self._views.items() if v is view), None)
        if tab_id is not None:
            self.tab_manager.close_tab(tab_id)
            del self._views[tab_id]
        self.removeTab(index)
        if view is not None:
            view.deleteLater()

    def _on_current_changed(self, index: int) -> None:
        view = self.widget(index)
        tab_id = next((tid for tid, v in self._views.items() if v is view), None)
        if tab_id is not None:
            self.tab_manager.activate(tab_id)
            tab = self.tab_manager.get(tab_id)
            if tab:
                self.activeUrlChanged.emit(tab.url)
                self.activeTitleChanged.emit(tab.title)

    def _on_title_changed(self, tab_id: str, title: str) -> None:
        index = self._index_of(tab_id)
        if index is not None and title:
            self.setTabText(index, title[:32])
        if self.tab_manager.get(tab_id):
            self.tab_manager.get(tab_id).title = title or "New Tab"
        if self.tab_manager.active_tab and self.tab_manager.active_tab.tab_id == tab_id:
            self.activeTitleChanged.emit(title)

    def _on_icon_changed(self, tab_id: str, icon: QIcon) -> None:
        index = self._index_of(tab_id)
        if index is not None:
            self.setTabIcon(index, icon)

    def _on_url_changed(self, tab_id: str, url: QUrl) -> None:
        tab = self.tab_manager.get(tab_id)
        if tab:
            tab.url = url.toString()
        if self.tab_manager.active_tab and self.tab_manager.active_tab.tab_id == tab_id:
            self.activeUrlChanged.emit(url.toString())

    def _on_load_started(self, tab_id: str) -> None:
        tab = self.tab_manager.get(tab_id)
        if tab:
            tab.load_state = LoadState.LOADING

    def _on_load_finished(self, tab_id: str, ok: bool) -> None:
        view = self._views.get(tab_id)
        title = view.page().title() if view else None
        self.tab_manager.finish_load(tab_id, title=title, error=not ok)

    def current_view(self) -> Optional[QWebEngineView]:
        return self.currentWidget()
