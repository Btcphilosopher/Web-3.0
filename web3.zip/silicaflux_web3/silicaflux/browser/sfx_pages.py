"""Renders the internal ``sfx://`` pages: a small, self-contained
"premium 2020s technology aesthetic" design system (spec section 16/29)
shared by every internal page, with page-specific content and, for
``sfx://runtime``, live-updating panels driven entirely through
``window.silicaflux.request({runtime: "internal", ...})`` — the same
bridge any other SilicaFlux application uses, just talking to the
browser-chrome operations registered in :mod:`silicaflux.browser.window`.
"""

from __future__ import annotations

_SHARED_STYLE = """
<style>
  :root {
    --bg: #0b0d12; --bg-elevated: #12151c; --border: #1f2430;
    --text: #e8eaf0; --text-dim: #8b93a7; --accent: #6ee7ff; --accent-2: #a78bfa;
    --good: #4ade80; --warn: #fbbf24; --bad: #f87171;
    --radius: 14px;
  }
  @media (prefers-color-scheme: light) {
    :root { --bg:#f6f7fb; --bg-elevated:#ffffff; --border:#e4e7ef; --text:#14161c; --text-dim:#5b6270; }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: radial-gradient(1200px 600px at 20% -10%, rgba(110,231,255,.08), transparent),
                            radial-gradient(1000px 500px at 100% 0%, rgba(167,139,250,.08), transparent), var(--bg);
    color: var(--text); font-family: -apple-system, "Segoe UI", Inter, Roboto, sans-serif;
    padding: 40px 48px 80px;
  }
  h1 { font-size: 28px; font-weight: 650; letter-spacing: -.02em; margin: 0 0 6px; }
  .subtitle { color: var(--text-dim); margin: 0 0 32px; font-size: 14px; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
  .card {
    background: var(--bg-elevated); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 18px 20px; transition: transform .15s ease, border-color .15s ease;
  }
  .card:hover { transform: translateY(-2px); border-color: var(--accent); }
  .card .label { color: var(--text-dim); font-size: 12px; text-transform: uppercase; letter-spacing: .08em; }
  .card .value { font-size: 26px; font-weight: 650; margin-top: 6px; background: linear-gradient(90deg, var(--accent), var(--accent-2));
                 -webkit-background-clip: text; background-clip: text; color: transparent; }
  .pill { display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 11px; font-weight: 600; letter-spacing: .02em; }
  .pill.ok { background: rgba(74,222,128,.15); color: var(--good); }
  .pill.off { background: rgba(248,113,113,.15); color: var(--bad); }
  table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }
  th, td { text-align: left; padding: 9px 12px; border-bottom: 1px solid var(--border); }
  th { color: var(--text-dim); font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: .06em; }
  a.tile { text-decoration: none; color: inherit; display: block; }
  .section { margin-top: 40px; }
  code { background: var(--border); padding: 2px 6px; border-radius: 6px; font-size: 12px; }
</style>
"""


def _page(title: str, body: str) -> str:
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{title} — SilicaFlux</title>{_SHARED_STYLE}</head>
<body>{body}</body></html>"""


def home_page() -> str:
    tiles = [
        ("sfx://apps", "Apps", "Installed SilicaFlux applications"),
        ("sfx://runtime", "Runtime", "Live packets, workers & system load"),
        ("sfx://wallet", "Wallet", "Web3 identity & connected sites"),
        ("sfx://history", "History", "Browsing history"),
        ("sfx://bookmarks", "Bookmarks", "Saved pages"),
        ("sfx://downloads", "Downloads", "Download manager"),
        ("sfx://settings", "Settings", "Appearance, privacy, runtimes"),
        ("sfx://developer", "Developer Tools", "Console, network, packets"),
    ]
    grid = "\n".join(
        f'<a class="tile" href="{href}"><div class="card"><div class="label">{name}</div>'
        f'<div style="margin-top:8px;color:var(--text-dim);font-size:13px">{desc}</div></div></a>'
        for href, name, desc in tiles
    )
    return _page(
        "Home",
        f"""
        <h1>SilicaFlux Web3.0</h1>
        <p class="subtitle">A standards-compatible browser with a Python/R/Rust/WASM packet runtime underneath.</p>
        <div class="grid">{grid}</div>
        """,
    )


def apps_page(apps: list[dict]) -> str:
    if not apps:
        rows = '<tr><td colspan="3" style="color:var(--text-dim)">No SilicaFlux applications installed yet.</td></tr>'
    else:
        rows = "\n".join(
            f"<tr><td>{a['name']}</td><td><code>{a['app_id']}</code></td><td>{a.get('manifest', {}).get('version','')}</td></tr>"
            for a in apps
        )
    return _page(
        "Apps",
        f"""
        <h1>SilicaFlux Applications</h1>
        <p class="subtitle">Web applications whose backend runs across Python, R, Rust and WASM.</p>
        <table><thead><tr><th>Name</th><th>ID</th><th>Version</th></tr></thead><tbody>{rows}</tbody></table>
        """,
    )


def runtime_page() -> str:
    return _page(
        "Runtime",
        """
        <h1>SilicaFlux Runtime</h1>
        <p class="subtitle">Live packet fabric, workers, cache and system load.</p>
        <div class="grid" id="stat-grid"></div>
        <div class="section">
          <h2 style="font-size:16px;">Runtimes</h2>
          <table id="runtime-table"><thead><tr><th>Runtime</th><th>Status</th></tr></thead><tbody></tbody></table>
        </div>
        <div class="section">
          <h2 style="font-size:16px;">Recent Packets</h2>
          <table id="packet-table">
            <thead><tr><th>Packet ID</th><th>Runtime</th><th>Operation</th><th>Priority</th><th>State</th><th>Queue (ms)</th><th>Exec (ms)</th></tr></thead>
            <tbody></tbody>
          </table>
        </div>
        <script>
        function fmt(n) { return (n === null || n === undefined) ? '—' : (typeof n === 'number' ? n.toFixed(2) : n); }
        function statCard(label, value) {
          return '<div class="card"><div class="label">' + label + '</div><div class="value">' + value + '</div></div>';
        }
        async function refresh() {
          try {
            const resp = await window.silicaflux.request({runtime: 'internal', operation: 'dashboard', payload: {}});
            if (!resp.ok) { return; }
            const d = resp.result;
            const sys = d.system || {};
            document.getElementById('stat-grid').innerHTML =
              statCard('CPU', sys.available ? sys.cpu_percent.toFixed(1) + '%' : 'n/a') +
              statCard('Memory', sys.available ? sys.memory_percent.toFixed(1) + '%' : 'n/a') +
              statCard('Queue Length', (d.engine && d.engine.queue_length) || 0) +
              statCard('In Flight', (d.engine && d.engine.in_flight) || 0);

            const runtimeRows = Object.entries(d.runtimes || {}).map(([name, ok]) =>
              '<tr><td>' + name + '</td><td><span class="pill ' + (ok ? 'ok">available' : 'off">unavailable') + '</span></td></tr>'
            ).join('');
            document.querySelector('#runtime-table tbody').innerHTML = runtimeRows;

            const packetRows = (d.recent_packets || []).slice().reverse().map(p =>
              '<tr><td><code>' + p.packet_id.slice(0,8) + '</code></td><td>' + p.runtime + '</td><td>' + p.operation +
              '</td><td>' + p.priority + '</td><td>' + p.state + '</td><td>' + fmt(p.queue_time ? p.queue_time*1000 : null) +
              '</td><td>' + fmt(p.execution_time ? p.execution_time*1000 : null) + '</td></tr>'
            ).join('');
            document.querySelector('#packet-table tbody').innerHTML = packetRows || '<tr><td colspan="7" style="color:var(--text-dim)">No packets yet.</td></tr>';
          } catch (e) { console.error('dashboard refresh failed', e); }
        }
        refresh();
        setInterval(refresh, 1500);
        </script>
        """,
    )


def wallet_page(accounts: list[dict]) -> str:
    if not accounts:
        rows = '<tr><td colspan="3" style="color:var(--text-dim)">No identities yet.</td></tr>'
    else:
        rows = "\n".join(
            f"<tr><td><code>{a['address'][:18]}…</code></td><td>{a['network']}</td><td><code>{a['identity_id'][:12]}…</code></td></tr>"
            for a in accounts
        )
    return _page(
        "Wallet",
        f"""
        <h1>SilicaFlux Wallet</h1>
        <p class="subtitle">Private keys never leave this device and are never sent to a webpage.</p>
        <table><thead><tr><th>Address</th><th>Network</th><th>Identity</th></tr></thead><tbody>{rows}</tbody></table>
        """,
    )


def settings_page() -> str:
    return _page(
        "Settings",
        """
        <h1>Settings</h1>
        <p class="subtitle">Appearance, privacy, security and per-runtime permissions.</p>
        <p style="color:var(--text-dim)">Full settings UI is available from the toolbar ⚙ menu.</p>
        """,
    )


def developer_page() -> str:
    return _page(
        "Developer Tools",
        """
        <h1>Developer Tools</h1>
        <p class="subtitle">Console, network panel, DOM/page info, SilicaFlux packets — open from the toolbar 🛠 menu.</p>
        """,
    )


PAGES = {
    "home": lambda ctx: home_page(),
    "apps": lambda ctx: apps_page(ctx.get("apps", [])),
    "runtime": lambda ctx: runtime_page(),
    "wallet": lambda ctx: wallet_page(ctx.get("accounts", [])),
    "settings": lambda ctx: settings_page(),
    "developer": lambda ctx: developer_page(),
}
