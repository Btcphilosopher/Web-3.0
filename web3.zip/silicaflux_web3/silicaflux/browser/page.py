"""``BrowserPage`` — a real ``QWebEnginePage`` wired to the SilicaFlux
bridge via ``QWebChannel``.

This is the module that actually requires PySide6 with the WebEngine
addon installed; everything it talks to below the Qt layer
(:class:`silicaflux.api.bridge.SilicaFluxBridge`,
:class:`silicaflux.core.tabs.TabManager`) is plain, toolkit-independent
Python, which is what keeps the headless core testable without a display.

The JS-facing contract: every page gets ``window.silicaflux.request({...})``
returning a Promise, backed by a ``QWebChannel`` object
(``sfxBridge``) whose one exposed slot accepts a JSON request string and a
JS callback. The shim script is injected at document-creation time so it
is available before any page script runs, on every navigation.
"""

from __future__ import annotations

import asyncio
import json
from typing import Callable, Optional

from PySide6.QtCore import QFile, QIODevice, QObject, QUrl, Signal, Slot
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineScript

from silicaflux.api.bridge import SilicaFluxBridge
from silicaflux.core.logging_setup import get_logger

logger = get_logger("browser.page")


def _load_qwebchannel_js() -> str:
    """Qt ships ``qwebchannel.js`` (the JS-side ``QWebChannel`` client
    class) as a Qt resource, registered once :mod:`PySide6.QtWebChannel`
    is imported — it is not automatically available to page JavaScript,
    so it must be injected the same way the bridge shim is."""
    qfile = QFile(":/qtwebchannel/qwebchannel.js")
    if not qfile.open(QIODevice.OpenModeFlag.ReadOnly):
        raise RuntimeError("could not read the bundled qwebchannel.js Qt resource")
    try:
        return bytes(qfile.readAll().data()).decode("utf-8")
    finally:
        qfile.close()

#: Injected before any page script runs (DocumentCreation, MainWorld) so
#: `window.silicaflux` is always defined, on every navigation, including
#: pages that don't know SilicaFlux exists (which simply never call it —
#: this is the "ordinary websites work unmodified" guarantee, spec
#: section 38).
_BRIDGE_SHIM_JS = """
(function() {
    if (window.silicaflux) { return; }
    window.silicaflux = {
        _pending: {},
        _seq: 0,
        _ready: new Promise(function(resolve) {
            if (typeof qt === 'undefined' || !qt.webChannelTransport) { resolve(false); return; }
            new QWebChannel(qt.webChannelTransport, function(channel) {
                window.silicaflux._backend = channel.objects.sfxBridge;
                resolve(true);
            });
        }),
        request: function(req) {
            return window.silicaflux._ready.then(function(ok) {
                if (!ok) { return Promise.reject(new Error('SilicaFlux bridge unavailable')); }
                return new Promise(function(resolve, reject) {
                    window.silicaflux._backend.request(JSON.stringify(req), function(resultJson) {
                        try { resolve(JSON.parse(resultJson)); }
                        catch (e) { reject(e); }
                    });
                });
            });
        }
    };
})();
"""


class SilicaFluxJSBridgeObject(QObject):
    """The ``QObject`` actually exposed to JavaScript as
    ``channel.objects.sfxBridge``. One instance per page, so ``origin``
    always reflects *that page's* current URL rather than being spoofable
    from the request payload."""

    def __init__(self, bridge: SilicaFluxBridge, origin_provider: Callable[[], str], parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
        self._bridge = bridge
        self._origin_provider = origin_provider

    @Slot(str, "QJSValue")
    def request(self, request_json: str, callback) -> None:  # noqa: ANN001 - QJSValue has no static type
        origin = self._origin_provider()

        async def _run() -> None:
            try:
                request = json.loads(request_json)
            except json.JSONDecodeError as exc:
                result = {"ok": False, "error": f"invalid request JSON: {exc}"}
            else:
                response = await self._bridge.request_dict(origin, request)
                result = response
            if callback.isCallable():
                callback.call([json.dumps(result)])

        asyncio.ensure_future(_run())


class BrowserPage(QWebEnginePage):
    """One tab's page. Emits Qt signals the tab widget listens to
    (title/icon/url/load-progress) and owns the ``QWebChannel`` that makes
    the SilicaFlux bridge reachable from this page's JavaScript context."""

    sfxLoadProgress = Signal(int)

    def __init__(self, bridge: SilicaFluxBridge, profile=None, parent: Optional[QObject] = None) -> None:
        super().__init__(profile, parent) if profile is not None else super().__init__(parent)
        self._bridge = bridge
        self._current_origin = "null"

        self._channel = QWebChannel(self)
        self._bridge_object = SilicaFluxJSBridgeObject(bridge, lambda: self._current_origin, self)
        self._channel.registerObject("sfxBridge", self._bridge_object)
        self.setWebChannel(self._channel)

        # Injection order matters: qwebchannel.js must define the
        # `QWebChannel` class before the shim script tries to instantiate
        # one, and both must run before any page script (DocumentCreation,
        # MainWorld) so `window.silicaflux` exists unconditionally.
        channel_script = QWebEngineScript()
        channel_script.setName("qwebchannel.js")
        channel_script.setSourceCode(_load_qwebchannel_js())
        channel_script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        channel_script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        channel_script.setRunsOnSubFrames(True)
        self.scripts().insert(channel_script)

        script = QWebEngineScript()
        script.setName("silicaflux-bridge-shim")
        script.setSourceCode(_BRIDGE_SHIM_JS)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        script.setRunsOnSubFrames(True)
        self.scripts().insert(script)

        self.urlChanged.connect(self._on_url_changed)
        self.loadProgress.connect(self.sfxLoadProgress.emit)

    def _on_url_changed(self, url: QUrl) -> None:
        from silicaflux.security.origins import parse_origin

        self._current_origin = str(parse_origin(url.toString()))

    @property
    def current_origin(self) -> str:
        return self._current_origin
