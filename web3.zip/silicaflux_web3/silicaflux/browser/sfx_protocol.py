"""The internal ``sfx://`` protocol (spec section 16): ``sfx://home``,
``sfx://apps``, ``sfx://runtime``, ``sfx://wallet``, ``sfx://settings``,
``sfx://developer``. Each page is plain HTML/CSS/JS served from a custom
``QWebEngineUrlSchemeHandler`` (no HTTP server, no filesystem round-trip)
that then talks to the *real* backend through the same
``window.silicaflux`` bridge every other page uses — the ``internal``
runtime namespace (see :mod:`silicaflux.api.bridge`), reachable only from
``sfx://`` origins.

:func:`register_sfx_scheme` must be called before the ``QApplication`` is
constructed — Qt requires custom URL schemes to be registered at
import/startup time, before any web engine profile exists.
"""

from __future__ import annotations

from typing import Callable

from PySide6.QtCore import QBuffer, QByteArray, QIODevice
from PySide6.QtWebEngineCore import QWebEngineUrlRequestJob, QWebEngineUrlScheme, QWebEngineUrlSchemeHandler

SFX_SCHEME = b"sfx"

PageProvider = Callable[[str], str]
"""``(page_name) -> html`` — e.g. "home" -> the home page's HTML."""


def register_sfx_scheme() -> None:
    if QWebEngineUrlScheme.schemeByName(SFX_SCHEME).name():
        return  # already registered (safe to call more than once)
    scheme = QWebEngineUrlScheme(SFX_SCHEME)
    scheme.setSyntax(QWebEngineUrlScheme.Syntax.Host)
    scheme.setFlags(
        QWebEngineUrlScheme.Flag.LocalAccessAllowed
        | QWebEngineUrlScheme.Flag.SecureScheme
        | QWebEngineUrlScheme.Flag.ContentSecurityPolicyIgnored
    )
    QWebEngineUrlScheme.registerScheme(scheme)


class SFXSchemeHandler(QWebEngineUrlSchemeHandler):
    def __init__(self, page_provider: PageProvider, parent=None) -> None:
        super().__init__(parent)
        self._page_provider = page_provider
        self._buffers: list[QBuffer] = []  # keep alive until the job consumes them

    def requestStarted(self, job: QWebEngineUrlRequestJob) -> None:
        host = job.requestUrl().host() or "home"
        try:
            html = self._page_provider(host)
        except Exception as exc:  # never crash the browser over a bad internal page
            html = f"<h1>sfx:// error</h1><pre>{exc}</pre>"
        data = QByteArray(html.encode("utf-8"))
        buf = QBuffer(self)
        buf.setData(data)
        buf.open(QIODevice.OpenModeFlag.ReadOnly)
        self._buffers.append(buf)
        buf.destroyed.connect(lambda: self._buffers.remove(buf) if buf in self._buffers else None)
        job.reply(b"text/html; charset=utf-8", buf)
