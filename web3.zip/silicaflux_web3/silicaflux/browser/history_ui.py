"""The History panel: search, delete-one, clear-all — backed by
:class:`silicaflux.storage.history.HistoryStore`."""

from __future__ import annotations

import asyncio
from typing import Callable, Optional

from PySide6.QtWidgets import QAbstractItemView, QDialog, QHBoxLayout, QLineEdit, QListWidget, QListWidgetItem, QPushButton, QVBoxLayout

from silicaflux.storage.history import HistoryStore


class HistoryPanel(QDialog):
    def __init__(self, store: HistoryStore, on_navigate: Optional[Callable[[str], None]] = None, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("History")
        self.resize(560, 420)
        self.store = store
        self.on_navigate = on_navigate

        layout = QVBoxLayout(self)
        search_row = QHBoxLayout()
        self.search_box = QLineEdit(self)
        self.search_box.setPlaceholderText("Search history")
        self.search_box.textChanged.connect(self._search)
        clear_button = QPushButton("Clear All")
        clear_button.clicked.connect(self._clear_all)
        search_row.addWidget(self.search_box, 1)
        search_row.addWidget(clear_button)
        layout.addLayout(search_row)

        self.list_widget = QListWidget(self)
        self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.list_widget.itemDoubleClicked.connect(self._on_item_activated)
        layout.addWidget(self.list_widget)

        delete_button = QPushButton("Delete Selected")
        delete_button.clicked.connect(self._delete_selected)
        layout.addWidget(delete_button)

        self._entries: dict[int, int] = {}  # list row -> history entry id
        asyncio.ensure_future(self._load())

    async def _load(self, query: str = "") -> None:
        entries = await self.store.search(query)
        self.list_widget.clear()
        self._entries.clear()
        for entry in entries:
            item = QListWidgetItem(f"{entry.title or entry.url}  —  {entry.url}  (visits: {entry.visit_count})")
            row = self.list_widget.count()
            self.list_widget.addItem(item)
            self._entries[row] = entry.id
            item.setData(256, entry.url)  # Qt.UserRole == 256

    def _search(self, text: str) -> None:
        asyncio.ensure_future(self._load(text))

    def _on_item_activated(self, item: QListWidgetItem) -> None:
        url = item.data(256)
        if url and self.on_navigate:
            self.on_navigate(url)

    def _delete_selected(self) -> None:
        row = self.list_widget.currentRow()
        if row in self._entries:
            asyncio.ensure_future(self._delete(self._entries[row]))

    async def _delete(self, entry_id: int) -> None:
        await self.store.delete(entry_id)
        await self._load(self.search_box.text())

    def _clear_all(self) -> None:
        asyncio.ensure_future(self._clear())

    async def _clear(self) -> None:
        await self.store.clear()
        await self._load()
