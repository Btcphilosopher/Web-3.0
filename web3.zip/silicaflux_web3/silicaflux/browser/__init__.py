"""The PySide6/QtWebEngine desktop browser shell.

This is the one subpackage that requires PySide6 (with the WebEngine
addon) to be installed — nothing else in :mod:`silicaflux` does. Nothing
is imported here at package level so that ``import silicaflux`` and every
other subpackage stay usable in a headless environment with no GUI
toolkit installed at all; import ``silicaflux.browser.window`` (or run
the top-level ``main.py``) only when you actually intend to launch the
GUI.
"""

from __future__ import annotations
