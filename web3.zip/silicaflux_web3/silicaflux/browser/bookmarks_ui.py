"""The Bookmarks panel: add/remove/edit/search/folders/import/export —
backed by :class:`silicaflux.storage.bookmarks.BookmarksStore`."""

from __future__ import annotations

import asyncio
import json
from typing import Callable, Optional

from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
)

from silicaflux.storage.bookmarks import BookmarksStore


class BookmarksPanel(QDialog):
    def __init__(self, store: BookmarksStore, on_navigate: Optional[Callable[[str], None]] = None, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Bookmarks")
        self.resize(560, 420)
        self.store = store
        self.on_navigate = on_navigate

        layout = QVBoxLayout(self)
        search_row = QHBoxLayout()
        self.search_box = QLineEdit(self)
        self.search_box.setPlaceholderText("Search bookmarks")
        self.search_box.textChanged.connect(self._search)
        search_row.addWidget(self.search_box, 1)
        layout.addLayout(search_row)

        self.list_widget = QListWidget(self)
        self.list_widget.itemDoubleClicked.connect(self._on_item_activated)
        layout.addWidget(self.list_widget)

        button_row = QHBoxLayout()
        add_button = QPushButton("Add…")
        add_button.clicked.connect(self._add_bookmark)
        remove_button = QPushButton("Remove Selected")
        remove_button.clicked.connect(self._remove_selected)
        export_button = QPushButton("Export…")
        export_button.clicked.connect(self._export)
        import_button = QPushButton("Import…")
        import_button.clicked.connect(self._import)
        for b in (add_button, remove_button, export_button, import_button):
            button_row.addWidget(b)
        layout.addLayout(button_row)

        self._entries: dict[int, int] = {}
        asyncio.ensure_future(self._load())

    async def _load(self, query: str = "") -> None:
        bookmarks = await self.store.list(query=query)
        self.list_widget.clear()
        self._entries.clear()
        for bm in bookmarks:
            item = QListWidgetItem(f"{bm.title or bm.url}  [{bm.folder}]")
            row = self.list_widget.count()
            self.list_widget.addItem(item)
            self._entries[row] = bm.id
            item.setData(256, bm.url)

    def _search(self, text: str) -> None:
        asyncio.ensure_future(self._load(text))

    def _on_item_activated(self, item: QListWidgetItem) -> None:
        url = item.data(256)
        if url and self.on_navigate:
            self.on_navigate(url)

    def _add_bookmark(self) -> None:
        url, ok = QInputDialog.getText(self, "Add Bookmark", "URL:")
        if not ok or not url:
            return
        title, _ = QInputDialog.getText(self, "Add Bookmark", "Title:")
        asyncio.ensure_future(self._add(url, title))

    async def _add(self, url: str, title: str) -> None:
        await self.store.add(url, title)
        await self._load(self.search_box.text())

    def _remove_selected(self) -> None:
        row = self.list_widget.currentRow()
        if row in self._entries:
            asyncio.ensure_future(self._remove(self._entries[row]))

    async def _remove(self, bookmark_id: int) -> None:
        await self.store.remove(bookmark_id)
        await self._load(self.search_box.text())

    def _export(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export Bookmarks", "bookmarks.json", "JSON (*.json)")
        if path:
            asyncio.ensure_future(self._do_export(path))

    async def _do_export(self, path: str) -> None:
        data = await self.store.export_json()
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    def _import(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import Bookmarks", "", "JSON (*.json)")
        if path:
            asyncio.ensure_future(self._do_import(path))

    async def _do_import(self, path: str) -> None:
        with open(path) as f:
            data = json.load(f)
        await self.store.import_json(data)
        await self._load()
