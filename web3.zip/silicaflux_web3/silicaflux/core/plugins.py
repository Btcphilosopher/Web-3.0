"""Minimal plugin architecture.

A SilicaFlux plugin is any object exposing a ``register(engine)`` function
or callable. Plugins can subscribe to the :class:`~silicaflux.core.events.EventBus`,
register additional runtime adapters, or add ``sfx://`` pages — anything
reachable from the injected :class:`~silicaflux.core.engine.SilicaFluxEngine`.
Discovery supports two mechanisms: explicit in-process registration
(:meth:`PluginManager.register`) and, optionally, Python entry points under
the ``silicaflux.plugins`` group for installable third-party packages.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Protocol

from silicaflux.core.logging_setup import get_logger

logger = get_logger("core.plugins")


class Plugin(Protocol):
    name: str

    def register(self, engine: Any) -> None: ...


@dataclass
class PluginRecord:
    name: str
    plugin: Any
    enabled: bool = True
    error: Optional[str] = None


class PluginManager:
    def __init__(self) -> None:
        self._plugins: dict[str, PluginRecord] = {}

    def register(self, plugin: Plugin) -> PluginRecord:
        name = getattr(plugin, "name", plugin.__class__.__name__)
        record = PluginRecord(name, plugin)
        self._plugins[name] = record
        return record

    def load_entry_points(self, engine: Any, group: str = "silicaflux.plugins") -> list[PluginRecord]:
        """Discover and activate installed plugins registered under the
        ``silicaflux.plugins`` entry-point group. Safe to call even if no
        such plugins are installed (returns an empty list)."""
        loaded: list[PluginRecord] = []
        try:
            from importlib.metadata import entry_points

            eps = entry_points(group=group)
        except Exception:
            return loaded
        for ep in eps:
            try:
                factory = ep.load()
                plugin = factory() if callable(factory) else factory
                record = self.register(plugin)
                loaded.append(record)
            except Exception as exc:
                logger.error(f"failed to load plugin entry point '{ep.name}': {exc}")
        if loaded:
            self.activate_all(engine)
        return loaded

    def activate_all(self, engine: Any) -> None:
        for record in self._plugins.values():
            if not record.enabled:
                continue
            try:
                record.plugin.register(engine)
                logger.info(f"plugin '{record.name}' activated")
            except Exception as exc:
                record.enabled = False
                record.error = str(exc)
                logger.exception(f"plugin '{record.name}' failed to activate; disabling")

    def list(self) -> list[PluginRecord]:
        return list(self._plugins.values())
