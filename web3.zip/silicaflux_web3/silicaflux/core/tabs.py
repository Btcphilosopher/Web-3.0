"""Headless tab model.

This is the data/behaviour layer for browser tabs, independent of any GUI
toolkit. :mod:`silicaflux.browser.tabs` (PySide6) wraps this with actual
``QWebEngineView`` widgets; :class:`TabManager` is exactly as useful in a
unit test or the CLI (``sfx-browser inspect``) as it is behind the GUI.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from silicaflux.core.events import EventBus
from silicaflux.core.logging_setup import get_logger
from silicaflux.core.navigation import NavigationManager

logger = get_logger("core.tabs")


class LoadState(str, Enum):
    IDLE = "idle"
    LOADING = "loading"
    LOADED = "loaded"
    ERROR = "error"


@dataclass
class Tab:
    tab_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    url: str = "sfx://home"
    title: str = "New Tab"
    favicon: Optional[str] = None
    pinned: bool = False
    private: bool = False
    load_state: LoadState = LoadState.IDLE
    created_at: float = field(default_factory=time.time)
    navigation: NavigationManager = field(default_factory=NavigationManager)
    #: arbitrary per-tab state (scroll position, form data, zoom, ...)
    state: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "tab_id": self.tab_id,
            "url": self.url,
            "title": self.title,
            "favicon": self.favicon,
            "pinned": self.pinned,
            "private": self.private,
            "load_state": self.load_state.value,
            "can_go_back": self.navigation.can_go_back(),
            "can_go_forward": self.navigation.can_go_forward(),
        }


class TabManager:
    """Owns the ordered list of open tabs for one browser window/profile,
    plus a bounded stack of recently-closed tabs for "restore closed tab".
    """

    def __init__(self, events: Optional[EventBus] = None, max_closed_history: int = 25) -> None:
        self.events = events or EventBus()
        self._tabs: list[Tab] = []
        self._active_id: Optional[str] = None
        self._closed_stack: list[tuple[Tab, int]] = []
        self._max_closed_history = max_closed_history

    # -- CRUD ------------------------------------------------------------
    def new_tab(self, url: str = "sfx://home", *, private: bool = False, background: bool = False) -> Tab:
        tab = Tab(url=url, private=private)
        tab.navigation.navigate(url)
        self._tabs.append(tab)
        if not background or self._active_id is None:
            self._active_id = tab.tab_id
        self.events.emit("tab.created", tab.to_dict(), source="tabs")
        logger.info(f"tab created ({'private' if private else 'normal'})")
        return tab

    def duplicate_tab(self, tab_id: str) -> Optional[Tab]:
        original = self.get(tab_id)
        if not original:
            return None
        new = self.new_tab(original.url, private=original.private)
        new.title = original.title
        new.pinned = original.pinned
        return new

    def close_tab(self, tab_id: str) -> bool:
        idx = self._index_of(tab_id)
        if idx is None:
            return False
        tab = self._tabs.pop(idx)
        if not tab.private:
            self._closed_stack.append((tab, idx))
            if len(self._closed_stack) > self._max_closed_history:
                self._closed_stack.pop(0)
        if self._active_id == tab_id:
            self._active_id = self._tabs[max(0, idx - 1)].tab_id if self._tabs else None
        self.events.emit("tab.closed", {"tab_id": tab_id}, source="tabs")
        return True

    def restore_closed_tab(self) -> Optional[Tab]:
        if not self._closed_stack:
            return None
        tab, idx = self._closed_stack.pop()
        idx = min(idx, len(self._tabs))
        self._tabs.insert(idx, tab)
        self._active_id = tab.tab_id
        self.events.emit("tab.restored", tab.to_dict(), source="tabs")
        return tab

    def reorder(self, tab_id: str, new_index: int) -> bool:
        idx = self._index_of(tab_id)
        if idx is None:
            return False
        tab = self._tabs.pop(idx)
        new_index = max(0, min(new_index, len(self._tabs)))
        self._tabs.insert(new_index, tab)
        return True

    def pin(self, tab_id: str, pinned: bool = True) -> bool:
        tab = self.get(tab_id)
        if not tab:
            return False
        tab.pinned = pinned
        return True

    # -- lookup ------------------------------------------------------
    def get(self, tab_id: str) -> Optional[Tab]:
        return next((t for t in self._tabs if t.tab_id == tab_id), None)

    def _index_of(self, tab_id: str) -> Optional[int]:
        for i, t in enumerate(self._tabs):
            if t.tab_id == tab_id:
                return i
        return None

    @property
    def active_tab(self) -> Optional[Tab]:
        return self.get(self._active_id) if self._active_id else None

    def activate(self, tab_id: str) -> bool:
        if self.get(tab_id) is None:
            return False
        self._active_id = tab_id
        self.events.emit("tab.activated", {"tab_id": tab_id}, source="tabs")
        return True

    def all_tabs(self) -> list[Tab]:
        return list(self._tabs)

    def __len__(self) -> int:
        return len(self._tabs)

    # -- navigation convenience ---------------------------------------
    def navigate(self, tab_id: str, url: str, title: str = "") -> bool:
        tab = self.get(tab_id)
        if not tab:
            return False
        tab.url = url
        tab.load_state = LoadState.LOADING
        tab.navigation.navigate(url, title)
        self.events.emit("tab.navigating", {"tab_id": tab_id, "url": url}, source="tabs")
        return True

    def finish_load(self, tab_id: str, *, title: Optional[str] = None, error: bool = False) -> None:
        tab = self.get(tab_id)
        if not tab:
            return
        tab.load_state = LoadState.ERROR if error else LoadState.LOADED
        if title:
            tab.title = title
            tab.navigation.update_current_title(title)
        self.events.emit("tab.loaded", tab.to_dict(), source="tabs")
