"""The Python Execution Graph (spec Phase 4).

A SilicaFlux application is representable as a DAG of typed nodes, each
targeting one runtime:

    INPUT -> TASK -> PYTHON -> R -> RUST/WASM -> PYTHON -> JAVASCRIPT -> HTML

:class:`ExecutionGraph` resolves dependencies, runs independent nodes in
parallel (bounded by a concurrency limit), propagates failures to
downstream nodes, retries per-node on failure up to ``max_retries``, and
exposes a JSON-serialisable description (:meth:`ExecutionGraph.to_dict`)
that a future graph-visualisation UI can render directly.

Execution itself is delegated to an injected ``executor`` callable so this
module has no direct dependency on the runtime adapters — tests can run a
graph with a trivial in-process executor, while
:class:`silicaflux.core.engine.SilicaFluxEngine` wires in one backed by the
real :class:`~silicaflux.core.router.RuntimeRouter`.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable, Optional

from silicaflux.core.logging_setup import get_logger

logger = get_logger("core.graph")

NodeExecutor = Callable[["Node", dict[str, Any]], Awaitable[Any]]


class NodeState(str, Enum):
    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"


class GraphCycleError(RuntimeError):
    pass


@dataclass
class Node:
    """One task in the execution graph."""

    id: str
    runtime: str
    function: str
    inputs: dict[str, Any] = field(default_factory=dict)  # literal values or {"$ref": "<node_id>"}
    dependencies: frozenset[str] = field(default_factory=frozenset)
    priority: int = 3
    memory_mb: Optional[int] = None
    cpu_cores: Optional[float] = None
    gpu: bool = False
    timeout_s: float = 30.0
    security_context: Optional[dict] = None
    cache_policy: str = "default"  # "default" | "never" | "force_refresh"
    max_retries: int = 0

    state: NodeState = NodeState.PENDING
    result: Any = None
    error: Optional[str] = None
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    retry_count: int = 0

    def duration(self) -> Optional[float]:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "runtime": self.runtime,
            "function": self.function,
            "dependencies": sorted(self.dependencies),
            "priority": self.priority,
            "state": self.state.value,
            "duration_s": self.duration(),
            "error": self.error,
            "retry_count": self.retry_count,
        }


class ExecutionGraph:
    """A DAG of :class:`Node` objects. Build with :meth:`add_node`, then
    run with :meth:`run`."""

    def __init__(self, graph_id: str = "graph", max_parallel: int = 8) -> None:
        self.graph_id = graph_id
        self.nodes: dict[str, Node] = {}
        self.max_parallel = max_parallel
        self._created_at = time.time()

    def add_node(self, node: Node) -> "ExecutionGraph":
        if node.id in self.nodes:
            raise ValueError(f"duplicate node id '{node.id}'")
        self.nodes[node.id] = node
        return self

    def add_task(
        self,
        id: str,
        runtime: str,
        function: str,
        inputs: Optional[dict[str, Any]] = None,
        depends_on: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> "ExecutionGraph":
        deps = frozenset(depends_on or [])
        return self.add_node(Node(id=id, runtime=runtime, function=function, inputs=inputs or {}, dependencies=deps, **kwargs))

    def validate(self) -> None:
        for node in self.nodes.values():
            for dep in node.dependencies:
                if dep not in self.nodes:
                    raise ValueError(f"node '{node.id}' depends on unknown node '{dep}'")
        self._topological_order()  # raises GraphCycleError if cyclic

    def _topological_order(self) -> list[str]:
        visited: dict[str, int] = {}  # 0=visiting,1=done
        order: list[str] = []

        def visit(node_id: str, stack: tuple[str, ...]) -> None:
            state = visited.get(node_id)
            if state == 1:
                return
            if state == 0:
                raise GraphCycleError(f"cycle detected: {' -> '.join(stack + (node_id,))}")
            visited[node_id] = 0
            for dep in self.nodes[node_id].dependencies:
                visit(dep, stack + (node_id,))
            visited[node_id] = 1
            order.append(node_id)

        for node_id in self.nodes:
            visit(node_id, ())
        return order

    def _resolve_inputs(self, node: Node) -> dict[str, Any]:
        resolved = {}
        for key, value in node.inputs.items():
            if isinstance(value, dict) and set(value.keys()) == {"$ref"}:
                ref_node = self.nodes[value["$ref"]]
                resolved[key] = ref_node.result
            else:
                resolved[key] = value
        return resolved

    async def run(self, executor: NodeExecutor, cache: Optional[Any] = None) -> dict[str, Node]:
        """Execute the graph to completion. ``cache`` may be a
        :class:`silicaflux.cache.computation_cache.ComputationCache` used
        to skip deterministic nodes whose (function, resolved inputs) hash
        has already been computed; nodes with ``cache_policy == "never"``
        always execute."""
        self.validate()
        semaphore = asyncio.Semaphore(self.max_parallel)
        pending = set(self.nodes.keys())
        running: dict[str, asyncio.Task] = {}

        def ready_nodes() -> list[str]:
            return [
                nid
                for nid in pending
                if nid not in running
                and all(self.nodes[d].state in (NodeState.COMPLETED, NodeState.FAILED, NodeState.SKIPPED) for d in self.nodes[nid].dependencies)
            ]

        async def run_node(node_id: str) -> None:
            node = self.nodes[node_id]
            if any(self.nodes[d].state in (NodeState.FAILED, NodeState.SKIPPED, NodeState.CANCELLED) for d in node.dependencies):
                node.state = NodeState.SKIPPED
                node.error = "upstream dependency failed"
                logger.warning(f"node '{node_id}' skipped: {node.error}")
                return
            async with semaphore:
                node.state = NodeState.RUNNING
                node.started_at = time.time()
                resolved_inputs = self._resolve_inputs(node)
                attempt = 0
                while True:
                    try:
                        cache_key = None
                        if cache is not None and node.cache_policy != "never":
                            cache_key = cache.make_key(node.function, resolved_inputs)
                            if node.cache_policy != "force_refresh":
                                hit = cache.get(cache_key)
                                if hit is not None:
                                    node.result = hit
                                    node.state = NodeState.COMPLETED
                                    node.finished_at = time.time()
                                    return
                        node.result = await asyncio.wait_for(executor(node, resolved_inputs), timeout=node.timeout_s)
                        if cache is not None and cache_key is not None:
                            cache.set(cache_key, node.result)
                        node.state = NodeState.COMPLETED
                        node.finished_at = time.time()
                        return
                    except asyncio.CancelledError:
                        node.state = NodeState.CANCELLED
                        node.finished_at = time.time()
                        raise
                    except Exception as exc:
                        attempt += 1
                        node.retry_count = attempt
                        if attempt <= node.max_retries:
                            logger.warning(f"node '{node_id}' failed (attempt {attempt}), retrying: {exc}")
                            continue
                        node.error = str(exc)
                        node.state = NodeState.FAILED
                        node.finished_at = time.time()
                        logger.error(f"node '{node_id}' failed permanently: {exc}")
                        return

        while pending:
            newly_ready = [n for n in ready_nodes() if self.nodes[n].state == NodeState.PENDING]
            for node_id in newly_ready:
                self.nodes[node_id].state = NodeState.READY
                running[node_id] = asyncio.create_task(run_node(node_id))
            if not running:
                break
            done, _ = await asyncio.wait(running.values(), return_when=asyncio.FIRST_COMPLETED)
            finished_ids = [nid for nid, task in running.items() if task in done]
            for nid in finished_ids:
                running.pop(nid)
                pending.discard(nid)

        return self.nodes

    def to_dict(self) -> dict:
        """Graph visualisation data API: nodes + edges, ready for a
        frontend renderer."""
        return {
            "graph_id": self.graph_id,
            "created_at": self._created_at,
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [
                {"from": dep, "to": node.id}
                for node in self.nodes.values()
                for dep in node.dependencies
            ],
        }
