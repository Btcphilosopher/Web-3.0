"""
SFXPacket — the central SilicaFlux abstraction.

Every unit of work that crosses the SilicaFlux bridge (a JavaScript
``silicaflux.request(...)`` call, an internal browser subsystem asking the
scheduler for CPU time, a Web3 signature request) is represented as an
:class:`SFXPacket`. Packets are immutable *requests* plus mutable *lifecycle
state*; the packet fabric (router + scheduler + workers, see
:mod:`silicaflux.core.router`, :mod:`silicaflux.core.scheduler` and
:mod:`silicaflux.core.workers`) moves a packet through a well-defined state
machine and never mutates the request payload in place.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional


class PacketState(str, Enum):
    """Lifecycle states a packet moves through inside the packet fabric."""

    CREATED = "created"
    QUEUED = "queued"
    ROUTED = "routed"
    EXECUTING = "executing"
    STREAMING = "streaming"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

    @property
    def is_terminal(self) -> bool:
        return self in (PacketState.COMPLETED, PacketState.FAILED, PacketState.CANCELLED)


#: Legal forward transitions. The fabric refuses any transition not listed
#: here, so a packet can never silently jump states (e.g. CREATED ->
#: COMPLETED without ever being routed/executed).
_LEGAL_TRANSITIONS: dict[PacketState, tuple[PacketState, ...]] = {
    PacketState.CREATED: (PacketState.QUEUED, PacketState.CANCELLED, PacketState.FAILED),
    PacketState.QUEUED: (PacketState.ROUTED, PacketState.CANCELLED, PacketState.FAILED),
    PacketState.ROUTED: (PacketState.EXECUTING, PacketState.CANCELLED, PacketState.FAILED),
    PacketState.EXECUTING: (
        PacketState.STREAMING,
        PacketState.COMPLETED,
        PacketState.FAILED,
        PacketState.CANCELLED,
        PacketState.QUEUED,  # re-queued for a retry attempt, see core.engine
    ),
    PacketState.STREAMING: (PacketState.COMPLETED, PacketState.FAILED, PacketState.CANCELLED),
    PacketState.COMPLETED: (),
    PacketState.FAILED: (),
    PacketState.CANCELLED: (),
}


class IllegalPacketTransition(RuntimeError):
    """Raised when the fabric attempts an illegal packet state transition."""


class PacketPriority(str, Enum):
    """Scheduling priority classes, highest first. See
    :mod:`silicaflux.core.scheduler` for how these influence ordering."""

    CRITICAL = "critical"
    INTERACTIVE = "interactive"
    REALTIME = "realtime"
    NORMAL = "normal"
    BACKGROUND = "background"
    BULK = "bulk"

    @property
    def weight(self) -> int:
        """Lower number == serviced first."""
        return _PRIORITY_WEIGHTS[self]


_PRIORITY_WEIGHTS: dict[PacketPriority, int] = {
    PacketPriority.CRITICAL: 0,
    PacketPriority.INTERACTIVE: 1,
    PacketPriority.REALTIME: 2,
    PacketPriority.NORMAL: 3,
    PacketPriority.BACKGROUND: 4,
    PacketPriority.BULK: 5,
}


@dataclass
class SecurityContext:
    """Carries the information the security layer needs to authorize a
    packet before a worker is allowed to touch it. See
    :mod:`silicaflux.security.policy`."""

    origin: str
    capabilities: frozenset[str] = field(default_factory=frozenset)
    capability_token: Optional[str] = None
    sandboxed: bool = True
    user_approved: bool = False


@dataclass
class PacketEvent:
    """One entry in a packet's audit trail."""

    state: PacketState
    timestamp: float
    detail: str = ""


@dataclass
class SFXPacket:
    """A single unit of work travelling through the SilicaFlux packet fabric.

    Attributes mirror section 8 of the specification: identity, routing,
    payload, lifecycle and observability fields all live on one object so
    the developer tools panel (:mod:`silicaflux.developer.inspector`) can
    render a packet's full life story from one record.
    """

    source: str
    destination: str
    runtime: str
    operation: str
    payload: Any = None
    priority: PacketPriority = PacketPriority.NORMAL
    security_context: Optional[SecurityContext] = None
    ttl: float = 30.0
    metadata: dict[str, Any] = field(default_factory=dict)

    packet_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    timestamp: float = field(default_factory=time.time)
    state: PacketState = PacketState.CREATED

    result: Any = None
    error: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 0

    history: list[PacketEvent] = field(default_factory=list)
    on_stream: Optional[Callable[["SFXPacket", Any], None]] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self.history.append(PacketEvent(self.state, self.timestamp, "packet created"))

    # -- lifecycle -----------------------------------------------------
    def transition(self, new_state: PacketState, detail: str = "") -> "SFXPacket":
        """Advance the packet's state machine, recording an audit entry.

        Raises :class:`IllegalPacketTransition` if the move isn't legal,
        which is what keeps the fabric's telemetry trustworthy: a packet
        that reads COMPLETED really did pass through EXECUTING first.
        """
        legal = _LEGAL_TRANSITIONS[self.state]
        if new_state not in legal:
            raise IllegalPacketTransition(
                f"packet {self.packet_id}: cannot go {self.state.value} -> {new_state.value}"
            )
        self.state = new_state
        self.history.append(PacketEvent(new_state, time.time(), detail))
        return self

    def is_expired(self, now: Optional[float] = None) -> bool:
        now = now if now is not None else time.time()
        return (now - self.timestamp) > self.ttl

    def elapsed(self, now: Optional[float] = None) -> float:
        now = now if now is not None else time.time()
        return now - self.timestamp

    def queue_time(self) -> Optional[float]:
        created = next((e for e in self.history if e.state == PacketState.CREATED), None)
        routed = next((e for e in self.history if e.state == PacketState.ROUTED), None)
        if created and routed:
            return routed.timestamp - created.timestamp
        return None

    def execution_time(self) -> Optional[float]:
        started = next((e for e in self.history if e.state == PacketState.EXECUTING), None)
        ended = next(
            (e for e in self.history if e.state in (PacketState.COMPLETED, PacketState.FAILED)),
            None,
        )
        if started and ended:
            return ended.timestamp - started.timestamp
        return None

    def total_latency(self) -> Optional[float]:
        if self.state.is_terminal:
            return self.history[-1].timestamp - self.history[0].timestamp
        return None

    def can_retry(self) -> bool:
        return self.retry_count < self.max_retries

    def to_dict(self) -> dict[str, Any]:
        """JSON-serialisable summary used by the developer tools panel and
        the ``sfx-runtime packets`` CLI command."""
        return {
            "packet_id": self.packet_id,
            "trace_id": self.trace_id,
            "source": self.source,
            "destination": self.destination,
            "runtime": self.runtime,
            "operation": self.operation,
            "priority": self.priority.value,
            "state": self.state.value,
            "timestamp": self.timestamp,
            "ttl": self.ttl,
            "retry_count": self.retry_count,
            "queue_time": self.queue_time(),
            "execution_time": self.execution_time(),
            "total_latency": self.total_latency(),
            "error": self.error,
            "metadata": self.metadata,
        }
