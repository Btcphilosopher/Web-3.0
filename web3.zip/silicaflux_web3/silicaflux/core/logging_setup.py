"""Structured logging for SilicaFlux.

Every log record can carry packet/runtime/operation/duration context so
that logs, the developer console (:mod:`silicaflux.developer.console`) and
the telemetry system (:mod:`silicaflux.telemetry`) all describe the same
events in the same vocabulary.
"""

from __future__ import annotations

import json
import logging
import sys
import time
from typing import Any, Optional

_CONFIGURED = False


class StructuredFormatter(logging.Formatter):
    """Renders log records as single-line JSON with SilicaFlux context
    fields (component, packet_id, runtime, operation, duration_ms, error)
    pulled out of ``extra=...`` when present."""

    CONTEXT_FIELDS = (
        "component",
        "packet_id",
        "trace_id",
        "runtime",
        "operation",
        "duration_ms",
        "origin",
    )

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": round(record.created, 6),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for field in self.CONTEXT_FIELDS:
            value = getattr(record, field, None)
            if value is not None:
                payload[field] = value
        if record.exc_info:
            payload["error"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


class HumanFormatter(logging.Formatter):
    """Readable console formatter used by the CLIs; falls back to
    :class:`StructuredFormatter`'s fields when present."""

    def format(self, record: logging.LogRecord) -> str:
        ts = time.strftime("%H:%M:%S", time.localtime(record.created))
        bits = [f"{ts}", f"{record.levelname:<8}", f"{record.name:<28}", record.getMessage()]
        extras = []
        for field in ("packet_id", "runtime", "operation", "duration_ms"):
            value = getattr(record, field, None)
            if value is not None:
                extras.append(f"{field}={value}")
        line = " ".join(bits)
        if extras:
            line += "  (" + " ".join(extras) + ")"
        if record.exc_info:
            line += "\n" + self.formatException(record.exc_info)
        return line


def configure_logging(
    level: int = logging.INFO,
    *,
    structured: bool = False,
    stream: Optional[Any] = None,
) -> None:
    """Idempotently configure the root ``silicaflux`` logger tree.

    Safe to call multiple times (e.g. once from the CLI, once from tests);
    only the first call takes effect unless ``force`` semantics are needed,
    in which case call :func:`reset_logging` first.
    """
    global _CONFIGURED
    if _CONFIGURED:
        return
    handler = logging.StreamHandler(stream or sys.stderr)
    handler.setFormatter(StructuredFormatter() if structured else HumanFormatter())
    root = logging.getLogger("silicaflux")
    root.setLevel(level)
    root.handlers.clear()
    root.addHandler(handler)
    root.propagate = False
    _CONFIGURED = True


def reset_logging() -> None:
    global _CONFIGURED
    logging.getLogger("silicaflux").handlers.clear()
    _CONFIGURED = False


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced ``silicaflux.<name>`` logger, configuring
    default logging on first use so importers never need to remember to
    call :func:`configure_logging` themselves."""
    if not _CONFIGURED:
        configure_logging()
    return logging.getLogger(f"silicaflux.{name}")


class LogTimer:
    """Context manager that logs an INFO record with ``duration_ms`` on
    exit — used throughout the runtime/telemetry code instead of manual
    ``time.time()`` bookkeeping."""

    def __init__(self, logger: logging.Logger, message: str, **context: Any) -> None:
        self.logger = logger
        self.message = message
        self.context = context
        self._start = 0.0

    def __enter__(self) -> "LogTimer":
        self._start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        duration_ms = round((time.perf_counter() - self._start) * 1000, 3)
        extra = dict(self.context)
        extra["duration_ms"] = duration_ms
        if exc_type is not None:
            self.logger.error(f"{self.message} failed: {exc}", extra=extra)
        else:
            self.logger.info(self.message, extra=extra)
