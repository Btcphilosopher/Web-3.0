"""Browser configuration system.

Settings are layered: built-in defaults (:mod:`silicaflux.config.defaults`)
< a JSON file on disk < explicit overrides passed at construction time.
Values are validated with :mod:`pydantic` so a malformed settings file
produces a clear error instead of a mysterious ``KeyError`` three modules
away.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

from silicaflux.config.defaults import DEFAULT_SETTINGS
from silicaflux.core.logging_setup import get_logger

logger = get_logger("core.config")


class PrivacySettings(BaseModel):
    block_third_party_cookies: bool = False
    do_not_track: bool = True
    clear_on_exit: bool = False


class SecuritySettings(BaseModel):
    require_https_upgrade: bool = True
    block_popups: bool = True
    verify_certificates: bool = True
    default_capability_policy: Literal["deny", "prompt", "allow"] = "prompt"


class RuntimeSettings(BaseModel):
    python_enabled: bool = True
    r_enabled: bool = True
    rust_enabled: bool = True
    wasm_enabled: bool = True
    javascript_bridge_enabled: bool = True
    python_worker_timeout_s: float = 10.0
    python_worker_memory_mb: int = 256


class AppearanceSettings(BaseModel):
    theme: Literal["light", "dark", "system"] = "system"
    compact_toolbar: bool = True
    animations: bool = True


class DownloadSettings(BaseModel):
    directory: str = str(Path.home() / "Downloads" / "SilicaFlux")
    ask_where_to_save: bool = False
    auto_execute: bool = False  # never allowed to be True by policy, see security/policy.py


class Settings(BaseModel):
    """Root settings object persisted to ``settings.json`` inside the
    active profile directory and mirrored into the SQLite settings table
    (:mod:`silicaflux.storage.settings`) for fast, transactional access
    from the developer tools and CLI."""

    homepage: str = "sfx://home"
    search_engine: str = "https://duckduckgo.com/?q={query}"
    appearance: AppearanceSettings = Field(default_factory=AppearanceSettings)
    privacy: PrivacySettings = Field(default_factory=PrivacySettings)
    security: SecuritySettings = Field(default_factory=SecuritySettings)
    runtimes: RuntimeSettings = Field(default_factory=RuntimeSettings)
    downloads: DownloadSettings = Field(default_factory=DownloadSettings)
    extra: dict[str, Any] = Field(default_factory=dict)

    model_config = {"validate_assignment": True}


class ConfigurationSystem:
    """Loads, validates, persists and hot-reloads :class:`Settings`."""

    def __init__(self, profile_dir: Path, overrides: Optional[dict[str, Any]] = None) -> None:
        self.profile_dir = profile_dir
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.profile_dir / "settings.json"
        self._settings = self._load(overrides or {})

    def _load(self, overrides: dict[str, Any]) -> Settings:
        data: dict[str, Any] = json.loads(json.dumps(DEFAULT_SETTINGS))
        if self.path.exists():
            try:
                on_disk = json.loads(self.path.read_text())
                data = _deep_merge(data, on_disk)
            except (json.JSONDecodeError, OSError) as exc:
                logger.warning(f"could not read settings.json ({exc}); using defaults")
        data = _deep_merge(data, overrides)
        return Settings.model_validate(data)

    @property
    def settings(self) -> Settings:
        return self._settings

    def update(self, patch: dict[str, Any]) -> Settings:
        merged = _deep_merge(json.loads(self._settings.model_dump_json()), patch)
        self._settings = Settings.model_validate(merged)
        self.save()
        return self._settings

    def save(self) -> None:
        self.path.write_text(self._settings.model_dump_json(indent=2))

    def reload(self) -> Settings:
        self._settings = self._load({})
        return self._settings


def _deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out
