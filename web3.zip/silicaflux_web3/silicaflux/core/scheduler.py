"""The SilicaFlux packet scheduler.

Prioritises queued packets using their :class:`~silicaflux.core.packet.PacketPriority`
plus a set of live signals (queue length, historical execution time for
the packet's runtime/operation pair) so that, e.g., an INTERACTIVE packet
from the focused tab is serviced ahead of a BULK background computation
even if the bulk packet arrived first.

This is intentionally a *policy* object separate from the actual thread of
execution (:mod:`silicaflux.core.workers`): :meth:`Scheduler.next_batch`
just decides ordering, so the same scheduler can drive a real worker pool
or be exercised directly in tests without spinning up processes.
"""

from __future__ import annotations

import heapq
import itertools
import statistics
import time
from dataclasses import dataclass, field
from typing import Optional

from silicaflux.core.packet import PacketPriority, SFXPacket
from silicaflux.core.logging_setup import get_logger

logger = get_logger("core.scheduler")


@dataclass
class LoadSample:
    """A point-in-time snapshot of system load the scheduler can factor
    into its decisions. Supplied by :mod:`silicaflux.telemetry`; defaults
    to "no pressure" so the scheduler degrades gracefully without a
    telemetry system attached."""

    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    active_workers: int = 0
    available_workers: int = 1


@dataclass(order=True)
class _QueueEntry:
    sort_key: tuple
    seq: int
    packet: SFXPacket = field(compare=False)


class Scheduler:
    """A priority queue of :class:`SFXPacket` with runtime-aware ordering
    and simple exponentially-weighted latency history, used to bias
    ordering away from runtimes that have recently been slow (basic
    "avoid the congested lane" behaviour — see spec section 19)."""

    def __init__(self) -> None:
        self._heap: list[_QueueEntry] = []
        self._counter = itertools.count()
        self._runtime_avg_latency_ms: dict[str, float] = {}
        self._load = LoadSample()

    # -- enqueue / dequeue --------------------------------------------
    def submit(self, packet: SFXPacket) -> None:
        from silicaflux.core.packet import PacketState

        if packet.state == PacketState.CREATED:
            packet.transition(PacketState.QUEUED, "submitted to scheduler")
        sort_key = self._sort_key(packet)
        heapq.heappush(self._heap, _QueueEntry(sort_key, next(self._counter), packet))
        logger.debug(
            "packet queued",
            extra={"packet_id": packet.packet_id, "runtime": packet.runtime, "operation": packet.operation},
        )

    def _sort_key(self, packet: SFXPacket) -> tuple:
        latency_bias = self._runtime_avg_latency_ms.get(packet.runtime, 0.0) / 1000.0
        # lower is serviced first: priority weight, then latency bias
        # (busy/slow runtimes sink slightly), then arrival time (FIFO
        # within the same priority+bias bucket).
        return (packet.priority.weight, round(latency_bias, 3), packet.timestamp)

    def next_batch(self, max_items: int = 1) -> list[SFXPacket]:
        """Pop up to ``max_items`` packets in priority order, skipping
        (and marking FAILED) any that expired while queued."""
        from silicaflux.core.packet import PacketState

        batch: list[SFXPacket] = []
        now = time.time()
        while self._heap and len(batch) < max_items:
            entry = heapq.heappop(self._heap)
            packet = entry.packet
            if packet.is_expired(now):
                packet.error = "ttl_expired_in_queue"
                packet.transition(PacketState.FAILED, "expired while queued")
                logger.warning("packet expired in queue", extra={"packet_id": packet.packet_id})
                continue
            batch.append(packet)
        return batch

    def peek(self) -> Optional[SFXPacket]:
        return self._heap[0].packet if self._heap else None

    def __len__(self) -> int:
        return len(self._heap)

    def cancel(self, packet_id: str) -> bool:
        from silicaflux.core.packet import PacketState

        for entry in self._heap:
            if entry.packet.packet_id == packet_id:
                entry.packet.transition(PacketState.CANCELLED, "cancelled while queued")
                self._heap.remove(entry)
                heapq.heapify(self._heap)
                return True
        return False

    # -- feedback --------------------------------------------------------
    def record_execution(self, runtime: str, duration_ms: float) -> None:
        """Update the running average latency for a runtime so future
        scheduling decisions can lean away from currently-slow runtimes."""
        prev = self._runtime_avg_latency_ms.get(runtime)
        self._runtime_avg_latency_ms[runtime] = duration_ms if prev is None else (prev * 0.7 + duration_ms * 0.3)

    def update_load(self, sample: LoadSample) -> None:
        self._load = sample

    def stats(self) -> dict:
        return {
            "queue_length": len(self._heap),
            "runtime_avg_latency_ms": dict(self._runtime_avg_latency_ms),
            "load": vars(self._load),
        }
