"""The SilicaFlux engine — the orchestrator that turns a submitted
:class:`~silicaflux.core.packet.SFXPacket` into a completed one.

    request -> security check -> scheduler -> router -> runtime adapter
        -> result -> telemetry -> caller

This is the object the JavaScript bridge (:mod:`silicaflux.api.bridge`),
the CLI, and (indirectly) the browser chrome all talk to. It owns the
dispatch loop: packets are enqueued into the :class:`~silicaflux.core.scheduler.Scheduler`
and a background task drains them, running up to ``max_parallel`` adapter
calls concurrently.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import PacketState, SFXPacket
from silicaflux.core.router import NoRouteError, RuntimeRouter
from silicaflux.core.scheduler import LoadSample, Scheduler
from silicaflux.core.workers import WorkerRegistry

logger = get_logger("core.engine")


class SecurityDenied(RuntimeError):
    """Raised (as a failed packet, not an exception to the caller — see
    :meth:`SilicaFluxEngine.request`) when a packet's origin lacks the
    capability its operation requires."""


class SilicaFluxEngine:
    def __init__(
        self,
        router: Optional[RuntimeRouter] = None,
        scheduler: Optional[Scheduler] = None,
        security_policy: Optional[Any] = None,
        worker_registry: Optional[WorkerRegistry] = None,
        telemetry: Optional[Any] = None,
        cache: Optional[Any] = None,
        max_parallel: int = 8,
        capability_map: Optional[dict[str, str]] = None,
    ) -> None:
        self.router = router or RuntimeRouter()
        self.scheduler = scheduler or Scheduler()
        self.security_policy = security_policy
        self.worker_registry = worker_registry or WorkerRegistry()
        self.telemetry = telemetry
        self.cache = cache
        self.max_parallel = max_parallel
        #: maps "runtime.operation" -> required capability name, e.g.
        #: {"python.analytics": "python.analytics", "wallet.sign": "wallet.sign"}.
        #: Falls back to "<runtime>.execute" when no explicit mapping exists.
        self.capability_map = capability_map or {}

        self._futures: dict[str, asyncio.Future] = {}
        self._semaphore = asyncio.Semaphore(max_parallel)
        self._dispatch_task: Optional[asyncio.Task] = None
        self._running = False
        self._completed_packets: list[SFXPacket] = []
        self._history_limit = 500

    # -- lifecycle -------------------------------------------------------
    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._dispatch_task = asyncio.create_task(self._dispatch_loop())
        logger.info("SilicaFlux engine started", extra={"component": "engine"})

    async def stop(self) -> None:
        self._running = False
        if self._dispatch_task is not None:
            self._dispatch_task.cancel()
            try:
                await self._dispatch_task
            except asyncio.CancelledError:
                pass
        logger.info("SilicaFlux engine stopped", extra={"component": "engine"})

    # -- submission --------------------------------------------------
    def _required_capability(self, packet: SFXPacket) -> str:
        key = f"{packet.runtime}.{packet.operation}"
        return self.capability_map.get(key, f"{packet.runtime}.execute")

    def _authorize(self, packet: SFXPacket) -> bool:
        if self.security_policy is None:
            return True
        if packet.security_context is None:
            return False
        capability = self._required_capability(packet)
        token = self.security_policy.authorize(packet.security_context.origin, capability)
        if token is not None:
            packet.security_context.capability_token = token.token_id
            packet.security_context.capabilities = frozenset({capability})
        return token is not None

    async def submit(self, packet: SFXPacket) -> asyncio.Future:
        """Enqueue ``packet`` and return a future that resolves to the
        completed (or failed/cancelled) packet. Does not block on
        execution — use :meth:`request` for the common "submit and await"
        case."""
        if not self._authorize(packet):
            packet.error = f"capability '{self._required_capability(packet)}' denied for origin '{getattr(packet.security_context, 'origin', None)}'"
            packet.transition(PacketState.FAILED, packet.error)
            future: asyncio.Future = asyncio.get_event_loop().create_future()
            future.set_result(packet)
            self._record_completion(packet)
            return future

        loop = asyncio.get_event_loop()
        future = loop.create_future()
        self._futures[packet.packet_id] = future
        self.scheduler.submit(packet)
        if not self._running:
            # engine not started (e.g. one-off CLI usage): drain inline.
            await self._drain_once()
        return future

    async def request(self, packet: SFXPacket) -> SFXPacket:
        future = await self.submit(packet)
        return await future

    def cancel(self, packet_id: str) -> bool:
        if self.scheduler.cancel(packet_id):
            future = self._futures.pop(packet_id, None)
            return True
        return False

    # -- dispatch ---------------------------------------------------------
    async def _dispatch_loop(self) -> None:
        while self._running:
            await self._drain_once()
            await asyncio.sleep(0.005)

    async def _drain_once(self) -> None:
        free_capacity = self._semaphore._value if hasattr(self._semaphore, "_value") else self.max_parallel
        batch = self.scheduler.next_batch(max(1, free_capacity))
        for packet in batch:
            if packet.state == PacketState.FAILED:  # expired in queue
                self._record_completion(packet)
                self._resolve_future(packet)
                continue
            asyncio.ensure_future(self._execute(packet))

    async def _execute(self, packet: SFXPacket) -> None:
        async with self._semaphore:
            try:
                adapter = self.router.route(packet)
            except NoRouteError:
                self._record_completion(packet)
                self._resolve_future(packet)
                return

            packet.transition(PacketState.EXECUTING, f"executing on {packet.runtime}")
            start = time.perf_counter()
            try:
                result_packet = await adapter.execute(packet)
                if result_packet.state not in (PacketState.COMPLETED, PacketState.FAILED, PacketState.CANCELLED):
                    result_packet.transition(PacketState.COMPLETED, "adapter returned without transitioning")
            except asyncio.CancelledError:
                packet.transition(PacketState.CANCELLED, "execution cancelled")
                result_packet = packet
            except Exception as exc:
                if packet.can_retry():
                    packet.retry_count += 1
                    packet.error = str(exc)
                    packet.transition(PacketState.QUEUED, f"retry {packet.retry_count}/{packet.max_retries} after: {exc}")
                    self.scheduler.submit(packet)
                    logger.warning(f"packet {packet.packet_id} failed, retrying", extra={"runtime": packet.runtime})
                    return
                packet.error = str(exc)
                packet.transition(PacketState.FAILED, str(exc))
                result_packet = packet

            duration_ms = (time.perf_counter() - start) * 1000
            self.scheduler.record_execution(packet.runtime, duration_ms)
            if self.telemetry is not None:
                try:
                    self.telemetry.record_packet(result_packet, duration_ms)
                except Exception:
                    logger.exception("telemetry.record_packet failed")
            self._record_completion(result_packet)
            self._resolve_future(result_packet)

    def _resolve_future(self, packet: SFXPacket) -> None:
        future = self._futures.pop(packet.packet_id, None)
        if future is not None and not future.done():
            future.set_result(packet)

    def _record_completion(self, packet: SFXPacket) -> None:
        self._completed_packets.append(packet)
        if len(self._completed_packets) > self._history_limit:
            self._completed_packets.pop(0)

    # -- observability -----------------------------------------------
    def load_sample(self) -> LoadSample:
        summary = self.worker_registry.summary()
        active = sum(b.get("busy", 0) for b in summary.values())
        available = sum(b.get("total", 0) for b in summary.values()) or 1
        return LoadSample(active_workers=active, available_workers=available)

    def recent_packets(self, limit: int = 100) -> list[dict]:
        return [p.to_dict() for p in self._completed_packets[-limit:]]

    def status(self) -> dict:
        return {
            "running": self._running,
            "queue_length": len(self.scheduler),
            "in_flight": len(self._futures),
            "runtimes": self.router.describe(),
            "workers": self.worker_registry.summary(),
            "scheduler": self.scheduler.stats(),
        }
