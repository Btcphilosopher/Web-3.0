"""Browser session manager: owns the active profile, the window's
:class:`~silicaflux.core.tabs.TabManager`, and session save/restore.

Kept decoupled from :mod:`silicaflux.storage` by depending only on a
duck-typed ``session_store`` (``save_session(profile, tabs) -> None`` /
``load_session(profile) -> list[dict]``), which
:class:`silicaflux.storage.database.Database` implements. This mirrors how
:mod:`silicaflux.security.permissions` takes an injected persistence
object — the core layer never imports storage directly, so
``silicaflux.core`` stays importable with zero I/O dependencies.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional

from silicaflux.core.events import EventBus
from silicaflux.core.logging_setup import get_logger
from silicaflux.core.tabs import TabManager

logger = get_logger("core.session")


@dataclass
class SessionSnapshot:
    profile: str
    saved_at: float
    tabs: list[dict] = field(default_factory=list)
    active_tab_id: Optional[str] = None


class BrowserSessionManager:
    def __init__(self, profile: str = "default", session_store: Optional[Any] = None, events: Optional[EventBus] = None) -> None:
        self.profile = profile
        self.session_store = session_store
        self.events = events or EventBus()
        self.tabs = TabManager(events=self.events)

    def restore_or_start(self, homepage: str = "sfx://home") -> None:
        restored = self.restore()
        if not restored:
            self.tabs.new_tab(homepage)

    def restore(self) -> bool:
        if self.session_store is None:
            return False
        try:
            rows = self.session_store.load_session(self.profile)
        except Exception:
            logger.exception("failed to load session; starting fresh")
            return False
        if not rows:
            return False
        for row in rows:
            tab = self.tabs.new_tab(row.get("url", "sfx://home"), private=False, background=True)
            tab.title = row.get("title", tab.title)
            tab.pinned = row.get("pinned", False)
        if self.tabs.all_tabs():
            self.tabs.activate(self.tabs.all_tabs()[0].tab_id)
        logger.info(f"restored session with {len(rows)} tab(s)")
        return True

    def save(self) -> Optional[SessionSnapshot]:
        snapshot = SessionSnapshot(
            profile=self.profile,
            saved_at=time.time(),
            tabs=[t.to_dict() for t in self.tabs.all_tabs() if not t.private],
            active_tab_id=self.tabs.active_tab.tab_id if self.tabs.active_tab else None,
        )
        if self.session_store is not None:
            try:
                self.session_store.save_session(self.profile, snapshot.tabs)
            except Exception:
                logger.exception("failed to persist session")
        return snapshot
