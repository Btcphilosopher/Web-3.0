"""Core orchestration layer: packets, routing, scheduling, execution graph,
sessions, tabs, navigation, events, tasks, configuration and plugins."""

from __future__ import annotations
