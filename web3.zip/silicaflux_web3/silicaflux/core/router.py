"""Runtime router — dispatches a packet to the worker registered for
``packet.runtime``.

    SFXPacket
        |
        +-- python
        +-- javascript
        +-- rust
        +-- r
        +-- wasm

Runtime adapters (:mod:`silicaflux.runtimes`) register themselves with a
:class:`RuntimeRouter` instance; the router itself knows nothing about
*how* a runtime executes a packet, only which adapter is responsible for
which ``runtime`` string. This is what lets
:mod:`silicaflux.runtimes.manager` add/remove/hot-swap adapters (e.g.
disabling the R adapter when R isn't installed) without touching the
router or engine.
"""

from __future__ import annotations

from typing import Protocol

from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import SFXPacket

logger = get_logger("core.router")


class RuntimeAdapterProtocol(Protocol):
    """The minimal interface the router requires from a runtime adapter.
    See :class:`silicaflux.runtimes.base.RuntimeAdapter` for the full,
    concrete base class every real adapter subclasses."""

    name: str

    def is_available(self) -> bool: ...

    async def execute(self, packet: SFXPacket) -> SFXPacket: ...


class NoRouteError(RuntimeError):
    """Raised when a packet names a runtime with no registered adapter."""


class RuntimeRouter:
    def __init__(self) -> None:
        self._adapters: dict[str, RuntimeAdapterProtocol] = {}

    def register(self, adapter: RuntimeAdapterProtocol) -> None:
        self._adapters[adapter.name] = adapter
        logger.info(f"registered runtime adapter '{adapter.name}'", extra={"runtime": adapter.name})

    def unregister(self, name: str) -> None:
        self._adapters.pop(name, None)

    def resolve(self, runtime: str) -> RuntimeAdapterProtocol:
        adapter = self._adapters.get(runtime)
        if adapter is None:
            raise NoRouteError(f"no runtime adapter registered for '{runtime}'")
        return adapter

    def route(self, packet: SFXPacket) -> RuntimeAdapterProtocol:
        """Resolve and mark a packet ROUTED. Raises :class:`NoRouteError`
        (and fails the packet) if nothing handles its runtime, or if the
        adapter is registered but currently unavailable (e.g. R adapter
        present but the ``Rscript`` binary is not installed on this
        machine)."""
        from silicaflux.core.packet import PacketState

        adapter = self.resolve(packet.runtime)
        if not adapter.is_available():
            packet.error = f"runtime '{packet.runtime}' is unavailable on this host"
            packet.transition(PacketState.FAILED, packet.error)
            raise NoRouteError(packet.error)
        packet.transition(PacketState.ROUTED, f"routed to {adapter.name}")
        return adapter

    def available_runtimes(self) -> list[str]:
        return [name for name, adapter in self._adapters.items() if adapter.is_available()]

    def all_runtimes(self) -> list[str]:
        return list(self._adapters.keys())

    def describe(self) -> dict[str, bool]:
        return {name: adapter.is_available() for name, adapter in self._adapters.items()}
