"""A small synchronous/asynchronous event bus used to decouple browser
subsystems (tabs, navigation, downloads, history, ...) from each other and
from the UI layer, so ``silicaflux.browser`` can stay a thin presentation
shell over the headless core."""

from __future__ import annotations

import asyncio
import inspect
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, DefaultDict

from silicaflux.core.logging_setup import get_logger

logger = get_logger("core.events")

Handler = Callable[..., Any]


@dataclass
class Event:
    name: str
    payload: Any = None
    source: str = "unknown"


class EventBus:
    """Publish/subscribe hub. Handlers may be plain callables or
    coroutine functions; :meth:`emit` runs sync handlers inline and
    schedules async handlers as tasks on the running loop (or awaits them
    directly when called via :meth:`emit_async`)."""

    def __init__(self) -> None:
        self._subscribers: DefaultDict[str, list[Handler]] = defaultdict(list)
        self._history: list[Event] = []
        self._history_limit = 500

    def on(self, event_name: str, handler: Handler) -> Callable[[], None]:
        """Subscribe ``handler`` to ``event_name``. Returns an unsubscribe
        callable for convenience."""
        self._subscribers[event_name].append(handler)

        def unsubscribe() -> None:
            try:
                self._subscribers[event_name].remove(handler)
            except ValueError:
                pass

        return unsubscribe

    def off(self, event_name: str, handler: Handler) -> None:
        try:
            self._subscribers[event_name].remove(handler)
        except ValueError:
            pass

    def emit(self, event_name: str, payload: Any = None, source: str = "unknown") -> Event:
        """Fire-and-forget emit. Sync handlers run immediately; coroutine
        handlers are scheduled on the running event loop if one exists,
        otherwise dropped with a warning (there is nothing to await)."""
        event = Event(event_name, payload, source)
        self._record(event)
        for handler in list(self._subscribers.get(event_name, [])) + list(
            self._subscribers.get("*", [])
        ):
            self._dispatch(handler, event)
        return event

    async def emit_async(self, event_name: str, payload: Any = None, source: str = "unknown") -> Event:
        event = Event(event_name, payload, source)
        self._record(event)
        for handler in list(self._subscribers.get(event_name, [])) + list(
            self._subscribers.get("*", [])
        ):
            result = handler(event)
            if inspect.isawaitable(result):
                await result
        return event

    def _dispatch(self, handler: Handler, event: Event) -> None:
        try:
            result = handler(event)
        except Exception:
            logger.exception(f"event handler for '{event.name}' raised")
            return
        if inspect.isawaitable(result):
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(result)
            except RuntimeError:
                logger.warning(
                    f"async handler for '{event.name}' returned a coroutine "
                    "but no event loop is running; use emit_async() instead"
                )

    def _record(self, event: Event) -> None:
        self._history.append(event)
        if len(self._history) > self._history_limit:
            self._history.pop(0)

    def history(self, event_name: str | None = None) -> list[Event]:
        if event_name is None:
            return list(self._history)
        return [e for e in self._history if e.name == event_name]
