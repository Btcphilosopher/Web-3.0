"""Headless engine bootstrap: constructs the same subsystem graph
:mod:`silicaflux.browser.launcher` wires up for the GUI, minus anything
that touches Qt/QtWebEngine. This is what :mod:`silicaflux.cli` and
:mod:`silicaflux.dev_cli` build on, and it's exactly what an integration
test wants too — the whole engine, real storage, real security, real
runtimes, with no GUI toolkit required.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from silicaflux.ai.manager import AIManager
from silicaflux.ai.registry import ModelRegistry
from silicaflux.cache import CacheManager
from silicaflux.config.defaults import DEFAULT_PROFILE_DIR
from silicaflux.core.config import ConfigurationSystem, Settings
from silicaflux.core.engine import SilicaFluxEngine
from silicaflux.core.logging_setup import get_logger
from silicaflux.core.session import BrowserSessionManager
from silicaflux.networking.client import HTTPClient
from silicaflux.networking.downloads import DownloadManager
from silicaflux.runtimes.manager import RuntimeManager
from silicaflux.security.audit import AuditLogger
from silicaflux.security.permissions import PermissionManager
from silicaflux.security.policy import SecurityPolicy
from silicaflux.storage.bookmarks import BookmarksStore
from silicaflux.storage.database import Database
from silicaflux.storage.downloads_store import DownloadsStore
from silicaflux.storage.history import HistoryStore
from silicaflux.storage.permissions_store import PermissionsStore
from silicaflux.telemetry.dashboard import RuntimeDashboard
from silicaflux.telemetry.manager import TelemetryManager
from silicaflux.web3.dapp_bridge import DAppBridge
from silicaflux.web3.identity import IdentityManager
from silicaflux.web3.permissions import DAppPermissionManager
from silicaflux.web3.wallet import Wallet

logger = get_logger("core.bootstrap")


def resolve_profile_dir(profile: str, profile_dir: Optional[str] = None) -> Path:
    base = Path(profile_dir) if profile_dir else DEFAULT_PROFILE_DIR
    resolved = base if base.name == profile else base / profile
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


@dataclass
class HeadlessContext:
    """Everything a CLI command or a test needs: storage, security,
    caching, the runtime router/engine, telemetry, Web3, and a couple of
    networking conveniences — with nothing Qt/GUI-specific."""

    profile_dir: Path
    settings: Settings
    db: Database
    policy: SecurityPolicy
    audit: AuditLogger
    cache_manager: CacheManager
    runtime_manager: RuntimeManager
    telemetry: TelemetryManager
    engine: SilicaFluxEngine
    identity_manager: IdentityManager
    wallet: Wallet
    dapp_permissions: DAppPermissionManager
    dapp_bridge: DAppBridge
    dashboard: RuntimeDashboard
    history: HistoryStore
    bookmarks: BookmarksStore
    downloads_store: DownloadsStore
    http_client: HTTPClient
    download_manager: DownloadManager
    session: BrowserSessionManager
    ai_manager: AIManager

    async def shutdown(self) -> None:
        await self.engine.stop()
        self.runtime_manager.shutdown()
        self.ai_manager.shutdown()
        await self.http_client.aclose()
        self.db.close()


async def build_headless_context(
    profile: str = "default",
    profile_dir: Optional[str] = None,
    *,
    approve_all: bool = False,
    register_demo_operations: bool = True,
) -> HeadlessContext:
    resolved_dir = resolve_profile_dir(profile, profile_dir)

    config = ConfigurationSystem(resolved_dir)
    settings = config.settings

    db = Database(resolved_dir / "silicaflux.sqlite3")
    history = HistoryStore(db)
    bookmarks = BookmarksStore(db)
    downloads_store = DownloadsStore(db)
    permissions_store = PermissionsStore(db)

    audit = AuditLogger(sink=db)
    approval_callback = (lambda origin, cap, scope: True) if approve_all else None
    policy = SecurityPolicy(
        default_policy=settings.security.default_capability_policy,
        approval_callback=approval_callback,
        audit=audit,
    )
    PermissionManager(policy, persistence=permissions_store)

    cache_manager = CacheManager(cache_dir=resolved_dir / "cache")

    runtime_manager = RuntimeManager(
        python_enabled=settings.runtimes.python_enabled,
        r_enabled=settings.runtimes.r_enabled,
        rust_enabled=settings.runtimes.rust_enabled,
        wasm_enabled=settings.runtimes.wasm_enabled,
        javascript_enabled=settings.runtimes.javascript_bridge_enabled,
    )
    if register_demo_operations:
        runtime_manager.python_registry.register("analytics", "silicaflux.runtimes.sample_functions", "analytics_summary")
        runtime_manager.python_registry.register("fib", "silicaflux.runtimes.sample_functions", "fibonacci")
        runtime_manager.python_registry.register("hash", "silicaflux.runtimes.sample_functions", "sha256_of")
        runtime_manager.python_registry.register("echo", "silicaflux.runtimes.sample_functions", "echo")

    telemetry = TelemetryManager(database=db)
    engine = SilicaFluxEngine(
        router=runtime_manager.router,
        security_policy=policy,
        worker_registry=runtime_manager.worker_registry,
        telemetry=telemetry,
    )
    await engine.start()

    identity_manager = IdentityManager(resolved_dir / "identity")
    wallet = Wallet(identity_manager, approval_prompt=lambda req: approve_all)
    dapp_permissions = DAppPermissionManager(policy, wallet)
    dapp_bridge = DAppBridge(wallet, dapp_permissions)

    dashboard = RuntimeDashboard(engine, telemetry, cache_manager=cache_manager, wallet=wallet)

    http_client = HTTPClient(resource_cache=cache_manager.resources)
    download_manager = DownloadManager(http_client, Path(settings.downloads.directory), store=downloads_store)

    ai_manager = AIManager(registry=ModelRegistry(), security_policy=policy, telemetry=telemetry)
    if register_demo_operations:
        ai_manager.registry.register_native(
            model_id="sentiment-demo",
            version="1.0.0",
            predict_target="silicaflux.ai.sample_models:sentiment_predict",
            input_schema={"text": "string"},
            output_schema={"score": "float", "label": "string"},
        )

    session = BrowserSessionManager(profile=profile, session_store=db)

    return HeadlessContext(
        profile_dir=resolved_dir,
        settings=settings,
        db=db,
        policy=policy,
        audit=audit,
        cache_manager=cache_manager,
        runtime_manager=runtime_manager,
        telemetry=telemetry,
        engine=engine,
        identity_manager=identity_manager,
        wallet=wallet,
        dapp_permissions=dapp_permissions,
        dapp_bridge=dapp_bridge,
        dashboard=dashboard,
        history=history,
        bookmarks=bookmarks,
        downloads_store=downloads_store,
        http_client=http_client,
        download_manager=download_manager,
        session=session,
        ai_manager=ai_manager,
    )
