"""Cross-runtime worker bookkeeping.

Each concrete runtime adapter (:mod:`silicaflux.runtimes.python_runtime`,
etc.) owns its own process/subprocess lifecycle, but they all report into
one :class:`WorkerRegistry` so the developer tools "Runtime workers" panel
and ``sfx-runtime workers`` CLI command have a single place to look.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from silicaflux.core.logging_setup import get_logger

logger = get_logger("core.workers")


class WorkerStatus(str, Enum):
    IDLE = "idle"
    BUSY = "busy"
    STARTING = "starting"
    CRASHED = "crashed"
    STOPPED = "stopped"


@dataclass
class WorkerHandle:
    worker_id: str
    runtime: str
    pid: Optional[int] = None
    status: WorkerStatus = WorkerStatus.STARTING
    started_at: float = field(default_factory=time.time)
    last_active_at: float = field(default_factory=time.time)
    tasks_completed: int = 0
    tasks_failed: int = 0
    restart_count: int = 0

    def to_dict(self) -> dict:
        return {
            "worker_id": self.worker_id,
            "runtime": self.runtime,
            "pid": self.pid,
            "status": self.status.value,
            "uptime_s": round(time.time() - self.started_at, 3),
            "idle_s": round(time.time() - self.last_active_at, 3),
            "tasks_completed": self.tasks_completed,
            "tasks_failed": self.tasks_failed,
            "restart_count": self.restart_count,
        }


class WorkerRegistry:
    """A process-wide registry (one instance lives on
    :class:`silicaflux.core.engine.SilicaFluxEngine`) that runtime adapters
    update as workers start, finish tasks, crash and restart. Deliberately
    holds no locks/process handles itself — those stay with the adapter
    that owns the worker; this is pure observability state.
    """

    def __init__(self) -> None:
        self._workers: dict[str, WorkerHandle] = {}

    def register(self, handle: WorkerHandle) -> None:
        self._workers[handle.worker_id] = handle
        logger.info(
            f"worker registered ({handle.runtime})",
            extra={"runtime": handle.runtime},
        )

    def mark_busy(self, worker_id: str) -> None:
        w = self._workers.get(worker_id)
        if w:
            w.status = WorkerStatus.BUSY
            w.last_active_at = time.time()

    def mark_idle(self, worker_id: str, success: bool = True) -> None:
        w = self._workers.get(worker_id)
        if w:
            w.status = WorkerStatus.IDLE
            w.last_active_at = time.time()
            if success:
                w.tasks_completed += 1
            else:
                w.tasks_failed += 1

    def mark_crashed(self, worker_id: str) -> None:
        w = self._workers.get(worker_id)
        if w:
            w.status = WorkerStatus.CRASHED
            logger.warning(f"worker crashed", extra={"runtime": w.runtime})

    def mark_restarted(self, worker_id: str, new_pid: Optional[int] = None) -> None:
        w = self._workers.get(worker_id)
        if w:
            w.status = WorkerStatus.STARTING
            w.restart_count += 1
            w.pid = new_pid

    def remove(self, worker_id: str) -> None:
        w = self._workers.pop(worker_id, None)
        if w:
            w.status = WorkerStatus.STOPPED

    def all(self) -> list[WorkerHandle]:
        return list(self._workers.values())

    def by_runtime(self, runtime: str) -> list[WorkerHandle]:
        return [w for w in self._workers.values() if w.runtime == runtime]

    def summary(self) -> dict:
        by_runtime: dict[str, dict] = {}
        for w in self._workers.values():
            bucket = by_runtime.setdefault(w.runtime, {"total": 0, "busy": 0, "idle": 0, "crashed": 0})
            bucket["total"] += 1
            bucket[w.status.value] = bucket.get(w.status.value, 0) + 1
        return by_runtime
