"""A lightweight named/cancellable asyncio task system used for background
work that isn't a SilicaFlux packet (periodic telemetry flushes, cache
eviction sweeps, session autosave) — see spec section "asynchronous task
system"."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional

from silicaflux.core.logging_setup import get_logger

logger = get_logger("core.tasks")


@dataclass
class TaskInfo:
    name: str
    created_at: float = field(default_factory=time.time)
    periodic: bool = False
    interval_s: Optional[float] = None
    run_count: int = 0
    last_error: Optional[str] = None


class AsyncTaskSystem:
    """Owns a set of named background ``asyncio`` tasks with graceful
    cancellation on shutdown and per-subsystem failure isolation: one
    background task raising never takes down another (spec section 30)."""

    def __init__(self) -> None:
        self._tasks: dict[str, asyncio.Task] = {}
        self._info: dict[str, TaskInfo] = {}

    def spawn(self, name: str, coro: Awaitable[Any]) -> asyncio.Task:
        if name in self._tasks and not self._tasks[name].done():
            raise ValueError(f"task '{name}' is already running")
        task = asyncio.ensure_future(coro)
        self._tasks[name] = task
        self._info[name] = TaskInfo(name)
        task.add_done_callback(lambda t: self._on_done(name, t))
        return task

    def spawn_periodic(
        self, name: str, interval_s: float, fn: Callable[[], Awaitable[Any]]
    ) -> asyncio.Task:
        async def loop() -> None:
            info = self._info[name]
            while True:
                await asyncio.sleep(interval_s)
                try:
                    await fn()
                    info.run_count += 1
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    info.last_error = str(exc)
                    logger.exception(f"periodic task '{name}' iteration failed")

        task = self.spawn(name, loop())
        self._info[name].periodic = True
        self._info[name].interval_s = interval_s
        return task

    def _on_done(self, name: str, task: asyncio.Task) -> None:
        if task.cancelled():
            logger.debug(f"task '{name}' cancelled")
            return
        exc = task.exception()
        if exc is not None:
            self._info[name].last_error = str(exc)
            logger.error(f"background task '{name}' raised: {exc}")

    def cancel(self, name: str) -> bool:
        task = self._tasks.get(name)
        if task is None:
            return False
        task.cancel()
        return True

    async def cancel_all(self) -> None:
        for task in self._tasks.values():
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks.values(), return_exceptions=True)

    def status(self) -> dict[str, dict]:
        out = {}
        for name, task in self._tasks.items():
            info = self._info[name]
            out[name] = {
                "running": not task.done(),
                "periodic": info.periodic,
                "interval_s": info.interval_s,
                "run_count": info.run_count,
                "last_error": info.last_error,
            }
        return out
