"""Inter-process communication primitives shared by every out-of-process
runtime worker (Python, R, Rust, WASM).

Two transports are provided:

* :class:`QueueChannel` — a ``multiprocessing`` pipe/queue pair, used for
  same-machine Python worker processes (:mod:`silicaflux.runtimes.python_runtime`).
* :class:`SharedMemoryBlock` — a POSIX shared-memory segment for large,
  zero-copy payloads (e.g. a NumPy-style tensor handed to a worker without
  serialising it through a pipe first). Only used when both sides opt in;
  everything else goes through ordinary (safe, inspectable) message
  passing.

Both transports only ever carry JSON-serialisable Python objects plus
optionally a shared-memory handle — never pickled callables or arbitrary
objects, which is what keeps a compromised worker from being able to
smuggle code back into the parent process.
"""

from __future__ import annotations

import json
import multiprocessing as mp
import time
import uuid
from dataclasses import dataclass
from multiprocessing import shared_memory
from typing import Any, Optional

from silicaflux.core.logging_setup import get_logger

logger = get_logger("core.ipc")


class IPCTimeout(TimeoutError):
    pass


@dataclass
class IPCMessage:
    kind: str  # "request" | "response" | "error" | "stream" | "log"
    payload: Any
    message_id: str
    timestamp: float

    def to_json(self) -> str:
        return json.dumps(
            {"kind": self.kind, "payload": self.payload, "message_id": self.message_id, "timestamp": self.timestamp}
        )

    @classmethod
    def from_json(cls, raw: str) -> "IPCMessage":
        data = json.loads(raw)
        return cls(data["kind"], data["payload"], data["message_id"], data["timestamp"])


class QueueChannel:
    """A duplex channel over a pair of ``multiprocessing.Queue`` objects.
    Construct once in the parent, pass ``(to_worker, from_worker)`` to the
    child process target."""

    def __init__(self) -> None:
        ctx = mp.get_context("spawn")
        self.to_worker: "mp.Queue" = ctx.Queue()
        self.from_worker: "mp.Queue" = ctx.Queue()

    def send_to_worker(self, kind: str, payload: Any) -> str:
        msg = IPCMessage(kind, payload, uuid.uuid4().hex, time.time())
        self.to_worker.put(msg.to_json())
        return msg.message_id

    def send_to_parent(self, kind: str, payload: Any, message_id: Optional[str] = None) -> None:
        msg = IPCMessage(kind, payload, message_id or uuid.uuid4().hex, time.time())
        self.from_worker.put(msg.to_json())

    def recv_from_worker(self, timeout: float) -> IPCMessage:
        try:
            raw = self.from_worker.get(timeout=timeout)
        except Exception as exc:  # queue.Empty
            raise IPCTimeout(f"no response from worker within {timeout}s") from exc
        return IPCMessage.from_json(raw)

    def recv_from_parent(self, timeout: Optional[float] = None) -> IPCMessage:
        raw = self.to_worker.get(timeout=timeout)
        return IPCMessage.from_json(raw)

    def close(self) -> None:
        for q in (self.to_worker, self.from_worker):
            try:
                q.close()
            except Exception:
                pass


class SharedMemoryBlock:
    """A small wrapper around :mod:`multiprocessing.shared_memory` for
    passing large binary payloads (e.g. WASM bytecode, tensors) between
    the engine process and a worker without a serialisation round-trip.
    Always created and destroyed by the owner (the side that calls
    :meth:`create`); the other side calls :meth:`attach`/:meth:`close`.
    """

    def __init__(self, name: Optional[str] = None) -> None:
        self.name = name
        self._shm: Optional[shared_memory.SharedMemory] = None

    def create(self, size: int) -> "SharedMemoryBlock":
        self._shm = shared_memory.SharedMemory(create=True, size=max(size, 1))
        self.name = self._shm.name
        return self

    def attach(self) -> "SharedMemoryBlock":
        if not self.name:
            raise ValueError("no shared memory name to attach to")
        self._shm = shared_memory.SharedMemory(name=self.name, create=False)
        return self

    def write(self, data: bytes) -> None:
        if self._shm is None or len(data) > self._shm.size:
            raise ValueError("shared memory block not created or too small")
        self._shm.buf[: len(data)] = data

    def read(self, length: Optional[int] = None) -> bytes:
        if self._shm is None:
            raise ValueError("shared memory block not attached")
        return bytes(self._shm.buf[: length or self._shm.size])

    def close(self) -> None:
        if self._shm is not None:
            self._shm.close()

    def unlink(self) -> None:
        if self._shm is not None:
            try:
                self._shm.unlink()
            except FileNotFoundError:
                pass
