"""Smart address-bar URL classification and navigation history.

Given whatever a user typed, :func:`classify_input` decides whether it is
a fully-qualified URL, a bare host/localhost/IP address, an internal
``sfx://`` address, or a search query — exactly the distinctions section 6
of the spec calls out.
"""

from __future__ import annotations

import ipaddress
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
from urllib.parse import quote, urlsplit

_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+\-.]*://")
_HOSTLIKE_RE = re.compile(
    r"^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?(/.*)?$"
)
_DOMAIN_RE = re.compile(
    r"^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}(:\d+)?(/.*)?$"
)


class AddressKind(str, Enum):
    HTTP_URL = "http_url"
    HTTPS_URL = "https_url"
    SFX_INTERNAL = "sfx_internal"
    ABOUT = "about"
    LOCALHOST = "localhost"
    IP_ADDRESS = "ip_address"
    BARE_DOMAIN = "bare_domain"
    SEARCH_QUERY = "search_query"


@dataclass
class ClassifiedAddress:
    kind: AddressKind
    normalized_url: str
    raw_input: str


def classify_input(text: str, search_engine_template: str = "https://duckduckgo.com/?q={query}") -> ClassifiedAddress:
    """Classify raw address-bar text and produce the URL that should
    actually be navigated to."""
    text = text.strip()
    if not text:
        return ClassifiedAddress(AddressKind.SEARCH_QUERY, search_engine_template.format(query=""), text)

    if text.startswith("sfx://"):
        return ClassifiedAddress(AddressKind.SFX_INTERNAL, text, text)

    # "about:" URIs (about:blank chief among them, used for new/empty
    # tabs and JS-opened popups) have no "//" so they never match
    # _SCHEME_RE below; pass them through unchanged rather than treating
    # "about:blank" as a search query for the literal text "about:blank".
    if text == "about:blank" or text.startswith("about:"):
        return ClassifiedAddress(AddressKind.ABOUT, text, text)

    if _SCHEME_RE.match(text):
        scheme = text.split("://", 1)[0].lower()
        kind = AddressKind.HTTPS_URL if scheme == "https" else AddressKind.HTTP_URL
        return ClassifiedAddress(kind, text, text)

    host_part = text.split("/", 1)[0].split(":", 1)[0]
    if host_part == "localhost" or host_part.startswith("127.") or host_part == "::1":
        return ClassifiedAddress(AddressKind.LOCALHOST, f"http://{text}", text)

    if _looks_like_ip(host_part):
        return ClassifiedAddress(AddressKind.IP_ADDRESS, f"http://{text}", text)

    if " " not in text and _DOMAIN_RE.match(text):
        return ClassifiedAddress(AddressKind.BARE_DOMAIN, f"https://{text}", text)

    query = quote(text)
    return ClassifiedAddress(AddressKind.SEARCH_QUERY, search_engine_template.format(query=query), text)


def _looks_like_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


@dataclass
class NavigationEntry:
    url: str
    title: str = ""
    timestamp: float = field(default_factory=time.time)


class NavigationManager:
    """Per-tab back/forward history stack. One instance per
    :class:`silicaflux.core.tabs.Tab`."""

    def __init__(self) -> None:
        self._stack: list[NavigationEntry] = []
        self._index: int = -1

    def navigate(self, url: str, title: str = "") -> NavigationEntry:
        entry = NavigationEntry(url, title)
        # navigating from a mid-history point discards forward entries,
        # matching conventional browser behaviour.
        self._stack = self._stack[: self._index + 1]
        self._stack.append(entry)
        self._index = len(self._stack) - 1
        return entry

    def can_go_back(self) -> bool:
        return self._index > 0

    def can_go_forward(self) -> bool:
        return self._index < len(self._stack) - 1

    def go_back(self) -> Optional[NavigationEntry]:
        if not self.can_go_back():
            return None
        self._index -= 1
        return self._stack[self._index]

    def go_forward(self) -> Optional[NavigationEntry]:
        if not self.can_go_forward():
            return None
        self._index += 1
        return self._stack[self._index]

    def current(self) -> Optional[NavigationEntry]:
        if 0 <= self._index < len(self._stack):
            return self._stack[self._index]
        return None

    def update_current_title(self, title: str) -> None:
        entry = self.current()
        if entry:
            entry.title = title

    def entries(self) -> list[NavigationEntry]:
        return list(self._stack)
