"""Performance benchmarks (spec section 33): real measurements of packet
creation, routing, computation-cache lookups, database operations and
end-to-end Python-runtime execution — everything reported here is a
timed measurement, never a claimed figure.

Each benchmark is an ``async def bench(ctx: HeadlessContext, iterations:
int) -> dict`` using :class:`silicaflux.telemetry.manager.Benchmark` for
consistent latency/throughput statistics. Registered in :data:`BENCHMARKS`
so :mod:`silicaflux.cli`'s ``benchmark`` command and
``tests/test_benchmarks.py`` share the exact same implementations.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Awaitable, Callable, Dict

if TYPE_CHECKING:
    from silicaflux.core.bootstrap import HeadlessContext

BenchmarkFn = Callable[["HeadlessContext", int], Awaitable[dict]]


async def bench_packet_creation(ctx: "HeadlessContext", iterations: int) -> dict:
    from silicaflux.core.packet import SFXPacket

    bench = ctx.telemetry.start_benchmark("packet_creation")
    for _ in range(iterations):
        start = time.perf_counter()
        SFXPacket(source="bench", destination="engine", runtime="python", operation="noop", payload={})
        bench.record((time.perf_counter() - start) * 1000)
    return bench.finish().summary()


async def bench_packet_routing(ctx: "HeadlessContext", iterations: int) -> dict:
    from silicaflux.core.packet import PacketState, SFXPacket

    bench = ctx.telemetry.start_benchmark("packet_routing")
    for _ in range(iterations):
        packet = SFXPacket(source="bench", destination="engine", runtime="python", operation="echo", payload={})
        packet.transition(PacketState.QUEUED)
        start = time.perf_counter()
        ctx.runtime_manager.router.route(packet)
        bench.record((time.perf_counter() - start) * 1000)
    return bench.finish().summary()


async def bench_runtime_roundtrip(ctx: "HeadlessContext", iterations: int) -> dict:
    """End-to-end: packet creation -> engine dispatch -> Python worker
    execution -> result, exercising the full fabric including
    process-isolated execution."""
    from silicaflux.core.packet import SFXPacket, SecurityContext

    bench = ctx.telemetry.start_benchmark("runtime_roundtrip")
    for _ in range(iterations):
        start = time.perf_counter()
        packet = SFXPacket(
            source="bench",
            destination="engine",
            runtime="python",
            operation="echo",
            payload={"n": 1},
            security_context=SecurityContext(origin="sfx://bench"),
        )
        await ctx.engine.request(packet)
        bench.record((time.perf_counter() - start) * 1000)
    return bench.finish().summary()


async def bench_cache_lookup(ctx: "HeadlessContext", iterations: int) -> dict:
    digest = ctx.cache_manager.content.put(b"benchmark payload bytes")
    bench = ctx.telemetry.start_benchmark("cache_lookup")
    for _ in range(iterations):
        start = time.perf_counter()
        ctx.cache_manager.content.get(digest)
        bench.record((time.perf_counter() - start) * 1000)
    return bench.finish().summary()


async def bench_computation_cache(ctx: "HeadlessContext", iterations: int) -> dict:
    bench = ctx.telemetry.start_benchmark("computation_cache")

    async def compute():
        return 42

    for i in range(iterations):
        start = time.perf_counter()
        await ctx.cache_manager.computation.memoize("bench_fn", {"i": i % 10}, compute)
        bench.record((time.perf_counter() - start) * 1000)
    return bench.finish().summary()


async def bench_database_write(ctx: "HeadlessContext", iterations: int) -> dict:
    bench = ctx.telemetry.start_benchmark("database_write")
    for i in range(iterations):
        start = time.perf_counter()
        await ctx.history.visit(f"https://bench.example/{i}", f"Benchmark {i}")
        bench.record((time.perf_counter() - start) * 1000)
    return bench.finish().summary()


async def bench_database_read(ctx: "HeadlessContext", iterations: int) -> dict:
    for i in range(min(iterations, 50)):
        await ctx.history.visit(f"https://bench.example/{i}")
    bench = ctx.telemetry.start_benchmark("database_read")
    for _ in range(iterations):
        start = time.perf_counter()
        await ctx.history.search(limit=20)
        bench.record((time.perf_counter() - start) * 1000)
    return bench.finish().summary()


async def bench_scheduler_throughput(ctx: "HeadlessContext", iterations: int) -> dict:
    from silicaflux.core.packet import PacketPriority, SFXPacket
    from silicaflux.core.scheduler import Scheduler

    scheduler = Scheduler()
    bench = ctx.telemetry.start_benchmark("scheduler_throughput")
    start_all = time.perf_counter()
    for i in range(iterations):
        priority = list(PacketPriority)[i % len(PacketPriority)]
        scheduler.submit(SFXPacket(source="bench", destination="e", runtime="python", operation="x", priority=priority))
    while len(scheduler):
        scheduler.next_batch(max_items=32)
    total_ms = (time.perf_counter() - start_all) * 1000
    bench.record(total_ms)
    return {**bench.finish().summary(), "total_ms": round(total_ms, 3), "throughput_per_s": round(iterations / (total_ms / 1000), 1) if total_ms else None}


BENCHMARKS: Dict[str, BenchmarkFn] = {
    "packet_creation": bench_packet_creation,
    "packet_routing": bench_packet_routing,
    "runtime_roundtrip": bench_runtime_roundtrip,
    "cache_lookup": bench_cache_lookup,
    "computation_cache": bench_computation_cache,
    "database_write": bench_database_write,
    "database_read": bench_database_read,
    "scheduler_throughput": bench_scheduler_throughput,
}


async def run_all(ctx: "HeadlessContext", iterations: int = 100) -> dict:
    return {name: await fn(ctx, iterations) for name, fn in BENCHMARKS.items()}
