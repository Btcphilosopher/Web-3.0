"""
SilicaFlux Web3.0
==================

A Python-first experimental browser platform.

``silicaflux`` is the systems/orchestration layer described in the project
specification: Python owns session, tab, navigation, scheduling, caching,
security, storage, telemetry and multi-language runtime routing; an
optional Chromium-based (Qt WebEngine) frontend renders standards-compliant
web content, and a packet fabric (:mod:`silicaflux.core.packet`) lets
"SilicaFlux applications" additionally dispatch computation to Python, R,
Rust and WebAssembly workers under strict capability-based security.

This package is import-safe without any GUI toolkit installed: everything
under :mod:`silicaflux.core`, :mod:`silicaflux.networking`,
:mod:`silicaflux.storage`, :mod:`silicaflux.cache`, :mod:`silicaflux.runtimes`,
:mod:`silicaflux.security`, :mod:`silicaflux.web3`, :mod:`silicaflux.ai` and
:mod:`silicaflux.telemetry` is pure Python. Only :mod:`silicaflux.browser`
requires ``PySide6`` with the WebEngine addon, and it is imported lazily.
"""

from __future__ import annotations

__version__ = "0.1.0"
__all__ = ["__version__"]
