"""Append-only audit log for every security-relevant decision: capability
requests, grants, denials, revocations and sandboxed executions. Persisted
to SQLite via :mod:`silicaflux.storage.database` so it survives restarts
and can be reviewed from ``sfx-runtime`` or the developer tools panel."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional

from silicaflux.core.logging_setup import get_logger

logger = get_logger("security.audit")


@dataclass
class AuditEntry:
    timestamp: float
    origin: str
    action: str
    outcome: str  # "granted" | "denied" | "revoked" | "executed" | "blocked"
    detail: dict[str, Any] = field(default_factory=dict)


class AuditLogger:
    """In-memory ring buffer plus an optional persistence sink. Kept
    dependency-free from storage so security code never has to wait on a
    database write to make a decision; :class:`~silicaflux.storage.database.Database`
    subscribes to :meth:`entries` to flush them asynchronously."""

    def __init__(self, capacity: int = 5000, sink: Optional[Any] = None) -> None:
        self._capacity = capacity
        self._entries: list[AuditEntry] = []
        self._sink = sink  # object with .record_audit_entry(entry) -> None

    def record(self, origin: str, action: str, outcome: str, **detail: Any) -> AuditEntry:
        entry = AuditEntry(time.time(), origin, action, outcome, detail)
        self._entries.append(entry)
        if len(self._entries) > self._capacity:
            self._entries.pop(0)
        log_fn = logger.warning if outcome in ("denied", "blocked", "revoked") else logger.info
        log_fn(f"{action} -> {outcome}", extra={"origin": origin})
        if self._sink is not None:
            try:
                self._sink.record_audit_entry(entry)
            except Exception:
                logger.exception("audit sink failed to persist entry")
        return entry

    def entries(self, origin: Optional[str] = None, limit: int = 200) -> list[AuditEntry]:
        rows = self._entries if origin is None else [e for e in self._entries if e.origin == origin]
        return rows[-limit:]
