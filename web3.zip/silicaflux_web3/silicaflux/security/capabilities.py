"""Capability vocabulary and tokens.

A *capability* names one narrow permission (``python.analytics``,
``wallet.sign``, ``network.fetch``). Nothing in SilicaFlux grants broad
"admin" access — every runtime call, filesystem touch, network request or
Web3 operation must present a capability that was actually issued to the
requesting origin.
"""

from __future__ import annotations

import hashlib
import secrets
import time
from dataclasses import dataclass, field
from typing import Optional


#: Canonical capability names. Applications may only request from this set;
#: an unknown capability name is always denied by the policy engine.
KNOWN_CAPABILITIES: frozenset[str] = frozenset(
    {
        "python.execute",
        "python.analytics",
        "r.execute",
        "r.compute",
        "rust.execute",
        "rust.compute",
        "wasm.execute",
        "network",
        "network.fetch",
        "storage",
        "storage.persistent",
        "filesystem",
        "filesystem.read",
        "filesystem.write",
        "camera",
        "microphone",
        "gpu",
        "npu",
        "identity",
        "identity.read",
        "cryptography",
        "cryptography.sign",
        "p2p",
        "local_compute",
        "wallet.connect",
        "wallet.sign",
        "wallet.read_address",
        "clipboard",
        "notifications",
        "geolocation",
    }
)


class UnknownCapability(ValueError):
    pass


@dataclass(frozen=True)
class CapabilityToken:
    """A signed, time-bounded grant of one capability to one origin.

    Tokens are opaque to applications: they cannot be forged because the
    ``signature`` is an HMAC-style hash over the token fields plus a
    process-local secret held only by :class:`~silicaflux.security.policy.SecurityPolicy`.
    """

    origin: str
    capability: str
    issued_at: float
    expires_at: Optional[float]
    token_id: str
    signature: str
    scope: dict = field(default_factory=dict)

    def is_expired(self, now: Optional[float] = None) -> bool:
        if self.expires_at is None:
            return False
        now = now if now is not None else time.time()
        return now >= self.expires_at

    def to_dict(self) -> dict:
        return {
            "origin": self.origin,
            "capability": self.capability,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "token_id": self.token_id,
            "scope": self.scope,
        }


def validate_capability_name(name: str) -> str:
    if name not in KNOWN_CAPABILITIES:
        raise UnknownCapability(f"'{name}' is not a recognised SilicaFlux capability")
    return name


def new_token_id() -> str:
    return secrets.token_hex(16)


def sign_token(secret: bytes, origin: str, capability: str, token_id: str, issued_at: float) -> str:
    material = f"{origin}|{capability}|{token_id}|{issued_at}".encode()
    return hashlib.sha256(secret + material).hexdigest()
