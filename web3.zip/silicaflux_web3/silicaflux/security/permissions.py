"""High-level permission manager used by the browser UI and Web3 layer.

Where :class:`~silicaflux.security.policy.SecurityPolicy` is the low-level
capability issuance engine, :class:`PermissionManager` is the thing a page
or the browser chrome actually talks to: "does this origin currently have
camera access", "remember this choice", "list everything example.com can
do". It is a thin, ergonomic façade over the policy engine plus a
persistence hook.
"""

from __future__ import annotations

from typing import Optional

from silicaflux.security.capabilities import CapabilityToken
from silicaflux.security.policy import SecurityPolicy


class PermissionManager:
    def __init__(self, policy: SecurityPolicy, persistence: Optional[object] = None) -> None:
        """``persistence`` is any object exposing
        ``save_permission(origin, capability, granted)`` /
        ``load_permissions() -> list[tuple[str, str, bool]]`` — typically
        :class:`silicaflux.storage.permissions_store.PermissionsStore`.
        """
        self.policy = policy
        self.persistence = persistence
        if persistence is not None:
            self._restore()

    def _restore(self) -> None:
        for origin, capability, granted in self.persistence.load_permissions():  # type: ignore[union-attr]
            if granted:
                self.policy.authorize(origin, capability)
            else:
                # a persisted denial simply means "don't auto-prompt again";
                # we do not pre-issue a token, so authorize() will re-run
                # the policy decision (and typically deny again) next time.
                continue

    def request(self, origin: str, capability: str, scope: Optional[dict] = None) -> Optional[CapabilityToken]:
        token = self.policy.authorize(origin, capability, scope)
        if self.persistence is not None:
            self.persistence.save_permission(origin, capability, token is not None)  # type: ignore[union-attr]
        return token

    def has(self, origin: str, capability: str) -> bool:
        return any(t.capability == capability for t in self.policy.grants_for(origin))

    def revoke(self, origin: str, capability: str) -> bool:
        ok = self.policy.revoke(origin, capability)
        if ok and self.persistence is not None:
            self.persistence.save_permission(origin, capability, False)  # type: ignore[union-attr]
        return ok

    def list_for_origin(self, origin: str) -> list[dict]:
        return [t.to_dict() for t in self.policy.grants_for(origin)]
