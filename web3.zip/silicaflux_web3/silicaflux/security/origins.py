"""Origin parsing and isolation.

Every capability grant, cache entry and packet is scoped to an *origin*
(scheme + host + port, following the standard web same-origin model). This
module is the single place that turns a URL into the canonical origin
string used everywhere else in the security layer.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlsplit


@dataclass(frozen=True)
class Origin:
    scheme: str
    host: str
    port: Optional[int]

    def __str__(self) -> str:
        if self.port is None:
            return f"{self.scheme}://{self.host}"
        return f"{self.scheme}://{self.host}:{self.port}"

    @property
    def is_secure(self) -> bool:
        return self.scheme in ("https", "sfx", "wss")

    @property
    def is_internal(self) -> bool:
        return self.scheme == "sfx"


_DEFAULT_PORTS = {"http": 80, "https": 443, "ws": 80, "wss": 443}


def parse_origin(url: str) -> Origin:
    """Parse ``url`` into its :class:`Origin`. Malformed URLs collapse to
    an opaque ``null`` origin (never trusted with any capability)."""
    try:
        parts = urlsplit(url)
        if not parts.scheme or not parts.hostname:
            return Origin("null", "null", None)
        port = parts.port or _DEFAULT_PORTS.get(parts.scheme)
        return Origin(parts.scheme.lower(), parts.hostname.lower(), port)
    except ValueError:
        return Origin("null", "null", None)


def same_origin(url_a: str, url_b: str) -> bool:
    return parse_origin(url_a) == parse_origin(url_b)


class OriginManager:
    """Tracks per-origin isolation state: which origins are currently
    active (have an open tab), and simple helpers used by the policy
    engine and developer tools."""

    def __init__(self) -> None:
        self._active: dict[str, int] = {}

    def register(self, url: str) -> Origin:
        origin = parse_origin(url)
        key = str(origin)
        self._active[key] = self._active.get(key, 0) + 1
        return origin

    def release(self, url: str) -> None:
        key = str(parse_origin(url))
        if key in self._active:
            self._active[key] -= 1
            if self._active[key] <= 0:
                del self._active[key]

    def active_origins(self) -> list[str]:
        return list(self._active.keys())

    def is_active(self, url: str) -> bool:
        return str(parse_origin(url)) in self._active
