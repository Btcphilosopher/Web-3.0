"""Process-level sandboxing primitives shared by the runtime adapters.

This does not attempt a full OS-level container (no chroot/seccomp/cgroups
management here — those are deployment-time concerns, see
``docs/SECURITY.md``); what it *does* provide is the in-process contract
every runtime worker must honour: a resource limit description, best-effort
enforcement via :mod:`resource` where the platform supports it, and a
uniform way to describe *why* a sandboxed call was refused.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Optional

from silicaflux.core.logging_setup import get_logger

logger = get_logger("security.sandbox")


@dataclass(frozen=True)
class ResourceLimits:
    """Resource ceiling applied to a sandboxed worker process."""

    cpu_seconds: float = 5.0
    memory_mb: int = 256
    wall_timeout_s: float = 10.0
    max_output_bytes: int = 10 * 1024 * 1024

    def as_dict(self) -> dict:
        return {
            "cpu_seconds": self.cpu_seconds,
            "memory_mb": self.memory_mb,
            "wall_timeout_s": self.wall_timeout_s,
            "max_output_bytes": self.max_output_bytes,
        }


class SandboxViolation(RuntimeError):
    """Raised when a worker attempted something its sandbox forbids, or
    exceeded its resource limits."""


def apply_worker_limits(limits: ResourceLimits) -> None:
    """Best-effort resource limiting for a freshly-spawned worker process.

    Called at the top of the child process entry point (see
    :mod:`silicaflux.runtimes.python_runtime`). On platforms without the
    POSIX :mod:`resource` module (Windows) this degrades gracefully to
    "no OS-level enforcement" — the wall-clock timeout in the parent
    process (via ``multiprocessing`` join/terminate) remains the primary
    guard everywhere.
    """
    if sys.platform == "win32":
        logger.debug("resource module unavailable on win32; relying on parent-side timeout")
        return
    try:
        import resource

        cpu = int(limits.cpu_seconds) + 1
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))

        mem_bytes = limits.memory_mb * 1024 * 1024
        try:
            resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
        except (ValueError, OSError):
            # RLIMIT_AS is refused on some sandboxed hosts (e.g. certain
            # containers); CPU + wall-clock limits still apply.
            logger.debug("RLIMIT_AS not settable in this environment; continuing without it")
    except Exception as exc:  # pragma: no cover - platform dependent
        logger.warning(f"could not apply resource limits: {exc}")


class SandboxManager:
    """Registry of active sandboxes, used by the developer tools to show
    what is currently constrained and by the runtime manager to look up
    the limits associated with a runtime/origin pair."""

    def __init__(self) -> None:
        self._policies: dict[str, ResourceLimits] = {}

    def set_limits(self, runtime: str, limits: ResourceLimits) -> None:
        self._policies[runtime] = limits

    def limits_for(self, runtime: str) -> ResourceLimits:
        return self._policies.get(runtime, ResourceLimits())

    def describe(self) -> dict[str, dict]:
        return {rt: limits.as_dict() for rt, limits in self._policies.items()}
