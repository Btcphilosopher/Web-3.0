"""Security and capability architecture: origin isolation, capability
tokens, sandboxing, policy decisions and audit logging.

See ``docs/SECURITY.md`` for the full threat model. The short version:
security failures default to denial, private keys never leave
:mod:`silicaflux.web3.identity`, and a webpage gets exactly the
capabilities it was explicitly and individually granted — nothing is
inherited, nothing is implicit.
"""

from __future__ import annotations

from silicaflux.security.audit import AuditLogger
from silicaflux.security.capabilities import CapabilityToken, KNOWN_CAPABILITIES
from silicaflux.security.origins import Origin, OriginManager, parse_origin, same_origin
from silicaflux.security.permissions import PermissionManager
from silicaflux.security.policy import SecurityPolicy
from silicaflux.security.sandbox import ResourceLimits, SandboxManager, SandboxViolation

__all__ = [
    "AuditLogger",
    "CapabilityToken",
    "KNOWN_CAPABILITIES",
    "Origin",
    "OriginManager",
    "parse_origin",
    "same_origin",
    "PermissionManager",
    "SecurityPolicy",
    "ResourceLimits",
    "SandboxManager",
    "SandboxViolation",
]
