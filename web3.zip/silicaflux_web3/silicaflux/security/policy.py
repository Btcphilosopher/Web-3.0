"""The security policy engine — the one place every capability decision is
made.

Flow (see section 18/9 of the spec):

    Application -> Capability Request -> Policy Engine -> User Approval
        -> Capability Token -> Resource

Nothing downstream (runtime workers, the Web3 layer, the filesystem/network
adapters) is trusted to make its own security decision; they call
:meth:`SecurityPolicy.authorize` and get back either a
:class:`~silicaflux.security.capabilities.CapabilityToken` or a denial.
Every decision is written to the :class:`~silicaflux.security.audit.AuditLogger`.
Failures default to denial.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Callable, Optional

from silicaflux.security.audit import AuditLogger
from silicaflux.security.capabilities import (
    CapabilityToken,
    KNOWN_CAPABILITIES,
    UnknownCapability,
    new_token_id,
    sign_token,
    validate_capability_name,
)
from silicaflux.security.origins import Origin, parse_origin
from silicaflux.core.logging_setup import get_logger

logger = get_logger("security.policy")

#: (origin_pattern, capability) -> always allow. Internal sfx:// pages are
#: implicitly trusted for the capabilities that make the runtime dashboard
#: and wallet UI work; ordinary web origins are never in this set.
_BUILTIN_TRUSTED_ORIGINS: frozenset[str] = frozenset({"sfx://home", "sfx://runtime", "sfx://wallet", "sfx://settings", "sfx://developer", "sfx://apps"})

#: Capabilities considered dangerous enough that "prompt" policy always
#: means "ask", even if a lower-friction default policy is configured.
_ALWAYS_PROMPT: frozenset[str] = frozenset(
    {"wallet.sign", "identity", "filesystem.write", "camera", "microphone", "geolocation"}
)

ApprovalCallback = Callable[[str, str, dict], bool]
"""``(origin, capability, scope) -> approved?`` — supplied by the UI layer
(or a CLI prompt / auto-deny in headless/test contexts)."""


@dataclass
class GrantRecord:
    token: CapabilityToken
    revoked: bool = False


def _auto_deny(origin: str, capability: str, scope: dict) -> bool:
    return False


class SecurityPolicy:
    """Central policy + capability issuance engine.

    ``default_policy`` mirrors :class:`silicaflux.core.config.SecuritySettings`:

    * ``"deny"``   — nothing is ever auto-granted; every request needs an
      explicit prior grant (used for locked-down/kiosk profiles).
    * ``"prompt"`` — unknown origin/capability pairs are routed to
      ``approval_callback`` (default: deny, since headless contexts have
      no user to ask).
    * ``"allow"``  — non-dangerous capabilities are auto-granted to any
      origin; capabilities in ``_ALWAYS_PROMPT`` still require approval.
      Intended for local development profiles only.
    """

    def __init__(
        self,
        default_policy: str = "prompt",
        approval_callback: Optional[ApprovalCallback] = None,
        audit: Optional[AuditLogger] = None,
        token_ttl_s: Optional[float] = 3600.0,
    ) -> None:
        self.default_policy = default_policy
        self.approval_callback = approval_callback or _auto_deny
        self.audit = audit or AuditLogger()
        self.token_ttl_s = token_ttl_s
        self._secret = os.urandom(32)
        self._grants: dict[tuple[str, str], GrantRecord] = {}

    # -- issuance --------------------------------------------------------
    def authorize(
        self, origin: str, capability: str, scope: Optional[dict] = None
    ) -> Optional[CapabilityToken]:
        """Request one capability for one origin. Returns a token on
        success, ``None`` on denial. Never raises for a normal denial —
        only for programmer errors (an unknown capability name)."""
        scope = scope or {}
        try:
            validate_capability_name(capability)
        except UnknownCapability:
            self.audit.record(origin, capability, "denied", reason="unknown_capability")
            return None

        existing = self._grants.get((origin, capability))
        if existing and not existing.revoked and not existing.token.is_expired():
            return existing.token

        approved = self._decide(origin, capability, scope)
        if not approved:
            self.audit.record(origin, capability, "denied", reason="policy_or_user")
            return None

        token = self._issue(origin, capability, scope)
        self._grants[(origin, capability)] = GrantRecord(token)
        self.audit.record(origin, capability, "granted", token_id=token.token_id)
        return token

    def _decide(self, origin: str, capability: str, scope: dict) -> bool:
        if origin in _BUILTIN_TRUSTED_ORIGINS:
            return True

        must_prompt = capability in _ALWAYS_PROMPT or self.default_policy == "prompt"
        if self.default_policy == "deny":
            return False
        if must_prompt:
            try:
                return bool(self.approval_callback(origin, capability, scope))
            except Exception:
                logger.exception("approval_callback raised; defaulting to deny")
                return False
        # default_policy == "allow" and capability isn't in the always-prompt set
        return True

    def _issue(self, origin: str, capability: str, scope: dict) -> CapabilityToken:
        now = time.time()
        token_id = new_token_id()
        expires_at = (now + self.token_ttl_s) if self.token_ttl_s else None
        signature = sign_token(self._secret, origin, capability, token_id, now)
        return CapabilityToken(origin, capability, now, expires_at, token_id, signature, scope)

    # -- verification ------------------------------------------------
    def verify(self, token: CapabilityToken) -> bool:
        """Re-validate a token's signature and expiry (used by workers
        that received a token over IPC and must not trust it blindly)."""
        expected = sign_token(self._secret, token.origin, token.capability, token.token_id, token.issued_at)
        if expected != token.signature:
            return False
        if token.is_expired():
            return False
        record = self._grants.get((token.origin, token.capability))
        return bool(record and not record.revoked and record.token.token_id == token.token_id)

    def revoke(self, origin: str, capability: str) -> bool:
        record = self._grants.get((origin, capability))
        if not record:
            return False
        record.revoked = True
        self.audit.record(origin, capability, "revoked")
        return True

    def revoke_all(self, origin: str) -> int:
        n = 0
        for (o, cap), record in self._grants.items():
            if o == origin and not record.revoked:
                record.revoked = True
                n += 1
        if n:
            self.audit.record(origin, "*", "revoked", count=n)
        return n

    def grants_for(self, origin: str) -> list[CapabilityToken]:
        return [
            r.token
            for (o, _cap), r in self._grants.items()
            if o == origin and not r.revoked and not r.token.is_expired()
        ]

    def known_capabilities(self) -> frozenset[str]:
        return KNOWN_CAPABILITIES
