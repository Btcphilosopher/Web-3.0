"""``sfx-runtime`` / ``silicaflux-dev`` — SilicaFlux runtime inspection and
SFX application development workflow.

    sfx-runtime status
    sfx-runtime workers
    sfx-runtime packets
    sfx-runtime telemetry

    silicaflux-dev create <name>
    silicaflux-dev inspect <app-dir>
    silicaflux-dev run <app-dir>
    silicaflux-dev test <app-dir>
    silicaflux-dev profile <app-dir>
    silicaflux-dev build <app-dir>
    silicaflux-dev package <app-dir>

An "SFX application" is a directory containing ``manifest.json`` (see
``examples/sfx_app/manifest.json`` for the shape) plus HTML/JS frontend
files and a Python ``backend.py`` exposing the operations the manifest
declares. This CLI is deliberately the SAME executable module as
:mod:`silicaflux.cli` under a second name — both are registered as
``console_scripts`` — but is invoked as ``sfx-runtime``/``silicaflux-dev``
so the two concerns (running the browser vs. developing an SFX app / a
runtime status one-liner) stay discoverable under names that match what a
developer is actually trying to do.

NOTE ON IMPORTS: ``build_headless_context`` (and everything it pulls in —
httpx, cryptography, psutil, ...) is imported lazily inside each
``async def go():`` below, never at module level — see the matching note
in :mod:`silicaflux.cli` for why: this module is what a spawned
multiprocessing worker re-imports as ``__main__``, and a heavy top-level
import graph here would make every worker pay that cost again.
"""

from __future__ import annotations

import asyncio
import json
import shutil
import zipfile
from pathlib import Path
from typing import Any

import click


def _run(coro):
    return asyncio.run(coro)


def _print_json(data: Any) -> None:
    click.echo(json.dumps(data, indent=2, default=str))


@click.group()
def runtime() -> None:
    """SilicaFlux Runtime inspection (``sfx-runtime``)."""


@runtime.command()
@click.option("--profile", default="default")
@click.option("--profile-dir", default=None)
def status(profile: str, profile_dir: str) -> None:
    """One-shot summary: runtime availability, queue length, workers."""

    async def go():
        from silicaflux.core.bootstrap import build_headless_context

        ctx = await build_headless_context(profile=profile, profile_dir=profile_dir, approve_all=True)
        try:
            s = ctx.engine.status()
            click.echo(f"SilicaFlux engine: {'running' if s['running'] else 'stopped'}")
            click.echo(f"Queue length: {s['queue_length']}   In flight: {s['in_flight']}")
            click.echo("Runtimes:")
            for name, ok in s["runtimes"].items():
                click.echo(f"  {'✓' if ok else '✗'} {name}")
        finally:
            await ctx.shutdown()

    _run(go())


@runtime.command()
@click.option("--profile", default="default")
@click.option("--profile-dir", default=None)
def workers(profile: str, profile_dir: str) -> None:
    """Worker pool table (per runtime)."""

    async def go():
        from silicaflux.core.bootstrap import build_headless_context

        ctx = await build_headless_context(profile=profile, profile_dir=profile_dir, approve_all=True)
        try:
            _print_json([w.to_dict() for w in ctx.engine.worker_registry.all()])
        finally:
            await ctx.shutdown()

    _run(go())


@runtime.command()
@click.option("--limit", default=50)
@click.option("--profile", default="default")
@click.option("--profile-dir", default=None)
def packets(limit: int, profile: str, profile_dir: str) -> None:
    """Recent packet history: id, runtime, operation, state, latency."""

    async def go():
        from silicaflux.core.bootstrap import build_headless_context

        ctx = await build_headless_context(profile=profile, profile_dir=profile_dir, approve_all=True)
        try:
            _print_json(ctx.engine.recent_packets(limit))
        finally:
            await ctx.shutdown()

    _run(go())


@runtime.command()
@click.option("--profile", default="default")
@click.option("--profile-dir", default=None)
def telemetry(profile: str, profile_dir: str) -> None:
    """Full telemetry snapshot: metrics, traces, system load."""

    async def go():
        from silicaflux.core.bootstrap import build_headless_context

        ctx = await build_headless_context(profile=profile, profile_dir=profile_dir, approve_all=True)
        try:
            _print_json(ctx.telemetry.snapshot())
        finally:
            await ctx.shutdown()

    _run(go())


# ---------------------------------------------------------------------------
# SFX application developer workflow (silicaflux-dev)
# ---------------------------------------------------------------------------

_APP_TEMPLATE_MANIFEST = {
    "app_id": "",
    "name": "",
    "version": "0.1.0",
    "description": "A SilicaFlux application",
    "entry": "app.html",
    "backend": "backend.py",
    "operations": [{"name": "hello", "runtime": "python", "function": "hello"}],
    "capabilities": ["python.execute"],
}

_APP_TEMPLATE_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><title>{name}</title></head>
<body>
<h1>{name}</h1>
<button id="run">Call backend</button>
<pre id="out"></pre>
<script src="app.js"></script>
</body></html>
"""

_APP_TEMPLATE_JS = """document.getElementById('run').addEventListener('click', async () => {
  const result = await window.silicaflux.request({runtime: 'python', operation: 'hello', payload: {}});
  document.getElementById('out').textContent = JSON.stringify(result, null, 2);
});
"""

_APP_TEMPLATE_BACKEND = '''"""Backend operations for this SilicaFlux application.

Each function here is registered by name in manifest.json's "operations"
list and runs process-isolated via silicaflux.runtimes.python_runtime —
see silicaflux.dev_cli's "run"/"build" commands for how it gets wired up.
"""


def hello(payload: dict) -> dict:
    return {"message": "Hello from the SilicaFlux Python runtime!", "payload": payload}
'''


@click.group()
def dev() -> None:
    """SilicaFlux SFX application developer workflow (``silicaflux-dev``)."""


@dev.command("create")
@click.argument("name")
@click.option("--dir", "target_dir", default=None, help="Parent directory (default: current directory)")
def dev_create(name: str, target_dir: str) -> None:
    """Scaffold a new SFX application directory."""
    base = Path(target_dir) if target_dir else Path.cwd()
    app_dir = base / name
    if app_dir.exists():
        raise click.ClickException(f"'{app_dir}' already exists")
    app_dir.mkdir(parents=True)

    manifest = dict(_APP_TEMPLATE_MANIFEST)
    manifest["app_id"] = name.lower().replace(" ", "-")
    manifest["name"] = name
    (app_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))
    (app_dir / "app.html").write_text(_APP_TEMPLATE_HTML.format(name=name))
    (app_dir / "app.js").write_text(_APP_TEMPLATE_JS)
    (app_dir / "backend.py").write_text(_APP_TEMPLATE_BACKEND)
    click.echo(f"Created SFX application at {app_dir}")


def _load_manifest(app_dir: Path) -> dict:
    manifest_path = app_dir / "manifest.json"
    if not manifest_path.exists():
        raise click.ClickException(f"no manifest.json found in {app_dir}")
    return json.loads(manifest_path.read_text())


@dev.command("inspect")
@click.argument("app_dir", type=click.Path(exists=True, file_okay=False))
def dev_inspect(app_dir: str) -> None:
    """Print an app's manifest and validate its declared operations exist."""
    path = Path(app_dir)
    manifest = _load_manifest(path)
    backend_path = path / manifest.get("backend", "backend.py")
    issues = []
    if not backend_path.exists():
        issues.append(f"backend file '{backend_path.name}' not found")
    else:
        source = backend_path.read_text()
        for op in manifest.get("operations", []):
            fn_name = op.get("function")
            if fn_name and f"def {fn_name}(" not in source:
                issues.append(f"operation '{op['name']}': function '{fn_name}' not found in {backend_path.name}")
    _print_json({"manifest": manifest, "issues": issues, "valid": not issues})


@dev.command("run")
@click.argument("app_dir", type=click.Path(exists=True, file_okay=False))
@click.option("--operation", default=None, help="Run only this operation (default: all)")
def dev_run(app_dir: str, operation: str) -> None:
    """Run each declared Python operation once, process-isolated, and
    print its result — a fast local smoke test before packaging."""
    path = Path(app_dir).resolve()
    manifest = _load_manifest(path)
    backend_module = manifest.get("backend", "backend.py").removesuffix(".py")

    async def go():
        import sys

        from silicaflux.core.bootstrap import build_headless_context

        sys.path.insert(0, str(path))
        ctx = await build_headless_context(profile="dev", profile_dir=str(path / ".sfx_dev_profile"), approve_all=True)
        try:
            for op in manifest.get("operations", []):
                if operation and op["name"] != operation:
                    continue
                if op.get("runtime") != "python":
                    click.echo(f"skipping '{op['name']}': runtime '{op.get('runtime')}' not runnable by 'dev run' yet")
                    continue
                ctx.runtime_manager.python_registry.register(op["name"], backend_module, op["function"])
                from silicaflux.core.packet import SFXPacket, SecurityContext

                packet = SFXPacket(
                    source="dev-cli",
                    destination="engine",
                    runtime="python",
                    operation=op["name"],
                    payload={},
                    security_context=SecurityContext(origin="sfx://dev"),
                )
                result = await ctx.engine.request(packet)
                click.echo(f"[{op['name']}] {result.state.value}: {result.result if result.state.value == 'completed' else result.error}")
        finally:
            await ctx.shutdown()

    _run(go())


@dev.command("test")
@click.argument("app_dir", type=click.Path(exists=True, file_okay=False))
def dev_test(app_dir: str) -> None:
    """Run pytest against the app's tests/ directory, if present."""
    path = Path(app_dir)
    tests_dir = path / "tests"
    if not tests_dir.exists():
        click.echo("no tests/ directory found; nothing to run")
        return
    import subprocess
    import sys

    result = subprocess.run([sys.executable, "-m", "pytest", str(tests_dir), "-v"])
    raise SystemExit(result.returncode)


@dev.command("profile")
@click.argument("app_dir", type=click.Path(exists=True, file_okay=False))
@click.option("--iterations", default=20)
def dev_profile(app_dir: str, iterations: int) -> None:
    """Benchmark each declared Python operation's latency."""
    path = Path(app_dir).resolve()
    manifest = _load_manifest(path)
    backend_module = manifest.get("backend", "backend.py").removesuffix(".py")

    async def go():
        import sys
        import time

        from silicaflux.core.bootstrap import build_headless_context

        sys.path.insert(0, str(path))
        ctx = await build_headless_context(profile="dev", profile_dir=str(path / ".sfx_dev_profile"), approve_all=True)
        try:
            results = {}
            for op in manifest.get("operations", []):
                if op.get("runtime") != "python":
                    continue
                ctx.runtime_manager.python_registry.register(op["name"], backend_module, op["function"])
                bench = ctx.telemetry.start_benchmark(op["name"])
                from silicaflux.core.packet import SFXPacket, SecurityContext

                for _ in range(iterations):
                    start = time.perf_counter()
                    packet = SFXPacket(
                        source="dev-cli", destination="engine", runtime="python", operation=op["name"], payload={},
                        security_context=SecurityContext(origin="sfx://dev"),
                    )
                    await ctx.engine.request(packet)
                    bench.record((time.perf_counter() - start) * 1000)
                results[op["name"]] = bench.finish().summary()
            _print_json(results)
        finally:
            await ctx.shutdown()

    _run(go())


@dev.command("build")
@click.argument("app_dir", type=click.Path(exists=True, file_okay=False))
def dev_build(app_dir: str) -> None:
    """Validate the manifest and compute content hashes for every file
    (a lightweight, hash-pinned "build" — no compilation step needed for
    an HTML/JS/Python app; the hashes are what a distributor would pin in
    a signed manifest, see silicaflux.web3.identity)."""
    from silicaflux.cache.content_cache import content_hash

    path = Path(app_dir)
    manifest = _load_manifest(path)
    hashes = {}
    for file in sorted(path.rglob("*")):
        if file.is_file() and ".sfx_dev_profile" not in str(file):
            hashes[str(file.relative_to(path))] = content_hash(file.read_bytes())
    _print_json({"app_id": manifest.get("app_id"), "files": hashes})


@dev.command("package")
@click.argument("app_dir", type=click.Path(exists=True, file_okay=False))
@click.option("--out", default=None, help="Output .sfxapp path (default: <app_id>.sfxapp)")
def dev_package(app_dir: str, out: str) -> None:
    """Zip the application directory into a distributable .sfxapp bundle."""
    path = Path(app_dir)
    manifest = _load_manifest(path)
    out_path = Path(out) if out else Path(f"{manifest.get('app_id', path.name)}.sfxapp")
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in sorted(path.rglob("*")):
            if file.is_file() and ".sfx_dev_profile" not in str(file):
                zf.write(file, file.relative_to(path))
    click.echo(f"Packaged {out_path} ({out_path.stat().st_size} bytes)")


def runtime_main() -> None:
    runtime()


def dev_main() -> None:
    dev()


if __name__ == "__main__":
    import sys

    if Path(sys.argv[0]).stem == "sfx-runtime":
        runtime_main()
    else:
        dev_main()
