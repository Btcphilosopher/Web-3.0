"""The SilicaFlux JavaScript bridge (spec section 14): the single,
capability-checked entry point a page's ``window.silicaflux.request(...)``
call reaches.

    silicaflux.request({runtime: "python", operation: "analytics", payload: {...}})

:class:`SilicaFluxBridge` is toolkit-independent — it does not import
PySide6. :mod:`silicaflux.browser.page` wraps one instance per tab with a
``QWebChannel``/``QObject`` adapter so JavaScript can actually call it;
this class is what that adapter delegates to, and it's exactly as
testable without a running browser.

Every request must resolve an origin (the calling page's origin — never
trusted from the payload, always supplied by the browser layer from the
tab's actual current URL) and passes through
:class:`silicaflux.core.engine.SilicaFluxEngine`, which enforces Origin ->
Permission -> Capability -> Runtime -> Policy exactly as spec section 14
requires. ``runtime: "web3"`` is the one exception routed outside the
packet fabric, straight to :class:`silicaflux.web3.dapp_bridge.DAppBridge`
— wallet state is in-process, per-profile UI state, not a
runtime-dispatched computation, so packaging it as an SFXPacket would add
indirection without adding safety.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Optional

from typing import Awaitable, Callable

from silicaflux.core.engine import SilicaFluxEngine
from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import PacketPriority, SFXPacket, SecurityContext
from silicaflux.web3.dapp_bridge import DAppBridge, DAppBridgeError

InternalHandler = Callable[[str, Any], Awaitable[Any]]
"""``(operation, payload) -> result`` — the browser chrome's own backend
for ``sfx://`` pages (the runtime dashboard, history/bookmarks search,
...). Never reachable from ordinary web content, see the origin check in
:meth:`SilicaFluxBridge.request`."""

logger = get_logger("api.bridge")


class BridgeRequestError(RuntimeError):
    pass


@dataclass
class BridgeResponse:
    ok: bool
    packet_id: Optional[str]
    result: Any = None
    error: Optional[str] = None
    latency_ms: Optional[float] = None

    def to_dict(self) -> dict:
        return {"ok": self.ok, "packet_id": self.packet_id, "result": self.result, "error": self.error, "latency_ms": self.latency_ms}


_VALID_RUNTIMES = {"python", "javascript", "r", "rust", "wasm", "web3", "internal"}


class SilicaFluxBridge:
    def __init__(
        self,
        engine: SilicaFluxEngine,
        dapp_bridge: Optional[DAppBridge] = None,
        internal_handler: Optional[InternalHandler] = None,
    ) -> None:
        self.engine = engine
        self.dapp_bridge = dapp_bridge
        self.internal_handler = internal_handler

    async def request(
        self,
        origin: str,
        runtime: str,
        operation: str,
        payload: Any = None,
        *,
        destination: str = "engine",
        priority: str = "normal",
        timeout_s: float = 30.0,
    ) -> BridgeResponse:
        """The one method ``window.silicaflux.request(...)`` ultimately
        calls. ``origin`` must come from the browser layer's own record of
        the calling tab's current URL — never from the JS payload, which
        is exactly the kind of thing a malicious page would lie about."""
        start = time.perf_counter()

        if runtime not in _VALID_RUNTIMES:
            return BridgeResponse(False, None, error=f"unknown runtime '{runtime}'")

        if runtime == "web3":
            if self.dapp_bridge is None:
                return BridgeResponse(False, None, error="web3 layer is not configured")
            try:
                result = await self.dapp_bridge.handle(operation, origin, payload or {})
                return BridgeResponse(True, None, result=result, latency_ms=(time.perf_counter() - start) * 1000)
            except DAppBridgeError as exc:
                return BridgeResponse(False, None, error=str(exc), latency_ms=(time.perf_counter() - start) * 1000)

        if runtime == "internal":
            if not origin.startswith("sfx://"):
                return BridgeResponse(False, None, error="the 'internal' runtime is reserved for sfx:// pages")
            if self.internal_handler is None:
                return BridgeResponse(False, None, error="internal browser-chrome API is not configured")
            try:
                result = await self.internal_handler(operation, payload or {})
                return BridgeResponse(True, None, result=result, latency_ms=(time.perf_counter() - start) * 1000)
            except Exception as exc:
                return BridgeResponse(False, None, error=str(exc), latency_ms=(time.perf_counter() - start) * 1000)

        try:
            priority_enum = PacketPriority(priority)
        except ValueError:
            priority_enum = PacketPriority.NORMAL

        packet = SFXPacket(
            source=f"js:{origin}",
            destination=destination,
            runtime=runtime,
            operation=operation,
            payload=payload,
            priority=priority_enum,
            ttl=timeout_s,
            security_context=SecurityContext(origin=origin),
        )
        result_packet = await self.engine.request(packet)
        latency_ms = (time.perf_counter() - start) * 1000
        if result_packet.state.value == "completed":
            return BridgeResponse(True, result_packet.packet_id, result=result_packet.result, latency_ms=latency_ms)
        return BridgeResponse(False, result_packet.packet_id, error=result_packet.error, latency_ms=latency_ms)

    async def request_dict(self, origin: str, request: dict) -> dict:
        """Convenience entry point matching the raw JS call shape
        (``silicaflux.request({runtime, operation, payload, ...})``) — the
        QWebChannel adapter calls this directly with the parsed JSON
        object it received from the page."""
        response = await self.request(
            origin,
            runtime=request.get("runtime", ""),
            operation=request.get("operation", ""),
            payload=request.get("payload"),
            destination=request.get("destination", "engine"),
            priority=request.get("priority", "normal"),
            timeout_s=float(request.get("timeout_s", 30.0)),
        )
        return response.to_dict()
