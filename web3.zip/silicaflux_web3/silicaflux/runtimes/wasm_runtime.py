"""The WebAssembly runtime adapter, backed by the ``wasmtime`` Python
embedding when it is installed.

WASM modules are registered ahead of time (raw ``.wasm`` bytes, or WAT
text compiled via ``wasmtime.wat2wasm``) — a packet's ``operation`` field
selects one of those pre-approved, pre-verified modules and one of its
exported functions; nothing about which bytecode runs is influenced by
packet payload data. Compiled modules are cached by content hash via
:class:`silicaflux.cache.wasm_cache.WASMCache` so repeated calls to the
same module skip recompilation.

When the ``wasmtime`` package is not installed, :meth:`is_available`
reports ``False`` and every WASM packet fails with a clear, honest
"unavailable" error rather than a mysterious import crash.
"""

from __future__ import annotations

import importlib.util
import time
from dataclasses import dataclass
from typing import Any, Optional

from silicaflux.cache.wasm_cache import WASMCache
from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import SFXPacket
from silicaflux.runtimes.base import OperationNotRegistered, RuntimeAdapter, RuntimeUnavailable

logger = get_logger("runtimes.wasm")

# NOTE: `wasmtime` is imported lazily (see _import_wasmtime), never at
# module load time. Loading wasmtime's native extension installs
# process-wide trap-handling signal handlers (SIGSEGV/SIGBUS — used to
# catch WebAssembly linear-memory out-of-bounds access) as a side effect
# of `import wasmtime` itself, before any Engine is even constructed.
# That has been observed to interfere with QtWebEngine's own Chromium-side
# signal handling when both live in the same process
# (`silicaflux.browser`), so this module must not trigger that import just
# by being imported (as `silicaflux.runtimes.manager` does unconditionally
# at startup). `is_available()` uses `importlib.util.find_spec`, which
# only checks whether the package *could* be imported, without actually
# loading it — the real import happens only once a WASM packet is
# genuinely executed.
_wasmtime_module: Any = None


def _wasmtime_installed() -> bool:
    return importlib.util.find_spec("wasmtime") is not None


def _import_wasmtime() -> Any:
    global _wasmtime_module
    if _wasmtime_module is None:
        import wasmtime as _wt

        _wasmtime_module = _wt
    return _wasmtime_module


@dataclass
class WASMTarget:
    wasm_bytes: bytes
    export_name: str


class WASMModuleRegistry:
    def __init__(self) -> None:
        self._targets: dict[str, WASMTarget] = {}

    def register_bytes(self, operation: str, wasm_bytes: bytes, export_name: str) -> None:
        self._targets[operation] = WASMTarget(wasm_bytes, export_name)

    def register_wat(self, operation: str, wat_source: str, export_name: str) -> None:
        if not _wasmtime_installed():
            raise RuntimeUnavailable("wasmtime is not installed; cannot compile WAT source")
        wasmtime = _import_wasmtime()
        wasm_bytes = wasmtime.wat2wasm(wat_source)
        self.register_bytes(operation, wasm_bytes, export_name)

    def resolve(self, operation: str) -> WASMTarget:
        if operation not in self._targets:
            raise OperationNotRegistered(f"no WASM module registered for operation '{operation}'")
        return self._targets[operation]

    def operations(self) -> list[str]:
        return list(self._targets.keys())


class WASMRuntimeAdapter(RuntimeAdapter):
    name = "wasm"

    def __init__(self, registry: Optional[WASMModuleRegistry] = None, cache: Optional[WASMCache] = None) -> None:
        self.registry = registry or WASMModuleRegistry()
        self.cache = cache or WASMCache()
        # The wasmtime module and its Engine are both created lazily (on
        # first run(), not here) — see the module docstring above the
        # _import_wasmtime helper for why.
        self._engine: Any = None

    def _get_engine(self, wasmtime: Any):
        if self._engine is None:
            self._engine = wasmtime.Engine()
        return self._engine

    def is_available(self) -> bool:
        return _wasmtime_installed()

    async def run(self, packet: SFXPacket) -> Any:
        if not self.is_available():
            raise RuntimeUnavailable(
                "WASM runtime is unavailable: the 'wasmtime' package is not installed. "
                "Install it with 'pip install wasmtime' to enable this runtime."
            )
        wasmtime = _import_wasmtime()
        engine = self._get_engine(wasmtime)
        target = self.registry.resolve(packet.operation)

        cached = self.cache.get(target.wasm_bytes)
        if cached is not None:
            module = cached.engine_handle
        else:
            start = time.perf_counter()
            module = wasmtime.Module(engine, target.wasm_bytes)
            logger.debug(f"compiled WASM module for '{packet.operation}' in {(time.perf_counter()-start)*1000:.1f}ms")
            self.cache.put(target.wasm_bytes, module, [target.export_name])

        store = wasmtime.Store(engine)
        instance = wasmtime.Instance(store, module, [])
        func = instance.exports(store)[target.export_name]
        if func is None:
            raise RuntimeError(f"export '{target.export_name}' not found in WASM module")

        args = packet.payload.get("args", []) if isinstance(packet.payload, dict) else []
        result = func(store, *args)
        return {"result": result}
