"""The Python runtime adapter: controlled, process-isolated execution of
*registered* application functions.

This deliberately does **not** accept code from a packet's payload and
``eval``/``exec`` it — that would let any website with ``python.execute``
capability run arbitrary code on the user's machine. Instead, an
application registers a function ahead of time by its importable location
(``module:function``, e.g. ``silicaflux.examples.sfx_app.backend:analyze``)
via :meth:`PythonFunctionRegistry.register`; a packet's ``operation`` field
is looked up *in that registry*, never used to import anything itself.
Only the resolved, pre-approved ``module:function`` string is ever sent to
a worker process — payload data is just the function's argument.

Isolation model: a small pool of ``multiprocessing`` worker processes
(spawn context, so nothing is inherited from the parent by fork), each
applying CPU/memory resource limits (:mod:`silicaflux.security.sandbox`)
before running any job, with a parent-side wall-clock timeout that kills
and replaces a worker that overruns. One crashed/hung worker never takes
down the engine — the pool detects it, restarts it, and reports the
failure on the packet.
"""

from __future__ import annotations

import asyncio
import importlib
import multiprocessing as mp
import queue
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import SFXPacket
from silicaflux.core.workers import WorkerHandle, WorkerRegistry, WorkerStatus
from silicaflux.runtimes.base import OperationNotRegistered, RuntimeAdapter
from silicaflux.security.sandbox import ResourceLimits, apply_worker_limits

logger = get_logger("runtimes.python")


class PythonFunctionRegistry:
    """Maps a SilicaFlux operation name to an importable ``module:function``
    target. This is the *only* way a Python worker decides what code to
    run — see module docstring."""

    def __init__(self) -> None:
        self._targets: dict[str, tuple[str, str]] = {}

    def register(self, operation: str, module: str, function: str) -> None:
        self._targets[operation] = (module, function)
        logger.info(f"registered python operation '{operation}' -> {module}:{function}")

    def register_target(self, operation: str, target: str) -> None:
        module, _, function = target.partition(":")
        if not function:
            raise ValueError(f"target must be 'module:function', got '{target}'")
        self.register(operation, module, function)

    def resolve(self, operation: str) -> tuple[str, str]:
        if operation not in self._targets:
            raise OperationNotRegistered(f"no python function registered for operation '{operation}'")
        return self._targets[operation]

    def operations(self) -> list[str]:
        return list(self._targets.keys())


def _worker_entry(to_worker: "mp.Queue", from_worker: "mp.Queue", limits: dict) -> None:
    """Child process main loop (module-level so it is picklable/importable
    under the ``spawn`` start method). Applies resource limits once, then
    services jobs until told to shut down."""
    apply_worker_limits(ResourceLimits(**limits))
    while True:
        job = to_worker.get()
        if job is None:  # shutdown sentinel
            return
        message_id, module_name, func_name, payload = job
        try:
            module = importlib.import_module(module_name)
            func = getattr(module, func_name)
            result = func(payload)
            from_worker.put((message_id, "ok", result))
        except BaseException as exc:  # noqa: BLE001 - report every failure to the parent
            from_worker.put((message_id, "error", f"{type(exc).__name__}: {exc}"))


@dataclass
class _PoolWorker:
    worker_id: str
    process: "mp.Process"
    to_worker: "mp.Queue"
    from_worker: "mp.Queue"


class PythonWorkerPool:
    def __init__(
        self,
        size: int = 2,
        limits: Optional[ResourceLimits] = None,
        registry: Optional[WorkerRegistry] = None,
    ) -> None:
        self.size = size
        self.limits = limits or ResourceLimits()
        self.registry = registry or WorkerRegistry()
        # NOTE: mp.get_context("spawn") is created lazily (on first actual
        # use in _spawn_worker, not here) rather than eagerly in __init__.
        # Constructing a PythonRuntimeAdapter is meant to be cheap and
        # side-effect-free — RuntimeManager builds one unconditionally at
        # startup even if the browser never runs a single Python packet —
        # and on Linux, touching multiprocessing's spawn machinery installs
        # process-wide SIGCHLD/resource-tracker bookkeeping that has been
        # observed to interfere with unrelated child-process-heavy
        # libraries initialised later in the same process (notably
        # QtWebEngine's own Chromium subprocess handshake). Deferring this
        # until a Python packet is actually submitted avoids that entirely
        # for the common case (browser never touches the Python runtime).
        self._ctx: "mp.context.SpawnContext | None" = None
        self._workers: dict[str, _PoolWorker] = {}
        self._idle: "asyncio.Queue[str]" = asyncio.Queue()
        self._started = False

    def _context(self) -> "mp.context.SpawnContext":
        if self._ctx is None:
            self._ctx = mp.get_context("spawn")
        return self._ctx

    def start(self) -> None:
        if self._started:
            return
        for _ in range(self.size):
            self._spawn_worker()
        self._started = True

    def _spawn_worker(self) -> str:
        ctx = self._context()
        worker_id = uuid.uuid4().hex[:8]
        to_worker: "mp.Queue" = ctx.Queue()
        from_worker: "mp.Queue" = ctx.Queue()
        process = ctx.Process(
            target=_worker_entry, args=(to_worker, from_worker, self.limits.as_dict()), daemon=True
        )
        process.start()
        self._workers[worker_id] = _PoolWorker(worker_id, process, to_worker, from_worker)
        self.registry.register(WorkerHandle(worker_id, runtime="python", pid=process.pid, status=WorkerStatus.IDLE))
        self._idle.put_nowait(worker_id)
        return worker_id

    def _replace_worker(self, worker_id: str) -> None:
        old = self._workers.pop(worker_id, None)
        if old is not None:
            old.process.terminate()
            old.process.join(timeout=1.0)
        self.registry.mark_crashed(worker_id)
        self.registry.remove(worker_id)
        new_id = self._spawn_worker()
        self.registry.mark_restarted(new_id, self._workers[new_id].process.pid)

    async def submit(self, module: str, function: str, payload: Any, timeout_s: float) -> Any:
        if not self._started:
            self.start()
        worker_id = await self._idle.get()
        worker = self._workers.get(worker_id)
        if worker is None or not worker.process.is_alive():
            self._replace_worker(worker_id)
            raise RuntimeError(f"python worker '{worker_id}' was not alive; restarted, please retry")

        self.registry.mark_busy(worker_id)
        message_id = uuid.uuid4().hex
        worker.to_worker.put((message_id, module, function, payload))
        try:
            reply_id, status, value = await asyncio.to_thread(worker.from_worker.get, True, timeout_s)
        except queue.Empty:
            self._replace_worker(worker_id)
            raise TimeoutError(f"python worker timed out after {timeout_s}s executing {module}:{function}")
        finally:
            pass

        if reply_id != message_id:
            # stale reply from a previous (timed-out) job racing in; the
            # worker is unreliable at this point, retire it defensively.
            self._replace_worker(worker_id)
            raise RuntimeError("python worker returned a mismatched response; worker restarted")

        self.registry.mark_idle(worker_id, success=(status == "ok"))
        await self._idle.put(worker_id)
        if status == "error":
            raise RuntimeError(value)
        return value

    def shutdown(self) -> None:
        for worker in self._workers.values():
            try:
                worker.to_worker.put(None)
            except Exception:
                pass
        for worker in self._workers.values():
            worker.process.join(timeout=1.0)
            if worker.process.is_alive():
                worker.process.terminate()


class PythonRuntimeAdapter(RuntimeAdapter):
    name = "python"

    def __init__(
        self,
        registry: Optional[PythonFunctionRegistry] = None,
        pool: Optional[PythonWorkerPool] = None,
        default_timeout_s: float = 10.0,
    ) -> None:
        self.registry = registry or PythonFunctionRegistry()
        self.pool = pool or PythonWorkerPool()
        self.default_timeout_s = default_timeout_s

    def is_available(self) -> bool:
        return True  # the interpreter running SilicaFlux itself is always "available"

    async def run(self, packet: SFXPacket) -> Any:
        module, function = self.registry.resolve(packet.operation)
        timeout_s = float(packet.metadata.get("timeout_s", self.default_timeout_s))
        return await self.pool.submit(module, function, packet.payload, timeout_s)
