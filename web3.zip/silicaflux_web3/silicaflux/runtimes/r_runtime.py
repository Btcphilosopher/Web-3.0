"""The R runtime adapter (spec Phase/section 11):

    Browser -> SFX Packet -> R Runtime -> Statistics -> SFX Packet -> Browser

R is invoked out-of-process via ``Rscript`` — never embedded into the
browser process — so a slow or crashing R script can't take the browser
down with it. Like the Python adapter, an operation must be registered to
a specific ``.R`` script ahead of time; the packet's ``operation`` name is
never used to construct a path or command directly from untrusted input.

When ``Rscript`` isn't on ``PATH`` (the common case in a container that
hasn't installed R), :meth:`RRuntimeAdapter.is_available` reports
``False`` and the router fails any R packet with a clear "R runtime
unavailable" error rather than pretending to support it.
"""

from __future__ import annotations

import asyncio
import json
import shutil
import tempfile
from pathlib import Path
from typing import Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import SFXPacket
from silicaflux.runtimes.base import OperationNotRegistered, RuntimeAdapter, RuntimeUnavailable

logger = get_logger("runtimes.r")

#: A minimal, self-contained R script bridge: reads one JSON object from
#: stdin (the payload), calls whichever function the registry selected via
#: an environment variable set by the parent, and writes one JSON object
#: to stdout. Application scripts define R functions and are invoked
#: through this same harness so the adapter never has to string-format
#: user-controlled data into an R expression.
_BRIDGE_TEMPLATE = """
args <- commandArgs(trailingOnly = TRUE)
script_path <- args[[1]]
function_name <- args[[2]]

if (!requireNamespace("jsonlite", quietly = TRUE)) {{
  cat(jsonlite::toJSON(list(error = "jsonlite package not available"), auto_unbox = TRUE))
  quit(status = 1)
}}

source(script_path)
payload <- jsonlite::fromJSON(file("stdin"), simplifyVector = TRUE)
result <- do.call(function_name, list(payload))
cat(jsonlite::toJSON(result, auto_unbox = TRUE))
"""


class RFunctionRegistry:
    def __init__(self) -> None:
        self._targets: dict[str, tuple[Path, str]] = {}

    def register(self, operation: str, script_path: Path, function_name: str) -> None:
        self._targets[operation] = (script_path, function_name)

    def resolve(self, operation: str) -> tuple[Path, str]:
        if operation not in self._targets:
            raise OperationNotRegistered(f"no R function registered for operation '{operation}'")
        return self._targets[operation]

    def operations(self) -> list[str]:
        return list(self._targets.keys())


class RRuntimeAdapter(RuntimeAdapter):
    name = "r"

    def __init__(self, registry: Optional[RFunctionRegistry] = None, default_timeout_s: float = 15.0) -> None:
        self.registry = registry or RFunctionRegistry()
        self.default_timeout_s = default_timeout_s
        self._rscript_path: Optional[str] = shutil.which("Rscript")

    def is_available(self) -> bool:
        self._rscript_path = self._rscript_path or shutil.which("Rscript")
        return self._rscript_path is not None

    async def run(self, packet: SFXPacket) -> dict:
        if not self.is_available():
            raise RuntimeUnavailable(
                "R runtime is unavailable: 'Rscript' was not found on PATH. "
                "Install R (https://www.r-project.org/) to enable this runtime."
            )
        script_path, function_name = self.registry.resolve(packet.operation)
        timeout_s = float(packet.metadata.get("timeout_s", self.default_timeout_s))

        with tempfile.NamedTemporaryFile("w", suffix=".R", delete=False) as bridge_file:
            bridge_file.write(_BRIDGE_TEMPLATE)
            bridge_path = bridge_file.name

        try:
            proc = await asyncio.create_subprocess_exec(
                self._rscript_path,
                "--vanilla",
                bridge_path,
                str(script_path),
                function_name,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(json.dumps(packet.payload).encode()), timeout=timeout_s
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                raise RuntimeError(f"R script timed out after {timeout_s}s")

            if proc.returncode != 0:
                raise RuntimeError(f"R script exited with {proc.returncode}: {stderr.decode(errors='replace')[:2000]}")
            try:
                return json.loads(stdout.decode())
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"R script produced invalid JSON: {exc}; stderr={stderr.decode(errors='replace')[:500]}")
        finally:
            Path(bridge_path).unlink(missing_ok=True)
