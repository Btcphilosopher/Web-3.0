"""Multi-language runtime adapters: Python (process-isolated), R
(subprocess via Rscript), Rust (capability-scoped compiled binaries),
WebAssembly (wasmtime) and JavaScript (the page-facing bridge). See
:mod:`silicaflux.runtimes.manager` for the object that wires all five
into a :class:`silicaflux.core.router.RuntimeRouter`."""

from __future__ import annotations

from silicaflux.runtimes.base import OperationNotRegistered, RuntimeAdapter, RuntimeUnavailable
from silicaflux.runtimes.data_model import SFXValue, ValueType
from silicaflux.runtimes.manager import RuntimeAvailability, RuntimeManager

__all__ = [
    "RuntimeAdapter",
    "RuntimeUnavailable",
    "OperationNotRegistered",
    "SFXValue",
    "ValueType",
    "RuntimeManager",
    "RuntimeAvailability",
]
