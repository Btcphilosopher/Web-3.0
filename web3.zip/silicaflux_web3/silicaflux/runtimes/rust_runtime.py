"""The Rust runtime adapter.

Rust participates in SilicaFlux as a compiled, capability-scoped binary
that speaks a tiny JSON-over-stdio protocol: one JSON object on stdin, one
JSON object on stdout, exit code 0 on success. This adapter never runs an
arbitrary path supplied by a packet — only binaries explicitly registered
via :meth:`RustBinaryRegistry.register` (or compiled once from a trusted
source crate via :meth:`RustBinaryRegistry.register_source`) can be
invoked, which is the capability-based permission model spec section 12
asks for: compiled Rust modules "participate" in the runtime, they are not
handed the keys to it.
"""

from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import SFXPacket
from silicaflux.runtimes.base import OperationNotRegistered, RuntimeAdapter, RuntimeUnavailable

logger = get_logger("runtimes.rust")


class RustBuildError(RuntimeError):
    pass


class RustBinaryRegistry:
    def __init__(self) -> None:
        self._binaries: dict[str, Path] = {}

    def register(self, operation: str, binary_path: Path) -> None:
        self._binaries[operation] = binary_path

    def register_source(self, operation: str, crate_dir: Path, *, release: bool = True) -> Path:
        """Build a Cargo crate once (``cargo build [--release]``) and
        register the resulting binary. Raises :class:`RustBuildError` if
        ``cargo`` isn't available or the build fails — callers should
        treat that as "this operation stays unregistered", not crash the
        whole adapter."""
        cargo = shutil.which("cargo")
        if cargo is None:
            raise RustBuildError("cargo not found on PATH; cannot build Rust source crate")
        cmd = [cargo, "build"] + (["--release"] if release else [])
        result = subprocess.run(cmd, cwd=str(crate_dir), capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            raise RustBuildError(f"cargo build failed for {crate_dir}:\n{result.stderr[-4000:]}")
        profile_dir = "release" if release else "debug"
        crate_name = _read_crate_name(crate_dir)
        binary_path = crate_dir / "target" / profile_dir / crate_name
        if not binary_path.exists():
            raise RustBuildError(f"expected binary not found at {binary_path}")
        self.register(operation, binary_path)
        logger.info(f"built and registered rust operation '{operation}' -> {binary_path}")
        return binary_path

    def resolve(self, operation: str) -> Path:
        if operation not in self._binaries:
            raise OperationNotRegistered(f"no Rust binary registered for operation '{operation}'")
        return self._binaries[operation]

    def operations(self) -> list[str]:
        return list(self._binaries.keys())


def _read_crate_name(crate_dir: Path) -> str:
    cargo_toml = (crate_dir / "Cargo.toml").read_text()
    for line in cargo_toml.splitlines():
        line = line.strip()
        if line.startswith("name"):
            return line.split("=", 1)[1].strip().strip('"')
    return crate_dir.name


class RustRuntimeAdapter(RuntimeAdapter):
    name = "rust"

    def __init__(self, registry: Optional[RustBinaryRegistry] = None, default_timeout_s: float = 15.0) -> None:
        self.registry = registry or RustBinaryRegistry()
        self.default_timeout_s = default_timeout_s

    def is_available(self) -> bool:
        return len(self.registry.operations()) > 0

    async def run(self, packet: SFXPacket) -> dict:
        binary_path = self.registry.resolve(packet.operation)
        if not binary_path.exists():
            raise RuntimeUnavailable(f"registered Rust binary is missing on disk: {binary_path}")
        timeout_s = float(packet.metadata.get("timeout_s", self.default_timeout_s))

        proc = await asyncio.create_subprocess_exec(
            str(binary_path),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(json.dumps(packet.payload).encode()), timeout=timeout_s
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise RuntimeError(f"Rust binary timed out after {timeout_s}s")

        if proc.returncode != 0:
            raise RuntimeError(f"Rust binary exited with {proc.returncode}: {stderr.decode(errors='replace')[:2000]}")
        try:
            return json.loads(stdout.decode())
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Rust binary produced invalid JSON: {exc}")
