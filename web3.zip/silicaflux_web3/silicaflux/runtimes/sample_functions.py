"""A handful of importable, side-effect-free functions used as the default
:class:`~silicaflux.runtimes.python_runtime.PythonFunctionRegistry`
targets for the CLI demo, tests and the example SFX application. Real
applications register their own module:function targets the same way —
see ``examples/sfx_app/backend.py``.
"""

from __future__ import annotations

import statistics
from typing import Any


def echo(payload: Any) -> Any:
    return payload


def analytics_summary(payload: dict) -> dict:
    """A small deterministic "analytics" computation: summary statistics
    over a list of numbers. Used by the demo dashboard and the
    computation-cache example."""
    values = [float(v) for v in payload.get("values", [])]
    if not values:
        return {"count": 0, "mean": None, "stdev": None, "min": None, "max": None}
    return {
        "count": len(values),
        "mean": statistics.fmean(values),
        "stdev": statistics.pstdev(values) if len(values) > 1 else 0.0,
        "min": min(values),
        "max": max(values),
    }


def fibonacci(payload: dict) -> int:
    n = int(payload.get("n", 0))
    a, b = 0, 1
    for _ in range(max(0, n)):
        a, b = b, a + b
    return a


def sha256_of(payload: dict) -> str:
    import hashlib

    text = str(payload.get("text", ""))
    return hashlib.sha256(text.encode()).hexdigest()


def slow_operation(payload: dict) -> dict:
    """Deliberately sleeps past a short timeout — used by tests/benchmarks
    to exercise the worker pool's timeout-and-restart path."""
    import time

    time.sleep(float(payload.get("seconds", 5.0)))
    return {"slept": True}
