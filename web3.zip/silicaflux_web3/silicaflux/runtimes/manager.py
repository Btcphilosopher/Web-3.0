"""RuntimeManager — constructs every runtime adapter, honours the
enable/disable flags in :class:`silicaflux.core.config.RuntimeSettings`,
registers the enabled ones with a :class:`~silicaflux.core.router.RuntimeRouter`,
and gives the developer tools / CLI one place to ask "what's available and
why isn't X".
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.core.router import RuntimeRouter
from silicaflux.core.workers import WorkerRegistry
from silicaflux.runtimes.javascript_runtime import JavaScriptChannelRegistry, JavaScriptRuntimeAdapter
from silicaflux.runtimes.python_runtime import PythonFunctionRegistry, PythonRuntimeAdapter, PythonWorkerPool
from silicaflux.runtimes.r_runtime import RFunctionRegistry, RRuntimeAdapter
from silicaflux.runtimes.rust_runtime import RustBinaryRegistry, RustRuntimeAdapter
from silicaflux.runtimes.wasm_runtime import WASMModuleRegistry, WASMRuntimeAdapter
from silicaflux.security.sandbox import ResourceLimits

logger = get_logger("runtimes.manager")


@dataclass
class RuntimeAvailability:
    runtime: str
    enabled_by_settings: bool
    available: bool
    reason: str = ""


class RuntimeManager:
    def __init__(
        self,
        router: Optional[RuntimeRouter] = None,
        worker_registry: Optional[WorkerRegistry] = None,
        *,
        python_enabled: bool = True,
        r_enabled: bool = True,
        rust_enabled: bool = True,
        wasm_enabled: bool = True,
        javascript_enabled: bool = True,
        python_pool_size: int = 2,
        python_worker_limits: Optional[ResourceLimits] = None,
    ) -> None:
        self.router = router or RuntimeRouter()
        self.worker_registry = worker_registry or WorkerRegistry()

        self.python_registry = PythonFunctionRegistry()
        self.python_pool = PythonWorkerPool(size=python_pool_size, limits=python_worker_limits, registry=self.worker_registry)
        self.python = PythonRuntimeAdapter(registry=self.python_registry, pool=self.python_pool)

        self.r_registry = RFunctionRegistry()
        self.r = RRuntimeAdapter(registry=self.r_registry)

        self.rust_registry = RustBinaryRegistry()
        self.rust = RustRuntimeAdapter(registry=self.rust_registry)

        self.wasm_registry = WASMModuleRegistry()
        self.wasm = WASMRuntimeAdapter(registry=self.wasm_registry)

        self.js_registry = JavaScriptChannelRegistry()
        self.javascript = JavaScriptRuntimeAdapter(registry=self.js_registry, enabled=javascript_enabled)

        self._enabled_by_settings = {
            "python": python_enabled,
            "r": r_enabled,
            "rust": rust_enabled,
            "wasm": wasm_enabled,
            "javascript": javascript_enabled,
        }
        self._adapters = {
            "python": self.python,
            "r": self.r,
            "rust": self.rust,
            "wasm": self.wasm,
            "javascript": self.javascript,
        }
        self._register_enabled()

    def _register_enabled(self) -> None:
        for name, adapter in self._adapters.items():
            if self._enabled_by_settings.get(name, True):
                self.router.register(adapter)
            else:
                self.router.unregister(name)

    def set_enabled(self, runtime: str, enabled: bool) -> None:
        self._enabled_by_settings[runtime] = enabled
        self._register_enabled()

    def availability(self) -> list[RuntimeAvailability]:
        report = []
        for name, adapter in self._adapters.items():
            enabled = self._enabled_by_settings.get(name, True)
            available = enabled and adapter.is_available()
            reason = ""
            if not enabled:
                reason = "disabled in settings"
            elif not adapter.is_available():
                reason = {
                    "r": "Rscript not found on PATH",
                    "rust": "no Rust operations registered/built",
                    "wasm": "wasmtime package not installed",
                }.get(name, "unavailable")
            report.append(RuntimeAvailability(name, enabled, available, reason))
        return report

    def shutdown(self) -> None:
        self.python_pool.shutdown()
