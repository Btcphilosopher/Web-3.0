"""A language-neutral value model shared by every runtime adapter.

When a value crosses a runtime boundary (Python -> R, JavaScript ->
Python, Rust -> WASM) it is wrapped in an :class:`SFXValue` tagging its
type from a small closed set the spec calls out explicitly: String,
Integer, Float, Boolean, Array, Map, Binary, Tensor, Stream, JSON. This is
what lets :mod:`silicaflux.runtimes.r_runtime` and
:mod:`silicaflux.runtimes.rust_runtime` serialise a request to a
subprocess and unambiguously reconstruct it on the way back, and what lets
the developer tools render a typed value instead of an opaque blob.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from enum import Enum
from typing import Any


class ValueType(str, Enum):
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    ARRAY = "array"
    MAP = "map"
    BINARY = "binary"
    TENSOR = "tensor"
    STREAM = "stream"
    JSON = "json"
    NULL = "null"


@dataclass
class TensorShape:
    dtype: str  # "float32" | "float64" | "int32" | "int64" | "uint8" | ...
    shape: tuple[int, ...]


class UnsupportedValueType(TypeError):
    pass


@dataclass
class SFXValue:
    """A tagged value plus enough metadata to reconstruct it faithfully."""

    type: ValueType
    data: Any
    tensor_shape: TensorShape | None = None

    def to_wire(self) -> dict[str, Any]:
        """JSON-safe representation for IPC / subprocess stdin-stdout."""
        if self.type == ValueType.BINARY:
            payload = base64.b64encode(self.data).decode("ascii")
        elif self.type == ValueType.TENSOR:
            payload = {
                "dtype": self.tensor_shape.dtype,
                "shape": list(self.tensor_shape.shape),
                "values": list(self.data),
            }
        else:
            payload = self.data
        return {"type": self.type.value, "data": payload}

    @classmethod
    def from_wire(cls, wire: dict[str, Any]) -> "SFXValue":
        vtype = ValueType(wire["type"])
        if vtype == ValueType.BINARY:
            return cls(vtype, base64.b64decode(wire["data"]))
        if vtype == ValueType.TENSOR:
            payload = wire["data"]
            return cls(vtype, payload["values"], TensorShape(payload["dtype"], tuple(payload["shape"])))
        return cls(vtype, wire["data"])

    @classmethod
    def infer(cls, value: Any) -> "SFXValue":
        """Best-effort classification of a plain Python value into the
        SilicaFlux type model — used when a runtime hands back a native
        value instead of an already-tagged one."""
        if value is None:
            return cls(ValueType.NULL, None)
        if isinstance(value, bool):
            return cls(ValueType.BOOLEAN, value)
        if isinstance(value, int):
            return cls(ValueType.INTEGER, value)
        if isinstance(value, float):
            return cls(ValueType.FLOAT, value)
        if isinstance(value, str):
            return cls(ValueType.STRING, value)
        if isinstance(value, (bytes, bytearray)):
            return cls(ValueType.BINARY, bytes(value))
        if isinstance(value, list):
            return cls(ValueType.ARRAY, value)
        if isinstance(value, dict):
            return cls(ValueType.MAP, value)
        raise UnsupportedValueType(f"cannot classify Python value of type {type(value)}")
