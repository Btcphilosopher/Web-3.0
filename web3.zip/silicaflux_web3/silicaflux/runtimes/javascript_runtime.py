"""The JavaScript runtime adapter — the Python-side half of the
JavaScript <-> SilicaFlux bridge (spec section 14).

There is no embedded JS engine here: page-side JavaScript already runs in
the Chromium/QtWebEngine process (:mod:`silicaflux.browser.page`), which
is exactly the point — SilicaFlux does not reimplement a JS runtime, it
routes *into* the one that's already there. This adapter represents
``packet.runtime == "javascript"``: SilicaFlux-initiated calls **into** a
page's JS context (e.g. handing a Python computation's result to a
callback the page registered), the mirror image of
:mod:`silicaflux.api.bridge`, which handles calls **from** a page's
``window.silicaflux.request(...)`` into the engine.

A "channel" is any async callable ``(operation, payload) -> result``
registered per destination (typically per tab). In the real GUI, the
browser layer registers a channel backed by ``QWebEngineView.page().runJavaScript``
plus a ``QWebChannel`` round-trip; tests and the CLI can register a plain
Python coroutine instead.
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable, Optional

from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import SFXPacket
from silicaflux.runtimes.base import OperationNotRegistered, RuntimeAdapter, RuntimeUnavailable

logger = get_logger("runtimes.javascript")

JSChannel = Callable[[str, Any], Awaitable[Any]]


class JavaScriptChannelRegistry:
    def __init__(self) -> None:
        self._channels: dict[str, JSChannel] = {}

    def register(self, destination: str, channel: JSChannel) -> None:
        self._channels[destination] = channel

    def unregister(self, destination: str) -> None:
        self._channels.pop(destination, None)

    def resolve(self, destination: str) -> JSChannel:
        if destination not in self._channels:
            raise OperationNotRegistered(f"no JavaScript channel registered for destination '{destination}'")
        return self._channels[destination]

    def destinations(self) -> list[str]:
        return list(self._channels.keys())


class JavaScriptRuntimeAdapter(RuntimeAdapter):
    name = "javascript"

    def __init__(self, registry: Optional[JavaScriptChannelRegistry] = None, enabled: bool = True, default_timeout_s: float = 10.0) -> None:
        self.registry = registry or JavaScriptChannelRegistry()
        self.enabled = enabled
        self.default_timeout_s = default_timeout_s

    def is_available(self) -> bool:
        return self.enabled

    async def run(self, packet: SFXPacket) -> Any:
        if not self.enabled:
            raise RuntimeUnavailable("JavaScript bridge is disabled by browser settings")
        channel = self.registry.resolve(packet.destination)
        timeout_s = float(packet.metadata.get("timeout_s", self.default_timeout_s))
        return await asyncio.wait_for(channel(packet.operation, packet.payload), timeout=timeout_s)
