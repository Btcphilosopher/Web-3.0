"""The common contract every runtime adapter implements, plus shared
helpers for turning adapter results into packet transitions.

Concrete adapters (:mod:`silicaflux.runtimes.python_runtime`,
``javascript_runtime``, ``r_runtime``, ``rust_runtime``, ``wasm_runtime``)
subclass :class:`RuntimeAdapter` and only need to implement
:meth:`RuntimeAdapter.is_available` and :meth:`RuntimeAdapter.run`
(the narrow "actually do the work" method); :meth:`RuntimeAdapter.execute`
(the method :class:`silicaflux.core.router.RuntimeRouter` calls) handles
packet state transitions and uncaught-exception -> FAILED translation
uniformly, so no adapter can accidentally leave a packet stuck mid-flight.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from typing import Any

from silicaflux.core.logging_setup import get_logger
from silicaflux.core.packet import PacketState, SFXPacket

logger = get_logger("runtimes.base")


class RuntimeUnavailable(RuntimeError):
    """Raised by :meth:`RuntimeAdapter.run` when the adapter is registered
    but the underlying language runtime isn't installed/reachable on this
    host (e.g. no ``Rscript`` on PATH). Distinct from a normal execution
    failure so the developer tools can show "not installed" rather than
    "crashed"."""


class OperationNotRegistered(RuntimeError):
    """Raised when a packet names an operation the adapter has no
    registered handler for. Adapters must never fall back to evaluating
    arbitrary code from ``packet.payload`` when this happens."""


class RuntimeAdapter(ABC):
    name: str = "unset"

    @abstractmethod
    def is_available(self) -> bool:
        """Cheap, side-effect-free check: is the underlying runtime usable
        right now (binary on PATH, worker pool alive, ...)."""

    @abstractmethod
    async def run(self, packet: SFXPacket) -> Any:
        """Do the actual work and return a JSON-ish result. Raise
        :class:`OperationNotRegistered` for an unknown operation or
        :class:`RuntimeUnavailable` if the runtime just became unreachable;
        any other exception is treated as an ordinary execution failure."""

    async def execute(self, packet: SFXPacket) -> SFXPacket:
        start = time.perf_counter()
        try:
            self._ensure_executing(packet)
            result = await self.run(packet)
            packet.result = result
            packet.transition(PacketState.COMPLETED, f"{self.name} run() succeeded")
        except (OperationNotRegistered, RuntimeUnavailable) as exc:
            packet.error = str(exc)
            packet.transition(PacketState.FAILED, str(exc))
        except Exception as exc:  # keep the fabric alive: one bad packet never crashes the engine
            logger.exception(f"[{self.name}] packet {packet.packet_id} raised during execution")
            packet.error = f"{type(exc).__name__}: {exc}"
            packet.transition(PacketState.FAILED, packet.error)
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            logger.info(
                f"{self.name}.{packet.operation} finished ({packet.state.value})",
                extra={"runtime": self.name, "operation": packet.operation, "duration_ms": round(duration_ms, 2)},
            )
        return packet

    def _ensure_executing(self, packet: SFXPacket) -> None:
        """Advance a packet through whatever legal states it hasn't yet
        passed through to reach EXECUTING. Normally the engine's dispatch
        loop (:mod:`silicaflux.core.engine`) already drove the packet from
        CREATED -> QUEUED -> ROUTED -> EXECUTING before calling
        :meth:`execute`; this makes an adapter safe to call directly too
        (e.g. from a unit test or a diagnostic CLI command) without
        requiring the caller to replay the whole fabric by hand."""
        order = [PacketState.CREATED, PacketState.QUEUED, PacketState.ROUTED, PacketState.EXECUTING]
        if packet.state not in order:
            return  # already EXECUTING/STREAMING or terminal; nothing to auto-advance
        for state in order[order.index(packet.state) + 1 :]:
            packet.transition(state, f"auto-advanced by {self.name} adapter")
