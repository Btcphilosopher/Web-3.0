"""A small asyncio-friendly DNS cache with TTL and negative-caching.

``socket.getaddrinfo`` is blocking, so lookups run in a thread pool via
``asyncio.to_thread``; concurrent lookups for the same host are
coalesced onto a single in-flight future so a page that fires ten
requests to the same host in the same tick doesn't trigger ten resolver
round-trips.
"""

from __future__ import annotations

import asyncio
import socket
import time
from dataclasses import dataclass, field
from typing import Optional

from silicaflux.cache.stats import CacheStats
from silicaflux.core.logging_setup import get_logger

logger = get_logger("networking.dns")


@dataclass
class DNSRecord:
    host: str
    addresses: list[str]
    resolved_at: float
    ttl_s: float
    error: Optional[str] = None

    def is_fresh(self, now: Optional[float] = None) -> bool:
        now = now if now is not None else time.time()
        return (now - self.resolved_at) < self.ttl_s


class DNSCache:
    def __init__(self, default_ttl_s: float = 60.0, negative_ttl_s: float = 5.0) -> None:
        self.default_ttl_s = default_ttl_s
        self.negative_ttl_s = negative_ttl_s
        self._records: dict[str, DNSRecord] = {}
        self._inflight: dict[str, asyncio.Future] = {}
        self.stats = CacheStats(name="dns_cache")

    async def resolve(self, host: str, port: int = 443) -> DNSRecord:
        record = self._records.get(host)
        if record is not None and record.is_fresh():
            self.stats.record_hit()
            return record
        self.stats.record_miss()

        if host in self._inflight:
            return await self._inflight[host]

        loop = asyncio.get_event_loop()
        future = loop.create_future()
        self._inflight[host] = future
        try:
            record = await self._do_resolve(host, port)
            self._records[host] = record
            future.set_result(record)
            return record
        finally:
            self._inflight.pop(host, None)

    async def _do_resolve(self, host: str, port: int) -> DNSRecord:
        start = time.perf_counter()
        try:
            infos = await asyncio.to_thread(socket.getaddrinfo, host, port, proto=socket.IPPROTO_TCP)
            addresses = sorted({info[4][0] for info in infos})
            logger.debug(f"resolved {host} -> {addresses} in {(time.perf_counter()-start)*1000:.1f}ms")
            return DNSRecord(host, addresses, time.time(), self.default_ttl_s)
        except socket.gaierror as exc:
            return DNSRecord(host, [], time.time(), self.negative_ttl_s, error=str(exc))

    def invalidate(self, host: str) -> None:
        self._records.pop(host, None)

    def snapshot(self) -> list[dict]:
        return [
            {"host": h, "addresses": r.addresses, "age_s": round(time.time() - r.resolved_at, 1), "error": r.error}
            for h, r in self._records.items()
        ]
