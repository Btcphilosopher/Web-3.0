"""Per-request performance timeline: DNS / TLS / Connection / TTFB /
Download / Total (spec section "Add a performance monitor").

``httpx`` exposes connection-pool events but not a W3C-Navigation-Timing
style breakdown out of the box, so :class:`RequestTiming` is populated
from wall-clock checkpoints the client records around the parts of a
request it controls directly (DNS resolution via
:mod:`silicaflux.networking.dns_cache`, and coarse phase boundaries around
the ``httpx`` call). This is honest about its precision: on a cached
connection, DNS/TLS/Connection collapse to ~0 rather than being guessed.
"""

from __future__ import annotations

import statistics
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RequestTiming:
    url: str
    dns_ms: float = 0.0
    tls_ms: float = 0.0
    connect_ms: float = 0.0
    ttfb_ms: float = 0.0
    download_ms: float = 0.0
    total_ms: float = 0.0
    bytes_downloaded: int = 0
    from_cache: bool = False
    status_code: Optional[int] = None
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "dns_ms": round(self.dns_ms, 2),
            "tls_ms": round(self.tls_ms, 2),
            "connect_ms": round(self.connect_ms, 2),
            "ttfb_ms": round(self.ttfb_ms, 2),
            "download_ms": round(self.download_ms, 2),
            "total_ms": round(self.total_ms, 2),
            "bytes_downloaded": self.bytes_downloaded,
            "from_cache": self.from_cache,
            "status_code": self.status_code,
            "error": self.error,
        }

    @property
    def throughput_bps(self) -> float:
        if self.download_ms <= 0:
            return 0.0
        return self.bytes_downloaded / (self.download_ms / 1000.0)


class _Stopwatch:
    def __init__(self) -> None:
        self._start = time.perf_counter()
        self._marks: dict[str, float] = {}

    def mark(self, name: str) -> float:
        now = time.perf_counter()
        elapsed_ms = (now - self._start) * 1000
        self._marks[name] = elapsed_ms
        return elapsed_ms

    def get(self, name: str) -> float:
        """Milliseconds elapsed (from stopwatch start) at the time
        ``name`` was marked; 0.0 if it was never marked."""
        return self._marks.get(name, 0.0)

    def since(self, name: str) -> float:
        """Milliseconds since ``name`` was marked, or since start if
        ``name`` was never marked."""
        base = self._marks.get(name, 0.0)
        return (time.perf_counter() - self._start) * 1000 - base

    def elapsed_ms(self) -> float:
        return (time.perf_counter() - self._start) * 1000


class PerformanceMonitor:
    """Aggregates :class:`RequestTiming` samples for the network panel
    (:mod:`silicaflux.developer.network_panel`) and telemetry system."""

    def __init__(self, history_limit: int = 500) -> None:
        self._history: list[RequestTiming] = []
        self._history_limit = history_limit

    def new_stopwatch(self) -> _Stopwatch:
        return _Stopwatch()

    def record(self, timing: RequestTiming) -> None:
        self._history.append(timing)
        if len(self._history) > self._history_limit:
            self._history.pop(0)

    def recent(self, limit: int = 100) -> list[dict]:
        return [t.to_dict() for t in self._history[-limit:]]

    def summary(self) -> dict:
        if not self._history:
            return {"count": 0}
        totals = [t.total_ms for t in self._history]
        ttfbs = [t.ttfb_ms for t in self._history if t.ttfb_ms]
        cache_hits = sum(1 for t in self._history if t.from_cache)
        return {
            "count": len(self._history),
            "avg_total_ms": round(statistics.mean(totals), 2),
            "p95_total_ms": round(_percentile(totals, 95), 2),
            "avg_ttfb_ms": round(statistics.mean(ttfbs), 2) if ttfbs else 0.0,
            "cache_hit_rate": round(cache_hits / len(self._history), 4),
            "errors": sum(1 for t in self._history if t.error),
        }


def _percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    k = (len(ordered) - 1) * (pct / 100)
    f, c = int(k), min(int(k) + 1, len(ordered) - 1)
    if f == c:
        return ordered[f]
    return ordered[f] + (ordered[c] - ordered[f]) * (k - f)
