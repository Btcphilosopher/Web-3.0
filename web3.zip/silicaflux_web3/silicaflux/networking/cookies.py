"""Cookie storage and same-site/third-party policy enforcement.

Deliberately simpler than a full RFC 6265 implementation (no public-suffix
list, no cookie prefixes) but enforces the parts that matter for privacy:
domain scoping, expiry, and an opt-in third-party-cookie block driven by
:class:`silicaflux.core.config.PrivacySettings`.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

from silicaflux.security.origins import parse_origin


@dataclass
class Cookie:
    name: str
    value: str
    domain: str
    path: str = "/"
    expires_at: Optional[float] = None
    secure: bool = False
    http_only: bool = False
    same_site: str = "Lax"  # "Strict" | "Lax" | "None"

    def is_expired(self, now: Optional[float] = None) -> bool:
        if self.expires_at is None:
            return False
        now = now if now is not None else time.time()
        return now >= self.expires_at


class CookieManager:
    def __init__(self, block_third_party: bool = False) -> None:
        self.block_third_party = block_third_party
        self._cookies: dict[str, dict[str, Cookie]] = {}  # domain -> name -> Cookie

    def set(self, cookie: Cookie) -> None:
        bucket = self._cookies.setdefault(cookie.domain, {})
        bucket[cookie.name] = cookie

    def get_for_request(self, request_url: str, document_url: Optional[str] = None) -> list[Cookie]:
        """Return cookies to attach to a request to ``request_url``,
        respecting third-party blocking when ``document_url`` (the origin
        of the page making the request) differs from the request's host."""
        req_origin = parse_origin(request_url)
        if self.block_third_party and document_url:
            doc_origin = parse_origin(document_url)
            if doc_origin.host != req_origin.host:
                return []
        now = time.time()
        out = []
        for domain, bucket in self._cookies.items():
            if req_origin.host == domain or req_origin.host.endswith("." + domain):
                for cookie in bucket.values():
                    if not cookie.is_expired(now) and (not cookie.secure or req_origin.is_secure):
                        out.append(cookie)
        return out

    def clear_domain(self, domain: str) -> int:
        return len(self._cookies.pop(domain, {}))

    def clear_all(self) -> None:
        self._cookies.clear()

    def clear_expired(self) -> int:
        removed = 0
        now = time.time()
        for domain in list(self._cookies):
            for name in list(self._cookies[domain]):
                if self._cookies[domain][name].is_expired(now):
                    del self._cookies[domain][name]
                    removed += 1
            if not self._cookies[domain]:
                del self._cookies[domain]
        return removed

    def export(self) -> list[dict]:
        return [
            {"name": c.name, "domain": c.domain, "path": c.path, "secure": c.secure, "same_site": c.same_site}
            for bucket in self._cookies.values()
            for c in bucket.values()
        ]
