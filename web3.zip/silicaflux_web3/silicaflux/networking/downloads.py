"""The download manager: queueing, pause/resume/cancel, progress
tracking, destination selection, history and file verification.

Hard rule (spec section 23 / 17): a downloaded file is never, under any
circumstance, automatically executed or opened by SilicaFlux. This module
contains no code path that invokes a downloaded file — the closest it
comes is computing a SHA-256 so the user (or an SFX application, if
explicitly granted ``filesystem.read``) can verify integrity themselves.
"""

from __future__ import annotations

import asyncio
import hashlib
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from silicaflux.core.events import EventBus
from silicaflux.core.logging_setup import get_logger
from silicaflux.networking.client import HTTPClient, RequestCancelled
from silicaflux.storage.downloads_store import DownloadRecord, DownloadsStore

logger = get_logger("networking.downloads")

ProgressCallback = Callable[["DownloadRecord"], None]


class DownloadManager:
    def __init__(
        self,
        client: HTTPClient,
        default_directory: Path,
        store: Optional[DownloadsStore] = None,
        events: Optional[EventBus] = None,
    ) -> None:
        self.client = client
        self.default_directory = default_directory
        self.default_directory.mkdir(parents=True, exist_ok=True)
        self.store = store
        self.events = events or EventBus()
        self._active: dict[str, DownloadRecord] = {}
        self._pause_flags: dict[str, asyncio.Event] = {}
        self._tasks: dict[str, asyncio.Task] = {}

    def _destination_for(self, filename: str, directory: Optional[Path] = None) -> Path:
        directory = directory or self.default_directory
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / filename
        stem, suffix = path.stem, path.suffix
        n = 1
        while path.exists():
            path = directory / f"{stem} ({n}){suffix}"
            n += 1
        return path

    def start(self, url: str, filename: Optional[str] = None, directory: Optional[Path] = None) -> DownloadRecord:
        filename = filename or Path(url.split("?")[0]).name or "download.bin"
        destination = self._destination_for(filename, directory)
        record = DownloadRecord.new(url, filename, str(destination))
        self._active[record.id] = record
        self._pause_flags[record.id] = asyncio.Event()
        self._pause_flags[record.id].set()  # "not paused" == set
        self._tasks[record.id] = asyncio.ensure_future(self._run(record))
        self.events.emit("download.started", record.as_row(), source="downloads")
        return record

    async def _run(self, record: DownloadRecord) -> None:
        record.status = "downloading"
        hasher = hashlib.sha256()
        destination = Path(record.destination)
        try:
            async for received in self.client.stream_download(
                record.url, destination=destination, request_id=record.id, on_progress=None
            ):
                await self._pause_flags[record.id].wait()
                record.received_bytes = received
                self.events.emit("download.progress", record.as_row(), source="downloads")
            if destination.exists():
                hasher.update(destination.read_bytes())
                record.sha256 = hasher.hexdigest()
                record.total_bytes = record.total_bytes or record.received_bytes
            record.status = "completed"
            record.finished_at = time.time()
            logger.info(f"download completed: {record.filename} ({record.received_bytes} bytes)")
        except RequestCancelled:
            record.status = "cancelled"
            record.finished_at = time.time()
        except Exception as exc:
            record.status = "failed"
            record.finished_at = time.time()
            logger.error(f"download failed: {record.url}: {exc}")
        finally:
            if self.store is not None:
                await self.store.save(record)
            self.events.emit("download.finished", record.as_row(), source="downloads")

    def pause(self, download_id: str) -> bool:
        flag = self._pause_flags.get(download_id)
        if not flag:
            return False
        flag.clear()
        record = self._active.get(download_id)
        if record:
            record.status = "paused"
        return True

    def resume(self, download_id: str) -> bool:
        flag = self._pause_flags.get(download_id)
        if not flag:
            return False
        flag.set()
        record = self._active.get(download_id)
        if record:
            record.status = "downloading"
        return True

    def cancel(self, download_id: str) -> bool:
        if download_id not in self._active:
            return False
        self.resume(download_id)  # unblock if paused, so the loop can observe cancellation
        self.client.cancel(download_id)
        return True

    def progress(self, download_id: str) -> Optional[dict]:
        record = self._active.get(download_id)
        return record.as_row() if record else None

    def active_downloads(self) -> list[dict]:
        return [r.as_row() for r in self._active.values()]

    async def verify(self, download_id: str, expected_sha256: str) -> bool:
        record = self._active.get(download_id)
        if not record or not record.sha256:
            return False
        return record.sha256.lower() == expected_sha256.lower()
