"""NetworkScheduler — prioritises outgoing HTTP requests the way a real
browser's resource loader does (spec Phase 2): user interaction, page
importance, resource type, latency history and cache state all bias
ordering, independent of the packet-fabric :class:`silicaflux.core.scheduler.Scheduler`
(which prioritises SilicaFlux *compute* packets, not raw HTTP fetches).
"""

from __future__ import annotations

import heapq
import itertools
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from silicaflux.core.logging_setup import get_logger

logger = get_logger("networking.scheduler")


class ResourceType(str, Enum):
    DOCUMENT = "document"
    XHR = "xhr"
    SCRIPT = "script"
    STYLESHEET = "stylesheet"
    FONT = "font"
    IMAGE = "image"
    MEDIA = "media"
    WEBSOCKET = "websocket"
    OTHER = "other"


#: Lower is more important. Documents and XHR/fetch block rendering or
#: application logic; images/media are comparatively deferrable.
_RESOURCE_BASE_WEIGHT: dict[ResourceType, int] = {
    ResourceType.DOCUMENT: 0,
    ResourceType.XHR: 1,
    ResourceType.STYLESHEET: 1,
    ResourceType.SCRIPT: 2,
    ResourceType.FONT: 3,
    ResourceType.WEBSOCKET: 3,
    ResourceType.MEDIA: 4,
    ResourceType.IMAGE: 4,
    ResourceType.OTHER: 5,
}


@dataclass
class NetworkRequest:
    request_id: str
    url: str
    resource_type: ResourceType
    is_active_tab: bool = True
    user_initiated: bool = False
    cache_state: str = "unknown"  # "hit" | "miss" | "unknown"
    created_at: float = field(default_factory=time.time)


@dataclass(order=True)
class _Entry:
    sort_key: tuple
    seq: int
    request: NetworkRequest = field(compare=False)


class NetworkScheduler:
    def __init__(self, max_concurrent_per_host: int = 6) -> None:
        self._heap: list[_Entry] = []
        self._counter = itertools.count()
        self._host_inflight: dict[str, int] = {}
        self.max_concurrent_per_host = max_concurrent_per_host
        self._host_latency_ms: dict[str, float] = {}

    def _host(self, url: str) -> str:
        from silicaflux.security.origins import parse_origin

        return parse_origin(url).host

    def _score(self, req: NetworkRequest) -> tuple:
        weight = _RESOURCE_BASE_WEIGHT[req.resource_type]
        if req.user_initiated:
            weight -= 2
        if not req.is_active_tab:
            weight += 3
        if req.cache_state == "hit":
            weight -= 1  # serve cache hits first, they're nearly free
        host_latency = self._host_latency_ms.get(self._host(req.url), 0.0) / 1000.0
        return (weight, round(host_latency, 3), req.created_at)

    def submit(self, request: NetworkRequest) -> None:
        heapq.heappush(self._heap, _Entry(self._score(request), next(self._counter), request))

    def next_batch(self, max_items: int = 8) -> list[NetworkRequest]:
        """Pop up to ``max_items`` requests, respecting the per-host
        connection-pool limit (a low-priority request to an already-busy
        host waits; a request to an idle host jumps the local queue)."""
        batch: list[NetworkRequest] = []
        deferred: list[_Entry] = []
        while self._heap and len(batch) < max_items:
            entry = heapq.heappop(self._heap)
            host = self._host(entry.request.url)
            if self._host_inflight.get(host, 0) >= self.max_concurrent_per_host:
                deferred.append(entry)
                continue
            self._host_inflight[host] = self._host_inflight.get(host, 0) + 1
            batch.append(entry.request)
        for entry in deferred:
            heapq.heappush(self._heap, entry)
        return batch

    def complete(self, request: NetworkRequest, duration_ms: float) -> None:
        host = self._host(request.url)
        self._host_inflight[host] = max(0, self._host_inflight.get(host, 1) - 1)
        prev = self._host_latency_ms.get(host)
        self._host_latency_ms[host] = duration_ms if prev is None else (prev * 0.7 + duration_ms * 0.3)

    def __len__(self) -> int:
        return len(self._heap)

    def stats(self) -> dict:
        return {
            "queue_length": len(self._heap),
            "host_inflight": dict(self._host_inflight),
            "host_latency_ms": {h: round(v, 2) for h, v in self._host_latency_ms.items()},
        }
