"""High-performance HTTP(S) networking: pooled async client, DNS caching,
cookie management, request scheduling/prioritisation, streaming/resumable
downloads and per-request performance telemetry."""

from __future__ import annotations

from silicaflux.networking.client import FetchResult, HTTPClient, RequestCancelled, RetryPolicy
from silicaflux.networking.cookies import Cookie, CookieManager
from silicaflux.networking.dns_cache import DNSCache
from silicaflux.networking.downloads import DownloadManager
from silicaflux.networking.performance import PerformanceMonitor, RequestTiming
from silicaflux.networking.scheduler import NetworkRequest, NetworkScheduler, ResourceType

__all__ = [
    "HTTPClient",
    "FetchResult",
    "RequestCancelled",
    "RetryPolicy",
    "CookieManager",
    "Cookie",
    "DNSCache",
    "DownloadManager",
    "PerformanceMonitor",
    "RequestTiming",
    "NetworkScheduler",
    "NetworkRequest",
    "ResourceType",
]
