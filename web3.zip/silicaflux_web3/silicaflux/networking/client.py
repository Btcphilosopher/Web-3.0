"""The SilicaFlux HTTP(S) client: connection pooling, DNS caching,
cache-aware GET requests, streaming/resumable downloads, retries with
backoff, cancellation, and a full DNS/TLS/Connect/TTFB/Download/Total
timing breakdown per request.

Built on ``httpx.AsyncClient`` rather than a hand-rolled socket layer —
per spec section "Use httpx" and "do not attempt to write a complete
browser engine from scratch", the goal is a well-integrated networking
*policy* layer (pooling, retries, caching, telemetry, scheduling), not a
reimplementation of HTTP itself. Certificate verification is always on;
there is no API to disable it.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator, Optional

import httpx

from silicaflux.cache.resource_cache import ResourceCache
from silicaflux.core.logging_setup import get_logger
from silicaflux.networking.cookies import Cookie, CookieManager
from silicaflux.networking.dns_cache import DNSCache
from silicaflux.networking.performance import PerformanceMonitor, RequestTiming

logger = get_logger("networking.client")


class RequestCancelled(Exception):
    pass


@dataclass
class RetryPolicy:
    max_retries: int = 2
    backoff_base_s: float = 0.25
    backoff_max_s: float = 4.0
    retry_statuses: frozenset[int] = frozenset({429, 502, 503, 504})

    def backoff(self, attempt: int) -> float:
        return min(self.backoff_max_s, self.backoff_base_s * (2**attempt))


@dataclass
class FetchResult:
    url: str
    status_code: int
    headers: dict[str, str]
    body: bytes
    from_cache: bool
    timing: RequestTiming
    ok: bool = True
    error: Optional[str] = None

    def text(self, encoding: str = "utf-8") -> str:
        return self.body.decode(encoding, errors="replace")


class HTTPClient:
    def __init__(
        self,
        *,
        dns_cache: Optional[DNSCache] = None,
        resource_cache: Optional[ResourceCache] = None,
        cookies: Optional[CookieManager] = None,
        performance: Optional[PerformanceMonitor] = None,
        retry_policy: Optional[RetryPolicy] = None,
        max_connections: int = 40,
        max_keepalive_connections: int = 20,
        verify_certificates: bool = True,
        enable_http2: bool = False,
        default_timeout_s: float = 30.0,
        user_agent: str = "SilicaFlux/0.1 (Web3.0)",
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ) -> None:
        if not verify_certificates:
            # spec: "Do not implement insecure certificate bypasses." This
            # constructor simply does not expose a way to turn verification
            # off; the parameter exists only so callers can pass True
            # explicitly and self-document intent.
            raise ValueError("SilicaFlux never disables certificate verification")

        http2 = False
        if enable_http2:
            try:
                import h2  # noqa: F401

                http2 = True
            except ImportError:
                logger.warning("HTTP/2 requested but the 'h2' package is not installed; falling back to HTTP/1.1")

        limits = httpx.Limits(max_connections=max_connections, max_keepalive_connections=max_keepalive_connections)
        self._client = httpx.AsyncClient(
            limits=limits,
            verify=True,
            follow_redirects=True,
            http2=http2,
            timeout=default_timeout_s,
            headers={"User-Agent": user_agent},
            transport=transport,
        )
        self.dns_cache = dns_cache or DNSCache()
        self.resource_cache = resource_cache
        self.cookies = cookies
        self.performance = performance or PerformanceMonitor()
        self.retry_policy = retry_policy or RetryPolicy()
        self._cancelled: set[str] = set()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "HTTPClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    # -- request lifecycle -------------------------------------------
    def cancel(self, request_id: str) -> None:
        self._cancelled.add(request_id)

    async def fetch(
        self,
        url: str,
        *,
        method: str = "GET",
        headers: Optional[dict[str, str]] = None,
        content: Optional[bytes] = None,
        origin: Optional[str] = None,
        use_cache: bool = True,
        max_age_s: Optional[float] = 300.0,
        request_id: Optional[str] = None,
        timeout_s: Optional[float] = None,
    ) -> FetchResult:
        headers = dict(headers or {})
        cacheable = method.upper() == "GET" and use_cache and self.resource_cache is not None

        if cacheable:
            hit = self.resource_cache.lookup(url)
            if hit is not None:
                meta, data = hit
                timing = RequestTiming(url=url, from_cache=True, total_ms=0.05, bytes_downloaded=len(data), status_code=200)
                self.performance.record(timing)
                return FetchResult(url, 200, {"content-type": meta.content_type}, data, True, timing)
            revalidation = self.resource_cache.revalidation_headers(url)
            headers.update(revalidation)

        if self.cookies is not None:
            for cookie in self.cookies.get_for_request(url, document_url=origin):
                headers.setdefault("Cookie", "")
                headers["Cookie"] = (headers["Cookie"] + "; " if headers["Cookie"] else "") + f"{cookie.name}={cookie.value}"

        stopwatch = self.performance.new_stopwatch()
        host = httpx.URL(url).host
        try:
            dns_record = await self.dns_cache.resolve(host)
            stopwatch.mark("dns_done")
            if dns_record.error:
                raise httpx.ConnectError(f"DNS resolution failed for {host}: {dns_record.error}")
        except Exception:
            stopwatch.mark("dns_done")

        timing = RequestTiming(url=url)
        timing.dns_ms = stopwatch.get("dns_done")

        attempt = 0
        last_exc: Optional[Exception] = None
        while attempt <= self.retry_policy.max_retries:
            if request_id and request_id in self._cancelled:
                self._cancelled.discard(request_id)
                raise RequestCancelled(f"request {request_id} cancelled")
            try:
                response = await self._client.request(
                    method, url, headers=headers, content=content, timeout=timeout_s
                )
                stopwatch.mark("response_started")
                body = await response.aread()
                stopwatch.mark("download_done")

                timing.connect_ms = max(0.0, stopwatch.get("dns_done"))
                timing.ttfb_ms = max(0.0, stopwatch.get("response_started") - timing.dns_ms)
                timing.download_ms = max(0.0, stopwatch.get("download_done") - stopwatch.get("response_started"))
                timing.total_ms = stopwatch.get("download_done")
                timing.bytes_downloaded = len(body)
                timing.status_code = response.status_code

                if response.status_code in self.retry_policy.retry_statuses and attempt < self.retry_policy.max_retries:
                    await asyncio.sleep(self.retry_policy.backoff(attempt))
                    attempt += 1
                    continue

                self.performance.record(timing)

                if cacheable and response.status_code == 200:
                    self.resource_cache.store(
                        url,
                        body,
                        response.headers.get("content-type", "application/octet-stream"),
                        origin or host,
                        max_age_s=_parse_cache_control(response.headers.get("cache-control")) or max_age_s,
                        etag=response.headers.get("etag"),
                        last_modified=response.headers.get("last-modified"),
                    )
                elif cacheable and response.status_code == 304:
                    self.resource_cache.mark_revalidated(url, max_age_s)
                    cached = self.resource_cache.lookup(url)
                    if cached:
                        return FetchResult(url, 200, dict(response.headers), cached[1], True, timing)

                return FetchResult(url, response.status_code, dict(response.headers), body, False, timing)

            except (httpx.TransportError, httpx.TimeoutException) as exc:
                last_exc = exc
                if attempt >= self.retry_policy.max_retries:
                    break
                await asyncio.sleep(self.retry_policy.backoff(attempt))
                attempt += 1

        timing.error = str(last_exc)
        timing.total_ms = stopwatch.elapsed_ms()
        self.performance.record(timing)
        return FetchResult(url, 0, {}, b"", False, timing, ok=False, error=str(last_exc))

    async def stream_download(
        self,
        url: str,
        *,
        destination: Path,
        request_id: str,
        resume: bool = True,
        chunk_size: int = 64 * 1024,
        on_progress: Optional[Any] = None,
    ) -> AsyncIterator[int]:
        """Stream a download to ``destination``, yielding the cumulative
        byte count after each chunk so a caller (the download manager) can
        drive a progress bar. Supports resuming via ``Range`` when
        ``destination`` already has partial bytes on disk."""
        headers: dict[str, str] = {}
        mode = "wb"
        received = 0
        if resume and destination.exists():
            received = destination.stat().st_size
            if received > 0:
                headers["Range"] = f"bytes={received}-"
                mode = "ab"

        async with self._client.stream("GET", url, headers=headers) as response:
            if response.status_code == 416:  # already fully downloaded
                yield received
                return
            response.raise_for_status()
            destination.parent.mkdir(parents=True, exist_ok=True)
            with open(destination, mode) as f:
                async for chunk in response.aiter_bytes(chunk_size):
                    if request_id in self._cancelled:
                        self._cancelled.discard(request_id)
                        raise RequestCancelled(f"download {request_id} cancelled")
                    f.write(chunk)
                    received += len(chunk)
                    if on_progress:
                        on_progress(received)
                    yield received


def _parse_cache_control(value: Optional[str]) -> Optional[float]:
    if not value:
        return None
    for directive in value.split(","):
        directive = directive.strip()
        if directive.startswith("max-age="):
            try:
                return float(directive.split("=", 1)[1])
            except ValueError:
                return None
        if directive in ("no-store", "no-cache"):
            return 0.0
    return None
