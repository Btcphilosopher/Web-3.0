"""Tensor handling for the local AI engine, built on NumPy when available
(a declared dependency, see ``requirements.txt``) with a pure-Python
fallback so the rest of :mod:`silicaflux.ai` stays importable even in a
minimal install. Tensors cross runtime/process boundaries as
:class:`silicaflux.runtimes.data_model.SFXValue` of type ``TENSOR`` —
this module is only responsible for the local, in-process representation
and NumPy <-> wire conversion.
"""

from __future__ import annotations

from typing import Any, Sequence

from silicaflux.runtimes.data_model import SFXValue, TensorShape, ValueType

try:
    import numpy as np

    _NUMPY_AVAILABLE = True
except ImportError:  # pragma: no cover
    np = None  # type: ignore[assignment]
    _NUMPY_AVAILABLE = False


class TensorManager:
    """Thin, honest wrapper: if NumPy isn't installed, tensor *creation*
    still works (backed by nested Python lists) but reshape/dtype-cast
    operations that need real array semantics raise
    :class:`NumPyUnavailable` rather than silently doing something
    approximate."""

    def numpy_available(self) -> bool:
        return _NUMPY_AVAILABLE

    def from_values(self, values: Sequence[float], shape: Sequence[int], dtype: str = "float32") -> SFXValue:
        expected = 1
        for d in shape:
            expected *= d
        if len(values) != expected:
            raise ValueError(f"value count {len(values)} does not match shape {tuple(shape)} ({expected} elements)")
        return SFXValue(ValueType.TENSOR, list(values), TensorShape(dtype, tuple(shape)))

    def to_ndarray(self, tensor: SFXValue) -> Any:
        if not _NUMPY_AVAILABLE:
            raise NumPyUnavailable("NumPy is not installed; install it to convert tensors to ndarrays")
        if tensor.type != ValueType.TENSOR or tensor.tensor_shape is None:
            raise ValueError("value is not a tensor")
        arr = np.array(tensor.data, dtype=tensor.tensor_shape.dtype)
        return arr.reshape(tensor.tensor_shape.shape)

    def from_ndarray(self, array: Any) -> SFXValue:
        if not _NUMPY_AVAILABLE:
            raise NumPyUnavailable("NumPy is not installed; install it to convert ndarrays to tensors")
        flat = array.astype(str(array.dtype)).flatten().tolist()
        return SFXValue(ValueType.TENSOR, flat, TensorShape(str(array.dtype), tuple(array.shape)))

    def describe(self, tensor: SFXValue) -> dict:
        if tensor.tensor_shape is None:
            return {"type": tensor.type.value}
        return {
            "type": tensor.type.value,
            "dtype": tensor.tensor_shape.dtype,
            "shape": list(tensor.tensor_shape.shape),
            "elements": len(tensor.data) if isinstance(tensor.data, list) else None,
        }


class NumPyUnavailable(RuntimeError):
    pass
