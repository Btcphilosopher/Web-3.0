"""A tiny, dependency-free demo "model" used by the CLI, tests and the
example dashboard app to exercise :class:`silicaflux.ai.manager.AIManager`
end-to-end without bundling (or pretending to download) a real neural
network. It is registered as an ``sfx-native`` model — see
:meth:`silicaflux.ai.registry.ModelRegistry.register_native`.

This is a linear model in the literal sense (a weighted sum through a
sigmoid), trained offline once and its weights frozen here — a completely
honest, small, real piece of inference, versus faking a framework that
isn't actually loaded.
"""

from __future__ import annotations

import math

#: Weights for a tiny sentiment-leaning classifier over a fixed bag of
#: features (frozen/offline-"trained" — this is a demo, not a claim of
#: state-of-the-art accuracy).
_WEIGHTS = {
    "good": 1.8,
    "great": 2.2,
    "excellent": 2.6,
    "love": 2.0,
    "bad": -1.9,
    "terrible": -2.5,
    "hate": -2.1,
    "poor": -1.6,
    "slow": -0.8,
    "fast": 0.9,
}
_BIAS = -0.1


def sentiment_predict(payload: dict) -> dict:
    """input_schema: {"text": str} -> output_schema: {"score": float (-1..1), "label": str}"""
    text = str(payload.get("text", "")).lower()
    score = _BIAS
    matched = []
    for word, weight in _WEIGHTS.items():
        if word in text:
            score += weight
            matched.append(word)
    probability = 1 / (1 + math.exp(-score))
    normalized = (probability - 0.5) * 2  # map to -1..1
    label = "positive" if normalized > 0.15 else "negative" if normalized < -0.15 else "neutral"
    return {"score": round(normalized, 4), "label": label, "matched_terms": matched}
