"""Isolated inference execution.

Reuses :class:`silicaflux.runtimes.python_runtime.PythonWorkerPool` rather
than inventing a second process-isolation mechanism: a model's
``predict_target`` is an importable ``module:function`` exactly like a
Python runtime operation, so the same sandboxing, timeout and crash
recovery guarantees apply to model inference as to any other
process-isolated Python call (spec: "Keep model execution isolated").
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Optional

from silicaflux.ai.registry import ModelMetadata, ModelRegistry
from silicaflux.core.logging_setup import get_logger
from silicaflux.runtimes.python_runtime import PythonWorkerPool
from silicaflux.security.sandbox import ResourceLimits

logger = get_logger("ai.inference")


@dataclass
class InferenceResult:
    model_id: str
    output: Any
    latency_ms: float
    hardware_target: str

    def to_dict(self) -> dict:
        return {
            "model_id": self.model_id,
            "output": self.output,
            "latency_ms": round(self.latency_ms, 3),
            "hardware_target": self.hardware_target,
        }


class InferenceWorker:
    def __init__(self, pool: Optional[PythonWorkerPool] = None, default_timeout_s: float = 15.0) -> None:
        self.pool = pool or PythonWorkerPool(size=1, limits=ResourceLimits(memory_mb=512, wall_timeout_s=default_timeout_s))
        self.default_timeout_s = default_timeout_s

    async def predict(self, metadata: ModelMetadata, input_payload: dict, hardware_target: str) -> InferenceResult:
        module, _, function = metadata.predict_target.partition(":")
        if not function:
            raise ValueError(f"model '{metadata.model_id}' has no valid predict_target")
        start = time.perf_counter()
        output = await self.pool.submit(module, function, input_payload, self.default_timeout_s)
        latency_ms = (time.perf_counter() - start) * 1000
        logger.info(
            f"inference on '{metadata.model_id}' took {latency_ms:.2f}ms",
            extra={"runtime": "ai", "operation": metadata.model_id, "duration_ms": round(latency_ms, 2)},
        )
        return InferenceResult(metadata.model_id, output, latency_ms, hardware_target)

    def shutdown(self) -> None:
        self.pool.shutdown()
