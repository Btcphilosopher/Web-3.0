"""AIManager: the entry point SilicaFlux applications call for local
inference (spec Phase 8).

    HTML -> JavaScript -> SilicaFlux -> Python AI Worker -> Local Model
        -> Result -> HTML

Hardware-aware scheduling here means exactly what can be honestly
implemented without pretending to control a GPU/NPU driver: a model
declares the hardware it needs, and :meth:`AIManager.predict` refuses to
run it if that hardware isn't actually available (spec: "Do not fake
hardware acceleration") — CPU is always available; GPU/NPU report
unavailable unless a real accelerator adapter is plugged in via
:meth:`AIManager.register_hardware`.
"""

from __future__ import annotations

from typing import Callable, Optional

from silicaflux.ai.inference import InferenceResult, InferenceWorker
from silicaflux.ai.registry import ModelMetadata, ModelRegistry
from silicaflux.core.logging_setup import get_logger
from silicaflux.security.policy import SecurityPolicy
from silicaflux.telemetry.manager import TelemetryManager

logger = get_logger("ai.manager")


class HardwareUnavailable(RuntimeError):
    pass


class CapabilityDenied(RuntimeError):
    pass


class AIManager:
    def __init__(
        self,
        registry: Optional[ModelRegistry] = None,
        worker: Optional[InferenceWorker] = None,
        security_policy: Optional[SecurityPolicy] = None,
        telemetry: Optional[TelemetryManager] = None,
    ) -> None:
        self.registry = registry or ModelRegistry()
        self.worker = worker or InferenceWorker()
        self.security_policy = security_policy
        self.telemetry = telemetry
        #: hardware target -> probe callable returning availability. CPU
        #: is always true; register a real probe for "gpu"/"npu" only when
        #: a genuine accelerator backend exists.
        self._hardware_probes: dict[str, Callable[[], bool]] = {"cpu": lambda: True}

    def register_hardware(self, target: str, probe: Callable[[], bool]) -> None:
        self._hardware_probes[target] = probe

    def hardware_available(self, target: str) -> bool:
        probe = self._hardware_probes.get(target)
        return bool(probe and probe())

    def hardware_report(self) -> dict[str, bool]:
        return {target: self.hardware_available(target) for target in ("cpu", "gpu", "npu")}

    async def predict(self, origin: str, model_id: str, input_payload: dict) -> InferenceResult:
        metadata = self.registry.get(model_id)

        if self.security_policy is not None:
            for capability in metadata.permissions:
                token = self.security_policy.authorize(origin, capability)
                if token is None:
                    raise CapabilityDenied(f"origin '{origin}' lacks capability '{capability}' required by model '{model_id}'")

        if not self.hardware_available(metadata.hardware_requirement):
            raise HardwareUnavailable(
                f"model '{model_id}' requires '{metadata.hardware_requirement}', which is not available on this host"
            )

        result = await self.worker.predict(metadata, input_payload, metadata.hardware_requirement)
        if self.telemetry is not None:
            self.telemetry.metrics.histogram("ai_inference_ms", result.latency_ms, tags={"model": model_id})
        return result

    async def benchmark(self, origin: str, model_id: str, input_payload: dict, iterations: int = 20) -> dict:
        if self.telemetry is None:
            raise ValueError("benchmark() requires a TelemetryManager")
        bench = self.telemetry.start_benchmark(f"ai:{model_id}")
        for _ in range(iterations):
            result = await self.predict(origin, model_id, input_payload)
            bench.record(result.latency_ms)
        return bench.finish().summary()

    def shutdown(self) -> None:
        self.worker.shutdown()
