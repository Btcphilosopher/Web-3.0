"""Model registry: metadata plus mandatory hash verification before a
model can be used for inference (spec: "Do not download or execute
arbitrary models without verification").

A model is never registered from raw bytes alone — the caller must state
the hash they expect (typically pinned in an SFX application's manifest,
signed the same way as any other resource, see
:mod:`silicaflux.web3.identity`), and registration fails loudly if the
actual file's hash doesn't match. This is the same content-addressing
discipline as :mod:`silicaflux.cache.content_cache`, applied to models
specifically because a model silently swapped out from under an
application is a much bigger blast radius than a swapped image.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from silicaflux.cache.content_cache import content_hash
from silicaflux.core.logging_setup import get_logger

logger = get_logger("ai.registry")


class ModelIntegrityError(RuntimeError):
    pass


class ModelNotFound(KeyError):
    pass


@dataclass
class ModelMetadata:
    model_id: str
    version: str
    framework: str  # "sfx-native" | "onnx" | "sklearn-pickle-free" | ... (adapter-defined)
    size_bytes: int
    hardware_requirement: str  # "cpu" | "gpu" | "npu"
    input_schema: dict
    output_schema: dict
    content_hash: str
    permissions: list[str] = field(default_factory=list)  # capabilities a caller needs, e.g. "local_compute"
    predict_target: str = ""  # "module:function" — see silicaflux.ai.inference

    def to_dict(self) -> dict:
        return {
            "model_id": self.model_id,
            "version": self.version,
            "framework": self.framework,
            "size_bytes": self.size_bytes,
            "hardware_requirement": self.hardware_requirement,
            "input_schema": self.input_schema,
            "output_schema": self.output_schema,
            "content_hash": self.content_hash,
            "permissions": self.permissions,
        }


class ModelRegistry:
    def __init__(self) -> None:
        self._models: dict[str, ModelMetadata] = {}

    def register_from_file(
        self,
        model_id: str,
        version: str,
        framework: str,
        model_path: Path,
        expected_hash: str,
        hardware_requirement: str,
        input_schema: dict,
        output_schema: dict,
        predict_target: str,
        permissions: Optional[list[str]] = None,
    ) -> ModelMetadata:
        data = model_path.read_bytes()
        actual_hash = content_hash(data)
        if actual_hash != expected_hash:
            raise ModelIntegrityError(
                f"model '{model_id}' hash mismatch: expected {expected_hash}, got {actual_hash}. Refusing to register."
            )
        metadata = ModelMetadata(
            model_id=model_id,
            version=version,
            framework=framework,
            size_bytes=len(data),
            hardware_requirement=hardware_requirement,
            input_schema=input_schema,
            output_schema=output_schema,
            content_hash=actual_hash,
            permissions=permissions or ["local_compute"],
            predict_target=predict_target,
        )
        self._models[model_id] = metadata
        logger.info(f"registered model '{model_id}' v{version} ({framework}, hash={actual_hash[:12]}...)")
        return metadata

    def register_native(
        self,
        model_id: str,
        version: str,
        predict_target: str,
        input_schema: dict,
        output_schema: dict,
        hardware_requirement: str = "cpu",
        permissions: Optional[list[str]] = None,
    ) -> ModelMetadata:
        """Register a "model" that is really a pure-Python predict
        function (see :mod:`silicaflux.ai.inference`) — no weights file to
        hash, so the content hash is derived from the predict target
        string itself, which is sufficient for the same "detect
        unexpected substitution" purpose."""
        metadata = ModelMetadata(
            model_id=model_id,
            version=version,
            framework="sfx-native",
            size_bytes=0,
            hardware_requirement=hardware_requirement,
            input_schema=input_schema,
            output_schema=output_schema,
            content_hash=content_hash(predict_target.encode()),
            permissions=permissions or ["local_compute"],
            predict_target=predict_target,
        )
        self._models[model_id] = metadata
        logger.info(f"registered native model '{model_id}' v{version} -> {predict_target}")
        return metadata

    def get(self, model_id: str) -> ModelMetadata:
        if model_id not in self._models:
            raise ModelNotFound(model_id)
        return self._models[model_id]

    def list_models(self) -> list[dict]:
        return [m.to_dict() for m in self._models.values()]
