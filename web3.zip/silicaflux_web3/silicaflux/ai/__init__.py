"""Local AI computation engine: verified model registry, process-isolated
inference, hardware-aware (honest, non-fabricated) scheduling and tensor
helpers."""

from __future__ import annotations

from silicaflux.ai.inference import InferenceResult, InferenceWorker
from silicaflux.ai.manager import AIManager, CapabilityDenied, HardwareUnavailable
from silicaflux.ai.registry import ModelIntegrityError, ModelMetadata, ModelNotFound, ModelRegistry
from silicaflux.ai.tensor import NumPyUnavailable, TensorManager

__all__ = [
    "InferenceResult",
    "InferenceWorker",
    "AIManager",
    "CapabilityDenied",
    "HardwareUnavailable",
    "ModelIntegrityError",
    "ModelMetadata",
    "ModelNotFound",
    "ModelRegistry",
    "NumPyUnavailable",
    "TensorManager",
]
