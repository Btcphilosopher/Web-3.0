"""Built-in default settings, merged under any on-disk settings.json and
any explicit overrides by :class:`silicaflux.core.config.ConfigurationSystem`."""

from __future__ import annotations

from pathlib import Path

DEFAULT_SETTINGS: dict = {
    "homepage": "sfx://home",
    "search_engine": "https://duckduckgo.com/?q={query}",
    "appearance": {
        "theme": "system",
        "compact_toolbar": True,
        "animations": True,
    },
    "privacy": {
        "block_third_party_cookies": False,
        "do_not_track": True,
        "clear_on_exit": False,
    },
    "security": {
        "require_https_upgrade": True,
        "block_popups": True,
        "verify_certificates": True,
        "default_capability_policy": "prompt",
    },
    "runtimes": {
        "python_enabled": True,
        "r_enabled": True,
        "rust_enabled": True,
        "wasm_enabled": True,
        "javascript_bridge_enabled": True,
        "python_worker_timeout_s": 10.0,
        "python_worker_memory_mb": 256,
    },
    "downloads": {
        "directory": str(Path.home() / "Downloads" / "SilicaFlux"),
        "ask_where_to_save": False,
        "auto_execute": False,
    },
    "extra": {},
}

#: Default profile directory, overridable via the ``SILICAFLUX_HOME`` env var
#: or the CLI ``--profile-dir`` flag.
DEFAULT_PROFILE_DIR = Path.home() / ".silicaflux" / "default"

#: Well-known internal sfx:// pages, see silicaflux.core.navigation.
SFX_INTERNAL_PAGES = (
    "home",
    "apps",
    "runtime",
    "wallet",
    "settings",
    "developer",
    "history",
    "bookmarks",
    "downloads",
)
