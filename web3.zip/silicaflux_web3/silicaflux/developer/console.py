"""The developer tools console: a structured, filterable log viewer.

Rather than exposing a Python ``eval``/REPL to the browser UI (a
capability-escalation risk with no offsetting benefit for a *developer
tools* feature), :class:`DevConsole` taps the same structured logging tree
every subsystem already writes to (:mod:`silicaflux.core.logging_setup`)
via a small in-memory ``logging.Handler`` and exposes filtering/search
over the captured records. This mirrors what a browser's DevTools console
actually is for developers: a readable, filterable log stream.
"""

from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass
from typing import Optional


@dataclass
class ConsoleRecord:
    timestamp: float
    level: str
    logger: str
    message: str
    packet_id: Optional[str] = None
    runtime: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "level": self.level,
            "logger": self.logger,
            "message": self.message,
            "packet_id": self.packet_id,
            "runtime": self.runtime,
        }


class _CaptureHandler(logging.Handler):
    def __init__(self, sink: "DevConsole") -> None:
        super().__init__()
        self.sink = sink

    def emit(self, record: logging.LogRecord) -> None:
        self.sink._append(
            ConsoleRecord(
                timestamp=record.created,
                level=record.levelname,
                logger=record.name,
                message=record.getMessage(),
                packet_id=getattr(record, "packet_id", None),
                runtime=getattr(record, "runtime", None),
            )
        )


class DevConsole:
    def __init__(self, capacity: int = 2000, root_logger: str = "silicaflux") -> None:
        self._records: deque[ConsoleRecord] = deque(maxlen=capacity)
        self._handler = _CaptureHandler(self)
        logging.getLogger(root_logger).addHandler(self._handler)

    def _append(self, record: ConsoleRecord) -> None:
        self._records.append(record)

    def query(self, level: Optional[str] = None, contains: str = "", limit: int = 200) -> list[dict]:
        rows = list(self._records)
        if level:
            order = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
            min_idx = order.index(level.upper()) if level.upper() in order else 0
            rows = [r for r in rows if r.level in order and order.index(r.level) >= min_idx]
        if contains:
            rows = [r for r in rows if contains.lower() in r.message.lower()]
        return [r.to_dict() for r in rows[-limit:]]

    def clear(self) -> None:
        self._records.clear()

    def detach(self) -> None:
        logging.getLogger("silicaflux").removeHandler(self._handler)
