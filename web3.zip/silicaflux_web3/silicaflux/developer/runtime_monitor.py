"""The developer tools "SilicaFlux" panel (spec section 26): a live table
of packets with exactly the columns the spec calls out — Packet ID,
Runtime, Source, Destination, Operation, Priority, State, Queue time,
Execution time, Total latency — plus worker and CPU/memory/permission
context alongside it.
"""

from __future__ import annotations

from typing import Any


class RuntimeMonitor:
    def __init__(self, engine: Any, security_policy: Any = None) -> None:
        self.engine = engine
        self.security_policy = security_policy

    def packet_table(self, limit: int = 100) -> list[dict]:
        """Rows shaped exactly for the spec's packet table: each already
        carries packet_id/runtime/source/destination/operation/priority/
        state/queue_time/execution_time/total_latency via
        :meth:`SFXPacket.to_dict`."""
        return self.engine.recent_packets(limit)

    def worker_table(self) -> list[dict]:
        return [w.to_dict() for w in self.engine.worker_registry.all()]

    def permissions_table(self, origin: str) -> list[dict]:
        if self.security_policy is None:
            return []
        return [t.to_dict() for t in self.security_policy.grants_for(origin)]

    def snapshot(self, origin: str = "", limit: int = 100) -> dict:
        return {
            "packets": self.packet_table(limit),
            "workers": self.worker_table(),
            "engine_status": self.engine.status(),
            "permissions": self.permissions_table(origin) if origin else [],
        }
