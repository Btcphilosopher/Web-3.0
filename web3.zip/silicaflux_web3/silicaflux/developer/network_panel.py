"""The developer tools "Network" tab: recent requests with their
DNS/TLS/Connect/TTFB/Download/Total breakdown, plus live
:class:`~silicaflux.networking.scheduler.NetworkScheduler` queue state."""

from __future__ import annotations

from typing import Optional

from silicaflux.networking.performance import PerformanceMonitor
from silicaflux.networking.scheduler import NetworkScheduler


class NetworkPanel:
    def __init__(self, performance: PerformanceMonitor, scheduler: Optional[NetworkScheduler] = None) -> None:
        self.performance = performance
        self.scheduler = scheduler

    def requests(self, limit: int = 100) -> list[dict]:
        return self.performance.recent(limit)

    def summary(self) -> dict:
        data = {"summary": self.performance.summary()}
        if self.scheduler is not None:
            data["scheduler"] = self.scheduler.stats()
        return data
