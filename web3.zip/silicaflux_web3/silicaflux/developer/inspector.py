"""The developer tools "Page Information" / "Storage" panel: a snapshot
of one tab's URL, title, load state, cookies, cached resources and
persisted browsing data — the DOM-inspection-adjacent information that's
actually available without a live Chromium DOM tree wired through
(:mod:`silicaflux.browser.page` owns that; when running under the real
GUI it additionally calls ``page.runJavaScript("document.documentElement.outerHTML")``
for live DOM/HTML inspection — this module stays useful headless too).
"""

from __future__ import annotations

from typing import Any, Optional

from silicaflux.cache.resource_cache import ResourceCache
from silicaflux.networking.cookies import CookieManager
from silicaflux.security.origins import parse_origin


class PageInspector:
    def __init__(
        self,
        resource_cache: Optional[ResourceCache] = None,
        cookies: Optional[CookieManager] = None,
        history: Optional[Any] = None,
    ) -> None:
        self.resource_cache = resource_cache
        self.cookies = cookies
        self.history = history

    def inspect_tab(self, tab: Any) -> dict:
        origin = str(parse_origin(tab.url))
        data: dict = {
            "tab": tab.to_dict(),
            "origin": origin,
            "navigation_entries": [
                {"url": e.url, "title": e.title, "timestamp": e.timestamp} for e in tab.navigation.entries()
            ],
        }
        if self.cookies is not None:
            data["cookies"] = [
                {"name": c.name, "domain": c.domain, "secure": c.secure} for c in self.cookies.get_for_request(tab.url)
            ]
        if self.resource_cache is not None:
            meta = self.resource_cache.metadata(tab.url)
            data["resource_metadata"] = meta.to_dict() if meta else None
        return data

    async def visit_count(self, url: str) -> Optional[int]:
        if self.history is None:
            return None
        entries = await self.history.search(url, limit=1)
        return entries[0].visit_count if entries else 0
