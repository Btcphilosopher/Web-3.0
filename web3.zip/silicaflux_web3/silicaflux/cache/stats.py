"""Shared hit/miss/storage accounting used by every cache tier so the
developer tools panel and ``sfx-runtime cache`` can report one consistent
picture: hit rate, miss rate, storage usage, bandwidth saved, computation
avoided (spec section 3)."""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class CacheStats:
    name: str
    hits: int = 0
    misses: int = 0
    stores: int = 0
    evictions: int = 0
    bytes_stored: int = 0
    bytes_saved: int = 0  # bytes not re-downloaded/re-computed thanks to a hit
    compute_seconds_saved: float = 0.0
    created_at: float = field(default_factory=time.time)

    @property
    def total_lookups(self) -> int:
        return self.hits + self.misses

    @property
    def hit_rate(self) -> float:
        return self.hits / self.total_lookups if self.total_lookups else 0.0

    @property
    def miss_rate(self) -> float:
        return self.misses / self.total_lookups if self.total_lookups else 0.0

    def record_hit(self, bytes_saved: int = 0, compute_seconds_saved: float = 0.0) -> None:
        self.hits += 1
        self.bytes_saved += bytes_saved
        self.compute_seconds_saved += compute_seconds_saved

    def record_miss(self) -> None:
        self.misses += 1

    def record_store(self, size_bytes: int = 0) -> None:
        self.stores += 1
        self.bytes_stored += size_bytes

    def record_eviction(self, size_bytes: int = 0) -> None:
        self.evictions += 1
        self.bytes_stored = max(0, self.bytes_stored - size_bytes)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "hits": self.hits,
            "misses": self.misses,
            "stores": self.stores,
            "evictions": self.evictions,
            "hit_rate": round(self.hit_rate, 4),
            "miss_rate": round(self.miss_rate, 4),
            "bytes_stored": self.bytes_stored,
            "bytes_saved": self.bytes_saved,
            "compute_seconds_saved": round(self.compute_seconds_saved, 4),
        }


class StatsRegistry:
    """Aggregates :class:`CacheStats` from every cache tier for a single
    ``sfx://runtime`` dashboard view."""

    def __init__(self) -> None:
        self._tiers: dict[str, CacheStats] = {}

    def register(self, stats: CacheStats) -> None:
        self._tiers[stats.name] = stats

    def snapshot(self) -> dict[str, dict]:
        return {name: s.to_dict() for name, s in self._tiers.items()}

    def totals(self) -> dict:
        hits = sum(s.hits for s in self._tiers.values())
        misses = sum(s.misses for s in self._tiers.values())
        total = hits + misses
        return {
            "hits": hits,
            "misses": misses,
            "hit_rate": round(hits / total, 4) if total else 0.0,
            "bytes_stored": sum(s.bytes_stored for s in self._tiers.values()),
            "bytes_saved": sum(s.bytes_saved for s in self._tiers.values()),
            "compute_seconds_saved": round(sum(s.compute_seconds_saved for s in self._tiers.values()), 4),
        }
