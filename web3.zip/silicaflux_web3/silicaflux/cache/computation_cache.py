"""Deterministic computation memoization (spec section 3):

    Input -> Hash -> Cache lookup -> existing result? -> return / execute+store

Used by :meth:`silicaflux.core.graph.ExecutionGraph.run` to skip
recomputing a node whose ``(function, resolved_inputs)`` pair has already
been evaluated, and directly by runtime adapters for expensive pure
functions (e.g. an R statistical computation on unchanged input data).

Only JSON-serialisable inputs are supported — this is a feature, not a
limitation: it's what makes the cache key reproducible across processes
and honest about what "the same input" means.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from typing import Any, Optional

from silicaflux.cache.stats import CacheStats
from silicaflux.core.logging_setup import get_logger

logger = get_logger("cache.computation")


class UnhashableInput(TypeError):
    pass


@dataclass
class ComputationResult:
    key: str
    value: Any
    computed_at: float
    compute_seconds: float
    hits: int = 0


class ComputationCache:
    def __init__(self, max_entries: int = 10_000, name: str = "computation_cache") -> None:
        self.max_entries = max_entries
        self._entries: dict[str, ComputationResult] = {}
        self._order: list[str] = []  # simple LRU tracking
        self.stats = CacheStats(name=name)

    def make_key(self, function: str, inputs: Any) -> str:
        try:
            canonical = json.dumps(inputs, sort_keys=True, default=_json_fallback)
        except TypeError as exc:
            raise UnhashableInput(f"computation cache inputs must be JSON-serialisable: {exc}") from exc
        digest = hashlib.sha256(f"{function}|{canonical}".encode()).hexdigest()
        return digest

    def get(self, key: str) -> Optional[Any]:
        entry = self._entries.get(key)
        if entry is None:
            self.stats.record_miss()
            return None
        entry.hits += 1
        self._touch(key)
        self.stats.record_hit(compute_seconds_saved=entry.compute_seconds)
        return entry.value

    def set(self, key: str, value: Any, compute_seconds: float = 0.0) -> None:
        if key not in self._entries and len(self._entries) >= self.max_entries:
            self._evict_lru()
        self._entries[key] = ComputationResult(key, value, time.time(), compute_seconds)
        self._touch(key)
        self.stats.record_store()

    def _touch(self, key: str) -> None:
        if key in self._order:
            self._order.remove(key)
        self._order.append(key)

    def _evict_lru(self) -> None:
        if not self._order:
            return
        oldest = self._order.pop(0)
        self._entries.pop(oldest, None)
        self.stats.record_eviction()

    def invalidate(self, key: str) -> bool:
        if key in self._entries:
            del self._entries[key]
            if key in self._order:
                self._order.remove(key)
            return True
        return False

    def clear(self) -> None:
        self._entries.clear()
        self._order.clear()

    async def memoize(self, function: str, inputs: Any, compute: Any) -> Any:
        """``compute`` is an async zero-arg callable producing the result
        on a miss. Convenience wrapper for the common
        "hash -> lookup -> compute-if-missing -> store" pattern."""
        key = self.make_key(function, inputs)
        cached = self.get(key)
        if cached is not None:
            return cached
        start = time.perf_counter()
        result = await compute()
        self.set(key, result, compute_seconds=time.perf_counter() - start)
        return result


def _json_fallback(obj: Any) -> Any:
    if isinstance(obj, (set, frozenset)):
        return sorted(obj)
    raise TypeError(f"object of type {type(obj)} is not JSON serialisable")
