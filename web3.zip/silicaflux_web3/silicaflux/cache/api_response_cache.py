"""Cache-aware API response cache used by
:mod:`silicaflux.networking.client` for GET-like, cacheable API calls
(SilicaFlux applications calling out to a JSON API, not full page
resources — see :mod:`silicaflux.cache.resource_cache` for those).

Keys on ``(method, url, canonical-body-hash)`` so a POST with a different
body never collides with a cached GET, and respects a simple TTL rather
than full HTTP cache-control parsing (that lives in
:class:`~silicaflux.cache.resource_cache.ResourceCache`).
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import Any, Optional

from silicaflux.cache.stats import CacheStats


@dataclass
class APIResponseEntry:
    key: str
    status_code: int
    body: Any
    headers: dict
    cached_at: float
    ttl_s: float

    def is_fresh(self, now: Optional[float] = None) -> bool:
        now = now if now is not None else time.time()
        return (now - self.cached_at) < self.ttl_s


class APIResponseCache:
    def __init__(self, default_ttl_s: float = 30.0, max_entries: int = 2000) -> None:
        self.default_ttl_s = default_ttl_s
        self.max_entries = max_entries
        self._entries: dict[str, APIResponseEntry] = {}
        self._order: list[str] = []
        self.stats = CacheStats(name="api_response_cache")

    def make_key(self, method: str, url: str, body: bytes = b"") -> str:
        body_hash = hashlib.sha256(body).hexdigest() if body else ""
        return hashlib.sha256(f"{method.upper()}|{url}|{body_hash}".encode()).hexdigest()

    def get(self, key: str) -> Optional[APIResponseEntry]:
        entry = self._entries.get(key)
        if entry is None or not entry.is_fresh():
            self.stats.record_miss()
            if entry is not None:
                self._evict(key)
            return None
        self.stats.record_hit()
        return entry

    def set(self, key: str, status_code: int, body: Any, headers: dict, ttl_s: Optional[float] = None) -> None:
        if key not in self._entries and len(self._entries) >= self.max_entries:
            self._evict(self._order[0])
        entry = APIResponseEntry(key, status_code, body, headers, time.time(), ttl_s or self.default_ttl_s)
        self._entries[key] = entry
        if key not in self._order:
            self._order.append(key)
        self.stats.record_store()

    def _evict(self, key: str) -> None:
        self._entries.pop(key, None)
        if key in self._order:
            self._order.remove(key)
        self.stats.record_eviction()

    def clear(self) -> None:
        self._entries.clear()
        self._order.clear()
