"""Content-addressable storage — the foundation every other cache tier
(resource, module, WASM) is built on.

A blob is identified by ``sha256(content)``; storing the same bytes twice
is a no-op, and callers can verify integrity on read by comparing the
returned hash against one they trust (e.g. a Subresource-Integrity value
from a page, or a signed resource hash from :mod:`silicaflux.web3.identity`).
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from silicaflux.cache.stats import CacheStats
from silicaflux.core.logging_setup import get_logger

logger = get_logger("cache.content")


def content_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass
class ContentEntry:
    content_hash: str
    size: int
    created_at: float = field(default_factory=time.time)
    ref_count: int = 1


class ContentCache:
    """Two-tier (memory + optional on-disk) content-addressable blob
    store. In-memory only when ``directory`` is omitted (useful for tests
    and short-lived computation caches); persists to disk otherwise so
    cached resources survive a restart.
    """

    def __init__(self, directory: Optional[Path] = None, max_memory_bytes: int = 64 * 1024 * 1024, name: str = "content_cache") -> None:
        self.directory = directory
        if self.directory is not None:
            self.directory.mkdir(parents=True, exist_ok=True)
        self.max_memory_bytes = max_memory_bytes
        self._memory: dict[str, bytes] = {}
        self._entries: dict[str, ContentEntry] = {}
        self._memory_bytes = 0
        self.stats = CacheStats(name=name)

    def put(self, data: bytes) -> str:
        digest = content_hash(data)
        if digest in self._entries:
            self._entries[digest].ref_count += 1
            return digest
        self._entries[digest] = ContentEntry(digest, len(data))
        self.stats.record_store(len(data))
        if self.directory is not None:
            (self.directory / digest).write_bytes(data)
        else:
            self._store_in_memory(digest, data)
        return digest

    def _store_in_memory(self, digest: str, data: bytes) -> None:
        while self._memory_bytes + len(data) > self.max_memory_bytes and self._memory:
            self._evict_lru()
        self._memory[digest] = data
        self._memory_bytes += len(data)

    def _evict_lru(self) -> None:
        oldest = min(self._entries.items(), key=lambda kv: kv[1].created_at, default=(None, None))
        digest = oldest[0]
        if digest and digest in self._memory:
            size = len(self._memory.pop(digest))
            self._memory_bytes -= size
            self._entries.pop(digest, None)
            self.stats.record_eviction(size)

    def get(self, digest: str) -> Optional[bytes]:
        if digest in self._memory:
            self.stats.record_hit(bytes_saved=len(self._memory[digest]))
            return self._memory[digest]
        if self.directory is not None:
            path = self.directory / digest
            if path.exists():
                data = path.read_bytes()
                self.stats.record_hit(bytes_saved=len(data))
                return data
        self.stats.record_miss()
        return None

    def contains(self, digest: str) -> bool:
        if digest in self._entries:
            return True
        return self.directory is not None and (self.directory / digest).exists()

    def verify(self, digest: str, data: bytes) -> bool:
        return content_hash(data) == digest

    def evict(self, digest: str) -> bool:
        entry = self._entries.pop(digest, None)
        removed = False
        if digest in self._memory:
            size = len(self._memory.pop(digest))
            self._memory_bytes -= size
            removed = True
        if self.directory is not None:
            path = self.directory / digest
            if path.exists():
                path.unlink()
                removed = True
        if removed and entry:
            self.stats.record_eviction(entry.size)
        return removed

    def size(self) -> int:
        return len(self._entries)
