"""Compiled-WebAssembly-module cache.

Ahead-of-time WASM compilation is expensive; this cache lets
:mod:`silicaflux.runtimes.wasm_runtime` avoid recompiling the same module
bytes on every invocation. Kept as its own tier (rather than reusing
:class:`~silicaflux.cache.module_cache.ModuleCache`) because WASM modules
are identified by their bytecode hash across *all* runtimes/origins that
happen to load the same module — a natural content-addressable case with
its own eviction pressure (compiled artifacts are often much larger than
source)."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional

from silicaflux.cache.content_cache import content_hash
from silicaflux.cache.stats import CacheStats


@dataclass
class CompiledModule:
    module_hash: str
    engine_handle: Any
    exports: list[str]
    cached_at: float = field(default_factory=time.time)
    size_bytes: int = 0


class WASMCache:
    def __init__(self, max_entries: int = 64) -> None:
        self.max_entries = max_entries
        self._modules: dict[str, CompiledModule] = {}
        self._order: list[str] = []
        self.stats = CacheStats(name="wasm_cache")

    def get(self, wasm_bytes: bytes) -> Optional[CompiledModule]:
        digest = content_hash(wasm_bytes)
        entry = self._modules.get(digest)
        if entry is None:
            self.stats.record_miss()
            return None
        self._touch(digest)
        self.stats.record_hit(compute_seconds_saved=0.0)
        return entry

    def put(self, wasm_bytes: bytes, engine_handle: Any, exports: list[str]) -> CompiledModule:
        digest = content_hash(wasm_bytes)
        if digest not in self._modules and len(self._modules) >= self.max_entries:
            oldest = self._order.pop(0)
            evicted = self._modules.pop(oldest, None)
            if evicted:
                self.stats.record_eviction(evicted.size_bytes)
        entry = CompiledModule(digest, engine_handle, exports, size_bytes=len(wasm_bytes))
        self._modules[digest] = entry
        self._touch(digest)
        self.stats.record_store(len(wasm_bytes))
        return entry

    def _touch(self, digest: str) -> None:
        if digest in self._order:
            self._order.remove(digest)
        self._order.append(digest)
