"""HTTP resource cache: URL -> content-addressed blob plus the metadata
needed to decide freshness (spec section 3): content hash, size, content
type, timestamp, expiry, ETag, Last-Modified, origin and an integrity
value pages can request verification against.

Freshness follows ordinary HTTP semantics (``Cache-Control: max-age``,
``Expires``) at the granularity this browser needs; conditional
revalidation (If-None-Match / If-Modified-Since) is exposed via
:meth:`ResourceCache.revalidation_headers` for
:mod:`silicaflux.networking.client` to attach to outgoing requests.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from silicaflux.cache.content_cache import ContentCache
from silicaflux.cache.stats import CacheStats
from silicaflux.core.logging_setup import get_logger

logger = get_logger("cache.resource")


@dataclass
class ResourceMetadata:
    url: str
    content_hash: str
    size: int
    content_type: str
    timestamp: float
    expiry: Optional[float]
    etag: Optional[str]
    last_modified: Optional[str]
    origin: str
    integrity: str
    #: other resource URLs this one depends on (e.g. an HTML page's
    #: linked stylesheets) — invalidating a dependency invalidates this
    #: entry too, see :meth:`ResourceCache.invalidate_dependents`.
    depends_on: frozenset[str] = field(default_factory=frozenset)

    def is_fresh(self, now: Optional[float] = None) -> bool:
        if self.expiry is None:
            return False  # no explicit freshness lifetime -> always revalidate
        now = now if now is not None else time.time()
        return now < self.expiry

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "content_hash": self.content_hash,
            "size": self.size,
            "content_type": self.content_type,
            "timestamp": self.timestamp,
            "expiry": self.expiry,
            "etag": self.etag,
            "last_modified": self.last_modified,
            "origin": self.origin,
            "integrity": self.integrity,
            "depends_on": sorted(self.depends_on),
        }


class ResourceCache:
    def __init__(self, blobs: Optional[ContentCache] = None, directory: Optional[Path] = None) -> None:
        self.blobs = blobs or ContentCache(directory=directory, name="resource_blobs")
        self._metadata: dict[str, ResourceMetadata] = {}
        self._dependents: dict[str, set[str]] = {}
        self.stats = CacheStats(name="resource_cache")

    def store(
        self,
        url: str,
        data: bytes,
        content_type: str,
        origin: str,
        *,
        max_age_s: Optional[float] = None,
        etag: Optional[str] = None,
        last_modified: Optional[str] = None,
        depends_on: Optional[list[str]] = None,
    ) -> ResourceMetadata:
        digest = self.blobs.put(data)
        expiry = (time.time() + max_age_s) if max_age_s is not None else None
        meta = ResourceMetadata(
            url=url,
            content_hash=digest,
            size=len(data),
            content_type=content_type,
            timestamp=time.time(),
            expiry=expiry,
            etag=etag,
            last_modified=last_modified,
            origin=origin,
            integrity=f"sha256-{digest}",
            depends_on=frozenset(depends_on or []),
        )
        self._metadata[url] = meta
        for dep in meta.depends_on:
            self._dependents.setdefault(dep, set()).add(url)
        self.stats.record_store(meta.size)
        return meta

    def lookup(self, url: str) -> Optional[tuple[ResourceMetadata, bytes]]:
        meta = self._metadata.get(url)
        if meta is None:
            self.stats.record_miss()
            return None
        data = self.blobs.get(meta.content_hash)
        if data is None:
            # blob evicted from the content store; metadata is now stale
            self._metadata.pop(url, None)
            self.stats.record_miss()
            return None
        if not meta.is_fresh():
            self.stats.record_miss()
            return None
        self.stats.record_hit(bytes_saved=meta.size)
        return meta, data

    def revalidation_headers(self, url: str) -> dict[str, str]:
        meta = self._metadata.get(url)
        if meta is None:
            return {}
        headers = {}
        if meta.etag:
            headers["If-None-Match"] = meta.etag
        if meta.last_modified:
            headers["If-Modified-Since"] = meta.last_modified
        return headers

    def mark_revalidated(self, url: str, max_age_s: Optional[float] = None) -> None:
        meta = self._metadata.get(url)
        if meta is None:
            return
        meta.timestamp = time.time()
        meta.expiry = (time.time() + max_age_s) if max_age_s is not None else None

    def invalidate(self, url: str) -> None:
        self._metadata.pop(url, None)
        self.invalidate_dependents(url)

    def invalidate_dependents(self, url: str) -> None:
        for dependent in self._dependents.pop(url, set()):
            self.invalidate(dependent)

    def metadata(self, url: str) -> Optional[ResourceMetadata]:
        return self._metadata.get(url)

    def clear_origin(self, origin: str) -> int:
        urls = [u for u, m in self._metadata.items() if m.origin == origin]
        for u in urls:
            self.invalidate(u)
        return len(urls)
