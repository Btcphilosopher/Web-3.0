"""Cache for loaded/compiled application modules — Python bytecode
handles, R script bodies, Rust dynamic library paths — keyed by content
hash so a runtime adapter never has to re-parse/re-compile source it has
already seen (spec section 3: ModuleCache)."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional

from silicaflux.cache.content_cache import ContentCache, content_hash
from silicaflux.cache.stats import CacheStats


@dataclass
class ModuleEntry:
    module_hash: str
    runtime: str
    compiled: Any
    cached_at: float = field(default_factory=time.time)


class ModuleCache:
    """Two-level cache: raw source bytes go through :class:`ContentCache`
    (so identical source is deduplicated across runtimes), while the
    *compiled/prepared* artifact (whatever that means for a given
    runtime — a ``code`` object, a parsed AST, a loaded library handle)
    lives in an in-memory map keyed by the same content hash."""

    def __init__(self, blobs: Optional[ContentCache] = None) -> None:
        self.blobs = blobs or ContentCache(name="module_source")
        self._compiled: dict[str, ModuleEntry] = {}
        self.stats = CacheStats(name="module_cache")

    def get_or_compile(self, runtime: str, source: bytes, compile_fn) -> Any:
        digest = content_hash(source)
        entry = self._compiled.get(digest)
        if entry is not None:
            self.stats.record_hit()
            return entry.compiled
        self.stats.record_miss()
        self.blobs.put(source)
        compiled = compile_fn(source)
        self._compiled[digest] = ModuleEntry(digest, runtime, compiled)
        self.stats.record_store(len(source))
        return compiled

    def invalidate(self, source: bytes) -> bool:
        digest = content_hash(source)
        return self._compiled.pop(digest, None) is not None
