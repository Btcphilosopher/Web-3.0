"""Multi-tier caching: content-addressable blob storage, HTTP resources,
deterministic computation memoization, loaded modules, compiled WASM and
cache-aware API responses. DNS caching lives in
:mod:`silicaflux.networking.dns_cache` alongside the rest of networking,
but is included in :class:`StatsRegistry` totals via the network scheduler.
"""

from __future__ import annotations

from silicaflux.cache.api_response_cache import APIResponseCache
from silicaflux.cache.computation_cache import ComputationCache
from silicaflux.cache.content_cache import ContentCache, content_hash
from silicaflux.cache.module_cache import ModuleCache
from silicaflux.cache.resource_cache import ResourceCache
from silicaflux.cache.stats import CacheStats, StatsRegistry
from silicaflux.cache.wasm_cache import WASMCache

__all__ = [
    "APIResponseCache",
    "ComputationCache",
    "ContentCache",
    "content_hash",
    "ModuleCache",
    "ResourceCache",
    "CacheStats",
    "StatsRegistry",
    "WASMCache",
]


class CacheManager:
    """Convenience bundle wiring up every cache tier with one shared
    :class:`StatsRegistry`, used by :mod:`silicaflux.core.engine` and the
    CLI so callers don't have to construct six objects by hand."""

    def __init__(self, cache_dir=None) -> None:
        from pathlib import Path

        cache_dir = Path(cache_dir) if cache_dir else None
        self.registry = StatsRegistry()

        self.content = ContentCache(directory=(cache_dir / "content") if cache_dir else None)
        self.resources = ResourceCache(directory=(cache_dir / "resources") if cache_dir else None)
        self.computation = ComputationCache()
        self.modules = ModuleCache()
        self.wasm = WASMCache()
        self.api_responses = APIResponseCache()

        for tier in (self.content, self.resources, self.computation, self.modules, self.wasm, self.api_responses):
            self.registry.register(tier.stats)

    def stats(self) -> dict:
        return {"tiers": self.registry.snapshot(), "totals": self.registry.totals()}
