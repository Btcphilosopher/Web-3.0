# SilicaFlux Web3.0

A real, runnable desktop web browser, written primarily in Python:
standards-compatible web rendering (Chromium via PySide6/QtWebEngine)
layered over **SilicaFlux** — a packet-based runtime fabric that routes
computation across Python, R, Rust and WebAssembly, plus a Web3 identity
layer, all under a deny-by-default capability security model.

```
                    WEB
                     │
           HTML / CSS / JS
                     │
                     ▼
            BROWSER RENDERER
                     │
                     ▼
            SILICAFLUX BRIDGE
                     │
       ┌─────────────┼─────────────┐
       ▼             ▼             ▼
    PYTHON           R           RUST
       │             │             │
       └─────────────┼─────────────┘
                     ▼
                   WASM
                     │
                     ▼
                CPU / GPU / NPU
```

An ordinary website loads like a website, full stop — no dependency on
SilicaFlux at all. A **SilicaFlux application** is the same HTML/CSS/JS,
plus `window.silicaflux.request(...)` calls that reach the packet fabric.
See `docs/ARCHITECTURE.md` for the full design.

## What's actually here

This is not a mockup. Every subsystem below is real, working code with
automated tests exercising it — **119 passing tests**, no mocks for the
core packet/security/storage/cache logic (httpx's `MockTransport` is used
only to avoid real network I/O in CI, per its intended purpose).

| Subsystem | What it does | Verified by |
|---|---|---|
| Packet fabric | `SFXPacket` state machine, priority scheduler, runtime router, async dispatch engine | `test_packet.py`, `test_router.py`, `test_scheduler.py`, `test_integration.py` |
| Execution graph | DAG of typed nodes across runtimes, dependency resolution, retries, cache-aware | `test_graph.py` |
| Python runtime | Real `multiprocessing` process isolation, resource limits, timeout + crash recovery | `test_runtimes.py` |
| R / Rust runtimes | Subprocess isolation; a real compiled Rust SHA-256 binary demo; honest "unavailable" when R isn't installed | `test_runtimes.py`, `examples/rust_compute/` |
| WASM runtime | Real `wasmtime` compilation + execution, content-hash module cache | `test_runtimes.py` |
| Security | Capability tokens, origin isolation, sandboxing, deny-by-default | `test_security.py` |
| Web3 | Real Ed25519 identity, encrypted-at-rest keys, wallet approval gating, P2P content retrieval | `test_web3.py` |
| Storage | SQLite-backed history/bookmarks/sessions/downloads/permissions/telemetry | `test_storage.py` |
| Cache | Content-addressable, resource, computation, module, WASM, API-response tiers | `test_cache.py` |
| Networking | Pooled async HTTP client, DNS cache, retries, streaming/resumable downloads | `test_networking.py` |
| Local AI | Verified-hash model registry, process-isolated inference, honest hardware reporting | `test_ai.py` |
| Browser GUI | PySide6/QtWebEngine shell: tabs, navigation, `sfx://` protocol, JS↔SilicaFlux bridge | see `docs/INSTALL.md` |

Run the whole pipeline yourself:

```bash
pip install -r requirements.txt
python examples/sfx_app/run_demo.py
```

That one command exercises HTML → JS → SilicaFlux → **Python** →
**Rust** → **WASM** → cache → **Web3 identity** → HTML, for real, in your
terminal — no display required.

## Quick start

```bash
git clone <this repo> && cd silicaflux_web3
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python -m pytest                       # 119 tests, ~7s
python -m silicaflux.cli diagnostics   # what's available on this machine
python examples/sfx_app/run_demo.py    # full multi-runtime demo, no display needed

# Desktop GUI:
pip install PySide6 qasync
python main.py
```

See `docs/INSTALL.md` for platform-specific setup (Linux system
libraries, macOS notes) and `docs/MACOS_BUILD.md` for packaging a
distributable `.app`.

## Project layout

```
silicaflux_web3/
├── main.py                     # GUI entry point (thin shim over silicaflux.browser.launcher)
├── requirements.txt  pyproject.toml  pytest.ini  LICENSE
├── docs/
│   ├── ARCHITECTURE.md         # full system design
│   ├── SECURITY.md             # capability model, sandboxing, Web3 key storage
│   ├── RUNTIME_API.md          # window.silicaflux JS API + Python API + CLI reference
│   ├── INSTALL.md              # setup for every platform
│   └── MACOS_BUILD.md          # packaging a .app bundle
├── examples/
│   ├── demo_page.html          # minimal standalone JS ↔ SilicaFlux page
│   ├── rust_compute/           # real compiled Rust binary (dependency-free SHA-256)
│   └── sfx_app/                # full example SFX application + headless demo runner
└── silicaflux/                 # the installable package
    ├── core/                   # packet, router, scheduler, engine, graph, tabs, navigation, config
    ├── browser/                # PySide6/QtWebEngine GUI (window, tabs, page, sfx:// protocol)
    ├── runtimes/                # python / r / rust / wasm / javascript adapters + manager
    ├── security/                # capabilities, policy, sandbox, origins, audit
    ├── storage/                  # SQLite: history, bookmarks, downloads, permissions, settings
    ├── cache/                    # content / resource / computation / module / wasm / API caches
    ├── networking/                # HTTP client, DNS cache, downloads, cookies, scheduler
    ├── web3/                      # identity, wallet, dapp bridge, permissions, P2P
    ├── ai/                         # model registry, inference worker, tensor helpers
    ├── telemetry/                  # metrics, tracing, real system snapshots, dashboard
    ├── developer/                   # console, network panel, page inspector, runtime monitor
    ├── api/                          # the window.silicaflux JS bridge
    ├── config/                       # default settings
    ├── benchmarks/                    # real latency/throughput benchmark suite
    ├── tests/                          # 119 pytest tests
    ├── cli.py                          # sfx-browser / silicaflux-browser
    └── dev_cli.py                      # sfx-runtime / silicaflux-dev
```

(148 Python/HTML/JS/Rust/config files in total — `find . -type f` for the
exact list.)

## Security posture, in one paragraph

Nothing gets access to anything by default. A webpage's every
capability — running Python, connecting a wallet, reading the
filesystem — is an explicit, origin-scoped, signed, revocable token
issued by a policy engine that defaults to denial. Untrusted code never
runs in the browser's own process: Python operations run in isolated
`multiprocessing` workers with resource limits, R and Rust run as
subprocesses, WASM runs inside `wasmtime`'s own sandbox. Private keys are
generated locally, encrypted at rest, never logged, and never leave the
device. Full detail in `docs/SECURITY.md`.

## What's honestly adapter-only

Per the project's own guiding principle — a clean, honest "unavailable"
beats a fake success — the **R** runtime reports unavailable unless
`Rscript` is actually on `PATH` (most CI containers don't have R
installed, and this repo doesn't pretend otherwise), and **GPU/NPU**
acceleration in the AI engine reports unavailable unless a real
accelerator adapter is registered (none is fabricated). Run
`sfx-browser diagnostics` to see exactly what's available on your
machine and why.

## License

MIT — see `LICENSE`.
