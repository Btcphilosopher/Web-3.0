#!/usr/bin/env python3
"""Convenience entry point: ``python main.py`` launches the SilicaFlux
Web3.0 desktop browser. Equivalent to ``sfx-browser start`` once the
package is installed (``pip install -e .``) — see ``docs/INSTALL.md``.
All the actual wiring lives in :mod:`silicaflux.browser.launcher`, which
is what :mod:`silicaflux.cli` calls too, so both entry points stay in
sync automatically.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from silicaflux.browser.launcher import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
