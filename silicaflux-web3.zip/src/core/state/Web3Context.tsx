'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  NetworkState,
  BlockState,
  TransactionState,
  AssetState,
  ContractState,
  DeFiReservoirState,
  GovernanceProposalState,
  WalletState,
  IdentityState,
  ViewTab,
  InfrastructureNetworkId,
  OperatingMode,
  ThemeMode,
  DensityMode,
} from '@/src/web3/types';
import {
  INITIAL_NETWORKS,
  INITIAL_WALLET,
  INITIAL_IDENTITY,
  INITIAL_ASSETS,
  INITIAL_BLOCKS,
  INITIAL_TRANSACTIONS,
  INITIAL_CONTRACTS,
  INITIAL_DEFI_RESERVOIRS,
  INITIAL_GOVERNANCE_PROPOSALS,
} from '@/src/data/mockWeb3Data';
import { formatNumber, formatCurrencyGbp } from '@/lib/utils';

interface SecurityPromptState {
  isOpen: boolean;
  title: string;
  what: string;
  who: string;
  where: string;
  howMuch: string;
  why: string;
  targetContract?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

interface Web3ContextValue {
  // Navigation & Modes
  currentTab: ViewTab;
  setCurrentTab: (tab: ViewTab) => void;
  operatingMode: OperatingMode;
  setOperatingMode: (mode: OperatingMode) => void;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  densityMode: DensityMode;
  setDensityMode: (density: DensityMode) => void;

  // State slices
  networks: NetworkState[];
  currentNetwork: NetworkState;
  switchNetwork: (networkId: InfrastructureNetworkId) => void;

  wallet: WalletState;
  connectWallet: (type?: WalletState['vaultType']) => void;
  disconnectWallet: () => void;

  identity: IdentityState;

  assets: AssetState[];
  selectedAsset: AssetState | null;
  setSelectedAsset: (asset: AssetState | null) => void;

  blocks: BlockState[];
  selectedBlock: BlockState | null;
  setSelectedBlock: (block: BlockState | null) => void;

  transactions: TransactionState[];
  selectedTransaction: TransactionState | null;
  setSelectedTransaction: (tx: TransactionState | null) => void;
  inspectCausalChain: (txHash: string) => void;
  causalModalOpen: boolean;
  setCausalModalOpen: (open: boolean) => void;

  contracts: ContractState[];
  selectedContract: ContractState | null;
  setSelectedContract: (contract: ContractState | null) => void;

  reservoirs: DeFiReservoirState[];
  proposals: GovernanceProposalState[];

  // Action methods
  createTransaction: (params: {
    destination: string;
    value: number;
    assetSymbol: string;
    methodCalled?: string;
    why?: string;
  }) => Promise<void>;

  executeContractFunction: (
    contractAddress: string,
    funcName: string,
    args: Record<string, string | number>
  ) => Promise<void>;

  voteProposal: (proposalId: string, vote: 'FOR' | 'AGAINST' | 'ABSTAIN') => void;

  // Security prompt
  securityPrompt: SecurityPromptState | null;
  dismissSecurityPrompt: () => void;

  // Network Switch Modal
  networkModalOpen: boolean;
  setNetworkModalOpen: (open: boolean) => void;

  // New Transaction Drawer
  newTxDrawerOpen: boolean;
  setNewTxDrawerOpen: (open: boolean) => void;
}

const Web3Context = createContext<Web3ContextValue | undefined>(undefined);

export function Web3Provider({ children }: { children: React.ReactNode }) {
  const [currentTab, setCurrentTab] = useState<ViewTab>('OBSERVATORY');
  const [operatingMode, setOperatingMode] = useState<OperatingMode>('LIVE_SIMULATION');
  const [themeMode, setThemeModeState] = useState<ThemeMode>('OBSIDIAN');
  const [densityMode, setDensityMode] = useState<DensityMode>('STANDARD');

  const [networks, setNetworks] = useState<NetworkState[]>(INITIAL_NETWORKS);
  const [activeNetworkId, setActiveNetworkId] = useState<InfrastructureNetworkId>('silica-sovereign-l1');

  const [wallet, setWallet] = useState<WalletState>(INITIAL_WALLET);
  const [identity, setIdentity] = useState<IdentityState>(INITIAL_IDENTITY);
  const [assets, setAssets] = useState<AssetState[]>(INITIAL_ASSETS);
  const [selectedAsset, setSelectedAsset] = useState<AssetState | null>(INITIAL_ASSETS[0]);

  const [blocks, setBlocks] = useState<BlockState[]>(INITIAL_BLOCKS);
  const [selectedBlock, setSelectedBlock] = useState<BlockState | null>(null);

  const [transactions, setTransactions] = useState<TransactionState[]>(INITIAL_TRANSACTIONS);
  const [selectedTransaction, setSelectedTransaction] = useState<TransactionState | null>(INITIAL_TRANSACTIONS[0]);
  const [causalModalOpen, setCausalModalOpen] = useState<boolean>(false);

  const [contracts, setContracts] = useState<ContractState[]>(INITIAL_CONTRACTS);
  const [selectedContract, setSelectedContract] = useState<ContractState | null>(INITIAL_CONTRACTS[0]);

  const [reservoirs, setReservoirs] = useState<DeFiReservoirState[]>(INITIAL_DEFI_RESERVOIRS);
  const [proposals, setProposals] = useState<GovernanceProposalState[]>(INITIAL_GOVERNANCE_PROPOSALS);

  const [securityPrompt, setSecurityPrompt] = useState<SecurityPromptState | null>(null);
  const [networkModalOpen, setNetworkModalOpen] = useState(false);
  const [newTxDrawerOpen, setNewTxDrawerOpen] = useState(false);

  // Sync theme mode with DOM
  const setThemeMode = useCallback((mode: ThemeMode) => {
    setThemeModeState(mode);
    if (typeof document !== 'undefined') {
      const root = document.documentElement;
      if (mode === 'OBSIDIAN') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }, []);

  const currentNetwork = networks.find((n) => n.id === activeNetworkId) || networks[0];

  // Network Switch with state transition
  const switchNetwork = useCallback((networkId: InfrastructureNetworkId) => {
    setActiveNetworkId(networkId);
    setNetworkModalOpen(false);
  }, []);

  const connectWallet = useCallback((type: WalletState['vaultType'] = 'SOVEREIGN_MULTISIG') => {
    setWallet((prev) => ({
      ...prev,
      vaultType: type,
      status: 'CONNECTED',
    }));
  }, []);

  const disconnectWallet = useCallback(() => {
    setWallet((prev) => ({
      ...prev,
      status: 'DISCONNECTED',
    }));
  }, []);

  const dismissSecurityPrompt = useCallback(() => {
    setSecurityPrompt(null);
  }, []);

  const inspectCausalChain = useCallback((txHash: string) => {
    const tx = transactions.find((t) => t.hash === txHash) || transactions[0];
    setSelectedTransaction(tx);
    setCausalModalOpen(true);
  }, [transactions]);

  // Live Simulation Heartbeat
  useEffect(() => {
    if (operatingMode !== 'LIVE_SIMULATION') return;

    const interval = setInterval(() => {
      // 1. Advance network block height & minor gas fluctuations
      setNetworks((prev) =>
        prev.map((net) => {
          const delta = net.id === 'london-l2-rollup' ? 3 : 1;
          const gasFluct = (Math.random() - 0.5) * 0.4;
          return {
            ...net,
            blockHeight: net.blockHeight + delta,
            gasPriceGwei: Math.max(0.01, +(net.gasPriceGwei + gasFluct).toFixed(2)),
            quorumsVerified: net.quorumsVerified + 1,
          };
        })
      );

      // 2. Generate an incoming verified block every 12 seconds
      if (Math.random() > 0.45) {
        const newHeight = blocks[0].height + 1;
        const newHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
        const parentHash = blocks[0].hash;
        const newBlock: BlockState = {
          height: newHeight,
          hash: newHash,
          parentHash: parentHash,
          timestamp: Date.now(),
          miner: '0x3F88...6C18 (Silica Enclave Attested Prover)',
          gasUsed: Math.floor(12000000 + Math.random() * 6000000),
          gasLimit: 30000000,
          transactionCount: Math.floor(110 + Math.random() * 120),
          baseFeeGwei: +(16.2 + Math.random() * 1.5).toFixed(2),
          stateRoot: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
          transactionsRoot: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
          receiptsRoot: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
          sizeBytes: Math.floor(110000 + Math.random() * 40000),
          difficulty: '0 (PoS Attestation #0x89)',
          networkId: activeNetworkId,
        };
        setBlocks((prev) => [newBlock, ...prev.slice(0, 19)]);
      }

      // 3. Increment pending transactions confirmations
      setTransactions((prev) =>
        prev.map((tx) => {
          if (tx.status === 'PENDING' && tx.confirmations < 12) {
            const nextConf = tx.confirmations + 1;
            return {
              ...tx,
              confirmations: nextConf,
              stage: nextConf >= 6 ? 'FINAL' : 'CONFIRMED',
              status: nextConf >= 6 ? 'SETTLED' : 'PENDING',
            };
          }
          return tx;
        })
      );
    }, 4500);

    return () => clearInterval(interval);
  }, [operatingMode, blocks, activeNetworkId]);

  // Create & Broadcast Transaction with security prompt & multi-stage lifecycle
  const createTransaction = useCallback(
    async (params: {
      destination: string;
      value: number;
      assetSymbol: string;
      methodCalled?: string;
      why?: string;
    }) => {
      const asset = assets.find((a) => a.symbol === params.assetSymbol) || assets[0];
      const targetNetwork = currentNetwork;

      return new Promise<void>((resolve, reject) => {
        setSecurityPrompt({
          isOpen: true,
          title: 'AUTHORISE CRYPTOGRAPHIC SETTLEMENT',
          what: `Transfer ${formatNumber(params.value)} ${params.assetSymbol}`,
          who: `${wallet.domainName} (${wallet.address.slice(0, 8)}...${wallet.address.slice(-6)})`,
          where: `${params.destination} on ${targetNetwork.name}`,
          howMuch: `${formatCurrencyGbp(params.value * asset.priceGbp)} (Est. Fee £0.12)`,
          why: params.why || 'Sovereign Treasury Transfer & Contract Call',
          targetContract: params.destination,
          onConfirm: () => {
            setSecurityPrompt(null);
            setNewTxDrawerOpen(false);

            const txHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
            const newTx: TransactionState = {
              hash: txHash,
              origin: wallet.address,
              originLabel: wallet.domainName,
              destination: params.destination,
              destinationLabel: 'Target Recipient / Contract Chamber',
              value: params.value,
              assetSymbol: params.assetSymbol,
              assetName: asset.name,
              networkId: targetNetwork.id,
              gasUsed: 48200,
              gasPriceGwei: targetNetwork.gasPriceGwei,
              feeGbp: +(targetNetwork.gasPriceGwei * 0.04).toFixed(2),
              timestamp: Date.now(),
              blockNumber: targetNetwork.blockHeight + 1,
              status: 'PENDING',
              confirmations: 0,
              stage: 'BROADCAST',
              nonce: wallet.nonce + 1,
              methodCalled: params.methodCalled || 'directTransfer(address recipient, uint256 amount)',
              contractAddress: params.destination.startsWith('0x') ? params.destination : undefined,
              causalTrace: {
                networkOrigin: targetNetwork.name,
                blockWitness: targetNetwork.blockHeight + 1,
                contractInvoked: params.destination,
                stateDeltas: [
                  {
                    account: `${wallet.address.slice(0, 6)}... (${wallet.domainName})`,
                    delta: `-${params.value} ${params.assetSymbol}`,
                    asset: params.assetSymbol,
                  },
                  {
                    account: `${params.destination.slice(0, 6)}...`,
                    delta: `+${params.value} ${params.assetSymbol}`,
                    asset: params.assetSymbol,
                  },
                ],
                gasExecutionStepCount: 94,
                cryptographicProof: 'ZK_STARK_TRANSACTION_SEAL_#UK_' + Math.floor(Math.random() * 90000 + 10000),
              },
            };

            // Deduct balance
            setAssets((prev) =>
              prev.map((a) =>
                a.symbol === params.assetSymbol
                  ? {
                      ...a,
                      balance: Math.max(0, a.balance - params.value),
                      totalValueGbp: Math.max(0, (a.balance - params.value) * a.priceGbp),
                    }
                  : a
              )
            );

            setWallet((prev) => ({
              ...prev,
              nonce: prev.nonce + 1,
              totalPortfolioValueGbp: prev.totalPortfolioValueGbp - params.value * asset.priceGbp,
            }));

            setTransactions((prev) => [newTx, ...prev]);
            setSelectedTransaction(newTx);

            // Progressive state settlement animation
            setTimeout(() => {
              setTransactions((prev) =>
                prev.map((t) => (t.hash === txHash ? { ...t, stage: 'MEMPOOL' } : t))
              );
            }, 800);

            setTimeout(() => {
              setTransactions((prev) =>
                prev.map((t) => (t.hash === txHash ? { ...t, stage: 'BLOCK', confirmations: 1 } : t))
              );
            }, 1800);

            setTimeout(() => {
              setTransactions((prev) =>
                prev.map((t) => (t.hash === txHash ? { ...t, stage: 'CONFIRMED', confirmations: 3 } : t))
              );
            }, 3000);

            setTimeout(() => {
              setTransactions((prev) =>
                prev.map((t) => (t.hash === txHash ? { ...t, stage: 'FINAL', status: 'SETTLED', confirmations: 12 } : t))
              );
            }, 4500);

            resolve();
          },
          onCancel: () => {
            setSecurityPrompt(null);
            reject(new Error('User declined cryptographic signature'));
          },
        });
      });
    },
    [assets, currentNetwork, wallet]
  );

  // Execute smart contract function
  const executeContractFunction = useCallback(
    async (contractAddress: string, funcName: string, args: Record<string, string | number>) => {
      const contract = contracts.find((c) => c.address === contractAddress) || contracts[0];
      const fn = contract.functions.find((f) => f.name === funcName);

      return new Promise<void>((resolve) => {
        setSecurityPrompt({
          isOpen: true,
          title: `EXECUTE SMART CONTRACT: ${contract.name}`,
          what: `Invocation of ${funcName}(${Object.keys(args).join(', ')})`,
          who: `${wallet.domainName}`,
          where: `${contract.address} on ${currentNetwork.name}`,
          howMuch: `Gas Limit: ${fn?.gasEstimate || 85000} (Est. £0.18)`,
          why: `Cryptographic Machine State Transition for ${contract.name}`,
          targetContract: contract.address,
          onConfirm: () => {
            setSecurityPrompt(null);
            // Log call
            setContracts((prev) =>
              prev.map((c) =>
                c.address === contractAddress
                  ? {
                      ...c,
                      totalCalls24h: c.totalCalls24h + 1,
                      eventsLoggedCount: c.eventsLoggedCount + 1,
                    }
                  : c
              )
            );
            resolve();
          },
          onCancel: () => {
            setSecurityPrompt(null);
          },
        });
      });
    },
    [contracts, currentNetwork, wallet]
  );

  // Vote on governance proposal
  const voteProposal = useCallback(
    (proposalId: string, vote: 'FOR' | 'AGAINST' | 'ABSTAIN') => {
      setProposals((prev) =>
        prev.map((p) => {
          if (p.id === proposalId) {
            const weight = identity.governanceWeight;
            return {
              ...p,
              forVotes: vote === 'FOR' ? p.forVotes + weight : p.forVotes,
              againstVotes: vote === 'AGAINST' ? p.againstVotes + weight : p.againstVotes,
              abstainVotes: vote === 'ABSTAIN' ? p.abstainVotes + weight : p.abstainVotes,
              status:
                p.forVotes + weight >= p.quorumThreshold
                  ? 'QUORUM_REACHED'
                  : p.status,
            };
          }
          return p;
        })
      );
    },
    [identity.governanceWeight]
  );

  return (
    <Web3Context.Provider
      value={{
        currentTab,
        setCurrentTab,
        operatingMode,
        setOperatingMode,
        themeMode,
        setThemeMode,
        densityMode,
        setDensityMode,
        networks,
        currentNetwork,
        switchNetwork,
        wallet,
        connectWallet,
        disconnectWallet,
        identity,
        assets,
        selectedAsset,
        setSelectedAsset,
        blocks,
        selectedBlock,
        setSelectedBlock,
        transactions,
        selectedTransaction,
        setSelectedTransaction,
        inspectCausalChain,
        causalModalOpen,
        setCausalModalOpen,
        contracts,
        selectedContract,
        setSelectedContract,
        reservoirs,
        proposals,
        createTransaction,
        executeContractFunction,
        voteProposal,
        securityPrompt,
        dismissSecurityPrompt,
        networkModalOpen,
        setNetworkModalOpen,
        newTxDrawerOpen,
        setNewTxDrawerOpen,
      }}
    >
      {children}
    </Web3Context.Provider>
  );
}

export function useWeb3() {
  const context = useContext(Web3Context);
  if (!context) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
}
