/**
 * SILICAFLUX DESIGN TOKENS
 * Anglo-Futurist, Architectural, Semiconductor-Grade Design System
 */

export const SILICAFLUX = {
  name: 'SILICAFLUX WEB3',
  version: '4.2.0-SOVEREIGN',
  arch: 'RTL_CORE_V4',

  colours: {
    obsidian: {
      void: '#07080a',
      base: '#0a0c0f',
      raised: '#101317',
      plate: '#161a20',
      card: '#12151b',
      cardHover: '#171b23',
    },
    archive: {
      paper: '#faf9f5',
      ivory: '#f6f4ee',
      parchment: '#eeeae0',
      stone: '#e3dfd3',
      ink: '#1a1e24',
    },
    metals: {
      blackenedSteel: '#1e242d',
      brushedAluminium: '#ccd2d9',
      silver: '#e2e5e9',
      graphite: '#2b323c',
      titanium: '#828c9a',
      goldLeaf: '#c29d62',
    },
    secondary: {
      steelBlue: '#4b7b9e',
      mutedBlue: '#3a607f',
      paleGreen: '#4e8752',
      amber: '#c98a2c',
      controlledRed: '#a33b39',
    },
  },

  typography: {
    display: "Cinzel, 'Times New Roman', serif",
    system: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
    machine: "'IBM Plex Mono', 'Courier New', monospace",
    scale: {
      submicro: '0.625rem', // 10px
      micro: '0.6875rem',    // 11px
      nano: '0.75rem',       // 12px
      caption: '0.8125rem',  // 13px
      base: '0.875rem',      // 14px
      body: '1rem',          // 16px
      lead: '1.125rem',      // 18px
      displaySm: '1.375rem', // 22px
      displayMd: '1.75rem',  // 28px
      displayLg: '2.25rem',  // 36px
      displayXl: '3rem',     // 48px
      displayHero: '4rem',   // 64px
    },
  },

  spacing: {
    unit: 4, // 4px baseline
    reticle: 8,
    gutter: 16,
    bay: 24,
    chamber: 32,
    quadrant: 48,
    hall: 64,
  },

  geometry: {
    radius: {
      none: '0px',
      subtle: '2px',
      sharp: '3px',
      panel: '4px',
      module: '6px',
      pill: '9999px',
    },
    borders: {
      hairline: '1px solid',
      datum: '2px solid',
    },
  },

  motion: {
    timing: {
      instant: '0.1s cubic-bezier(0.16, 1, 0.3, 1)',
      snappy: '0.2s cubic-bezier(0.16, 1, 0.3, 1)',
      settled: '0.4s cubic-bezier(0.16, 1, 0.3, 1)',
      monumental: '0.8s cubic-bezier(0.16, 1, 0.3, 1)',
    },
  },

  density: {
    calm: {
      rowHeight: '52px',
      padding: 'p-6',
      gap: 'gap-6',
      chartHeight: 320,
    },
    standard: {
      rowHeight: '42px',
      padding: 'p-4',
      gap: 'gap-4',
      chartHeight: 260,
    },
    dense: {
      rowHeight: '34px',
      padding: 'p-3',
      gap: 'gap-2',
      chartHeight: 200,
    },
  },
} as const;
