'use client';

import React, { useState } from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { GovernanceProposalState } from '@/src/web3/types';
import { formatNumber, formatDate } from '@/lib/utils';
import {
  Landmark,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck,
  FileText,
  ChevronRight,
  Vote,
} from 'lucide-react';

export function GovernanceParliamentView() {
  const { proposals, voteProposal, identity } = useWeb3();
  const [selectedProposal, setSelectedProposal] = useState<GovernanceProposalState>(proposals[0]);
  const [votedMessage, setVotedMessage] = useState<string | null>(null);

  const p = selectedProposal || proposals[0];

  const handleVote = (vote: 'FOR' | 'AGAINST' | 'ABSTAIN') => {
    voteProposal(p.id, vote);
    setVotedMessage(
      `BALLOT CAST: ${formatNumber(identity.governanceWeight)} Sovereign Voting Power allocated ${vote} on ${p.billNumber}.`
    );
    setTimeout(() => setVotedMessage(null), 4000);
  };

  const totalVotesCast = p.forVotes + p.againstVotes + p.abstainVotes;
  const quorumPercent = Math.min(100, (p.forVotes / p.quorumThreshold) * 100);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-architectural pb-4">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            SOVEREIGN DIGITAL PARLIAMENT & BILL REGISTRY
          </span>
          <h1 className="font-display text-2xl font-bold text-(--text-display) mt-0.5">
            CONSTITUTIONAL GOVERNANCE OBSERVATORY
          </h1>
        </div>

        <div className="flex items-center gap-2 font-machine text-xs">
          <span className="text-(--text-muted)">YOUR VOTING POWER:</span>
          <span className="px-3 py-1 bg-amber-950/40 text-amber-400 border border-amber-800/60 font-bold rounded-xs">
            {formatNumber(identity.governanceWeight)} VOTES
          </span>
        </div>
      </div>

      {/* Main Dual Bay: Proposals List & Selected Formal Bill Document */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Parliamentary Bills List (5 cols) */}
        <div className="lg:col-span-5 border border-architectural bg-(--bg-card) p-4 rounded-xs space-y-3">
          <div className="flex items-center justify-between border-b border-architectural pb-3">
            <span className="font-machine text-xs font-semibold text-(--text-display)">
              PARLIAMENTARY PROPOSALS ({proposals.length})
            </span>
            <span className="font-machine text-[10px] text-(--text-muted)">FORMAL ACTS</span>
          </div>

          <div className="space-y-2">
            {proposals.map((prop) => {
              const isSelected = p.id === prop.id;
              return (
                <button
                  key={prop.id}
                  onClick={() => {
                    setSelectedProposal(prop);
                    setVotedMessage(null);
                  }}
                  className={`w-full p-4 border rounded-xs text-left transition-all relative ${
                    isSelected
                      ? 'border-amber-600 bg-(--bg-secondary) shadow-sm'
                      : 'border-architectural bg-(--bg-primary) hover:bg-(--bg-card-hover)'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-machine text-xs font-bold text-amber-500">
                      {prop.billNumber}
                    </span>
                    <span
                      className={`font-machine text-[9px] px-1.5 py-0.5 border rounded-xs ${
                        prop.status === 'ENACTED'
                          ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/60'
                          : prop.status === 'QUORUM_REACHED'
                          ? 'bg-blue-950/40 text-blue-300 border-blue-800/60'
                          : 'bg-amber-950/40 text-amber-300 border-amber-800/60'
                      }`}
                    >
                      {prop.status.replace('_', ' ')}
                    </span>
                  </div>

                  <h4 className="font-display text-xs font-bold text-(--text-display) line-clamp-2">
                    {prop.title}
                  </h4>

                  <div className="font-machine text-[10px] text-(--text-muted) mt-2 truncate">
                    SPONSOR: {prop.sponsorDomain}
                  </div>

                  {isSelected && <div className="absolute inset-y-0 left-0 w-1 bg-amber-500" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Formal Digital Bill Document (7 cols) */}
        <div className="lg:col-span-7 border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-6">
          {/* Bill Document Header */}
          <div className="border-b border-architectural pb-5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-machine text-xs font-bold text-amber-500">
                {p.billNumber} • SOVEREIGN ACT
              </span>
              <span className="font-machine text-xs text-(--text-muted)">
                DEADLINE: {formatDate(p.deadlineTimestamp)}
              </span>
            </div>

            <h2 className="font-display text-xl font-bold text-(--text-display) leading-snug">
              {p.title}
            </h2>

            <div className="font-machine text-xs text-(--text-secondary)">
              Sponsor: <span className="text-(--text-primary) font-semibold">{p.sponsorDomain}</span> ({p.sponsor})
            </div>
          </div>

          {/* Executive Summary */}
          <div className="p-4 border border-architectural bg-(--bg-secondary) rounded-xs space-y-2">
            <span className="font-machine text-[10px] text-(--text-muted) uppercase tracking-wider block font-semibold">
              EXECUTIVE ACT SUMMARY
            </span>
            <p className="font-system text-xs text-(--text-primary) leading-relaxed">
              {p.executiveSummary}
            </p>
          </div>

          {/* Quorum Progress Bar */}
          <div className="p-4 border border-architectural bg-(--bg-secondary) rounded-xs space-y-3 font-machine text-xs">
            <div className="flex justify-between items-center">
              <span className="text-(--text-muted)">PARLIAMENTARY QUORUM STATUS</span>
              <span className="font-bold text-amber-400">
                {quorumPercent.toFixed(1)}% ({formatNumber(p.forVotes)} / {formatNumber(p.quorumThreshold)})
              </span>
            </div>

            <div className="h-2 w-full bg-slate-800 rounded-xs overflow-hidden">
              <div
                style={{ width: `${quorumPercent}%` }}
                className="h-full bg-amber-500 transition-all duration-500"
              />
            </div>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-(--border-subtle) text-center text-[10px]">
              <div>
                <span className="text-(--text-muted) block">FOR</span>
                <span className="text-emerald-400 font-bold">{formatNumber(p.forVotes)}</span>
              </div>
              <div>
                <span className="text-(--text-muted) block">AGAINST</span>
                <span className="text-red-400 font-bold">{formatNumber(p.againstVotes)}</span>
              </div>
              <div>
                <span className="text-(--text-muted) block">ABSTAIN</span>
                <span className="text-(--text-muted) font-bold">{formatNumber(p.abstainVotes)}</span>
              </div>
            </div>
          </div>

          {/* Voting Action Controls */}
          <div className="space-y-3">
            <span className="font-machine text-xs font-semibold text-(--text-display) block">
              CAST SOVEREIGN BALLOT
            </span>

            <div className="grid grid-cols-3 gap-3 font-machine text-xs">
              <button
                onClick={() => handleVote('FOR')}
                className="py-3 border border-architectural hover:border-emerald-500 bg-(--bg-secondary) hover:bg-emerald-950/20 text-emerald-400 font-bold rounded-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>VOTE FOR</span>
              </button>

              <button
                onClick={() => handleVote('AGAINST')}
                className="py-3 border border-architectural hover:border-red-500 bg-(--bg-secondary) hover:bg-red-950/20 text-red-400 font-bold rounded-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <XCircle className="w-4 h-4" />
                <span>VOTE AGAINST</span>
              </button>

              <button
                onClick={() => handleVote('ABSTAIN')}
                className="py-3 border border-architectural hover:border-(--border-accent) bg-(--bg-secondary) text-(--text-muted) font-bold rounded-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <Clock className="w-4 h-4" />
                <span>ABSTAIN</span>
              </button>
            </div>

            {votedMessage && (
              <div className="p-3 border border-emerald-800 bg-emerald-950/40 text-emerald-300 font-machine text-xs rounded-xs animate-in fade-in">
                {votedMessage}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
