'use client';

import React, { useState } from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { ReservoirGauge } from '@/src/visualisation/ReservoirGauge';
import { DeFiReservoirState } from '@/src/web3/types';
import {
  Activity,
  Droplets,
  ShieldCheck,
  TrendingUp,
  ArrowRightLeft,
  RefreshCw,
  Plus,
  Send,
  Zap,
} from 'lucide-react';

export function DefiReservoirView() {
  const { reservoirs, assets, createTransaction } = useWeb3();
  const [selectedReservoir, setSelectedReservoir] = useState<DeFiReservoirState>(reservoirs[0]);
  const [swapIn, setSwapIn] = useState('1000');
  const [swapAssetIn, setSwapAssetIn] = useState('GBP-D');
  const [swapAssetOut, setSwapAssetOut] = useState('SILICA');
  const [swapping, setSwapping] = useState(false);

  const res = selectedReservoir || reservoirs[0];

  const handleSwap = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(swapIn) || 0;
    if (val <= 0) return;

    setSwapping(true);
    try {
      await createTransaction({
        destination: '0x981249A801284B9102477C018991284bE1058402',
        value: val,
        assetSymbol: swapAssetIn,
        methodCalled: `executeSovereignSwap(address,address,uint256,uint256)`,
        why: `Atomic reservoir swap from ${swapAssetIn} to ${swapAssetOut} under asymptotic invariant.`,
      });
    } catch (err) {
      console.log('Swap canceled', err);
    } finally {
      setSwapping(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-architectural pb-4">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            STRUCTURAL CAPITAL INVARIANTS & RESERVOIRS
          </span>
          <h1 className="font-display text-2xl font-bold text-(--text-display) mt-0.5">
            FINANCIAL ENGINEERING INFRASTRUCTURE
          </h1>
        </div>

        {/* Reservoir Selector Tabs */}
        <div className="flex items-center gap-2 font-machine text-xs overflow-x-auto">
          {reservoirs.map((r) => (
            <button
              key={r.id}
              onClick={() => setSelectedReservoir(r)}
              className={`px-3 py-1.5 border rounded-xs whitespace-nowrap transition-colors ${
                res.id === r.id
                  ? 'border-amber-600 bg-(--bg-secondary) text-(--text-display) font-bold'
                  : 'border-architectural bg-(--bg-card) text-(--text-secondary) hover:text-(--text-primary)'
              }`}
            >
              {r.pair}
            </button>
          ))}
        </div>
      </div>

      {/* Primary Reservoir Hydrostatic Gauge */}
      <ReservoirGauge reservoir={res} />

      {/* Dual Bay: Sovereign Flow Swap Chamber & Structural Collateral Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Atomic Flow Swap Chamber */}
        <div className="lg:col-span-6 border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-4">
          <div className="flex items-center justify-between border-b border-architectural pb-3">
            <div>
              <span className="font-machine text-[10px] text-(--text-muted) uppercase">
                LOW-SLIPPAGE ATOMIC FLOW
              </span>
              <h3 className="font-display text-base font-bold text-(--text-display)">
                EXECUTE SOVEREIGN SWAP
              </h3>
            </div>
            <span className="font-machine text-xs text-emerald-400">
              SLIPPAGE: {res.currentSlippageBps} BPS
            </span>
          </div>

          <form onSubmit={handleSwap} className="space-y-4 font-machine text-xs">
            {/* Input Asset */}
            <div className="p-3.5 border border-architectural bg-(--bg-secondary) rounded-xs space-y-2">
              <div className="flex justify-between text-(--text-muted)">
                <span>INPUT CAPITAL</span>
                <span>BALANCE: 54,200 {swapAssetIn}</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  step="any"
                  value={swapIn}
                  onChange={(e) => setSwapIn(e.target.value)}
                  className="w-full font-mono text-base font-bold bg-transparent text-(--text-display) focus:outline-hidden"
                  placeholder="0.00"
                />
                <select
                  value={swapAssetIn}
                  onChange={(e) => setSwapAssetIn(e.target.value)}
                  className="bg-(--bg-card) border border-architectural px-3 py-1.5 rounded-xs font-bold text-(--text-primary)"
                >
                  <option value="GBP-D">GBP-D</option>
                  <option value="SILICA">SILICA</option>
                  <option value="ETH">ETH</option>
                </select>
              </div>
            </div>

            {/* Swap direction indicator */}
            <div className="flex justify-center -my-2">
              <div className="w-8 h-8 rounded-full border border-architectural bg-(--bg-card) flex items-center justify-center text-amber-500 shadow-xs">
                <ArrowRightLeft className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Output Estimate */}
            <div className="p-3.5 border border-architectural bg-(--bg-secondary) rounded-xs space-y-2">
              <div className="flex justify-between text-(--text-muted)">
                <span>ESTIMATED RECEIPT</span>
                <span>RATE: 1 GBP-D = 0.207 SILICA</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-full font-mono text-base font-bold text-emerald-400">
                  {((parseFloat(swapIn) || 0) * 0.207).toFixed(2)}
                </div>
                <select
                  value={swapAssetOut}
                  onChange={(e) => setSwapAssetOut(e.target.value)}
                  className="bg-(--bg-card) border border-architectural px-3 py-1.5 rounded-xs font-bold text-(--text-primary)"
                >
                  <option value="SILICA">SILICA</option>
                  <option value="GBP-D">GBP-D</option>
                  <option value="GILT-28">GILT-28</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={swapping || (parseFloat(swapIn) || 0) <= 0}
              className="w-full py-3.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-bold text-xs tracking-wider rounded-xs flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>EXECUTE ATOMIC INVARIANT SWAP</span>
            </button>
          </form>
        </div>

        {/* Right: Structural Collateral Matrix */}
        <div className="lg:col-span-6 border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-4">
          <div className="flex items-center justify-between border-b border-architectural pb-3">
            <div>
              <span className="font-machine text-[10px] text-(--text-muted) uppercase">
                MACRO STRUCTURAL HEALTH
              </span>
              <h3 className="font-display text-base font-bold text-(--text-display)">
                COLLATERAL & RISK LOAD MATRIX
              </h3>
            </div>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>

          <div className="space-y-3 font-machine text-xs">
            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs flex justify-between items-center">
              <div>
                <span className="text-(--text-muted) block text-[10px]">TOTAL VALUE SECURED</span>
                <span className="font-display text-sm font-bold text-(--text-display)">
                  £{(res.totalLiquidityGbp / 1000000).toFixed(2)}M Digital Sterling
                </span>
              </div>
              <span className="text-emerald-400 font-semibold">100% COLLATERALISED</span>
            </div>

            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs flex justify-between items-center">
              <div>
                <span className="text-(--text-muted) block text-[10px]">RESERVOIR CIRUCLATION INVARIANT</span>
                <span className="font-display text-sm font-bold text-(--text-display)">
                  k = x^0.5 * y^0.5 (CONSERVED)
                </span>
              </div>
              <span className="text-amber-400 font-semibold">0.00% DRIFT</span>
            </div>

            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs flex justify-between items-center">
              <div>
                <span className="text-(--text-muted) block text-[10px]">CIRCUIT BREAKER STATUS</span>
                <span className="font-display text-sm font-bold text-(--text-display)">
                  MONITORED BY BANK OF ENGLAND QUORUM
                </span>
              </div>
              <span className="text-emerald-400 font-semibold">NOMINAL</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
