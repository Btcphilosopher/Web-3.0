'use client';

import React, { useState } from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { TransactionState } from '@/src/web3/types';
import { formatNumber, formatDateTime } from '@/lib/utils';
import {
  ArrowRightLeft,
  Activity,
  CheckCircle2,
  Clock,
  Zap,
  Search,
  Plus,
  Copy,
  ExternalLink,
  SlidersHorizontal,
} from 'lucide-react';

export function TransactionLedgerView() {
  const { transactions, inspectCausalChain, setNewTxDrawerOpen } = useWeb3();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'SETTLED' | 'PENDING'>('ALL');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const filteredTransactions = transactions.filter((tx) => {
    const matchesSearch =
      tx.hash.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.assetSymbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.destination.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || tx.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const copyHash = (hash: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 1800);
  };

  const stages = ['ORIGIN', 'SIGNED', 'BROADCAST', 'MEMPOOL', 'BLOCK', 'CONFIRMED', 'FINAL'];

  return (
    <div className="space-y-6 pb-12">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-architectural pb-4">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            CHRONOLOGICAL VALUE MOVEMENT
          </span>
          <h1 className="font-display text-2xl font-bold text-(--text-display) mt-0.5">
            DISTRIBUTED TRANSACTION LEDGER
          </h1>
        </div>

        <button
          onClick={() => setNewTxDrawerOpen(true)}
          className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-machine font-bold text-xs rounded-xs flex items-center gap-2 self-start sm:self-auto shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>NEW TRANSACTION</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 border border-architectural bg-(--bg-card) rounded-xs flex flex-wrap items-center justify-between gap-4">
        {/* Search input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-3 text-(--text-muted)" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by hash, destination, or asset symbol..."
            className="w-full pl-9 pr-4 py-2 font-machine text-xs border border-architectural bg-(--bg-secondary) text-(--text-primary) rounded-xs focus:outline-hidden focus:border-amber-500"
          />
        </div>

        {/* Status toggles */}
        <div className="flex items-center gap-1 font-machine text-xs">
          {(['ALL', 'SETTLED', 'PENDING'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 border rounded-xs transition-colors ${
                statusFilter === st
                  ? 'border-amber-600 bg-(--bg-secondary) text-(--text-display) font-bold'
                  : 'border-architectural bg-(--bg-card) text-(--text-secondary) hover:text-(--text-primary)'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Transaction Engineering Table */}
      <div className="border border-architectural bg-(--bg-card) rounded-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left font-machine text-xs">
            <thead className="bg-(--bg-secondary) border-b border-architectural text-[10px] text-(--text-muted) uppercase tracking-wider">
              <tr>
                <th className="p-4">CHRONO / HASH</th>
                <th className="p-4">QUANTITY & ASSET</th>
                <th className="p-4">ORIGIN → DESTINATION</th>
                <th className="p-4">LIFECYCLE STAGE</th>
                <th className="p-4">FEE (GBP)</th>
                <th className="p-4 text-right">CAUSAL TRACE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-(--border-subtle)">
              {filteredTransactions.map((tx) => {
                const stageIndex = stages.indexOf(tx.stage);
                return (
                  <tr
                    key={tx.hash}
                    onClick={() => inspectCausalChain(tx.hash)}
                    className="hover:bg-(--bg-secondary) transition-colors cursor-pointer group"
                  >
                    {/* Hash & Date */}
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-(--text-display) font-mono">
                          {tx.hash.slice(0, 10)}...{tx.hash.slice(-6)}
                        </span>
                        <button
                          onClick={(e) => copyHash(tx.hash, e)}
                          className="opacity-0 group-hover:opacity-100 p-1 hover:text-amber-400 transition-opacity"
                          title="Copy full hash"
                        >
                          {copiedHash === tx.hash ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                      <div className="text-[10px] text-(--text-muted) mt-0.5">
                        {formatDateTime(tx.timestamp)}
                      </div>
                    </td>

                    {/* Value & Asset */}
                    <td className="p-4">
                      <div className="font-display font-bold text-sm text-(--text-display)">
                        {formatNumber(tx.value)} {tx.assetSymbol}
                      </div>
                      <div className="text-[10px] text-(--text-secondary)">{tx.assetName}</div>
                    </td>

                    {/* Origin -> Destination */}
                    <td className="p-4 max-w-xs truncate">
                      <div className="font-mono text-[11px] text-(--text-primary)">
                        {tx.originLabel || `${tx.origin.slice(0, 6)}...`}
                      </div>
                      <div className="text-[10px] text-(--text-muted) font-mono truncate mt-0.5">
                        → {tx.destinationLabel || tx.destination}
                      </div>
                    </td>

                    {/* Lifecycle Stage with physical progress bar */}
                    <td className="p-4">
                      <div className="flex items-center gap-2 mb-1.5">
                        <span
                          className={`px-2 py-0.5 text-[9px] font-bold border rounded-xs ${
                            tx.status === 'SETTLED'
                              ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/60'
                              : 'bg-amber-950/40 text-amber-400 border-amber-800/60'
                          }`}
                        >
                          {tx.stage}
                        </span>
                        <span className="text-[10px] text-(--text-muted)">
                          {tx.confirmations} CONF
                        </span>
                      </div>

                      {/* 7-Segment Lifecycle Micro-Gauge */}
                      <div className="flex items-center gap-1 w-32">
                        {stages.map((st, idx) => (
                          <div
                            key={st}
                            className={`h-1 flex-1 rounded-xs ${
                              idx <= stageIndex ? 'bg-amber-500' : 'bg-slate-800'
                            }`}
                          />
                        ))}
                      </div>
                    </td>

                    {/* Fee */}
                    <td className="p-4 text-(--text-secondary)">
                      <div>£{tx.feeGbp.toFixed(2)}</div>
                      <div className="text-[10px] text-(--text-muted)">{tx.gasPriceGwei} Gwei</div>
                    </td>

                    {/* Causal Action Button */}
                    <td className="p-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          inspectCausalChain(tx.hash);
                        }}
                        className="px-3 py-1.5 border border-architectural hover:border-amber-500 bg-(--bg-card) text-amber-400 hover:text-amber-300 font-bold rounded-xs text-[10px] flex items-center gap-1.5 ml-auto transition-colors"
                      >
                        <Activity className="w-3.5 h-3.5" />
                        <span>TRACE</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t border-architectural bg-(--bg-secondary) flex items-center justify-between text-[11px] font-machine text-(--text-muted)">
          <span>TOTAL SETTLED VOLUME AUDITED: £184,920.48</span>
          <span>ALL TRANSACTIONS IMMUTABLY SEALED ON INFRASTRUCTURE</span>
        </div>
      </div>
    </div>
  );
}
