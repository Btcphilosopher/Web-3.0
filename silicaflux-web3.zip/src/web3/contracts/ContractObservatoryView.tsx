'use client';

import React, { useState } from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { ContractState, SmartContractFunction } from '@/src/web3/types';
import { formatNumber } from '@/lib/utils';
import {
  FileCode2,
  Play,
  CheckCircle2,
  Cpu,
  Layers,
  ShieldCheck,
  Zap,
  Terminal,
  ChevronRight,
  Code2,
  RefreshCw,
} from 'lucide-react';

export function ContractObservatoryView() {
  const { contracts, selectedContract, setSelectedContract, executeContractFunction } = useWeb3();
  const [activeContract, setActiveContract] = useState<ContractState>(selectedContract || contracts[0]);
  const [selectedFunction, setSelectedFunction] = useState<SmartContractFunction>(
    (selectedContract || contracts[0]).functions[0]
  );
  const [inputArgs, setInputArgs] = useState<Record<string, string>>({});
  const [executionResult, setExecutionResult] = useState<string | null>(null);
  const [executing, setExecuting] = useState(false);

  const contract = activeContract || contracts[0];

  const handleExecute = async (e: React.FormEvent) => {
    e.preventDefault();
    setExecuting(true);
    setExecutionResult(null);

    try {
      await executeContractFunction(contract.address, selectedFunction.name, inputArgs);
      setExecutionResult(
        `SUCCESS: Execution verified. Tx hash emitted. Storage state transitioned. Gas units consumed: ${selectedFunction.gasEstimate}`
      );
    } catch (err: any) {
      setExecutionResult(`DECLINED: ${err.message || 'Invocation stopped by user.'}`);
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-architectural pb-4">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            PROGRAMMABLE COMPUTATION MODULES
          </span>
          <h1 className="font-display text-2xl font-bold text-(--text-display) mt-0.5">
            SMART CONTRACT MACHINE OBSERVATORY
          </h1>
        </div>

        {/* Contract Selector Pills */}
        <div className="flex items-center gap-2 font-machine text-xs overflow-x-auto">
          {contracts.map((c) => (
            <button
              key={c.address}
              onClick={() => {
                setActiveContract(c);
                setSelectedContract(c);
                setSelectedFunction(c.functions[0]);
                setInputArgs({});
                setExecutionResult(null);
              }}
              className={`px-3 py-1.5 border rounded-xs whitespace-nowrap transition-colors ${
                contract.address === c.address
                  ? 'border-amber-600 bg-(--bg-secondary) text-(--text-display) font-bold'
                  : 'border-architectural bg-(--bg-card) text-(--text-secondary) hover:text-(--text-primary)'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      {/* Contract Machine Specifications Monolith */}
      <div className="border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-architectural pb-5">
          <div>
            <div className="flex items-center gap-3">
              <span className="font-display text-2xl font-bold text-(--text-display)">
                {contract.name}
              </span>
              <span className="font-machine text-xs px-2 py-0.5 bg-emerald-950/40 text-emerald-400 border border-emerald-800/60 rounded-xs">
                FORMALLY VERIFIED (IR PROVER)
              </span>
            </div>
            <div className="font-machine text-xs text-(--text-secondary) font-mono mt-1">
              ADDRESS: {contract.address}
            </div>
          </div>

          <div className="font-machine text-xs text-right text-(--text-muted)">
            <div>COMPILER: {contract.compiler}</div>
            <div className="text-amber-400 font-semibold mt-0.5">
              BYTECODE: {(contract.bytecodeSizeBytes / 1024).toFixed(1)} KB
            </div>
          </div>
        </div>

        {/* State Variables Table */}
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) uppercase tracking-widest block mb-2 font-semibold">
            PRIMARY STORAGE STATE VARIABLES (SLOT REGISTER)
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-machine text-xs">
            {contract.stateVariables.map((s, i) => (
              <div key={i} className="p-3.5 border border-architectural bg-(--bg-secondary) rounded-xs">
                <span className="text-[10px] text-(--text-muted) block truncate">{s.key}</span>
                <span className="font-bold text-(--text-display) mt-1 block truncate">{s.value}</span>
                <span className="text-[9px] text-(--text-muted) mt-1 block">{s.type}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Machine Functions Grid & Interactive Execution Chamber */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-4 border-t border-architectural">
          {/* Left: Machine Function Modules List (5 cols) */}
          <div className="lg:col-span-5 space-y-2">
            <span className="font-machine text-[10px] text-(--text-muted) uppercase tracking-widest block mb-2 font-semibold">
              AVAILABLE MACHINE MODULES ({contract.functions.length})
            </span>

            {contract.functions.map((fn) => {
              const isSelected = selectedFunction.name === fn.name;
              return (
                <button
                  key={fn.name}
                  onClick={() => {
                    setSelectedFunction(fn);
                    setInputArgs({});
                    setExecutionResult(null);
                  }}
                  className={`w-full p-3.5 border rounded-xs text-left transition-all relative ${
                    isSelected
                      ? 'border-amber-600 bg-(--bg-secondary) shadow-sm'
                      : 'border-architectural bg-(--bg-primary) hover:bg-(--bg-card-hover)'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-machine text-xs font-bold text-(--text-display)">
                      {fn.name}
                    </span>
                    <span className="font-machine text-[9px] px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded-xs">
                      {fn.machineModule}
                    </span>
                  </div>
                  <div className="font-machine text-[10px] text-(--text-muted) font-mono truncate mt-1">
                    {fn.signature}
                  </div>
                  {isSelected && <div className="absolute inset-y-0 left-0 w-1 bg-amber-500" />}
                </button>
              );
            })}
          </div>

          {/* Right: Function Execution Chamber (7 cols) */}
          <div className="lg:col-span-7 border border-architectural bg-(--bg-secondary) p-5 rounded-xs space-y-4">
            <div className="flex items-center justify-between border-b border-architectural pb-3">
              <div>
                <span className="font-machine text-[10px] text-(--text-muted) uppercase">
                  ACTIVE INVOCATION CHAMBER
                </span>
                <h3 className="font-display text-base font-bold text-(--text-display)">
                  {selectedFunction.name}
                </h3>
              </div>
              <span className="font-machine text-xs text-amber-400">
                EST. GAS: {formatNumber(selectedFunction.gasEstimate)}
              </span>
            </div>

            <p className="font-system text-xs text-(--text-secondary) leading-relaxed">
              {selectedFunction.description}
            </p>

            {/* Input Form */}
            <form onSubmit={handleExecute} className="space-y-4">
              {selectedFunction.inputs.length === 0 ? (
                <div className="p-3 border border-architectural bg-(--bg-card) font-machine text-xs text-(--text-muted) rounded-xs">
                  No parameter inputs required. Pure computational query or parameterless execution.
                </div>
              ) : (
                selectedFunction.inputs.map((inp) => (
                  <div key={inp.name} className="space-y-1 font-machine text-xs">
                    <label className="text-(--text-muted) uppercase block text-[10px]">
                      {inp.name} ({inp.type}) — {inp.description}
                    </label>
                    <input
                      type="text"
                      required
                      value={inputArgs[inp.name] || ''}
                      onChange={(e) =>
                        setInputArgs({ ...inputArgs, [inp.name]: e.target.value })
                      }
                      placeholder={`e.g. ${inp.type === 'address' ? '0x3F88...6C18' : '1000'}`}
                      className="w-full p-2.5 font-mono text-xs border border-architectural bg-(--bg-card) text-(--text-primary) rounded-xs focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                ))
              )}

              <button
                type="submit"
                disabled={executing}
                className="w-full py-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-machine font-bold text-xs tracking-wider rounded-xs flex items-center justify-center gap-2 transition-colors shadow-md"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{executing ? 'PROVING STATE TRANSITION...' : 'EXECUTE MACHINE MODULE'}</span>
              </button>
            </form>

            {/* Execution Result Log */}
            {executionResult && (
              <div className="p-3 border border-architectural bg-(--bg-card) font-machine text-xs rounded-xs text-emerald-400 leading-relaxed">
                {executionResult}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
