'use client';

import React from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { formatNumber } from '@/lib/utils';
import {
  ShieldCheck,
  Award,
  Lock,
  Copy,
  CheckCircle2,
  ExternalLink,
  KeyRound,
  Layers,
  Landmark,
} from 'lucide-react';

export function IdentitySovereignView() {
  const { identity, wallet } = useWeb3();

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="border-b border-architectural pb-4">
        <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
          CRYPTOGRAPHIC PROVENANCE & SOVEREIGN STATUS
        </span>
        <h1 className="font-display text-2xl font-bold text-(--text-display) mt-0.5">
          SOVEREIGN IDENTITY & CREDENTIAL VAULT
        </h1>
      </div>

      {/* Sovereign Identity Master Badge */}
      <div className="border border-architectural bg-(--bg-card) p-6 sm:p-8 rounded-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span className="font-machine text-xs px-2 py-0.5 bg-emerald-950/40 text-emerald-300 border border-emerald-800/60 rounded-xs">
                {identity.kycTier.replace('_', ' ')}
              </span>
            </div>

            <h2 className="font-display text-3xl font-bold text-(--text-display)">
              {identity.primaryDomain}
            </h2>

            <div className="font-machine text-xs text-(--text-secondary) font-mono">
              IDENTIFIER: {identity.address}
            </div>
          </div>

          <div className="text-left md:text-right font-machine">
            <span className="text-[10px] text-(--text-muted) uppercase tracking-wider block">
              REPUTATION ATTESTATION SCORE
            </span>
            <div className="font-display text-3xl font-bold text-emerald-400 mt-0.5">
              {identity.reputationScore} / 100
            </div>
            <span className="text-[10px] text-(--text-muted)">
              SOVEREIGN WEIGHT: {formatNumber(identity.governanceWeight)} VOTES
            </span>
          </div>
        </div>
      </div>

      {/* Verified Sovereign Credentials Registry */}
      <div className="border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-4">
        <div className="flex items-center justify-between border-b border-architectural pb-3">
          <div>
            <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
              INSTITUTIONAL ZERO-KNOWLEDGE PROOFS
            </span>
            <h3 className="font-display text-base font-bold text-(--text-display)">
              VERIFIED SOVEREIGN CREDENTIALS ({identity.sovereignCredentials.length})
            </h3>
          </div>
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {identity.sovereignCredentials.map((cred, idx) => (
            <div
              key={idx}
              className="p-4 border border-architectural bg-(--bg-secondary) rounded-xs space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-machine text-(--text-muted) mb-1">
                  <span>ISSUER</span>
                  <span className="text-emerald-400 font-semibold">VERIFIED</span>
                </div>
                <div className="font-display text-xs font-bold text-(--text-display)">
                  {cred.issuer}
                </div>
                <div className="font-system text-xs text-(--text-secondary) mt-2 leading-relaxed">
                  {cred.claim}
                </div>
              </div>

              <div className="pt-3 border-t border-(--border-subtle) font-machine text-[10px] text-(--text-muted) flex justify-between">
                <span>SEALED: {cred.verifiedDate}</span>
                <span>{cred.revocable ? 'DYNAMIC ATTEST' : 'PERMANENT IMMUTABLE'}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Associated Multi-Sig Vaults */}
      <div className="border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-3">
        <div className="flex items-center justify-between font-machine text-xs border-b border-architectural pb-2">
          <span className="font-semibold text-(--text-display)">
            LINKED SOVEREIGN CHAMBERS & CONTRACTS
          </span>
          <span className="text-(--text-muted)">MULTI-VAULT ENCLAVE</span>
        </div>

        <div className="divide-y divide-(--border-subtle) font-machine text-xs">
          {identity.associatedWallets.map((w, i) => (
            <div key={i} className="py-2.5 flex items-center justify-between">
              <span className="font-mono text-(--text-primary)">{w}</span>
              <span className="text-emerald-400 text-[10px]">AUTHORIZED</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
