'use client';

import React, { useState } from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { formatNumber, formatCurrencyGbp } from '@/lib/utils';
import {
  Wallet,
  ShieldCheck,
  KeyRound,
  Lock,
  Copy,
  CheckCircle2,
  ExternalLink,
  Plus,
  Coins,
  ArrowRightLeft,
  ChevronRight,
  Cpu,
  RefreshCw,
} from 'lucide-react';

export function WalletVaultView() {
  const { wallet, assets, transactions, inspectCausalChain, setNewTxDrawerOpen, setCurrentTab } = useWeb3();
  const [copiedAddr, setCopiedAddr] = useState(false);
  const [copiedEnclave, setCopiedEnclave] = useState(false);

  const copyText = (txt: string, isEnclave = false) => {
    navigator.clipboard?.writeText(txt);
    if (isEnclave) {
      setCopiedEnclave(true);
      setTimeout(() => setCopiedEnclave(false), 1800);
    } else {
      setCopiedAddr(true);
      setTimeout(() => setCopiedAddr(false), 1800);
    }
  };

  const totalValueGbp = assets.reduce((sum, a) => sum + a.totalValueGbp, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Vault Master Monolith */}
      <div className="border border-architectural bg-(--bg-card) p-6 sm:p-8 rounded-xs relative">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span className="font-machine text-xs px-2 py-0.5 bg-emerald-950/40 text-emerald-300 border border-emerald-800/60 rounded-xs">
                VAULT STATUS: ENCLAVE ATTESTED & ACTIVE
              </span>
              <span className="font-machine text-xs text-(--text-muted)">
                NONCE #{wallet.nonce}
              </span>
            </div>

            <h1 className="font-display text-3xl sm:text-4xl font-bold text-(--text-display)">
              {wallet.domainName}
            </h1>

            {/* Address Serial Box */}
            <div className="flex flex-wrap items-center gap-2 font-machine text-xs">
              <span className="text-(--text-muted)">VAULT SERIAL:</span>
              <span className="px-3 py-1.5 bg-(--bg-secondary) border border-architectural rounded-xs font-mono text-(--text-primary)">
                {wallet.address}
              </span>
              <button
                onClick={() => copyText(wallet.address)}
                className="p-1.5 border border-architectural hover:border-(--border-accent) bg-(--bg-primary) rounded-xs text-(--text-secondary) hover:text-(--text-primary) transition-colors"
                title="Copy cryptographic serial"
              >
                {copiedAddr ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Balance & Action Column */}
          <div className="text-left md:text-right space-y-3">
            <div>
              <span className="font-machine text-[10px] text-(--text-muted) uppercase tracking-wider block">
                TOTAL CONSOLIDATED TREASURY
              </span>
              <div className="font-display text-3xl sm:text-4xl font-bold text-(--text-display) mt-0.5">
                {formatCurrencyGbp(totalValueGbp)}
              </div>
            </div>

            <div className="flex items-center md:justify-end gap-3 pt-2">
              <button
                onClick={() => setNewTxDrawerOpen(true)}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-machine font-bold text-xs tracking-wider rounded-xs flex items-center gap-2 shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>DISPATCH ASSETS</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Hardware Enclave & Delegated Access Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hardware Security Module Specs */}
        <div className="p-6 border border-architectural bg-(--bg-card) rounded-xs space-y-4">
          <div className="flex items-center justify-between border-b border-architectural pb-3">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-500" />
              <h3 className="font-display text-sm font-bold text-(--text-display)">
                HARDWARE ENCLAVE ATTESTATION
              </h3>
            </div>
            <span className="font-machine text-[10px] text-emerald-400">ISOLATED ENCLAVE</span>
          </div>

          <div className="space-y-3 font-machine text-xs">
            <div className="flex justify-between py-1.5 border-b border-(--border-subtle)">
              <span className="text-(--text-muted)">CHIP SPECIFICATION:</span>
              <span className="text-(--text-primary)">UK-SGX-ENCLAVE-2026-v4</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-(--border-subtle)">
              <span className="text-(--text-muted)">SIGNING ALGORITHM:</span>
              <span className="text-(--text-primary)">SECP256K1 + ED25519</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-(--border-subtle)">
              <span className="text-(--text-muted)">SECURITY COMPLIANCE:</span>
              <span className="text-emerald-400 font-semibold">{wallet.securityScore}/100 (FCA TIER-1)</span>
            </div>
            <div className="flex items-center justify-between py-1.5">
              <span className="text-(--text-muted)">PUBLIC ENCLAVE KEY:</span>
              <button
                onClick={() => copyText(wallet.publicEnclaveKey, true)}
                className="text-[11px] font-mono text-amber-400 hover:underline flex items-center gap-1"
              >
                <span>{wallet.publicEnclaveKey.slice(0, 16)}...</span>
                {copiedEnclave ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
          </div>
        </div>

        {/* Active Delegations & Multi-Sig Permissions */}
        <div className="p-6 border border-architectural bg-(--bg-card) rounded-xs space-y-4">
          <div className="flex items-center justify-between border-b border-architectural pb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h3 className="font-display text-sm font-bold text-(--text-display)">
                ACTIVE CRYPTOGRAPHIC DELEGATIONS
              </h3>
            </div>
            <span className="font-machine text-[10px] text-(--text-muted)">
              {wallet.activeDelegations.length} ACTIVE GRANTS
            </span>
          </div>

          <div className="space-y-3 font-machine text-xs">
            {wallet.activeDelegations.map((del, i) => (
              <div key={i} className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-(--text-display)">{del.scope}</span>
                  <span className="text-[10px] text-amber-400">EXP: {del.expires}</span>
                </div>
                <div className="text-[11px] text-(--text-muted) truncate">{del.delegate}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Asset Chamber Inventory */}
      <div className="border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-4">
        <div className="flex items-center justify-between border-b border-architectural pb-3">
          <div>
            <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
              REGISTERED TOKEN CHAMBERS
            </span>
            <h3 className="font-display text-base font-bold text-(--text-display)">
              TREASURY ASSETS HELD IN VAULT
            </h3>
          </div>
          <button
            onClick={() => setCurrentTab('ASSETS')}
            className="font-machine text-xs text-amber-500 hover:underline flex items-center gap-1"
          >
            <span>FULL ASSET REGISTRY</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {assets.map((asset) => (
            <div
              key={asset.id}
              className="p-4 border border-architectural bg-(--bg-secondary) rounded-xs flex flex-col justify-between space-y-3"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-display text-base font-bold text-(--text-display)">
                    {asset.symbol}
                  </span>
                  <span className="font-machine text-[10px] text-(--text-muted)">
                    {asset.category}
                  </span>
                </div>
                <div className="font-system text-xs text-(--text-secondary) mt-0.5">
                  {asset.name}
                </div>
              </div>

              <div className="pt-2 border-t border-(--border-subtle) font-machine text-xs flex justify-between items-end">
                <div>
                  <span className="text-(--text-muted) text-[10px] block">BALANCE</span>
                  <span className="font-bold text-(--text-primary)">
                    {formatNumber(asset.balance)} {asset.symbol}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-(--text-muted) text-[10px] block">GBP EQUIVALENT</span>
                  <span className="font-bold text-amber-400">
                    {formatCurrencyGbp(asset.totalValueGbp)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
