/**
 * SILICAFLUX WEB3 DATA & STATE ARCHITECTURE
 * Strict typed state representation of the Internet of Value
 */

export type InfrastructureNetworkId = 
  | 'ethereum-mainnet'
  | 'london-l2-rollup'
  | 'silica-sovereign-l1'
  | 'bank-of-england-settlement';

export interface NetworkState {
  id: InfrastructureNetworkId;
  name: string;
  code: string;
  symbol: string;
  type: 'L1_SETTLEMENT' | 'L2_EXECUTION' | 'SOVEREIGN_CONSORTIUM' | 'STATE_CHAMBER';
  status: 'OPTIMAL' | 'CONGESTED' | 'MAINTENANCE' | 'SETTLING';
  blockHeight: number;
  blockTimeMs: number;
  tps: number;
  gasPriceGwei: number;
  finalityTimeSec: number;
  validatorCount: number;
  totalValueLockedGbp: number;
  consensusMechanism: string;
  rpcLatencyMs: number;
  epoch: number;
  quorumsVerified: number;
  colourAccent: string;
}

export interface BlockState {
  height: number;
  hash: string;
  parentHash: string;
  timestamp: number;
  miner: string;
  gasUsed: number;
  gasLimit: number;
  transactionCount: number;
  baseFeeGwei: number;
  stateRoot: string;
  transactionsRoot: string;
  receiptsRoot: string;
  sizeBytes: number;
  difficulty: string;
  networkId: InfrastructureNetworkId;
  transactions?: TransactionState[];
}

export type TransactionLifecycleStage = 
  | 'ORIGIN'
  | 'SIGNED'
  | 'BROADCAST'
  | 'MEMPOOL'
  | 'BLOCK'
  | 'CONFIRMED'
  | 'FINAL';

export interface TransactionState {
  hash: string;
  origin: string;
  originLabel?: string;
  destination: string;
  destinationLabel?: string;
  value: number;
  assetSymbol: string;
  assetName: string;
  networkId: InfrastructureNetworkId;
  gasUsed: number;
  gasPriceGwei: number;
  feeGbp: number;
  timestamp: number;
  blockNumber: number;
  status: 'SETTLED' | 'PENDING' | 'REVERTED' | 'BROADCASTING';
  confirmations: number;
  stage: TransactionLifecycleStage;
  nonce: number;
  methodCalled?: string;
  contractAddress?: string;
  causalTrace?: {
    networkOrigin: string;
    blockWitness: number;
    contractInvoked: string;
    stateDeltas: { account: string; delta: string; asset: string }[];
    gasExecutionStepCount: number;
    cryptographicProof: string;
  };
}

export interface AssetState {
  id: string;
  symbol: string;
  name: string;
  category: 'SOVEREIGN_CURRENCY' | 'SETTLEMENT_GAS' | 'TOKENISED_BULLION' | 'YIELD_BEARING_NOTE' | 'COMPUTE_CREDIT';
  balance: number;
  priceGbp: number;
  change24hPercent: number;
  totalValueGbp: number;
  circulatingSupply: number;
  marketCapGbp: number;
  liquidityDepthGbp: number;
  contractAddress: string;
  networkId: InfrastructureNetworkId;
  precision: number;
  isNative: boolean;
  reserveRatio?: number;
  yieldApy?: number;
  historicalPrices: { timestamp: number; price: number; volume: number }[];
}

export interface SmartContractFunction {
  name: string;
  signature: string;
  stateMutability: 'view' | 'nonpayable' | 'payable' | 'pure';
  inputs: { name: string; type: string; description: string }[];
  outputs: { name: string; type: string }[];
  gasEstimate: number;
  machineModule: 'RESERVOIR_IO' | 'SETTLEMENT' | 'COLLATERAL_ENGINE' | 'AUTHORITY_GATE' | 'MINT_BURN';
  description: string;
}

export interface ContractState {
  address: string;
  name: string;
  standard: 'ERC-20' | 'ERC-4626' | 'SOVEREIGN_VAULT' | 'GOVERNANCE_TIMELOCK' | 'AUTOMATED_MARKET_MAKER';
  networkId: InfrastructureNetworkId;
  compiler: string;
  verified: boolean;
  bytecodeSizeBytes: number;
  deploymentTimestamp: number;
  deployerAddress: string;
  stateVariables: { key: string; value: string; type: string; mutable: boolean }[];
  functions: SmartContractFunction[];
  eventsLoggedCount: number;
  totalCalls24h: number;
  description: string;
}

export interface DeFiReservoirState {
  id: string;
  name: string;
  pair: string;
  baseAsset: string;
  quoteAsset: string;
  totalLiquidityGbp: number;
  volume24hGbp: number;
  feeApr: number;
  utilizationRate: number;
  structuralCollateralGbp: number;
  currentSlippageBps: number;
  riskStressLoad: number; // 0 to 100
  depthCurve: { price: number; depth: number }[];
}

export interface GovernanceProposalState {
  id: string;
  billNumber: string;
  title: string;
  sponsor: string;
  sponsorDomain: string;
  status: 'ACTIVE_DEBATE' | 'VOTING_OPEN' | 'QUORUM_REACHED' | 'ROYAL_ASSENT' | 'ENACTED' | 'REJECTED';
  forVotes: number;
  againstVotes: number;
  abstainVotes: number;
  quorumThreshold: number;
  totalEligibleVotes: number;
  deadlineTimestamp: number;
  executiveSummary: string;
  targetContract: string;
  calldataSnippet: string;
}

export interface WalletState {
  address: string;
  domainName: string;
  vaultType: 'SOVEREIGN_MULTISIG' | 'HARDWARE_ENCLAVE' | 'INSTITUTIONAL_CUSTODY' | 'EPHEMERAL_KEY';
  status: 'CONNECTED' | 'DISCONNECTED' | 'LOCKED' | 'PENDING_APPROVAL';
  nativeBalance: number;
  totalPortfolioValueGbp: number;
  nonce: number;
  activeDelegations: { delegate: string; scope: string; expires: string }[];
  securityScore: number;
  publicEnclaveKey: string;
}

export interface IdentityState {
  address: string;
  primaryDomain: string;
  reputationScore: number;
  sovereignCredentials: {
    issuer: string;
    claim: string;
    verifiedDate: string;
    revocable: boolean;
  }[];
  associatedWallets: string[];
  governanceWeight: number;
  kycTier: 'INSTITUTIONAL_VERIFIED' | 'ACCREDITED_SOVEREIGN' | 'STANDARD_CRYPTOGRAPHIC';
}

export type ViewTab = 
  | 'OBSERVATORY'
  | 'WALLET'
  | 'ASSETS'
  | 'TRANSACTIONS'
  | 'BLOCKCHAIN'
  | 'CONTRACTS'
  | 'DEFI'
  | 'GOVERNANCE'
  | 'IDENTITY';

export type OperatingMode = 'LIVE_SIMULATION' | 'DETERMINISTIC_INSPECT';
export type ThemeMode = 'OBSIDIAN' | 'ARCHIVE';
export type DensityMode = 'CALM' | 'STANDARD' | 'DENSE';
