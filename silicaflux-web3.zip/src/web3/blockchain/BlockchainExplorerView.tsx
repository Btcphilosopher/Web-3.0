'use client';

import React, { useState } from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { BlockState } from '@/src/web3/types';
import { BlockRailway } from '@/src/visualisation/BlockRailway';
import { formatNumber, formatDateTime } from '@/lib/utils';
import {
  Layers,
  CheckCircle2,
  Clock,
  Cpu,
  Hash,
  Copy,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Zap,
} from 'lucide-react';

export function BlockchainExplorerView() {
  const { blocks, selectedBlock, setSelectedBlock, currentNetwork, inspectCausalChain, transactions } = useWeb3();
  const [activeBlock, setActiveBlock] = useState<BlockState>(selectedBlock || blocks[0]);
  const [copiedHash, setCopiedHash] = useState(false);

  const copyText = (txt: string) => {
    navigator.clipboard?.writeText(txt);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 1800);
  };

  const block = activeBlock || blocks[0];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-architectural pb-4">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            DISTRIBUTED CONSENSUS OBSERVATORY
          </span>
          <h1 className="font-display text-2xl font-bold text-(--text-display) mt-0.5">
            BLOCKCHAIN RAILWAY & CHRONICLE
          </h1>
        </div>

        <div className="flex items-center gap-2 font-machine text-xs">
          <span className="text-(--text-muted)">NETWORK:</span>
          <span className="px-2.5 py-1 border border-architectural bg-(--bg-card) font-semibold text-(--text-display) rounded-xs">
            {currentNetwork.name}
          </span>
        </div>
      </div>

      {/* Interactive Blockchain Railway Visualizer */}
      <BlockRailway
        blocks={blocks}
        onSelectBlock={(b) => setActiveBlock(b)}
        selectedBlockHeight={block.height}
      />

      {/* Deep Block Chamber Inspector */}
      <div className="border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-6">
        {/* Block Header Summary */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-architectural pb-5">
          <div>
            <div className="flex items-center gap-3">
              <span className="font-display text-3xl font-bold text-(--text-display)">
                BLOCK #{formatNumber(block.height)}
              </span>
              <span className="font-machine text-xs px-2 py-0.5 bg-emerald-950/40 text-emerald-400 border border-emerald-800/60 rounded-xs">
                PROVED & SEALED
              </span>
            </div>
            <div className="flex items-center gap-2 font-machine text-xs text-(--text-secondary) mt-1">
              <span className="font-mono">HASH: {block.hash}</span>
              <button
                onClick={() => copyText(block.hash)}
                className="hover:text-amber-400 p-0.5"
                title="Copy hash"
              >
                {copiedHash ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div className="font-machine text-xs text-right text-(--text-muted)">
            <div>CHRONOMETER TIME: {formatDateTime(block.timestamp)}</div>
            <div className="text-emerald-400 font-semibold mt-0.5">FINALITY: IMMUTABLE</div>
          </div>
        </div>

        {/* 4-Column Technical Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-machine text-xs">
          <div className="p-3.5 border border-architectural bg-(--bg-secondary) rounded-xs">
            <span className="text-[10px] text-(--text-muted) block uppercase">TRANSACTION COUNT</span>
            <span className="font-display text-base font-bold text-(--text-display) mt-0.5 block">
              {block.transactionCount} TXs
            </span>
          </div>

          <div className="p-3.5 border border-architectural bg-(--bg-secondary) rounded-xs">
            <span className="text-[10px] text-(--text-muted) block uppercase">GAS UTILISATION</span>
            <span className="font-display text-base font-bold text-(--text-display) mt-0.5 block">
              {((block.gasUsed / block.gasLimit) * 100).toFixed(1)}%
            </span>
            <span className="text-[9px] text-(--text-muted)">{(block.gasUsed / 1000000).toFixed(2)}M / 30M</span>
          </div>

          <div className="p-3.5 border border-architectural bg-(--bg-secondary) rounded-xs">
            <span className="text-[10px] text-(--text-muted) block uppercase">BASE FEE</span>
            <span className="font-display text-base font-bold text-amber-400 mt-0.5 block">
              {block.baseFeeGwei} Gwei
            </span>
          </div>

          <div className="p-3.5 border border-architectural bg-(--bg-secondary) rounded-xs">
            <span className="text-[10px] text-(--text-muted) block uppercase">BLOCK SIZE</span>
            <span className="font-display text-base font-bold text-(--text-display) mt-0.5 block">
              {(block.sizeBytes / 1024).toFixed(1)} KB
            </span>
          </div>
        </div>

        {/* Cryptographic Roots Specification Chamber */}
        <div className="border border-architectural bg-(--bg-secondary) p-4 rounded-xs space-y-3 font-machine text-xs">
          <span className="text-[10px] text-(--text-muted) uppercase tracking-widest block font-semibold">
            MERKLE PATRICIA TREE ROOTS & ATTESTATION
          </span>

          <div className="space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between py-1.5 border-b border-(--border-subtle) gap-1">
              <span className="text-(--text-muted)">PARENT BLOCK HASH:</span>
              <span className="font-mono text-(--text-primary) truncate max-w-md">{block.parentHash}</span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between py-1.5 border-b border-(--border-subtle) gap-1">
              <span className="text-(--text-muted)">STATE ROOT:</span>
              <span className="font-mono text-(--text-primary) truncate max-w-md">{block.stateRoot}</span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between py-1.5 border-b border-(--border-subtle) gap-1">
              <span className="text-(--text-muted)">TRANSACTIONS ROOT:</span>
              <span className="font-mono text-(--text-primary) truncate max-w-md">{block.transactionsRoot}</span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between py-1.5 gap-1">
              <span className="text-(--text-muted)">RECEIPTS ROOT:</span>
              <span className="font-mono text-(--text-primary) truncate max-w-md">{block.receiptsRoot}</span>
            </div>
          </div>
        </div>

        {/* Transactions in this Block */}
        <div className="border border-architectural bg-(--bg-card) p-4 rounded-xs space-y-3">
          <div className="flex items-center justify-between font-machine text-xs border-b border-architectural pb-2">
            <span className="font-bold text-(--text-display)">
              WITNESSED TRANSACTIONS IN BLOCK #{formatNumber(block.height)}
            </span>
            <span className="text-(--text-muted)">ORDERED BY GAS BID</span>
          </div>

          <div className="divide-y divide-(--border-subtle) font-machine text-xs">
            {transactions.slice(0, 3).map((tx) => (
              <div
                key={tx.hash}
                onClick={() => inspectCausalChain(tx.hash)}
                className="py-3 px-2 hover:bg-(--bg-secondary) rounded-xs cursor-pointer flex items-center justify-between transition-colors"
              >
                <div>
                  <div className="font-bold text-(--text-primary)">
                    {formatNumber(tx.value)} {tx.assetSymbol}
                  </div>
                  <div className="text-[11px] text-(--text-muted) font-mono truncate">
                    HASH: {tx.hash.slice(0, 16)}...
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-[10px] px-2 py-0.5 bg-emerald-950/40 text-emerald-400 border border-emerald-800/60 rounded-xs">
                    FINAL
                  </span>
                  <button className="px-2 py-1 text-[10px] border border-architectural hover:border-amber-500 text-amber-400 rounded-xs">
                    TRACE
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
