'use client';

import React, { useState } from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { AssetState } from '@/src/web3/types';
import { ScientificChart } from '@/src/visualisation/ScientificChart';
import { formatNumber, formatCurrencyGbp, formatTime } from '@/lib/utils';
import {
  Coins,
  ArrowRight,
  ShieldCheck,
  TrendingUp,
  Activity,
  Layers,
  FileCode2,
  Send,
  RefreshCw,
  ExternalLink,
  ChevronLeft,
} from 'lucide-react';

export function AssetRegistryView() {
  const {
    assets,
    selectedAsset,
    setSelectedAsset,
    currentNetwork,
    setNewTxDrawerOpen,
    inspectCausalChain,
    transactions,
  } = useWeb3();

  const [activeAssetView, setActiveAssetView] = useState<AssetState | null>(selectedAsset || assets[0]);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  const filteredAssets = filterCategory === 'ALL'
    ? assets
    : assets.filter((a) => a.category === filterCategory);

  const asset = activeAssetView || assets[0];

  return (
    <div className="space-y-6 pb-12">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-architectural pb-4">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            SOVEREIGN CRYPTOGRAPHIC ASSET CHAMBER
          </span>
          <h1 className="font-display text-2xl font-bold text-(--text-display) mt-0.5">
            PROGRAMMATIC ASSET REGISTER
          </h1>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1 font-machine text-xs overflow-x-auto">
          {['ALL', 'SETTLEMENT_GAS', 'SOVEREIGN_CURRENCY', 'TOKENISED_BULLION', 'YIELD_BEARING_NOTE'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1 border rounded-xs whitespace-nowrap transition-colors ${
                filterCategory === cat
                  ? 'border-amber-600 bg-(--bg-secondary) text-(--text-display) font-bold'
                  : 'border-architectural bg-(--bg-card) text-(--text-secondary) hover:text-(--text-primary)'
              }`}
            >
              {cat.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Main Layout: Registry on Left, Deep Asset Chamber on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Registry Table (40%) */}
        <div className="lg:col-span-5 border border-architectural bg-(--bg-card) p-4 rounded-xs space-y-3">
          <div className="flex items-center justify-between border-b border-architectural pb-3">
            <span className="font-machine text-xs font-semibold text-(--text-display)">
              ASSET OBJECT REGISTER ({filteredAssets.length})
            </span>
            <span className="font-machine text-[10px] text-(--text-muted)">ORDER BY VALUE</span>
          </div>

          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {filteredAssets.map((item) => {
              const isSelected = asset.id === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveAssetView(item);
                    setSelectedAsset(item);
                  }}
                  className={`w-full p-4 border rounded-xs text-left transition-all relative ${
                    isSelected
                      ? 'border-amber-600 bg-(--bg-secondary) shadow-sm'
                      : 'border-architectural bg-(--bg-primary) hover:bg-(--bg-card-hover)'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-display text-base font-bold text-(--text-display)">
                          {item.symbol}
                        </span>
                        <span className="font-machine text-[10px] px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded-xs">
                          {item.category.split('_')[0]}
                        </span>
                      </div>
                      <div className="font-system text-xs text-(--text-secondary) mt-0.5 truncate max-w-[180px]">
                        {item.name}
                      </div>
                    </div>

                    <div className="text-right font-machine">
                      <div className="text-sm font-bold text-(--text-primary)">
                        {formatCurrencyGbp(item.priceGbp, 2, item.priceGbp < 10 ? 4 : 2)}
                      </div>
                      <div
                        className={`text-[11px] font-semibold ${
                          item.change24hPercent >= 0 ? 'text-emerald-400' : 'text-amber-500'
                        }`}
                      >
                        {item.change24hPercent >= 0 ? '+' : ''}
                        {item.change24hPercent}%
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-3 mt-3 border-t border-(--border-subtle) font-machine text-[11px]">
                    <div>
                      <span className="text-(--text-muted) block text-[9px]">VAULT HOLDINGS</span>
                      <span className="font-semibold text-(--text-primary)">
                        {formatNumber(item.balance)} {item.symbol}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-(--text-muted) block text-[9px]">TOTAL VALUE</span>
                      <span className="font-semibold text-amber-400">
                        {formatCurrencyGbp(item.totalValueGbp)}
                      </span>
                    </div>
                  </div>

                  {isSelected && <div className="absolute inset-y-0 left-0 w-1 bg-amber-500" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Asset Chamber Hero (60%) */}
        <div className="lg:col-span-7 border border-architectural bg-(--bg-card) p-6 rounded-xs space-y-6">
          {/* Asset Hero Header */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-architectural pb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display text-3xl font-bold text-(--text-display)">
                  {asset.name}
                </span>
                <span className="font-machine text-sm text-amber-400 font-bold px-2 py-0.5 bg-amber-950/40 border border-amber-800/60 rounded-xs">
                  {asset.symbol}
                </span>
              </div>
              <div className="font-machine text-xs text-(--text-secondary) mt-1 font-mono">
                CONTRACT: {asset.contractAddress}
              </div>
            </div>

            <button
              onClick={() => setNewTxDrawerOpen(true)}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-machine font-bold text-xs rounded-xs flex items-center gap-2 transition-colors self-start shadow-sm"
            >
              <Send className="w-3.5 h-3.5" />
              <span>DISPATCH {asset.symbol}</span>
            </button>
          </div>

          {/* Scientific Chart Trajectory */}
          <ScientificChart
            data={asset.historicalPrices}
            title={`${asset.symbol} / GBP PROGRAMMATIC VALUATION`}
            symbol="GBP"
            height={220}
            color="#C98A2C"
          />

          {/* Scientific Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-machine text-xs">
            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
              <span className="text-[10px] text-(--text-muted) block">MARKET CAPITALISATION</span>
              <span className="font-display text-sm font-bold text-(--text-display) mt-0.5 block">
                £{(asset.marketCapGbp / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
              <span className="text-[10px] text-(--text-muted) block">LIQUIDITY DEPTH</span>
              <span className="font-display text-sm font-bold text-(--text-display) mt-0.5 block">
                £{(asset.liquidityDepthGbp / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
              <span className="text-[10px] text-(--text-muted) block">CIRCULATING SUPPLY</span>
              <span className="font-display text-sm font-bold text-(--text-display) mt-0.5 block">
                {(asset.circulatingSupply / 1000000).toFixed(1)}M
              </span>
            </div>

            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
              <span className="text-[10px] text-(--text-muted) block">NATIVE ON NETWORK</span>
              <span className="font-display text-sm font-bold text-emerald-400 mt-0.5 block truncate">
                {asset.networkId.split('-')[0].toUpperCase()}
              </span>
            </div>
          </div>

          {/* Associated Transactions for this Asset */}
          <div className="border border-architectural bg-(--bg-secondary) p-4 rounded-xs space-y-3">
            <div className="flex items-center justify-between font-machine text-xs border-b border-architectural pb-2">
              <span className="font-semibold text-(--text-display)">
                RECENT MOVEMENTS FOR {asset.symbol}
              </span>
              <span className="text-(--text-muted)">AUDIT TRAIL</span>
            </div>

            <div className="divide-y divide-(--border-subtle) font-machine text-xs">
              {transactions
                .filter((t) => t.assetSymbol === asset.symbol)
                .slice(0, 3)
                .map((tx) => (
                  <div
                    key={tx.hash}
                    onClick={() => inspectCausalChain(tx.hash)}
                    className="py-2.5 flex items-center justify-between hover:bg-(--bg-card) px-2 rounded-xs cursor-pointer transition-colors"
                  >
                    <div>
                      <div className="font-bold text-(--text-primary)">
                        {formatNumber(tx.value)} {tx.assetSymbol}
                      </div>
                      <div className="text-[10px] text-(--text-muted) font-mono">
                        {tx.hash.slice(0, 16)}...
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-emerald-400 text-[10px] font-semibold">{tx.stage}</span>
                      <div className="text-[10px] text-(--text-muted)">
                        {formatTime(tx.timestamp)}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
