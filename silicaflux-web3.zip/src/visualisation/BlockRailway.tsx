'use client';

import React from 'react';
import { motion } from 'motion/react';
import { BlockState } from '@/src/web3/types';
import { formatNumber, formatTime } from '@/lib/utils';

interface BlockRailwayProps {
  blocks: BlockState[];
  onSelectBlock: (block: BlockState) => void;
  selectedBlockHeight?: number;
}

export function BlockRailway({ blocks, onSelectBlock, selectedBlockHeight }: BlockRailwayProps) {
  return (
    <div className="border border-architectural bg-(--bg-card) p-4 rounded-xs">
      <div className="flex items-center justify-between border-b border-architectural pb-3 mb-4">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            BLOCKCHAIN RAILWAY SIGNAL TRACK & CHRONICLE
          </span>
          <h3 className="font-display text-sm font-bold text-(--text-display) mt-0.5">
            CHRONOMETRIC BLOCK SEQUENCE
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="font-machine text-xs text-emerald-400 font-medium">REAL-TIME TELEMETRY</span>
        </div>
      </div>

      {/* Railway Horizontal Track */}
      <div className="relative overflow-x-auto pb-3 pt-2">
        {/* Railway line graphic */}
        <div className="absolute top-10 left-0 right-0 h-0.5 bg-(--border-primary) z-0" />

        <div className="flex items-center gap-4 min-w-max relative z-10 px-2">
          {blocks.slice(0, 10).map((block, idx) => {
            const isSelected = selectedBlockHeight === block.height;
            return (
              <motion.button
                key={block.height}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                onClick={() => onSelectBlock(block)}
                className={`p-3.5 w-60 border rounded-xs text-left transition-all relative ${
                  isSelected
                    ? 'border-amber-600/80 bg-(--bg-secondary) shadow-md'
                    : 'border-architectural bg-(--bg-primary) hover:bg-(--bg-card-hover)'
                }`}
              >
                {/* Track Node Pin */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full border ${idx === 0 ? 'bg-emerald-400 border-emerald-300 animate-pulse' : 'bg-slate-700 border-slate-600'}`} />
                    <span className="font-machine text-xs font-bold text-(--text-display)">
                      #{formatNumber(block.height)}
                    </span>
                  </div>
                  <span className="font-machine text-[10px] text-(--text-muted)">
                    {formatTime(block.timestamp)}
                  </span>
                </div>

                <div className="font-machine text-[11px] text-(--text-secondary) truncate mb-1">
                  HASH: {block.hash.slice(0, 10)}...{block.hash.slice(-6)}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-(--border-subtle) font-machine text-[10px]">
                  <div>
                    <span className="text-(--text-muted) block">TX COUNT</span>
                    <span className="text-(--text-primary) font-semibold">{block.transactionCount} TXs</span>
                  </div>
                  <div>
                    <span className="text-(--text-muted) block">BASE FEE</span>
                    <span className="text-amber-500 font-semibold">{block.baseFeeGwei} Gwei</span>
                  </div>
                </div>

                {isSelected && (
                  <div className="absolute inset-x-0 bottom-0 h-0.5 bg-amber-500" />
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
