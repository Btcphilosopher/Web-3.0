'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { TransactionState } from '@/src/web3/types';
import { formatNumber, formatTime } from '@/lib/utils';
import {
  Network,
  ShieldCheck,
  Zap,
  Layers,
  FileCode2,
  CheckCircle2,
  Copy,
  X,
} from 'lucide-react';

interface CausalChainVisualizerProps {
  transaction: TransactionState | null;
  onClose?: () => void;
}

export function CausalChainVisualizer({ transaction, onClose }: CausalChainVisualizerProps) {
  const [activeStep, setActiveStep] = useState<number>(2); // Default on transaction
  const [copiedHash, setCopiedHash] = useState(false);

  if (!transaction) return null;

  const copyToClipboard = (text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 1800);
  };

  const steps = [
    {
      id: 0,
      title: 'NETWORK INFRASTRUCTURE',
      code: 'NET_LAYER_0',
      icon: Network,
      primary: transaction.causalTrace?.networkOrigin || 'Silica Sovereign Settlement L1',
      secondary: 'Consensus: Asynchronous BFT with SGX Enclave Attestation',
      metric: 'Latency: 4.2ms | Epoch #456177',
      details: {
        'Consensus Protocol': 'Silica aBFT / Casper FFG Hybrid',
        'State Root': '0x71e98a12b94098214c7701ab44990184b2384a9108c90184a82194c20981249b',
        'Validator Quorum': '256 Institutional Nodes (Bank of England / FCA Sandbox / DMO)',
        'Finality Status': 'Deterministic Finality Sealed',
      },
    },
    {
      id: 1,
      title: 'BLOCK WITNESS CHRONICLE',
      code: 'BLOCK_LAYER_1',
      icon: Layers,
      primary: `Block #${formatNumber(transaction.blockNumber)}`,
      secondary: `Slot Timestamp: ${formatTime(transaction.timestamp)}`,
      metric: `Gas Consumed: ${formatNumber(transaction.gasUsed)} units`,
      details: {
        'Parent Block Hash': '0x55d019847120948a9018247192048912a8490182490182a9449018491209481a',
        'Merkle Receipts Root': '0x449018491209481a890214b77192048a9018247192048912a8490182490182a9',
        'Gas Limit': '30,000,000 units',
        'Base Fee': `${transaction.gasPriceGwei} Gwei`,
      },
    },
    {
      id: 2,
      title: 'TRANSACTION SIGNATURE & MEMPOOL',
      code: 'TX_RECORD_2',
      icon: Zap,
      primary: `${formatNumber(transaction.value)} ${transaction.assetSymbol}`,
      secondary: `Nonce: ${transaction.nonce} | Stage: ${transaction.stage}`,
      metric: `Fee: £${transaction.feeGbp.toFixed(2)} | Status: ${transaction.status}`,
      details: {
        'Origin Account': transaction.origin,
        'Destination Chamber': transaction.destination,
        'Cryptographic Signature': 'ECDSA_SECP256K1_r_s_v (Hardware Enclave Certified)',
        'ZK Validity Proof': transaction.causalTrace?.cryptographicProof || 'ZK_STARK_SETTLEMENT_VERIFIED_#0918',
      },
    },
    {
      id: 3,
      title: 'SMART CONTRACT MACHINE MODULE',
      code: 'VM_EXECUTION_3',
      icon: FileCode2,
      primary: transaction.causalTrace?.contractInvoked || 'Direct Sovereign Transfer',
      secondary: transaction.methodCalled || 'directTransfer(address,uint256)',
      metric: `EVM Steps: ${transaction.causalTrace?.gasExecutionStepCount || 94} Opcodes Executed`,
      details: {
        'Target Address': transaction.contractAddress || transaction.destination,
        'ABI Invocation': transaction.methodCalled || 'directTransfer(address,uint256)',
        'Storage Slot Diffs': 'SSTORE (Slot 0x04 -> Delta Balanced)',
        'Reentrancy Guard': 'Locked & Cleared (0x01)',
      },
    },
    {
      id: 4,
      title: 'ASSET LEDGER STATE DELTA',
      code: 'LEDGER_SETTLEMENT_4',
      icon: ShieldCheck,
      primary: `Net Impact: ${formatNumber(transaction.value)} ${transaction.assetSymbol}`,
      secondary: 'State Tree Transition Verified across all Distributed Nodes',
      metric: `${transaction.confirmations} Quorum Confirmations`,
      details: {
        'Source Balance Delta': transaction.causalTrace?.stateDeltas?.[0]?.delta || `-${transaction.value} ${transaction.assetSymbol}`,
        'Destination Delta': transaction.causalTrace?.stateDeltas?.[1]?.delta || `+${transaction.value} ${transaction.assetSymbol}`,
        'Conservation Law': 'Total Circulating Reserve Conserved (Invariance Checked)',
        'Sovereign Seal': 'UK-DMO Sovereign Ledger Interlock Active',
      },
    },
  ];

  return (
    <div className="flex flex-col h-full bg-(--bg-primary) text-(--text-primary)">
      {/* Header */}
      <div className="p-6 border-b border-architectural flex items-center justify-between bg-(--bg-secondary)">
        <div>
          <div className="flex items-center gap-3">
            <span className="font-machine text-xs px-2 py-0.5 bg-amber-900/30 text-amber-300 border border-amber-800/60 rounded-xs">
              CAUSAL OBSERVER V4.2
            </span>
            <span className="font-machine text-xs text-(--text-muted)">
              HASH: {transaction.hash.slice(0, 16)}...{transaction.hash.slice(-8)}
            </span>
          </div>
          <h2 className="font-display text-2xl font-bold mt-1 text-(--text-display) tracking-wide">
            TRANSACTION CAUSAL GRAPH ARCHITECTURE
          </h2>
          <p className="text-xs text-(--text-secondary) mt-0.5 font-system">
            Full physical and computational propagation path: Network → Block Witness → Cryptographic Execution → Contract Machine → Asset Ledger.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => copyToClipboard(transaction.hash)}
            className="flex items-center gap-2 px-3 py-1.5 text-xs font-machine border border-architectural hover:border-(--border-accent) bg-(--bg-primary) rounded-xs transition-colors"
          >
            {copiedHash ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedHash ? 'HASH COPIED' : 'COPY HASH'}
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 border border-architectural hover:border-(--border-accent) text-(--text-secondary) hover:text-(--text-primary) rounded-xs transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Horizontal Pipeline Steps */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            const isSelected = activeStep === idx;
            return (
              <button
                key={step.id}
                onClick={() => setActiveStep(idx)}
                className={`text-left p-4 rounded-xs border transition-all relative ${
                  isSelected
                    ? 'border-amber-600/80 bg-(--bg-secondary) shadow-sm'
                    : 'border-architectural bg-(--bg-card) hover:bg-(--bg-card-hover)'
                }`}
              >
                {/* Step indicator */}
                <div className="flex items-center justify-between mb-2">
                  <span className="font-machine text-[10px] text-(--text-muted) tracking-wider">
                    {step.code}
                  </span>
                  <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-amber-400 animate-pulse' : 'bg-(--text-muted)'}`} />
                </div>

                <div className="flex items-center gap-2 mb-2">
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-400' : 'text-(--text-secondary)'}`} />
                  <span className="font-machine text-xs font-semibold text-(--text-display) truncate">
                    {step.title.split(' ')[0]}
                  </span>
                </div>

                <div className="font-system text-xs font-medium text-(--text-primary) truncate">
                  {step.primary}
                </div>

                <div className="font-machine text-[11px] text-(--text-secondary) mt-1 truncate">
                  {step.metric}
                </div>

                {isSelected && (
                  <motion.div
                    layoutId="activeStepBorder"
                    className="absolute inset-x-0 bottom-0 h-0.5 bg-amber-500"
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Deep Inspector Chamber */}
        <div className="border border-architectural bg-(--bg-secondary) p-6 rounded-xs relative">
          <div className="flex items-center justify-between border-b border-architectural pb-4 mb-4">
            <div className="flex items-center gap-3">
              <span className="font-machine text-xs px-2 py-0.5 bg-slate-800/50 text-slate-300 border border-slate-700/60 rounded-xs">
                MODULE 0{activeStep + 1} OF 05
              </span>
              <h3 className="font-display text-lg font-bold text-(--text-display) tracking-wide">
                {steps[activeStep].title}
              </h3>
            </div>
            <div className="flex items-center gap-2 font-machine text-xs text-(--text-muted)">
              <span>STAGE: VERIFIED & CONFIRMED</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Primary Details */}
            <div className="space-y-4">
              <div className="p-4 border border-architectural bg-(--bg-card) rounded-xs">
                <span className="font-machine text-[10px] text-(--text-muted) uppercase tracking-widest block mb-1">
                  CORE OBJECT IDENTIFIER
                </span>
                <div className="font-display text-xl font-bold text-(--text-display)">
                  {steps[activeStep].primary}
                </div>
                <div className="font-system text-xs text-(--text-secondary) mt-1">
                  {steps[activeStep].secondary}
                </div>
              </div>

              <div className="p-4 border border-architectural bg-(--bg-card) rounded-xs space-y-2">
                <span className="font-machine text-[10px] text-(--text-muted) uppercase tracking-widest block">
                  PHYSICAL & HARDWARE TELEMETRY
                </span>
                <div className="font-machine text-xs text-amber-400/90">
                  {steps[activeStep].metric}
                </div>
                <div className="font-machine text-[11px] text-(--text-secondary) leading-relaxed">
                  Cryptographic attestation signed by secure hardware enclave with constant-time execution proof.
                </div>
              </div>
            </div>

            {/* Architectural Key-Value Specifications */}
            <div className="border border-architectural bg-(--bg-card) p-4 rounded-xs">
              <span className="font-machine text-[10px] text-(--text-muted) uppercase tracking-widest block mb-3">
                FORMAL MACHINE SPECIFICATIONS
              </span>
              <div className="space-y-3 font-machine text-xs">
                {Object.entries(steps[activeStep].details).map(([key, val]) => (
                  <div key={key} className="flex flex-col sm:flex-row sm:items-center justify-between py-1.5 border-b border-(--border-subtle) gap-1">
                    <span className="text-(--text-muted) font-medium">{key}</span>
                    <span className="text-(--text-primary) font-mono truncate max-w-xs">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Causal State Diff Bar */}
          {transaction.causalTrace?.stateDeltas && transaction.causalTrace.stateDeltas.length > 0 && (
            <div className="mt-6 p-4 border border-architectural bg-(--bg-card) rounded-xs">
              <div className="flex items-center justify-between mb-3">
                <span className="font-machine text-xs font-semibold text-(--text-display)">
                  ATOMIC STATE DELTA LEDGER
                </span>
                <span className="font-machine text-[11px] text-emerald-400">
                  Zero-Knowledge Proof Verified
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {transaction.causalTrace.stateDeltas.map((delta, i) => (
                  <div key={i} className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
                    <div className="font-machine text-[10px] text-(--text-muted) truncate">{delta.account}</div>
                    <div className={`font-machine text-sm font-bold mt-1 ${delta.delta.startsWith('+') ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {delta.delta}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
