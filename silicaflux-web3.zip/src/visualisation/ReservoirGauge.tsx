'use client';

import React from 'react';
import { DeFiReservoirState } from '@/src/web3/types';
import { ShieldCheck, Activity, AlertTriangle, Droplets } from 'lucide-react';

interface ReservoirGaugeProps {
  reservoir: DeFiReservoirState;
}

export function ReservoirGauge({ reservoir }: ReservoirGaugeProps) {
  const isHealthy = reservoir.riskStressLoad < 50;

  return (
    <div className="border border-architectural bg-(--bg-card) p-5 rounded-xs space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-architectural pb-3">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            HYDROSTATIC LIQUIDITY RESERVOIR CHAMBER
          </span>
          <h3 className="font-display text-lg font-bold text-(--text-display) mt-0.5">
            {reservoir.name}
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <span
            className={`font-machine text-xs px-2 py-0.5 border rounded-xs ${
              isHealthy
                ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/60'
                : 'bg-amber-950/40 text-amber-400 border-amber-800/60'
            }`}
          >
            {isHealthy ? 'STRUCTURAL LOAD: NOMINAL' : 'ELEVATED STRESS COEFFICIENT'}
          </span>
        </div>
      </div>

      {/* Main Reservoir Visualizer */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Hydrostatic Column */}
        <div className="md:col-span-4 p-4 border border-architectural bg-(--bg-secondary) rounded-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between font-machine text-xs text-(--text-muted) mb-2">
              <span>CAPITAL DEPTH FILL</span>
              <span>{reservoir.utilizationRate}% UTILISATION</span>
            </div>

            {/* Reservoir Column Graphic */}
            <div className="h-44 w-full border border-architectural bg-(--bg-primary) rounded-xs relative overflow-hidden flex flex-col justify-end p-1">
              {/* Reference Grid lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none p-2 opacity-30">
                <div className="border-b border-dashed border-(--text-muted) text-[8px] font-machine text-(--text-muted)">100% MAXIMUM CAPACITY</div>
                <div className="border-b border-dashed border-(--text-muted) text-[8px] font-machine text-(--text-muted)">75% HIGH LIQUIDITY THRESHOLD</div>
                <div className="border-b border-dashed border-(--text-muted) text-[8px] font-machine text-(--text-muted)">50% EQUILIBRIUM DATUM</div>
                <div className="border-b border-dashed border-(--text-muted) text-[8px] font-machine text-(--text-muted)">25% STRUCTURAL DRAIN WARNING</div>
              </div>

              {/* Fluid fill */}
              <div
                style={{ height: `${reservoir.utilizationRate}%` }}
                className="w-full bg-linear-to-t from-slate-800 to-amber-700/60 border-t-2 border-amber-400/80 transition-all duration-700 rounded-xs relative z-10"
              >
                <div className="absolute top-1 right-2 font-machine text-[10px] text-amber-200 font-bold">
                  £{(reservoir.totalLiquidityGbp / 1000000).toFixed(1)}M
                </div>
              </div>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-(--border-subtle) font-machine text-xs flex justify-between">
            <span className="text-(--text-muted)">24H VOLUME FLOW</span>
            <span className="text-(--text-primary) font-bold">
              £{(reservoir.volume24hGbp / 1000000).toFixed(2)}M
            </span>
          </div>
        </div>

        {/* Structural Load & Stress Telemetry */}
        <div className="md:col-span-8 space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-machine">
            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
              <span className="text-[10px] text-(--text-muted) block">ANNUAL YIELD NOTE</span>
              <span className="font-display text-lg font-bold text-emerald-400 mt-1 block">
                {reservoir.feeApr}%
              </span>
              <span className="text-[9px] text-(--text-muted)">Programmatic Fee APR</span>
            </div>

            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
              <span className="text-[10px] text-(--text-muted) block">SLIPPAGE DAMPING</span>
              <span className="font-display text-lg font-bold text-(--text-display) mt-1 block">
                {reservoir.currentSlippageBps} bps
              </span>
              <span className="text-[9px] text-(--text-muted)">Asymptotic Invariant</span>
            </div>

            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
              <span className="text-[10px] text-(--text-muted) block">COLLATERAL BUFFER</span>
              <span className="font-display text-lg font-bold text-amber-400 mt-1 block">
                £{(reservoir.structuralCollateralGbp / 1000000).toFixed(0)}M
              </span>
              <span className="text-[9px] text-(--text-muted)">HM Treasury Backed</span>
            </div>

            <div className="p-3 border border-architectural bg-(--bg-secondary) rounded-xs">
              <span className="text-[10px] text-(--text-muted) block">STRESS COEFFICIENT</span>
              <span className={`font-display text-lg font-bold mt-1 block ${isHealthy ? 'text-emerald-400' : 'text-amber-500'}`}>
                {reservoir.riskStressLoad}%
              </span>
              <span className="text-[9px] text-(--text-muted)">Load Limit: 80%</span>
            </div>
          </div>

          {/* Depth Spectrum Bars */}
          <div className="p-4 border border-architectural bg-(--bg-secondary) rounded-xs">
            <div className="flex items-center justify-between font-machine text-xs text-(--text-muted) mb-2">
              <span>RESERVOIR DEPTH DENSITY BY PRICE TICK</span>
              <span>INVARIANT: CONSERVED</span>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {reservoir.depthCurve.map((tick, i) => (
                <div key={i} className="text-center font-machine">
                  <div className="h-16 bg-(--bg-primary) border border-architectural rounded-xs flex flex-col justify-end p-1 mb-1">
                    <div
                      style={{ height: `${(tick.depth / 25000000) * 100}%` }}
                      className="bg-amber-600/70 border-t border-amber-400 rounded-xs w-full transition-all"
                    />
                  </div>
                  <div className="text-[10px] text-(--text-primary) font-semibold">£{tick.price}</div>
                  <div className="text-[9px] text-(--text-muted)">£{(tick.depth / 1000000).toFixed(1)}M</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
