'use client';

import React, { useState } from 'react';
import { formatDate, formatShortTime, formatCurrencyGbp } from '@/lib/utils';

interface DataPoint {
  timestamp: number;
  price: number;
  volume?: number;
}

interface ScientificChartProps {
  data: DataPoint[];
  title?: string;
  symbol?: string;
  height?: number;
  color?: string;
  showVolume?: boolean;
}

export function ScientificChart({
  data,
  title = 'CHRONOMETRIC PRICE & SETTLEMENT TRAJECTORY',
  symbol = 'GBP',
  height = 240,
  color = '#C98A2C',
  showVolume = true,
}: ScientificChartProps) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div
        style={{ height }}
        className="flex items-center justify-center border border-architectural bg-(--bg-card) text-xs font-machine text-(--text-muted)"
      >
        TELEMETRY_AWAITING_CHRONOMETER_FEED
      </div>
    );
  }

  const padding = { top: 20, right: 30, bottom: 35, left: 60 };
  const width = 680; // normalized coordinate space

  const prices = data.map((d) => d.price);
  const volumes = data.map((d) => d.volume || 0);

  const minPrice = Math.min(...prices) * 0.995;
  const maxPrice = Math.max(...prices) * 1.005;
  const maxVol = Math.max(...volumes, 1);

  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const getX = (index: number) => padding.left + (index / (data.length - 1)) * chartWidth;
  const getY = (price: number) =>
    padding.top + chartHeight - ((price - minPrice) / (maxPrice - minPrice || 1)) * chartHeight;

  // Path generation
  const points = data.map((d, i) => `${getX(i)},${getY(d.price)}`);
  const pathD = `M ${points.join(' L ')}`;
  const areaD = `${pathD} L ${getX(data.length - 1)},${padding.top + chartHeight} L ${getX(0)},${padding.top + chartHeight} Z`;

  const activePoint = hoverIndex !== null ? data[hoverIndex] : data[data.length - 1];

  return (
    <div className="border border-architectural bg-(--bg-card) p-4 rounded-xs relative">
      {/* Chart Meta Bar */}
      <div className="flex items-center justify-between border-b border-architectural pb-3 mb-3">
        <div>
          <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
            {title}
          </span>
          <div className="flex items-baseline gap-2 mt-0.5">
            <span className="font-display text-xl font-bold text-(--text-display)">
              {formatCurrencyGbp(activePoint.price, 2, 4)}
            </span>
            <span className="font-machine text-xs text-(--text-secondary)">{symbol}</span>
          </div>
        </div>

        <div className="text-right font-machine text-[11px] text-(--text-secondary)">
          <div suppressHydrationWarning>DATUM: {formatDate(activePoint.timestamp)}</div>
          <div className="text-emerald-500 font-medium">PRECISION: HIGH_RES (12-TICK)</div>
        </div>
      </div>

      {/* SVG Canvas */}
      <div className="relative w-full overflow-hidden" style={{ height }}>
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full cursor-crosshair"
          onMouseLeave={() => setHoverIndex(null)}
        >
          <defs>
            <linearGradient id={`grad-${symbol}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={color} stopOpacity="0.25" />
              <stop offset="100%" stopColor={color} stopOpacity="0.0" />
            </linearGradient>
            <pattern id="gridPattern" width="32" height="32" patternUnits="userSpaceOnUse">
              <path d="M 32 0 L 0 0 0 32" fill="none" stroke="currentColor" strokeOpacity="0.05" />
            </pattern>
          </defs>

          {/* Grid lines */}
          <rect
            x={padding.left}
            y={padding.top}
            width={chartWidth}
            height={chartHeight}
            fill="url(#gridPattern)"
          />

          {/* Y Axis Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const y = padding.top + chartHeight * ratio;
            const priceVal = maxPrice - ratio * (maxPrice - minPrice);
            return (
              <g key={ratio}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="currentColor"
                  strokeOpacity="0.08"
                  strokeDasharray="2,2"
                />
                <text
                  x={padding.left - 8}
                  y={y + 3}
                  textAnchor="end"
                  className="font-machine text-[9px] fill-(--text-muted)"
                >
                  £{priceVal.toFixed(priceVal > 100 ? 0 : 2)}
                </text>
              </g>
            );
          })}

          {/* Volume bars (subtle bottom bars) */}
          {showVolume &&
            data.map((d, i) => {
              if (!d.volume) return null;
              const x = getX(i) - 4;
              const volHeight = ((d.volume || 0) / maxVol) * (chartHeight * 0.25);
              const y = padding.top + chartHeight - volHeight;
              return (
                <rect
                  key={i}
                  x={x}
                  y={y}
                  width="8"
                  height={volHeight}
                  fill="currentColor"
                  className="fill-(--text-muted) opacity-20"
                />
              );
            })}

          {/* Area gradient under line */}
          <path d={areaD} fill={`url(#grad-${symbol})`} />

          {/* Precision Price Line */}
          <path d={pathD} fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" />

          {/* X Axis ticks */}
          {data.map((d, i) => {
            if (i % 2 !== 0 && i !== data.length - 1) return null;
            const x = getX(i);
            return (
              <text
                key={i}
                x={x}
                y={height - 10}
                textAnchor="middle"
                className="font-machine text-[9px] fill-(--text-muted)"
              >
                {formatShortTime(d.timestamp)}
              </text>
            );
          })}

          {/* Hover crosshair & interaction zones */}
          {data.map((_, i) => {
            const x = getX(i);
            const w = chartWidth / data.length;
            return (
              <rect
                key={i}
                x={x - w / 2}
                y={padding.top}
                width={w}
                height={chartHeight}
                fill="transparent"
                onMouseEnter={() => setHoverIndex(i)}
              />
            );
          })}

          {/* Active crosshair dot */}
          {hoverIndex !== null && (
            <g>
              <line
                x1={getX(hoverIndex)}
                y1={padding.top}
                x2={getX(hoverIndex)}
                y2={padding.top + chartHeight}
                stroke={color}
                strokeWidth="1"
                strokeDasharray="3,3"
                opacity="0.6"
              />
              <circle
                cx={getX(hoverIndex)}
                cy={getY(data[hoverIndex].price)}
                r="4.5"
                fill={color}
                stroke="var(--bg-primary)"
                strokeWidth="2"
              />
            </g>
          )}
        </svg>
      </div>
    </div>
  );
}
