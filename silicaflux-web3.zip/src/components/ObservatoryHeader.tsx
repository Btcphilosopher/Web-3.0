'use client';

import React from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { formatNumber } from '@/lib/utils';
import { ViewTab } from '@/src/web3/types';
import {
  Layers,
  Network,
  Wallet,
  Coins,
  ArrowRightLeft,
  FileCode2,
  Landmark,
  ShieldCheck,
  Activity,
  Sun,
  Moon,
  Zap,
  Sliders,
  Plus,
  Compass,
} from 'lucide-react';

export function ObservatoryHeader() {
  const {
    currentTab,
    setCurrentTab,
    currentNetwork,
    wallet,
    operatingMode,
    setOperatingMode,
    themeMode,
    setThemeMode,
    densityMode,
    setDensityMode,
    setNetworkModalOpen,
    setNewTxDrawerOpen,
    inspectCausalChain,
    transactions,
  } = useWeb3();

  const navItems: { tab: ViewTab; label: string; icon: React.ElementType }[] = [
    { tab: 'OBSERVATORY', label: 'OBSERVATORY', icon: Compass },
    { tab: 'WALLET', label: 'VAULT', icon: Wallet },
    { tab: 'ASSETS', label: 'ASSETS', icon: Coins },
    { tab: 'TRANSACTIONS', label: 'LEDGER', icon: ArrowRightLeft },
    { tab: 'BLOCKCHAIN', label: 'CHAIN', icon: Layers },
    { tab: 'CONTRACTS', label: 'MACHINES', icon: FileCode2 },
    { tab: 'DEFI', label: 'RESERVOIR', icon: Activity },
    { tab: 'GOVERNANCE', label: 'PARLIAMENT', icon: Landmark },
    { tab: 'IDENTITY', label: 'SOVEREIGN', icon: ShieldCheck },
  ];

  return (
    <header className="border-b border-architectural bg-(--bg-primary) text-(--text-primary) sticky top-0 z-40">
      {/* Top Infrastructure Datum Bar */}
      <div className="px-4 py-2 hairline-b flex flex-wrap items-center justify-between gap-3 text-xs font-machine bg-(--bg-secondary)">
        {/* Brand & Arch Code */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-amber-500 rounded-xs rotate-45" />
            <span className="font-display font-bold tracking-widest text-sm text-(--text-display)">
              SILICAFLUX
            </span>
          </div>
          <span className="hidden sm:inline text-(--text-muted)">|</span>
          <span className="hidden sm:inline text-(--text-secondary) text-[11px]">
            ANGLO-FUTURIST INTERNET OF VALUE (RTL_CORE_V4)
          </span>
        </div>

        {/* Live Network & Block Metrics */}
        <div className="flex items-center gap-4">
          {/* Network Switch Trigger */}
          <button
            onClick={() => setNetworkModalOpen(true)}
            className="flex items-center gap-2 px-2.5 py-1 border border-architectural hover:border-(--border-accent) bg-(--bg-card) rounded-xs transition-colors"
          >
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: currentNetwork.colourAccent }} />
            <span className="font-semibold text-(--text-display)">{currentNetwork.name}</span>
            <span className="text-[10px] text-(--text-muted)">({currentNetwork.code})</span>
          </button>

          {/* Block Height Ticker */}
          <div className="hidden md:flex items-center gap-2">
            <span className="text-(--text-muted)">BLOCK</span>
            <span className="font-bold text-(--text-display)">
              #{formatNumber(currentNetwork.blockHeight)}
            </span>
          </div>

          {/* Gas Barometer */}
          <div className="hidden lg:flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span className="text-(--text-muted)">GAS</span>
            <span className="text-amber-400 font-semibold">{currentNetwork.gasPriceGwei} Gwei</span>
          </div>

          {/* Mode controls */}
          <div className="flex items-center gap-1 pl-2 border-l border-architectural">
            {/* Simulation / Live Toggle */}
            <button
              onClick={() =>
                setOperatingMode(
                  operatingMode === 'LIVE_SIMULATION' ? 'DETERMINISTIC_INSPECT' : 'LIVE_SIMULATION'
                )
              }
              title="Toggle Live Simulation / Deterministic State"
              className={`px-2 py-0.5 text-[10px] rounded-xs border transition-colors ${
                operatingMode === 'LIVE_SIMULATION'
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/60'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              {operatingMode === 'LIVE_SIMULATION' ? 'LIVE SIM' : 'INSPECT'}
            </button>

            {/* Density Selector */}
            <button
              onClick={() => {
                if (densityMode === 'CALM') setDensityMode('STANDARD');
                else if (densityMode === 'STANDARD') setDensityMode('DENSE');
                else setDensityMode('CALM');
              }}
              title="Cycle Information Density"
              className="p-1 border border-architectural hover:border-(--border-accent) rounded-xs text-(--text-secondary) hover:text-(--text-primary)"
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>

            {/* Theme Toggle (Obsidian vs Archive) */}
            <button
              onClick={() => setThemeMode(themeMode === 'OBSIDIAN' ? 'ARCHIVE' : 'OBSIDIAN')}
              title={`Switch to ${themeMode === 'OBSIDIAN' ? 'Archive Mode (Day Archive)' : 'Obsidian Mode (Night Institution)'}`}
              className="p-1 border border-architectural hover:border-(--border-accent) rounded-xs text-(--text-secondary) hover:text-(--text-primary)"
            >
              {themeMode === 'OBSIDIAN' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation & Operational Toolbar */}
      <div className="px-4 py-2 flex flex-wrap items-center justify-between gap-3">
        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.tab;
            return (
              <button
                key={item.tab}
                onClick={() => setCurrentTab(item.tab)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xs text-xs font-system font-medium whitespace-nowrap transition-all border ${
                  isActive
                    ? 'border-amber-600/80 bg-(--bg-secondary) text-(--text-display) font-semibold shadow-xs'
                    : 'border-transparent text-(--text-secondary) hover:text-(--text-primary) hover:bg-(--bg-card-hover)'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-500' : 'text-(--text-muted)'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Vault Status & Direct Actions */}
        <div className="flex items-center gap-2 font-machine text-xs">
          {/* Trace Causal Path Button (The WOW Feature) */}
          <button
            onClick={() => {
              if (transactions.length > 0) inspectCausalChain(transactions[0].hash);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-linear-to-r from-amber-900/30 to-slate-900/40 border border-amber-600/50 hover:border-amber-500 text-amber-300 rounded-xs transition-colors"
          >
            <Activity className="w-3.5 h-3.5" />
            <span className="font-semibold">TRACE CAUSAL PATH</span>
          </button>

          {/* New Transaction Constructor */}
          <button
            onClick={() => setNewTxDrawerOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-(--bg-card) border border-architectural hover:border-(--border-accent) text-(--text-display) rounded-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-amber-500" />
            <span>DISPATCH TX</span>
          </button>

          {/* Wallet Vault Quick Badge */}
          <button
            onClick={() => setCurrentTab('WALLET')}
            className="flex items-center gap-2 px-3 py-1.5 border border-architectural hover:border-(--border-accent) bg-(--bg-secondary) rounded-xs"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-machine text-[11px] text-(--text-primary)">
              {wallet.domainName}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
