'use client';

import React from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { ScientificChart } from '@/src/visualisation/ScientificChart';
import { BlockRailway } from '@/src/visualisation/BlockRailway';
import { formatNumber, formatCurrencyGbp, formatTime } from '@/lib/utils';
import {
  Compass,
  ArrowRight,
  ShieldCheck,
  Zap,
  Activity,
  Coins,
  Layers,
  FileCode2,
  Landmark,
  Plus,
  ExternalLink,
} from 'lucide-react';

export function HomeObservatory() {
  const {
    currentNetwork,
    wallet,
    assets,
    blocks,
    transactions,
    setCurrentTab,
    setSelectedAsset,
    setSelectedBlock,
    inspectCausalChain,
    setNewTxDrawerOpen,
  } = useWeb3();

  // Total Portfolio Value in GBP
  const totalValueGbp = assets.reduce((sum, a) => sum + a.totalValueGbp, 0);

  // Top asset for chart preview
  const heroAsset = assets[0];

  return (
    <div className="space-y-6 pb-12">
      {/* Sovereign Treasury Hero Monolith */}
      <div className="border border-architectural bg-semiconductor-wafer p-8 md:p-10 rounded-xs relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="font-machine text-xs px-2 py-0.5 bg-amber-950/40 text-amber-300 border border-amber-800/60 rounded-xs">
                SOVEREIGN TREASURY VALUATION
              </span>
              <span className="font-machine text-xs text-(--text-muted)">
                VAULT: {wallet.domainName}
              </span>
            </div>

            <div className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-(--text-display)">
              {formatCurrencyGbp(totalValueGbp)}
            </div>

            <p className="font-system text-xs text-(--text-secondary) mt-2 max-w-xl leading-relaxed">
              Consolidated net asset value across 4 institutional networks and cryptographic vaults. Fully backed by Bank of England Digital Sterling, tokenised gilts, and bullion reserves.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setNewTxDrawerOpen(true)}
              className="px-5 py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 font-machine font-bold text-xs tracking-wider rounded-xs flex items-center gap-2 transition-all shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>DISPATCH VALUE</span>
            </button>

            <button
              onClick={() => {
                if (transactions.length > 0) inspectCausalChain(transactions[0].hash);
              }}
              className="px-5 py-3 border border-architectural hover:border-(--border-accent) bg-(--bg-card) text-(--text-display) font-machine text-xs tracking-wider rounded-xs flex items-center gap-2 transition-all"
            >
              <Activity className="w-4 h-4 text-amber-500" />
              <span>TRACE CAUSAL GRAPH</span>
            </button>
          </div>
        </div>

        {/* Reticle marks */}
        <div className="absolute top-2 left-2 font-machine text-[8px] text-(--text-muted) select-none">
          OBS_LAT: 51.5074° N, 0.1278° W (LONDON)
        </div>
        <div className="absolute bottom-2 right-2 font-machine text-[8px] text-(--text-muted) select-none">
          HARDWARE SECURITY SGX ENCLAVE PASS #0912
        </div>
      </div>

      {/* 3-Column Architectural Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Network Infrastructure Monitor */}
        <div className="p-5 border border-architectural bg-(--bg-card) rounded-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between font-machine text-xs text-(--text-muted) mb-1">
              <span>SETTLEMENT INFRASTRUCTURE</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            </div>
            <div className="font-display text-xl font-bold text-(--text-display)">
              {currentNetwork.name}
            </div>
            <div className="font-machine text-xs text-(--text-secondary) mt-1">
              {currentNetwork.consensusMechanism}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-3 border-t border-(--border-subtle) font-machine text-xs">
            <div>
              <span className="text-(--text-muted) block text-[10px]">THROUGHPUT</span>
              <span className="font-bold text-(--text-primary)">{formatNumber(currentNetwork.tps)} TPS</span>
            </div>
            <div>
              <span className="text-(--text-muted) block text-[10px]">FINALITY</span>
              <span className="font-bold text-emerald-400">{currentNetwork.finalityTimeSec}s</span>
            </div>
          </div>
        </div>

        {/* Live Block Witness */}
        <div className="p-5 border border-architectural bg-(--bg-card) rounded-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between font-machine text-xs text-(--text-muted) mb-1">
              <span>LATEST BLOCK WITNESS</span>
              <span className="font-machine text-[10px] text-amber-400">CHRONOMETER</span>
            </div>
            <div className="font-display text-xl font-bold text-(--text-display)">
              #{formatNumber(blocks[0]?.height || 0)}
            </div>
            <div className="font-machine text-xs text-(--text-secondary) truncate mt-1">
              HASH: {blocks[0]?.hash.slice(0, 16)}...
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-3 border-t border-(--border-subtle) font-machine text-xs">
            <div>
              <span className="text-(--text-muted) block text-[10px]">BLOCK GAS</span>
              <span className="font-bold text-(--text-primary)">
                {(blocks[0]?.gasUsed / 1000000).toFixed(2)}M / 30M
              </span>
            </div>
            <div>
              <span className="text-(--text-muted) block text-[10px]">TX DENSITY</span>
              <span className="font-bold text-(--text-primary)">{blocks[0]?.transactionCount} TXs</span>
            </div>
          </div>
        </div>

        {/* Identity & Reputation Authority */}
        <div className="p-5 border border-architectural bg-(--bg-card) rounded-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between font-machine text-xs text-(--text-muted) mb-1">
              <span>SOVEREIGN VAULT ACCREDITATION</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="font-display text-xl font-bold text-(--text-display)">
              Tier-1 Institutional
            </div>
            <div className="font-machine text-xs text-(--text-secondary) mt-1">
              UK Financial Conduct Authority Sandbox Verified
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-3 border-t border-(--border-subtle) font-machine text-xs">
            <div>
              <span className="text-(--text-muted) block text-[10px]">SECURITY SCORE</span>
              <span className="font-bold text-emerald-400">{wallet.securityScore}/100</span>
            </div>
            <div>
              <span className="text-(--text-muted) block text-[10px]">ACTIVE DELEGATIONS</span>
              <span className="font-bold text-(--text-primary)">{wallet.activeDelegations.length} Grants</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Dual Bay: Asset Chamber Preview & Chronometric Block Sequence */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Hero Scientific Price Trajectory */}
        <div className="lg:col-span-8 space-y-6">
          <ScientificChart
            data={heroAsset.historicalPrices}
            title={`${heroAsset.name} — PROGRAMMATIC TELEMETRY`}
            symbol={heroAsset.symbol}
            height={260}
            color="#C98A2C"
          />

          {/* Chronometric Block Sequence Railway */}
          <BlockRailway
            blocks={blocks}
            onSelectBlock={(b) => {
              setSelectedBlock(b);
              setCurrentTab('BLOCKCHAIN');
            }}
            selectedBlockHeight={blocks[0]?.height}
          />
        </div>

        {/* Right Column: Asset Registry Quick Access */}
        <div className="lg:col-span-4 border border-architectural bg-(--bg-card) p-5 rounded-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-architectural pb-3 mb-4">
              <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
                ASSET REGISTRY SNAPSHOT
              </span>
              <button
                onClick={() => setCurrentTab('ASSETS')}
                className="font-machine text-xs text-amber-500 hover:underline flex items-center gap-1"
              >
                <span>CHAMBER</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-2">
              {assets.map((asset) => (
                <button
                  key={asset.id}
                  onClick={() => {
                    setSelectedAsset(asset);
                    setCurrentTab('ASSETS');
                  }}
                  className="w-full p-3 border border-architectural hover:border-(--border-accent) bg-(--bg-primary) hover:bg-(--bg-card-hover) rounded-xs text-left transition-all flex items-center justify-between"
                >
                  <div>
                    <div className="font-display text-xs font-bold text-(--text-display)">
                      {asset.name}
                    </div>
                    <div className="font-machine text-[10px] text-(--text-muted)">
                      {formatNumber(asset.balance)} {asset.symbol}
                    </div>
                  </div>
                  <div className="text-right font-machine">
                    <div className="text-xs font-bold text-(--text-primary)">
                      {formatCurrencyGbp(asset.totalValueGbp)}
                    </div>
                    <div
                      className={`text-[10px] ${
                        asset.change24hPercent >= 0 ? 'text-emerald-400' : 'text-amber-500'
                      }`}
                    >
                      {asset.change24hPercent >= 0 ? '+' : ''}
                      {asset.change24hPercent}%
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-(--border-subtle) mt-4 font-machine text-[11px] text-(--text-muted) flex justify-between">
            <span>INVARIANT CONSERVATION: PASS</span>
            <span>AUDIT: ZERO-DELTA</span>
          </div>
        </div>
      </div>

      {/* Recent Activity Ledger Preview */}
      <div className="border border-architectural bg-(--bg-card) p-5 rounded-xs">
        <div className="flex items-center justify-between border-b border-architectural pb-3 mb-3">
          <div>
            <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
              DISTRIBUTED LEDGER MOVEMENT
            </span>
            <h3 className="font-display text-sm font-bold text-(--text-display)">
              RECENT CRYPTOGRAPHIC SETTLEMENTS
            </h3>
          </div>
          <button
            onClick={() => setCurrentTab('TRANSACTIONS')}
            className="font-machine text-xs text-amber-500 hover:underline flex items-center gap-1"
          >
            <span>FULL LEDGER</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="divide-y divide-(--border-subtle) font-machine text-xs">
          {transactions.slice(0, 4).map((tx) => (
            <div
              key={tx.hash}
              onClick={() => inspectCausalChain(tx.hash)}
              className="py-3 px-2 hover:bg-(--bg-secondary) rounded-xs cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-2 transition-colors"
            >
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <div>
                  <div className="font-bold text-(--text-display)">
                    {formatNumber(tx.value)} {tx.assetSymbol}
                  </div>
                  <div className="text-[11px] text-(--text-muted) truncate max-w-sm">
                    {tx.destinationLabel || tx.destination}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4 sm:text-right">
                <div>
                  <span className="px-2 py-0.5 text-[10px] bg-emerald-950/40 text-emerald-300 border border-emerald-800/60 rounded-xs">
                    {tx.stage}
                  </span>
                  <div className="text-[10px] text-(--text-muted) mt-0.5">
                    {formatTime(tx.timestamp)}
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    inspectCausalChain(tx.hash);
                  }}
                  className="px-2.5 py-1 text-[10px] border border-architectural hover:border-amber-500 text-amber-400 rounded-xs"
                >
                  TRACE
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
