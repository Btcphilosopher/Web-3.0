'use client';

import React from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { InfrastructureNetworkId } from '@/src/web3/types';
import { formatNumber } from '@/lib/utils';
import { Network, CheckCircle2, ShieldCheck, X, Cpu, Server } from 'lucide-react';

export function NetworkSelectorModal() {
  const { networks, currentNetwork, switchNetwork, networkModalOpen, setNetworkModalOpen } = useWeb3();

  if (!networkModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-(--bg-primary) border border-architectural rounded-xs shadow-2xl overflow-hidden text-(--text-primary)">
        {/* Header */}
        <div className="p-5 border-b border-architectural flex items-center justify-between bg-(--bg-secondary)">
          <div>
            <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
              DISTRIBUTED SETTLEMENT TOPOLOGY
            </span>
            <h2 className="font-display text-xl font-bold text-(--text-display) mt-0.5">
              SWITCH INFRASTRUCTURE NETWORK
            </h2>
          </div>
          <button
            onClick={() => setNetworkModalOpen(false)}
            className="p-1 border border-architectural hover:border-(--border-accent) rounded-xs text-(--text-secondary) hover:text-(--text-primary)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Network Grid */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[70vh] overflow-y-auto">
          {networks.map((net) => {
            const isSelected = net.id === currentNetwork.id;
            return (
              <button
                key={net.id}
                onClick={() => switchNetwork(net.id as InfrastructureNetworkId)}
                className={`p-4 border rounded-xs text-left transition-all relative ${
                  isSelected
                    ? 'border-amber-600 bg-(--bg-secondary) shadow-sm'
                    : 'border-architectural bg-(--bg-card) hover:bg-(--bg-card-hover)'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: net.colourAccent }} />
                    <span className="font-display text-sm font-bold text-(--text-display)">
                      {net.name}
                    </span>
                  </div>
                  {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-500" />}
                </div>

                <div className="font-machine text-[11px] text-(--text-secondary) mb-3">
                  {net.type} • {net.consensusMechanism}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-(--border-subtle) font-machine text-[10px]">
                  <div>
                    <span className="text-(--text-muted) block">THROUGHPUT</span>
                    <span className="text-(--text-primary) font-semibold">{formatNumber(net.tps)} TPS</span>
                  </div>
                  <div>
                    <span className="text-(--text-muted) block">FINALITY</span>
                    <span className="text-(--text-primary) font-semibold">{net.finalityTimeSec}s</span>
                  </div>
                  <div>
                    <span className="text-(--text-muted) block">TOTAL VALUE LOCKED</span>
                    <span className="text-(--text-primary) font-semibold">
                      £{(net.totalValueLockedGbp / 1000000000).toFixed(2)}B
                    </span>
                  </div>
                  <div>
                    <span className="text-(--text-muted) block">RPC LATENCY</span>
                    <span className="text-emerald-400 font-semibold">{net.rpcLatencyMs}ms</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-architectural bg-(--bg-secondary) flex items-center justify-between font-machine text-xs text-(--text-muted)">
          <span>ALL NETWORKS MONITORED VIA ZERO-KNOWLEDGE PROOF INTERLOCK</span>
          <span>CHAPS v4 & RTGS COMPLIANT</span>
        </div>
      </div>
    </div>
  );
}
