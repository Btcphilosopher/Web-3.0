'use client';

import React from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { ShieldAlert, CheckCircle2, XCircle, KeyRound, Lock } from 'lucide-react';

export function SecuritySignModal() {
  const { securityPrompt } = useWeb3();

  if (!securityPrompt || !securityPrompt.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-(--bg-primary) border-2 border-amber-600/90 rounded-xs shadow-2xl overflow-hidden text-(--text-primary)">
        {/* Top Warning Banner */}
        <div className="p-4 bg-amber-950/40 border-b border-amber-800/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <span className="font-machine text-xs font-bold text-amber-300 tracking-wider">
              {securityPrompt.title}
            </span>
          </div>
          <span className="font-machine text-[10px] text-amber-400/80">
            ENCLAVE_SIGNATURE_CHAMBER
          </span>
        </div>

        {/* Security Matrix: WHAT, WHO, WHERE, HOW MUCH, WHY */}
        <div className="p-6 space-y-4">
          <p className="font-system text-xs text-(--text-secondary) leading-relaxed">
            Review the complete cryptographic authorization payload before delegating signature from your sovereign hardware enclave.
          </p>

          <div className="border border-architectural bg-(--bg-secondary) divide-y divide-(--border-subtle) font-machine text-xs rounded-xs">
            <div className="p-3 grid grid-cols-3 gap-2">
              <span className="text-(--text-muted) font-semibold uppercase tracking-wider">01. WHAT (ACTION)</span>
              <span className="col-span-2 text-(--text-display) font-bold">{securityPrompt.what}</span>
            </div>

            <div className="p-3 grid grid-cols-3 gap-2">
              <span className="text-(--text-muted) font-semibold uppercase tracking-wider">02. WHO (SIGNER)</span>
              <span className="col-span-2 text-(--text-primary) truncate">{securityPrompt.who}</span>
            </div>

            <div className="p-3 grid grid-cols-3 gap-2">
              <span className="text-(--text-muted) font-semibold uppercase tracking-wider">03. WHERE (TARGET)</span>
              <span className="col-span-2 text-(--text-primary) font-mono break-all">{securityPrompt.where}</span>
            </div>

            <div className="p-3 grid grid-cols-3 gap-2">
              <span className="text-(--text-muted) font-semibold uppercase tracking-wider">04. HOW MUCH (VALUE)</span>
              <span className="col-span-2 text-amber-400 font-bold">{securityPrompt.howMuch}</span>
            </div>

            <div className="p-3 grid grid-cols-3 gap-2">
              <span className="text-(--text-muted) font-semibold uppercase tracking-wider">05. WHY (PURPOSE)</span>
              <span className="col-span-2 text-(--text-secondary)">{securityPrompt.why}</span>
            </div>
          </div>

          <div className="p-3 border border-architectural bg-(--bg-card) flex items-center gap-3 rounded-xs font-machine text-[11px] text-(--text-muted)">
            <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Hardware Enclave Attestation active: Private keys never leave the secure boundary.</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 border-t border-architectural bg-(--bg-secondary) flex items-center justify-end gap-3 font-machine text-xs">
          <button
            onClick={securityPrompt.onCancel}
            className="flex items-center gap-1.5 px-4 py-2 border border-architectural hover:border-red-500 hover:text-red-400 bg-(--bg-card) rounded-xs transition-colors"
          >
            <XCircle className="w-4 h-4" />
            <span>DECLINE SIGNATURE</span>
          </button>

          <button
            onClick={securityPrompt.onConfirm}
            className="flex items-center gap-1.5 px-5 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-xs transition-colors shadow-md"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>CONFIRM & DISPATCH</span>
          </button>
        </div>
      </div>
    </div>
  );
}
