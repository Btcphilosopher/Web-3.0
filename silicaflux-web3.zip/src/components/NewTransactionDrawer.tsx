'use client';

import React, { useState } from 'react';
import { useWeb3 } from '@/src/core/state/Web3Context';
import { formatNumber, formatCurrencyGbp } from '@/lib/utils';
import { X, ArrowRight, ShieldCheck, Zap, Send, Coins } from 'lucide-react';

export function NewTransactionDrawer() {
  const {
    newTxDrawerOpen,
    setNewTxDrawerOpen,
    assets,
    currentNetwork,
    wallet,
    createTransaction,
  } = useWeb3();

  const [selectedSymbol, setSelectedSymbol] = useState(assets[0]?.symbol || 'SILICA');
  const [destination, setDestination] = useState('0x981249A801284B9102477C018991284bE1058402');
  const [value, setValue] = useState('100');
  const [purpose, setPurpose] = useState('Treasury Reserve Allocation');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!newTxDrawerOpen) return null;

  const currentAsset = assets.find((a) => a.symbol === selectedSymbol) || assets[0];
  const numVal = parseFloat(value) || 0;
  const totalGbp = numVal * currentAsset.priceGbp;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (numVal <= 0) return;

    setIsSubmitting(true);
    try {
      await createTransaction({
        destination,
        value: numVal,
        assetSymbol: selectedSymbol,
        why: purpose,
      });
    } catch (err) {
      console.log('Transaction canceled or failed', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-(--bg-primary) border-l border-architectural h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300 text-(--text-primary)">
        {/* Header */}
        <div className="p-6 border-b border-architectural flex items-center justify-between bg-(--bg-secondary)">
          <div>
            <span className="font-machine text-[10px] text-(--text-muted) tracking-widest uppercase">
              TRANSACTION CONSTRUCTOR & STATE PIPELINE
            </span>
            <h2 className="font-display text-xl font-bold text-(--text-display) mt-0.5">
              DISPATCH NEW TRANSACTION
            </h2>
          </div>
          <button
            onClick={() => setNewTxDrawerOpen(false)}
            className="p-1 border border-architectural hover:border-(--border-accent) rounded-xs text-(--text-secondary) hover:text-(--text-primary)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Origin Info */}
          <div className="p-4 border border-architectural bg-(--bg-card) rounded-xs font-machine text-xs space-y-1">
            <span className="text-[10px] text-(--text-muted) uppercase">SIGNING ORIGIN (SOVEREIGN VAULT)</span>
            <div className="font-bold text-(--text-display)">{wallet.domainName}</div>
            <div className="text-[11px] text-(--text-secondary) font-mono truncate">{wallet.address}</div>
          </div>

          {/* Network Banner */}
          <div className="p-3 border border-architectural bg-(--bg-secondary) flex items-center justify-between font-machine text-xs rounded-xs">
            <span className="text-(--text-muted)">TARGET INFRASTRUCTURE</span>
            <div className="flex items-center gap-2 font-semibold text-(--text-primary)">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: currentNetwork.colourAccent }} />
              <span>{currentNetwork.name}</span>
            </div>
          </div>

          {/* Asset Selection */}
          <div className="space-y-2">
            <label className="font-machine text-xs text-(--text-muted) uppercase block">
              SELECT ASSET REGISTRY OBJECT
            </label>
            <div className="grid grid-cols-2 gap-2">
              {assets.map((asset) => (
                <button
                  type="button"
                  key={asset.symbol}
                  onClick={() => setSelectedSymbol(asset.symbol)}
                  className={`p-3 border rounded-xs text-left transition-all ${
                    selectedSymbol === asset.symbol
                      ? 'border-amber-600 bg-(--bg-secondary)'
                      : 'border-architectural bg-(--bg-card) hover:bg-(--bg-card-hover)'
                  }`}
                >
                  <div className="font-display text-sm font-bold text-(--text-display)">{asset.symbol}</div>
                  <div className="font-machine text-[10px] text-(--text-muted) mt-0.5">
                    BAL: {formatNumber(asset.balance)}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Destination Address */}
          <div className="space-y-2">
            <label className="font-machine text-xs text-(--text-muted) uppercase block">
              DESTINATION CHAMBER OR CONTRACT ADDRESS
            </label>
            <input
              type="text"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              required
              className="w-full p-3 font-mono text-xs border border-architectural bg-(--bg-card) text-(--text-primary) rounded-xs focus:outline-hidden focus:border-amber-500"
              placeholder="0x..."
            />
            {/* Quick destination presets */}
            <div className="flex items-center gap-2 pt-1 font-machine text-[10px]">
              <span className="text-(--text-muted)">PRESETS:</span>
              <button
                type="button"
                onClick={() => setDestination('0x981249A801284B9102477C018991284bE1058402')}
                className="underline hover:text-amber-400"
              >
                Silica Pool
              </button>
              <button
                type="button"
                onClick={() => setDestination('0x88F0918B227160399581A728490B8129849501a1')}
                className="underline hover:text-amber-400"
              >
                HM Gilt
              </button>
              <button
                type="button"
                onClick={() => setDestination('0x114B924089a81C72490B8129849501a182471920')}
                className="underline hover:text-amber-400"
              >
                BoE Bridge
              </button>
            </div>
          </div>

          {/* Value Quantity */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-machine text-xs text-(--text-muted) uppercase block">
                QUANTITY TO TRANSFER
              </label>
              <button
                type="button"
                onClick={() => setValue(currentAsset.balance.toString())}
                className="font-machine text-[10px] text-amber-500 hover:underline"
              >
                MAX: {currentAsset.balance} {currentAsset.symbol}
              </button>
            </div>
            <div className="relative">
              <input
                type="number"
                step="any"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                required
                className="w-full p-3 font-mono text-sm border border-architectural bg-(--bg-card) text-(--text-primary) rounded-xs focus:outline-hidden focus:border-amber-500"
                placeholder="0.00"
              />
              <span className="absolute right-3 top-3 font-machine text-xs text-(--text-muted)">
                {currentAsset.symbol}
              </span>
            </div>
            <div className="font-machine text-xs text-(--text-secondary) flex justify-between pt-1">
              <span>ESTIMATED FIAT VALUE:</span>
              <span className="font-bold text-(--text-display)">
                {formatCurrencyGbp(totalGbp)}
              </span>
            </div>
          </div>

          {/* Purpose / Why */}
          <div className="space-y-2">
            <label className="font-machine text-xs text-(--text-muted) uppercase block">
              PURPOSE & AUDIT MEMO (WHY)
            </label>
            <input
              type="text"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              className="w-full p-3 font-system text-xs border border-architectural bg-(--bg-card) text-(--text-primary) rounded-xs focus:outline-hidden focus:border-amber-500"
              placeholder="e.g. Collateral Injection, Payment, Coupon Execution"
            />
          </div>

          {/* Gas & Settlement telemetry */}
          <div className="p-4 border border-architectural bg-(--bg-secondary) rounded-xs font-machine text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-(--text-muted)">BASE GAS FEE</span>
              <span className="text-(--text-primary)">{currentNetwork.gasPriceGwei} Gwei (~£0.08)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-(--text-muted)">SETTLEMENT FINALITY</span>
              <span className="text-emerald-400 font-semibold">{currentNetwork.finalityTimeSec}s (Deterministic)</span>
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isSubmitting || numVal <= 0}
            className="w-full py-3.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-machine font-bold text-xs tracking-wider rounded-xs flex items-center justify-center gap-2 transition-colors shadow-lg"
          >
            <Send className="w-4 h-4" />
            <span>AUTHORISE & DISPATCH TO MEMPOOL</span>
          </button>
        </form>
      </div>
    </div>
  );
}
