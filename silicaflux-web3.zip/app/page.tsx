'use client';

import React, { useEffect } from 'react';
import { Web3Provider, useWeb3 } from '@/src/core/state/Web3Context';
import { ObservatoryHeader } from '@/src/components/ObservatoryHeader';
import { HomeObservatory } from '@/src/components/HomeObservatory';
import { WalletVaultView } from '@/src/web3/wallet/WalletVaultView';
import { AssetRegistryView } from '@/src/web3/assets/AssetRegistryView';
import { TransactionLedgerView } from '@/src/web3/transactions/TransactionLedgerView';
import { BlockchainExplorerView } from '@/src/web3/blockchain/BlockchainExplorerView';
import { ContractObservatoryView } from '@/src/web3/contracts/ContractObservatoryView';
import { DefiReservoirView } from '@/src/web3/defi/DefiReservoirView';
import { GovernanceParliamentView } from '@/src/web3/governance/GovernanceParliamentView';
import { IdentitySovereignView } from '@/src/web3/identity/IdentitySovereignView';
import { NetworkSelectorModal } from '@/src/components/NetworkSelectorModal';
import { SecuritySignModal } from '@/src/components/SecuritySignModal';
import { NewTransactionDrawer } from '@/src/components/NewTransactionDrawer';
import { CausalChainVisualizer } from '@/src/visualisation/CausalChainVisualizer';
import { ViewTab } from '@/src/web3/types';

function SilicaFluxApp() {
  const {
    currentTab,
    setCurrentTab,
    densityMode,
    themeMode,
    setThemeMode,
    causalModalOpen,
    setCausalModalOpen,
    selectedTransaction,
    setNetworkModalOpen,
    inspectCausalChain,
    transactions,
  } = useWeb3();

  // Keyboard shortcut listener for power operators
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in an input
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === '1') setCurrentTab('OBSERVATORY');
      else if (e.key === '2') setCurrentTab('WALLET');
      else if (e.key === '3') setCurrentTab('ASSETS');
      else if (e.key === '4') setCurrentTab('TRANSACTIONS');
      else if (e.key === '5') setCurrentTab('BLOCKCHAIN');
      else if (e.key === '6') setCurrentTab('CONTRACTS');
      else if (e.key === '7') setCurrentTab('DEFI');
      else if (e.key === '8') setCurrentTab('GOVERNANCE');
      else if (e.key === '9') setCurrentTab('IDENTITY');
      else if (e.key.toLowerCase() === 't') {
        setThemeMode(themeMode === 'OBSIDIAN' ? 'ARCHIVE' : 'OBSIDIAN');
      } else if (e.key.toLowerCase() === 'n') {
        setNetworkModalOpen(true);
      } else if (e.key === ' ' || e.key.toLowerCase() === 'c') {
        e.preventDefault();
        if (transactions.length > 0) {
          inspectCausalChain(transactions[0].hash);
        }
      } else if (e.key === 'Escape') {
        setCausalModalOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setCurrentTab, setThemeMode, themeMode, setNetworkModalOpen, inspectCausalChain, transactions, setCausalModalOpen]);

  // Render view tab
  const renderTabContent = () => {
    switch (currentTab) {
      case 'OBSERVATORY':
        return <HomeObservatory />;
      case 'WALLET':
        return <WalletVaultView />;
      case 'ASSETS':
        return <AssetRegistryView />;
      case 'TRANSACTIONS':
        return <TransactionLedgerView />;
      case 'BLOCKCHAIN':
        return <BlockchainExplorerView />;
      case 'CONTRACTS':
        return <ContractObservatoryView />;
      case 'DEFI':
        return <DefiReservoirView />;
      case 'GOVERNANCE':
        return <GovernanceParliamentView />;
      case 'IDENTITY':
        return <IdentitySovereignView />;
      default:
        return <HomeObservatory />;
    }
  };

  const densityPadding =
    densityMode === 'CALM' ? 'p-6 md:p-8 max-w-7xl' : densityMode === 'DENSE' ? 'p-3 md:p-4 max-w-7xl' : 'p-4 md:p-6 max-w-7xl';

  return (
    <div className="min-h-screen flex flex-col bg-(--bg-primary) text-(--text-primary) bg-silica-grid">
      {/* Top Architectural Bar */}
      <ObservatoryHeader />

      {/* Main Observatory Stage */}
      <main className={`flex-1 w-full mx-auto ${densityPadding}`}>
        {renderTabContent()}
      </main>

      {/* Architectural Bottom Telemetry Footer */}
      <footer className="border-t border-architectural bg-(--bg-secondary) px-6 py-4 font-machine text-xs text-(--text-muted) flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span className="text-(--text-primary) font-semibold">SILICAFLUX SOVEREIGN ENGINE</span>
          <span>|</span>
          <span>ANGLO-FUTURIST INTERNET OF VALUE</span>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          <span>SHORTCUTS: [1-9] TABS • [SPACE] CAUSAL TRACE • [N] NETWORK • [T] THEME</span>
          <span>UK-DMO & FCA COMPLIANT</span>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <NetworkSelectorModal />
      <SecuritySignModal />
      <NewTransactionDrawer />

      {/* The WOW Full Causal Chain Visualizer Modal */}
      {causalModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-5xl h-[88vh] bg-(--bg-primary) border-2 border-amber-600/90 rounded-xs shadow-2xl overflow-hidden flex flex-col">
            <CausalChainVisualizer
              transaction={selectedTransaction}
              onClose={() => setCausalModalOpen(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}

export default function Page() {
  return (
    <Web3Provider>
      <SilicaFluxApp />
    </Web3Provider>
  );
}
