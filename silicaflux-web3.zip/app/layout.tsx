import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SilicaFlux Web3 — Anglo-Futurist Internet of Value',
  description: 'An architectural visual operating system for the Internet of Value. Sovereign digital treasury, cryptographic asset registry, machine smart contracts, and causal blockchain observatory.',
  openGraph: {
    title: 'SilicaFlux Web3 — Anglo-Futurist Internet of Value',
    description: 'An architectural visual operating system for the Internet of Value.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SilicaFlux Web3 — Anglo-Futurist Internet of Value',
    description: 'An architectural visual operating system for the Internet of Value.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased selection:bg-slate-700 selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
