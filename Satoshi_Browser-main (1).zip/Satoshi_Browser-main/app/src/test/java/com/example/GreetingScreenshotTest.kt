package com.example

import android.app.Application
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.test.core.app.ApplicationProvider
import com.example.ui.screens.SatoshiMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.SatoshiViewModel
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

    @get:Rule val composeTestRule = createComposeRule()

    @Test
    fun greeting_screenshot() {
        // Create actual ViewModel using application context inside Robolectric!
        val application = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = SatoshiViewModel(application)

        composeTestRule.setContent {
            MyApplicationTheme {
                SatoshiMainScreen(viewModel = viewModel)
            }
        }

        // Capture visual output of our gorgeous Satoshi Browser dashboard
        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
    }
}
