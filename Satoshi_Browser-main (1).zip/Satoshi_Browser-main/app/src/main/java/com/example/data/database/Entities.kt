package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wallet_transactions")
data class WalletTx(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val amountSats: Long,
    val type: String, // "INCOMING" or "OUTGOING"
    val memo: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String, // "SUCCESS", "PENDING", "FAILED"
    val destinationNode: String = ""
)

@Entity(tableName = "lightning_channels")
data class LnkChannel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nodeId: String,
    val capacitySats: Long,
    val localBalanceSats: Long,
    val remoteBalanceSats: Long,
    val active: Boolean
)

@Entity(tableName = "purchased_access")
data class PurchasedAccess(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val url: String,
    val merchant: String,
    val amountPaid: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val accessKey: String,
    val contentType: String // "NEWS_ARTICLE", "AUDIO_STREAM", "API_SESSION"
)
