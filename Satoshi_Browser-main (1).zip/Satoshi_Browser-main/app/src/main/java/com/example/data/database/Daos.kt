package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallet_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<WalletTx>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: WalletTx)

    @Query("DELETE FROM wallet_transactions")
    suspend fun deleteAll()
}

@Dao
interface ChannelDao {
    @Query("SELECT * FROM lightning_channels")
    fun getAllChannels(): Flow<List<LnkChannel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannel(channel: LnkChannel)

    @Update
    suspend fun updateChannel(channel: LnkChannel)

    @Delete
    suspend fun deleteChannel(channel: LnkChannel)

    @Query("SELECT COUNT(*) FROM lightning_channels")
    fun getChannelCount(): Flow<Int>

    @Query("DELETE FROM lightning_channels")
    suspend fun deleteAll()
}

@Dao
interface PurchasedAccessDao {
    @Query("SELECT * FROM purchased_access ORDER BY timestamp DESC")
    fun getAllPurchases(): Flow<List<PurchasedAccess>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(access: PurchasedAccess)

    @Query("SELECT * FROM purchased_access WHERE url = :url LIMIT 1")
    suspend fun getPurchaseByUrl(url: String): PurchasedAccess?

    @Query("DELETE FROM purchased_access")
    suspend fun deleteAll()
}
