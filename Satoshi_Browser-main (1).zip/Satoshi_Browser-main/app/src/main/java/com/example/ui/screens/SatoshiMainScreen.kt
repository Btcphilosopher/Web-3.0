package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.InputChipDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.database.LnkChannel
import com.example.ui.theme.AccentGold
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BitcoinOrange
import com.example.ui.theme.CryptoGreen
import com.example.ui.theme.DarkSteel
import com.example.ui.theme.DeepObsidian
import com.example.ui.theme.LightChalk
import com.example.ui.theme.LightningBlue
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.SlateCard
import com.example.ui.viewmodel.SatoshiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SatoshiMainScreen(viewModel: SatoshiViewModel) {
    var selectedTab by remember { mutableStateOf(0) }

    val currentUrl by viewModel.currentUrl.collectAsState()
    val isWebLoading by viewModel.isWebPageLoading.collectAsState()
    val activeIntent by viewModel.activePaymentIntent.collectAsState()
    val isNodeOperating by viewModel.isNodeOperating.collectAsState()
    val syncProgress by viewModel.syncProgress.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("satoshi_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Satoshi Browser WebView") },
                    label = { Text("Browser", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BitcoinOrange,
                        selectedTextColor = BitcoinOrange,
                        indicatorColor = SlateCard
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Star, contentDescription = "LDK Node Wallet Client") },
                    label = { Text("LDK Wallet", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BitcoinOrange,
                        selectedTextColor = BitcoinOrange,
                        indicatorColor = SlateCard
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Info, contentDescription = "Merchant API & SDK documentation") },
                    label = { Text("Developer API", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BitcoinOrange,
                        selectedTextColor = BitcoinOrange,
                        indicatorColor = SlateCard
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.List, contentDescription = "Core Architecture Flow Map") },
                    label = { Text("Architecture", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BitcoinOrange,
                        selectedTextColor = BitcoinOrange,
                        indicatorColor = SlateCard
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedTab) {
                0 -> BrowserTab(viewModel)
                1 -> WalletTab(viewModel)
                2 -> DeveloperApiTab()
                3 -> ArchitectureTab(viewModel)
            }

            activeIntent?.let { intent ->
                PaymentPromptDialog(
                    intent = intent,
                    onApprove = { viewModel.approvePaymentIntent() },
                    onDecline = { viewModel.rejectPaymentIntent() }
                )
            }
        }
    }
}

// ==========================================
// BROWSER VIEW TAB (WEB VIEW + METADATA DETECTION)
// ==========================================

@Composable
fun BrowserTab(viewModel: SatoshiViewModel) {
    val currentUrl by viewModel.currentUrl.collectAsState()
    val isWebLoading by viewModel.isWebPageLoading.collectAsState()
    val liveLogs by viewModel.paymentLogs.collectAsState()
    val isNodeOperating by viewModel.isNodeOperating.collectAsState()

    var showQuickMenu by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            shape = RoundedCornerShape(0.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo("satoshi://paywall-news") },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Prev Page", tint = BitcoinOrange)
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(SlateCard)
                            .border(
                                width = 1.dp,
                                color = if (currentUrl.startsWith("satoshi://")) BitcoinOrange.copy(alpha = 0.5f) else Color.Transparent,
                                shape = RoundedCornerShape(22.dp)
                            )
                            .clickable { showQuickMenu = !showQuickMenu }
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚡️",
                            fontSize = 16.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = currentUrl.replace("satoshi://", ""),
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f),
                            maxLines = 1
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(BitcoinOrange)
                                .padding(horizontal = 6.dp, vertical = 2.5.dp)
                        ) {
                            Text(
                                "SECURE",
                                color = Color(0xFF381E72),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isWebLoading) {
                            Spacer(modifier = Modifier.width(6.dp))
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = BitcoinOrange
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = { showQuickMenu = !showQuickMenu },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Browse addresses", tint = BitcoinOrange)
                    }
                }

                if (!isNodeOperating) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, start = 8.dp, end = 8.dp)
                            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(vertical = 4.dp, horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "LDK node offline label", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Browser LDK node is offline. Web3 commerce calls will be blocked.",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        AnimatedVisibility(visible = showQuickMenu) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BitcoinOrange.copy(alpha = 0.25f), RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Satoshi Protocol Web3 Sandboxes",
                        color = BitcoinOrange,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    val webSites = listOf(
                        Triple("satoshi://paywall-news", "The Daily Sovereign News", "LN payment verification wall"),
                        Triple("satoshi://streamtune", "StreamTune Music Player", "Lightning streaming micro-payments"),
                        Triple("satoshi://lumina-api", "Lumina AI Model Sandbox", "Pay-per-use L402 capabilities"),
                        Triple("satoshi://coffee-shop", "Satoshi Espresso Shop", "Product metadata scanning")
                    )

                    webSites.forEach { (url, title, desc) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.navigateTo(url)
                                    showQuickMenu = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = null,
                                tint = BitcoinOrange,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(title, fontWeight = FontWeight.Bold, color = LightChalk, fontSize = 13.sp)
                                Text(desc, color = MutedSlate, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (isWebLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = BitcoinOrange)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Parsing webpage metadata & initializing Satoshi JavaScript bindings...", color = MutedSlate, fontSize = 11.sp)
                    }
                }
            } else {
                when (currentUrl) {
                    "satoshi://paywall-news" -> PaywallNewsScreen(viewModel)
                    "satoshi://streamtune" -> StreamTuneMusicScreen(viewModel)
                    "satoshi://lumina-api" -> LuminaApiScreen(viewModel)
                    "satoshi://coffee-shop" -> CoffeeMetadataStoreScreen(viewModel)
                    else -> CustomWebViewSimulator(url = currentUrl)
                }
            }
        }

        Card(
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSteel),
            modifier = Modifier
                .fillMaxWidth()
                .height(115.dp)
                .border(width = 1.dp, color = BitcoinOrange.copy(alpha = 0.2f), shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Simulated LDK node activities console",
                            tint = LightningBlue,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Satoshi Host IPC Broker Logs", color = LightningBlue, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Text("ACTIVE INTEGRATION VIA LDK", color = CryptoGreen, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (liveLogs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Ready. No lightning commerce interactions detected on current DOM.", color = MutedSlate, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(liveLogs) { log ->
                            Text(
                                text = log,
                                color = if (log.contains("✓")) CryptoGreen else if (log.contains("✕") || log.contains("⚠")) AlertRed else LightChalk,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------
// MOCK SUB-PAGES RENDERING INSIDE THE SATOSHI BROWSER
// -----------------------------------------------------

@Composable
fun PaywallNewsScreen(viewModel: SatoshiViewModel) {
    val isNewsUnlocked by viewModel.isNewsUnlocked.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "THE DAILY SOVEREIGN",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = LightChalk
            )
            Card(
                colors = CardDefaults.cardColors(containerColor = BitcoinOrange.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    "SATOSHI-PAYWALL-DOM Enabled",
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = BitcoinOrange,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(MutedSlate.copy(alpha = 0.3f))
        )
        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Breaking: Satoshi Browser Introduces Native LDK Integration into DOM Primitives",
            fontSize = 19.sp,
            fontWeight = FontWeight.ExtraBold,
            color = LightChalk,
            lineHeight = 24.sp,
            fontFamily = FontFamily.Serif
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(BitcoinOrange),
                contentAlignment = Alignment.Center
            ) {
                Text("H", color = DeepObsidian, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("Hal Finney II", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LightChalk)
                Text("June 8, 2026 • 3 min read", fontSize = 9.sp, color = MutedSlate)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "For over thirty years, general-purpose web commerce has been fundamentally broken, throttled by structural friction. Credit card networks demand massive merchant fees (3%+) and set absurd minimum checkout prices. To survive, publishers built bloated paywall portals, invasive registration schemas, and cookie-based ad trackers.",
            fontSize = 13.sp,
            color = LightChalk,
            lineHeight = 19.sp,
            textAlign = TextAlign.Justify
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "The Web3 dream sought to solve this, but initially failed by stuffing heavy wallets into browser extensions requiring complex key configurations and high gas fees. Bitcoin's Layer 2, the Lightning Network, changes this equation. By bringing LDK directly behind the browser viewport core process, micro-commerce can now be treated as a pure system native.",
            fontSize = 13.sp,
            color = LightChalk,
            lineHeight = 19.sp,
            textAlign = TextAlign.Justify
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (!isNewsUnlocked) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BitcoinOrange.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .background(SlateCard.copy(alpha = 0.6f))
                    .padding(16.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = "Locked element",
                        tint = BitcoinOrange,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "🔒 Micro-Payment Lock Active",
                        color = LightChalk,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "The remainder of this premium analytical report consists of 1,200 words. Click below to execute a 10 Sats lightning micro-transaction directly through your built-in Satoshi browser wallet.",
                        color = MutedSlate,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Price: 10 Satoshis (~$0.007)",
                        color = AccentGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.requestPaymentPrompt(
                                merchantName = "The Daily Sovereign",
                                description = "Unlocking analytical article (LDK binding test)",
                                amountSats = 10,
                                invoice = "lnbc10p1pw0newsanchor...",
                                pageUrl = "satoshi://paywall-news"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BitcoinOrange),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("pay_news_button")
                    ) {
                        Text("Settle Paywall & Reveal Text", color = DeepObsidian, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CryptoGreen.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .background(CryptoGreen.copy(alpha = 0.05f))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = "Settle complete", tint = CryptoGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Lightning Settle Proof Validated. Context Decrypted Successfully.", color = CryptoGreen, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Premium Content Decrypted:",
                color = AccentGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Sovereign publishers can now declare their payment requirements dynamically via Web API parameters without relying on Stripe, PayPal, or expensive merchant logins. When the user loads a webpage, the Satoshi Browser scans for semantic tags pointing to lightning pricing schedules.\n\n" +
                        "If price conditions are met, the browser's Rust core handles the node channel rebalancing under the hood. Using the instant window.satoshi.payInvoice API, the browser processes instant nano-transactions in milliseconds. Web developers register custom callbacks. In our field tests, page loading billing resolved in under 32ms, representing a spectacular 98% improvement over legacy card rails. This marks the definitive end of subscription traps, yielding true cryptographic freedom to read and write.",
                fontSize = 13.sp,
                color = LightChalk,
                lineHeight = 19.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Justify
            )
        }
    }
}

@Composable
fun StreamTuneMusicScreen(viewModel: SatoshiViewModel) {
    val isAudioStreaming by viewModel.isAudioStreaming.collectAsState()
    val streamTickCount by viewModel.streamTickCount.collectAsState()
    val budgets by viewModel.budgets.collectAsState()

    val streamTuneBudget = budgets["streamtune"] ?: 0L

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("STREAMTUNE AUDIO LABS", color = LightningBlue, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        Text("Continuous Micro-Payment Protocol Demo", color = MutedSlate, fontSize = 10.sp)

        Spacer(modifier = Modifier.height(20.dp))

        Box(
            modifier = Modifier
                .size(140.dp)
                .drawBehind {
                    drawCircle(color = SlateCard)
                    drawCircle(
                        color = if (isAudioStreaming) LightningBlue else MutedSlate,
                        radius = size.minDimension / 2.1f,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(
                            width = 6f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                        )
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(DarkSteel)
                    .border(3.dp, BitcoinOrange, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = "Playing track",
                    tint = BitcoinOrange,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Cryptographic Cypherpunk Symphony", color = LightChalk, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text("Rate: 1 Satoshi / 3 Seconds", color = AccentGold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            if (!isAudioStreaming) {
                Button(
                    onClick = { viewModel.startStreamingMusic() },
                    colors = ButtonDefaults.buttonColors(containerColor = LightningBlue),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.width(160.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Play music", tint = DeepObsidian)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Play Stream", color = DeepObsidian, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Button(
                    onClick = { viewModel.stopStreaming() },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.width(160.dp)
                ) {
                    Text("Pause Stream", color = LightChalk, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Streaming Payment Telemetry",
                    fontSize = 11.sp,
                    color = LightningBlue,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Packets Delivered: $streamTickCount", fontSize = 11.sp, color = LightChalk)
                    Text("Total Paid: $streamTickCount Sats", fontSize = 11.sp, color = AccentGold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = if (isAudioStreaming) 0.6f else 0.0f,
                    color = LightningBlue,
                    trackColor = DarkSteel,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BitcoinOrange.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = "Budgets explanation", tint = BitcoinOrange, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Pre-Approved Stream Authorization", color = BitcoinOrange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Bypass prompt sheets by pre-allocating a maximum Satoshis budget. Browser LDK processes payments instantly background.",
                    color = MutedSlate,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Current Autopay Budget: $streamTuneBudget Sats",
                        color = LightChalk,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    if (streamTuneBudget > 0) {
                        Text(
                            "✓ BYPASSING PROMPTS",
                            color = CryptoGreen,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.setPreApprovedBudget("streamtune", 15) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LightningBlue),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, LightningBlue.copy(alpha = 0.4f))
                    ) {
                        Text("+15 Sats", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { viewModel.setPreApprovedBudget("streamtune", 50) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LightningBlue),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, LightningBlue.copy(alpha = 0.4f))
                    ) {
                        Text("+50 Sats", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { viewModel.setPreApprovedBudget("streamtune", 0) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AlertRed.copy(alpha = 0.4f))
                    ) {
                        Text("Reset", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun LuminaApiScreen(viewModel: SatoshiViewModel) {
    val apiInput by viewModel.apiInput.collectAsState()
    val apiOutput by viewModel.apiOutput.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("LUMINA CRYPTO-AI ENGINE", color = BitcoinOrange, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("Pay-per-use AI Model API endpoint via L402 HTTP primitives", color = MutedSlate, fontSize = 10.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Text("Select an Example Query:", color = LightChalk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            InputChip(
                selected = apiInput == "Translate 'Hello planet' to Spanish",
                onClick = { viewModel.setApiInput("Translate 'Hello planet' to Spanish") },
                label = { Text("Translate prompt", fontSize = 10.sp) },
                colors = InputChipDefaults.inputChipColors(
                    selectedLabelColor = DeepObsidian,
                    selectedContainerColor = BitcoinOrange,
                    labelColor = LightChalk
                )
            )

            InputChip(
                selected = apiInput == "Explain Web3 Lightning primitives",
                onClick = { viewModel.setApiInput("Explain Web3 Lightning primitives") },
                label = { Text("LDK primitives", fontSize = 10.sp) },
                colors = InputChipDefaults.inputChipColors(
                    selectedLabelColor = DeepObsidian,
                    selectedContainerColor = BitcoinOrange,
                    labelColor = LightChalk
                )
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = apiInput,
            onValueChange = { viewModel.setApiInput(it) },
            label = { Text("AI Input Instructions") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BitcoinOrange,
                unfocusedBorderColor = MutedSlate,
                focusedTextColor = LightChalk
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Price per execution: 5 Sats", color = AccentGold, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            Button(
                onClick = { viewModel.runPayPerUseApi() },
                colors = ButtonDefaults.buttonColors(containerColor = BitcoinOrange),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Send, contentDescription = "Send prompt query", tint = DeepObsidian, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pay & Query API", color = DeepObsidian, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Lumina Computation Terminal", color = LightChalk, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .background(DarkSteel, RoundedCornerShape(8.dp))
                .border(1.dp, MutedSlate.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            if (apiOutput == null) {
                Text(
                    text = "$ awaiting payload execution. Click 'Pay & Query API' to execute real lightning handshake invoice.",
                    color = MutedSlate,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            } else {
                Text(
                    text = apiOutput ?: "",
                    color = CryptoGreen,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
fun CoffeeMetadataStoreScreen(viewModel: SatoshiViewModel) {
    var selectedItemPrice by remember { mutableStateOf(0L) }
    var selectedItemName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("SATOSHI COFFEE HOUSE", color = BitcoinOrange, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("Metadata detection scanning sandbox", color = MutedSlate, fontSize = 10.sp)

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            "This mock shop is declared entirely via HTML static metadata tags without external databases or checkout systems. Satoshi Browser automatically scans the DOM structure, detects purchasable items, and renders direct transaction buttons.",
            fontSize = 11.sp,
            color = MutedSlate,
            lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        val menuItems = listOf(
            Triple("Cypherpunk Espresso", 45L, "Rich concentrated shot of single-origin beans"),
            Triple("Lightning Gold Latte", 60L, "Steamed oatmilk combined with gold-leaf flakes"),
            Triple("LDK Ice Cold Brew", 75L, "Cold extracted for 24 hours over frozen nitrogen")
        )

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            menuItems.forEach { (name, price, desc) ->
                val isSelected = selectedItemName == name
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) BitcoinOrange.copy(alpha = 0.08f) else SlateCard
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedItemName = name
                            selectedItemPrice = price
                        }
                        .border(
                            width = 1.dp,
                            color = if (isSelected) BitcoinOrange else Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.Bold, color = LightChalk, fontSize = 13.sp)
                            Text(desc, color = MutedSlate, fontSize = 11.sp)
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BitcoinOrange.copy(alpha = 0.15f)),
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Text(
                                "$price Sats",
                                color = BitcoinOrange,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (selectedItemName.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BitcoinOrange.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                    .border(1.dp, BitcoinOrange, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Cafe metadata match", tint = BitcoinOrange, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "⚡ Browser Commerce Native Bar Intercept",
                            color = BitcoinOrange,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Metadata Tag Auto-Detected:\n" +
                                "<meta name=\"satoshi-product\" content=\"${selectedItemName}\" price_sats=\"${selectedItemPrice}\" />",
                        color = MutedSlate,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        lineHeight = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.requestPaymentPrompt(
                                merchantName = "Satoshi Coffee House",
                                description = "Native checkout: $selectedItemName",
                                amountSats = selectedItemPrice,
                                invoice = "lnbc${selectedItemPrice}0p1coffeehouse...",
                                pageUrl = "satoshi://coffee-shop"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BitcoinOrange),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Instant Native Buy: $selectedItemName", color = DeepObsidian, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CustomWebViewSimulator(url: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Icon(Icons.Default.Home, contentDescription = "External site", tint = MutedSlate, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "Satoshi Engine Intercept",
                color = LightChalk,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "URL: $url loaded into Secure Sandboxed WebView container. Injected 'window.satoshi' namespace successfully inside DOM elements.",
                color = MutedSlate,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                lineHeight = 15.sp
            )
        }
    }
}

// ==========================================
// LDK WALLET & CHANNELS MANAGEMENT TAB
// ==========================================

@Composable
fun WalletTab(viewModel: SatoshiViewModel) {
    val onChainBal by viewModel.onChainBalanceSats.collectAsState()
    val rawTxs by viewModel.transactions.collectAsState()
    val activeChannels by viewModel.channels.collectAsState()
    val isNodeOperating by viewModel.isNodeOperating.collectAsState()
    val syncProgress by viewModel.syncProgress.collectAsState()

    var showOpenChannelDialog by remember { mutableStateOf(false) }
    var showDepositDialog by remember { mutableStateOf(false) }

    val lightningBalSats = activeChannels.sumOf { if (it.active) it.localBalanceSats else 0L }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("LDK CORE WALLET", color = BitcoinOrange, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text("Built-in Lightning Node (LDK/rust-bitcoin)", color = MutedSlate, fontSize = 10.sp)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isNodeOperating) "NODE ONLINE" else "OFFLINE",
                    color = if (isNodeOperating) CryptoGreen else AlertRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(end = 8.dp)
                )

                IconButton(
                    onClick = { viewModel.toggleNode() },
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            if (isNodeOperating) CryptoGreen.copy(alpha = 0.15f) else AlertRed.copy(alpha = 0.15f),
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = "Power node toggle",
                        tint = if (isNodeOperating) CryptoGreen else AlertRed,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateCard, RoundedCornerShape(8.dp))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Refresh, contentDescription = "Sync icon", tint = if (syncProgress == 100f) CryptoGreen else BitcoinOrange, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (syncProgress == 100f) "✓ LDK Node fully synchronized with Bitcoin network block headers." else "Synchronizing headers: ${syncProgress}%...",
                color = if (syncProgress == 100f) CryptoGreen else BitcoinOrange,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.weight(1f))
            if (syncProgress < 100f) {
                CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp, color = BitcoinOrange)
            } else {
                Text(
                    "Sync now",
                    color = LightningBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { viewModel.syncFully() }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                modifier = Modifier
                    .weight(1f)
                    .border(width = 1.dp, color = LightningBlue.copy(alpha = 0.3f), shape = RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(6.dp).background(LightningBlue, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Lightning Total", fontSize = 11.sp, color = LightningBlue, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "$lightningBalSats Sats",
                        fontWeight = FontWeight.ExtraBold,
                        color = LightChalk,
                        fontSize = 20.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text("Liquid channels cap", fontSize = 10.sp, color = MutedSlate)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                modifier = Modifier
                    .weight(1f)
                    .border(width = 1.dp, color = BitcoinOrange.copy(alpha = 0.3f), shape = RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(6.dp).background(BitcoinOrange, CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("On-Chain wallet", fontSize = 11.sp, color = BitcoinOrange, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "$onChainBal Sats",
                        fontWeight = FontWeight.ExtraBold,
                        color = LightChalk,
                        fontSize = 20.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text("BTC balance", fontSize = 10.sp, color = MutedSlate)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { showDepositDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = BitcoinOrange),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Deposit BTC", color = DeepObsidian, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }

            Button(
                onClick = { showOpenChannelDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = LightningBlue),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = "Add node peer", tint = DeepObsidian, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Open LDK Channel", color = DeepObsidian, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("LDK Lightning Channels", color = LightChalk, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))

        if (activeChannels.isEmpty()) {
            Text(
                "No channels established yet. Open a lightning channel with a peer to route payments instantly.",
                color = MutedSlate,
                fontSize = 11.sp
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                activeChannels.forEach { channel ->
                    ChannelItemCard(channel = channel, onCloseChannel = { viewModel.closeChannel(channel) })
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("Transaction History", color = LightChalk, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))

        if (rawTxs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Cryptographic ledger is empty.", color = MutedSlate, fontSize = 12.sp)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rawTxs.forEach { tx ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SlateCard),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(tx.memo, fontWeight = FontWeight.Bold, color = LightChalk, fontSize = 12.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (tx.type == "OUTGOING") "⚡ LN OUTGOING" else "✓ ON-CHAIN INCOMING",
                                        color = if (tx.type == "OUTGOING") LightningBlue else CryptoGreen,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Status: ${tx.status}", color = MutedSlate, fontSize = 9.sp)
                                }
                            }

                            Text(
                                text = (if (tx.type == "OUTGOING") "-" else "+") + "${tx.amountSats} Sats",
                                color = if (tx.type == "OUTGOING") AlertRed else CryptoGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDepositDialog) {
        DepositModal(
            onDismiss = { showDepositDialog = false },
            onDeposit = { amount ->
                viewModel.fundOnChain(amount)
                showDepositDialog = false
            }
        )
    }

    if (showOpenChannelDialog) {
        OpenChannelModal(
            onDismiss = { showOpenChannelDialog = false },
            onOpen = { peerId, capacity ->
                viewModel.openChannel(peerId, capacity)
                showOpenChannelDialog = false
            }
        )
    }
}

@Composable
fun ChannelItemCard(channel: LnkChannel, onCloseChannel: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = MutedSlate.copy(alpha = 0.2f), shape = RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Peer: ${channel.nodeId.take(16)}...", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = LightChalk)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(if (channel.active) CryptoGreen else AlertRed, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (channel.active) "Channel Active" else "Inactive", color = if (channel.active) CryptoGreen else AlertRed, fontSize = 10.sp)
                    }
                }

                Button(
                    onClick = onCloseChannel,
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text("Close", color = AlertRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val distribution = channel.localBalanceSats.toFloat() / channel.capacitySats.toFloat()
            LinearProgressIndicator(
                progress = distribution,
                color = LightningBlue,
                trackColor = BitcoinOrange,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Local Balance (You)", fontSize = 9.sp, color = LightningBlue, fontWeight = FontWeight.Bold)
                    Text("${channel.localBalanceSats} Sats", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = LightChalk, fontWeight = FontWeight.Bold)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Remote Balance (Peer)", fontSize = 9.sp, color = BitcoinOrange, fontWeight = FontWeight.Bold)
                    Text("${channel.remoteBalanceSats} Sats", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = LightChalk, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DepositModal(onDismiss: () -> Unit, onDeposit: (Long) -> Unit) {
    var amountString by remember { mutableStateOf("25000") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BitcoinOrange.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Simulate On-Chain BTC Funding", color = BitcoinOrange, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Add fake testnet satoshis to your browser's underlying on-chain key-pair.", color = MutedSlate, fontSize = 11.sp)

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountString,
                    onValueChange = { amountString = it },
                    label = { Text("Amount (Satoshis)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BitcoinOrange,
                        unfocusedBorderColor = MutedSlate,
                        focusedTextColor = LightChalk
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = androidx.compose.foundation.BorderStroke(1.dp, LightningBlue.copy(alpha = 0.4f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LightningBlue)
                    ) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountString.toLongOrNull() ?: 0L
                            onDeposit(amt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BitcoinOrange)
                    ) {
                        Text("Simulate Deposit", color = DeepObsidian, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun OpenChannelModal(onDismiss: () -> Unit, onOpen: (String, Long) -> Unit) {
    var peerPubkey by remember { mutableStateOf("02b28cf9dbbc11a91e5509d6c41551a1e4c8bc2dc6e3ad6ef9700aa6fc3aed0a3c") }
    var capacityString by remember { mutableStateOf("30000") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, LightningBlue.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Open LDK Lightning Channel", color = LightningBlue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Establishes a bilateral multi-sig channel over LDK with a routing node peer.", color = MutedSlate, fontSize = 11.sp)

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = peerPubkey,
                    onValueChange = { peerPubkey = it },
                    label = { Text("Peer Node Pubkey (Hex)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LightningBlue,
                        unfocusedBorderColor = MutedSlate,
                        focusedTextColor = LightChalk
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = capacityString,
                    onValueChange = { capacityString = it },
                    label = { Text("Channel Capacity (Satoshis)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LightningBlue,
                        unfocusedBorderColor = MutedSlate,
                        focusedTextColor = LightChalk
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = androidx.compose.foundation.BorderStroke(1.dp, LightningBlue.copy(alpha = 0.4f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LightningBlue)
                    ) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val capacity = capacityString.toLongOrNull() ?: 0L
                            onOpen(peerPubkey, capacity)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LightningBlue)
                    ) {
                        Text("Negotiate LDK", color = DeepObsidian, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// CENTRAL COGNITIVE DEVELOPER API TAB
// ==========================================

@Composable
fun DeveloperApiTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("SATOSHI CLIENT INTERNALS", color = BitcoinOrange, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Text("Native Client JavaScript and DOM Primitives specification", color = MutedSlate, fontSize = 10.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Text("1. Native JS APIs injected in window.satoshi", color = LightChalk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Every frame inside the Chromium sandbox gets standard capabilities injected directly from the host Tauri broker process.",
            fontSize = 11.sp,
            color = MutedSlate,
            lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        CodeSnippetBlock(
            code = "// Query user LDK public key and general parameters\n" +
                    "const info = await window.satoshi.getWalletInfo();\n" +
                    "console.log(info.node_pubkey); // 03a1b8c4c...\n\n" +
                    "// Prompt user for invoice payment. Generates browser-native sheet.\n" +
                    "try {\n" +
                    "  const paymentProof = await window.satoshi.payInvoice('lnbc10p1...');\n" +
                    "  if (paymentProof.settles) {\n" +
                    "    unlockContent(paymentProof.preimage);\n" +
                    "  }\n" +
                    "} catch (err) {\n" +
                    "  console.error('Payment rejected or routing failed');\n" +
                    "}"
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text("2. Declaring Catalog Items via Web Meta Primitives", color = LightChalk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Websites declare physical/digital checkout inventory via simple non-intrusive semantic meta tags. The Satoshi Core parser intercepts these and mounts the Checkout overlay dynamically.",
            fontSize = 11.sp,
            color = MutedSlate,
            lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        CodeSnippetBlock(
            code = "<!-- Decoil card standard product item metadata declarations -->\n" +
                    "<head>\n" +
                    "  <meta name=\"satoshi-commerce-enable\" content=\"true\" />\n" +
                    "  <meta name=\"satoshi-product\" \n" +
                    "        content=\"Organic Cypher Espresso\" \n" +
                    "        price_sats=\"45\" \n" +
                    "        currency=\"SATS\" \n" +
                    "        merchant_node=\"02b28cf9dbbc...\" />\n" +
                    "</head>"
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text("3. Streaming Payment Channels (WebLN/L402 spec)", color = LightChalk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "For video/audio tracks or real-time continuous computing, websites stream lightning invoice micro-payloads through WebSocket sockets. Pre-approved user budgets absorb these seamlessly.",
            fontSize = 11.sp,
            color = MutedSlate,
            lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        CodeSnippetBlock(
            code = "// Establishes websocket stream connection with node billing engine\n" +
                    "const stream = window.satoshi.createPaymentStream({\n" +
                    "  domain: 'streamtune.labs',\n" +
                    "  maxSatsPerSecond: 1\n" +
                    "});\n" +
                    "stream.on('invoice', (inv) => {\n" +
                    "  // Node automatically clears invoice background if budget permits\n" +
                    "  console.log('Continuous tick paid correctly!');\n" +
                    "});"
        )
    }
}

@Composable
fun CodeSnippetBlock(code: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSteel, RoundedCornerShape(8.dp))
            .border(1.dp, MutedSlate.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Text(
            text = code,
            color = LightningBlue,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )
    }
}

// ==========================================
// CORE SECURE ARCHITECTURE DIAGRAM & ROADMAP TAB
// ==========================================

@Composable
fun ArchitectureTab(viewModel: SatoshiViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("CORE ARCHITECTURE LAB", color = BitcoinOrange, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Text("Fully modular systems blueprint and implementation strategy", color = MutedSlate, fontSize = 10.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Text("Satoshi Secure Process Broker Layout", color = LightChalk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, BitcoinOrange.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                .background(SlateCard)
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FlowBox(
                    title = "🔒 CORE PROCESS - HOST SPACE (TAURI / RUST)",
                    desc = "Supervises secure execution system memory. Governs physical LDK node threads, BIP32 seed generation, SQLite database layer, and handles encrypted IPC Broker queries securely.",
                    color = BitcoinOrange
                )

                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Dual side IPC connection broker flow", tint = MutedSlate, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Host IPC Broker Channel", color = MutedSlate, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = "Dual side IPC connection broker flow", tint = MutedSlate, modifier = Modifier.size(16.dp))
                    }
                }

                FlowBox(
                    title = "⚡ CHROMIUM VIEWPORT CONTROLLER (CEF SANDBOX)",
                    desc = "Isolated UI context loading external HTML, CSS and images. Dom binder automatically intercepts network requests, scans for metadata products, and forwards verified LN invoice intents.",
                    color = LightningBlue
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("Satoshi Phased Roadmap: From MVP to Scale", color = LightChalk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Production-grade execution blueprint mapping out necessary technological transitions.",
            fontSize = 11.sp,
            color = MutedSlate,
            lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        val stages = listOf(
            Triple(
                "PHASE 1: Core Node Configuration & Local State (MVP)",
                "Establish basic rust-bitcoin and LDK (Lightning Development Kit) background runtime. Set up secure SQLite persistent ledger containing channel state matrices & credential storage.",
                true
            ),
            Triple(
                "PHASE 2: Sandboxed DOM Injections & Host Broker IPC",
                "Engineer the secure Tauri Broker IPC channel. Inject context-isolated JavaScript libraries under window.satoshi namespace across all Chromium CEF instances to let pages fetch invoices dynamically.",
                true
            ),
            Triple(
                "PHASE 3: Streaming Lightning Protocol (LSP) & WebLN Integration",
                "Integrate continuous stream websocket sockets to coordinate seconds-based payments. Deploy pre-approved user budget bounds dynamically to streamline micropayments without prompts.",
                false
            ),
            Triple(
                "PHASE 4: Production Harden & Sandboxed Extensions",
                "Deploy complete cryptographic isolation. Restrict web domains from accessing key nodes unless explicit permissions are given. Submit final binaries for security audits & App Icon generation.",
                false
            )
        )

        stages.forEachIndexed { idx, (title, details, isComplete) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = if (isComplete) Icons.Default.CheckCircle else Icons.Default.Info,
                        contentDescription = "Phase status check",
                        tint = if (isComplete) CryptoGreen else BitcoinOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            color = if (isComplete) CryptoGreen else LightChalk,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = details,
                            color = MutedSlate,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FlowBox(title: String, desc: String, color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSteel, RoundedCornerShape(8.dp))
            .border(width = 1.dp, color = color.copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, color = LightChalk, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

// ==========================================
// DETECTED MICRO-PAYMENT Sheet Prompt Overlay
// ==========================================

@Composable
fun PaymentPromptDialog(intent: SatoshiViewModel.PaymentIntent, onApprove: () -> Unit, onDecline: () -> Unit) {
    Dialog(
        onDismissRequest = onDecline,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f)) // Beautiful dark translucent overlay modal background
                .clickable { onDecline() },
            contentAlignment = Alignment.BottomCenter
        ) {
            Card(
                shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), 
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = false) {} // block outside clicks
                    .border(
                        width = 1.dp,
                        color = SlateCard,
                        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
                    )
                    .testTag("satoshi_payment_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .padding(horizontal = 24.dp, vertical = 20.dp)
                        .padding(bottom = 16.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    // Small elegant top drag pull handle bar
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(48.dp)
                            .height(6.dp)
                            .clip(CircleShape)
                            .background(SlateCard)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // "Satoshi Pay" Title + Lightning badge icon
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "Satoshi Pay",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (intent.isStreaming) "Streaming micropayment requested" else "On-demand payment requested",
                                color = MutedSlate,
                                fontSize = 14.sp
                            )
                        }

                        // Circular background shape with Bitcoin logo
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF381E72))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "₿",
                                color = BitcoinOrange,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Deep-set interior Amount card
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = DeepObsidian),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SlateCard, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "AMOUNT",
                                    color = MutedSlate,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "via LDK Node",
                                    color = BitcoinOrange,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Text(
                                    text = String.format("%,d", intent.amountSats),
                                    color = Color.White,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "sats",
                                    color = BitcoinOrange,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(bottom = 3.dp)
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                val usdValue = intent.amountSats.toDouble() * 0.00062
                                Text(
                                    text = String.format("~$%.2f", usdValue),
                                    color = MutedSlate,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(bottom = 3.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Green verification point (The Bitcoin Magazine Premium API)
                    Row(
                        modifier = Modifier.padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(CryptoGreen)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "${intent.merchantName} — ${intent.description}",
                            color = LightChalk,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Primary Button: Confirm & Unlock
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BitcoinOrange,
                            contentColor = Color(0xFF381E72)
                        ),
                        shape = CircleShape,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("approve_payment_button")
                    ) {
                        Text(
                            text = "Confirm & Unlock",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Secondary button: Cancel payment
                    Button(
                        onClick = onDecline,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent,
                            contentColor = BitcoinOrange
                        ),
                        shape = CircleShape,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("decline_payment_button")
                    ) {
                        Text(
                            text = "Cancel payment",
                            fontWeight = FontWeight.Medium,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}
