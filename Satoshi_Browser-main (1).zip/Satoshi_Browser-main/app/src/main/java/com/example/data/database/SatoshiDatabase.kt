package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [WalletTx::class, LnkChannel::class, PurchasedAccess::class],
    version = 1,
    exportSchema = false
)
abstract class SatoshiDatabase : RoomDatabase() {
    abstract fun walletDao(): WalletDao
    abstract fun channelDao(): ChannelDao
    abstract fun purchasedAccessDao(): PurchasedAccessDao

    companion object {
        @Volatile
        private var INSTANCE: SatoshiDatabase? = null

        fun getDatabase(context: Context): SatoshiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SatoshiDatabase::class.java,
                    "satoshi_browser_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
