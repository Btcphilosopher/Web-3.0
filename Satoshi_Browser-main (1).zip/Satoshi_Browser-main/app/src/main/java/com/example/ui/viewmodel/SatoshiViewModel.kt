package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.LnkChannel
import com.example.data.database.PurchasedAccess
import com.example.data.database.SatoshiDatabase
import com.example.data.database.WalletTx
import com.example.data.repository.SatoshiRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class SatoshiViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: SatoshiRepository

    // Database Flows
    val transactions: StateFlow<List<WalletTx>>
    val channels: StateFlow<List<LnkChannel>>
    val purchases: StateFlow<List<PurchasedAccess>>

    // General Wallet State
    private val _onChainBalanceSats = MutableStateFlow(85000L)
    val onChainBalanceSats: StateFlow<Long> = _onChainBalanceSats.asStateFlow()

    private val _isNodeOperating = MutableStateFlow(true)
    val isNodeOperating: StateFlow<Boolean> = _isNodeOperating.asStateFlow()

    private val _syncProgress = MutableStateFlow(100f) // 100% Synced
    val syncProgress: StateFlow<Float> = _syncProgress.asStateFlow()

    val nodeId = "03a1b8c4c77e2d78f219cd433bc93a8d9a101f3db983ba2d0bc7b8d4f6c4ff5512"

    // Browser and Payment Flow State
    private val _currentUrl = MutableStateFlow("satoshi://paywall-news")
    val currentUrl: StateFlow<String> = _currentUrl.asStateFlow()

    private val _isWebPageLoading = MutableStateFlow(false)
    val isWebPageLoading: StateFlow<Boolean> = _isWebPageLoading.asStateFlow()

    // Interactive payment intent sheet model
    data class PaymentIntent(
        val merchantName: String,
        val description: String,
        val amountSats: Long,
        val invoice: String,
        val pageUrl: String,
        val isStreaming: Boolean = false
    )

    private val _activePaymentIntent = MutableStateFlow<PaymentIntent?>(null)
    val activePaymentIntent: StateFlow<PaymentIntent?> = _activePaymentIntent.asStateFlow()

    // Pre-approved streaming and API budgets: Domain -> remaining sats allowed
    private val _budgets = MutableStateFlow<Map<String, Long>>(emptyMap())
    val budgets: StateFlow<Map<String, Long>> = _budgets.asStateFlow()

    // Real-time payment ticker logs
    private val _paymentLogs = MutableStateFlow<List<String>>(emptyList())
    val paymentLogs: StateFlow<List<String>> = _paymentLogs.asStateFlow()

    // State of loaded mockup content (e.g. if paid access is verified, stream plays, API resolves)
    private val _isNewsUnlocked = MutableStateFlow(false)
    val isNewsUnlocked: StateFlow<Boolean> = _isNewsUnlocked.asStateFlow()

    private val _isAudioStreaming = MutableStateFlow(false)
    val isAudioStreaming: StateFlow<Boolean> = _isAudioStreaming.asStateFlow()

    private val _streamTicksPaid = MutableStateFlow(0)
    val streamTickCount: StateFlow<Int> = _streamTicksPaid.asStateFlow()

    private val _apiInput = MutableStateFlow("Translate 'Hello planet' to Spanish")
    val apiInput: StateFlow<String> = _apiInput.asStateFlow()

    private val _apiOutput = MutableStateFlow<String?>(null)
    val apiOutput: StateFlow<String?> = _apiOutput.asStateFlow()

    // Streaming payments active job
    private var streamingJob: Job? = null

    init {
        val database = SatoshiDatabase.getDatabase(application)
        repository = SatoshiRepository(
            database.walletDao(),
            database.channelDao(),
            database.purchasedAccessDao()
        )

        transactions = repository.allTransactions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        channels = repository.allChannels.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        purchases = repository.allPurchases.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Seed initial data if DB is completely empty
        seedInitialData()
    }

    private fun seedInitialData() {
        viewModelScope.launch {
            val existingChannels = repository.allChannels.first()
            if (existingChannels.isEmpty()) {
                // Insert mock channel
                repository.insertChannel(
                    LnkChannel(
                        nodeId = "02b28cf9dbbc11a91e5509d6c41551a1e4c8bc2dc6e3ad6ef9700aa6fc3aed0a3c",
                        capacitySats = 100000,
                        localBalanceSats = 40000,
                        remoteBalanceSats = 60000,
                        active = true
                    )
                )
                repository.insertChannel(
                    LnkChannel(
                        nodeId = "03612d19f29881ab7db39efc1cb2ba1e4cbcfdc281fa0eaceb37d8fac1f26aedab",
                        capacitySats = 50000,
                        localBalanceSats = 15000,
                        remoteBalanceSats = 35000,
                        active = true
                    )
                )

                // Insert mock transactions
                repository.insertTransaction(
                    WalletTx(
                        amountSats = 50000,
                        type = "OUTGOING",
                        memo = "Channel Funded - Peer Node",
                        status = "SUCCESS",
                        destinationNode = "02b28cf..."
                    )
                )
                repository.insertTransaction(
                    WalletTx(
                        amountSats = 1500,
                        type = "INCOMING",
                        memo = "Satoshi SDK Sandbox Reward",
                        status = "SUCCESS"
                    )
                )
            }
        }
    }

    // Navigation and Page triggers
    fun navigateTo(url: String) {
        viewModelScope.launch {
            _isWebPageLoading.value = true
            _currentUrl.value = url
            delay(400) // Simulate network/layout engine latency
            _isWebPageLoading.value = false

            // Check if page access was already paid/purchased
            checkUrlAccess(url)
        }
    }

    private suspend fun checkUrlAccess(url: String) {
        val purchase = repository.getPurchaseByUrl(url)
        if (purchase != null) {
            if (url.startsWith("satoshi://paywall-news")) {
                _isNewsUnlocked.value = true
                addLog("✓ Access verified for URL: $url (Paid ${purchase.amountPaid} Sats previously)")
            }
        } else {
            if (url.startsWith("satoshi://paywall-news")) {
                _isNewsUnlocked.value = false
            }
        }
    }

    // Toggle simulated LDK Node Status
    fun toggleNode() {
        _isNodeOperating.update { !it }
        val status = if (_isNodeOperating.value) "RUNNING" else "SHUTDOWN"
        addLog("LDK Node Status Changed: $status")
        if (!_isNodeOperating.value) {
            stopStreaming()
        }
    }

    fun syncFully() {
        viewModelScope.launch {
            _syncProgress.value = 0f
            while (_syncProgress.value < 100f) {
                _syncProgress.value += 12.5f
                delay(120)
            }
            _syncProgress.value = 100f
            addLog("✓ Synchronized Lightning status block headers successfully.")
        }
    }

    // On-Chain Wallet interaction
    fun fundOnChain(amount: Long) {
        _onChainBalanceSats.update { it + amount }
        addLog("Received $amount Sats on-chain. Generating block confirmation...")
        viewModelScope.launch {
            repository.insertTransaction(
                WalletTx(
                    amountSats = amount,
                    type = "INCOMING",
                    memo = "On-Chain Deposit",
                    status = "SUCCESS"
                )
            )
        }
    }

    // Add channel (Simulating LDK Peer handshake + anchor funding)
    fun openChannel(peerId: String, capacity: Long) {
        if (_onChainBalanceSats.value < capacity + 500) {
            addLogs("⚠ Error funding channel: Insufficient on-chain balance (Requires capital + 500 sat fee).")
            return
        }

        _onChainBalanceSats.update { it - (capacity + 500) }

        viewModelScope.launch {
            val newChannel = LnkChannel(
                nodeId = if (peerId.length < 10) "03${UUID.randomUUID().toString().replace("-", "").take(62)}" else peerId,
                capacitySats = capacity,
                localBalanceSats = capacity - 1000, // Reserve balance is reserved
                remoteBalanceSats = 1000,
                active = true
            )
            repository.insertChannel(newChannel)
            repository.insertTransaction(
                WalletTx(
                    amountSats = capacity + 500,
                    type = "OUTGOING",
                    memo = "LDK Channel Opened with Peer",
                    status = "SUCCESS",
                    destinationNode = peerId.take(15) + "..."
                )
            )
            addLog("✓ LDK Channel successfully negotiated and funded. Anchor block generated.")
        }
    }

    fun closeChannel(channel: LnkChannel) {
        viewModelScope.launch {
            _onChainBalanceSats.update { it + channel.localBalanceSats }
            repository.deleteChannel(channel)
            repository.insertTransaction(
                WalletTx(
                    amountSats = channel.localBalanceSats,
                    type = "INCOMING",
                    memo = "Mutual Channel Close settlement",
                    status = "SUCCESS",
                    destinationNode = channel.nodeId.take(15) + "..."
                )
            )
            addLog("✓ Closed channel with peer. Settled satoshis back to on-chain address.")
        }
    }

    // Trigger purchase intents automatically detected on the site (Commerce Primitives)
    fun requestPaymentPrompt(merchantName: String, description: String, amountSats: Long, invoice: String, pageUrl: String, isStreaming: Boolean = false) {
        if (!_isNodeOperating.value) {
            addLogs("⚠ Payment request blocked: LDK Node is currently offline!")
            return
        }

        // Check if there is already a pre-approved budget for this domain to bypass prompts (streaming/APIs)
        val host = getDomainName(pageUrl)
        val remainingBudget = _budgets.value[host] ?: 0L

        if (remainingBudget >= amountSats) {
            // Bypass prompt and auto pay!
            autoPayBudgeted(host, amountSats, merchantName, description, invoice, pageUrl, isStreaming)
        } else {
            // Trigger overlay prompt
            _activePaymentIntent.value = PaymentIntent(
                merchantName = merchantName,
                description = description,
                amountSats = amountSats,
                invoice = invoice,
                pageUrl = pageUrl,
                isStreaming = isStreaming
            )
        }
    }

    private fun autoPayBudgeted(domain: String, amount: Long, merchant: String, description: String, invoice: String, url: String, isStreaming: Boolean) {
        // Deduct from budget
        _budgets.update { current ->
            val updated = current.toMutableMap()
            val before = updated[domain] ?: 0L
            updated[domain] = (before - amount).coerceAtLeast(0)
            updated
        }

        // Execute payment
        executeSatoshiPayment(amount, merchant, description, invoice, url, isStreaming, isAutoPaid = true)
    }

    fun setPreApprovedBudget(domain: String, amountSats: Long) {
        _budgets.update { current ->
            val updated = current.toMutableMap()
            updated[domain] = amountSats
            updated
        }
        addLog("⚙ Configured Pre-Approved Budget of $amountSats Sats for domain: $domain")
    }

    fun approvePaymentIntent() {
        val intent = _activePaymentIntent.value ?: return
        _activePaymentIntent.value = null

        executeSatoshiPayment(
            amount = intent.amountSats,
            merchant = intent.merchantName,
            description = intent.description,
            invoice = intent.invoice,
            url = intent.pageUrl,
            isStreaming = intent.isStreaming,
            isAutoPaid = false
        )
    }

    fun rejectPaymentIntent() {
        val intent = _activePaymentIntent.value ?: return
        _activePaymentIntent.value = null
        addLog("✕ Payment of ${intent.amountSats} Sats rejected by the user.")
        if (intent.isStreaming) {
            stopStreaming()
        }
    }

    private fun executeSatoshiPayment(amount: Long, merchant: String, description: String, invoice: String, url: String, isStreaming: Boolean, isAutoPaid: Boolean) {
        viewModelScope.launch {
            // Find active channels to route the lightning HTLC
            val activeChList = repository.allChannels.first().filter { it.active && it.localBalanceSats >= amount }
            if (activeChList.isEmpty()) {
                addLog("✕ Router failed: Insufficient local balance across open channels to route $amount Sats!")
                _activePaymentIntent.value = null
                stopStreaming()
                return@launch
            }

            // Deduct from the first capable channel (Simulate LN routing HTLC lock & settle)
            val channelToRoute = activeChList.first()
            val updatedChannel = channelToRoute.copy(
                localBalanceSats = channelToRoute.localBalanceSats - amount,
                remoteBalanceSats = channelToRoute.remoteBalanceSats + amount
            )
            repository.updateChannel(updatedChannel)

            // Log Transaction
            val tx = WalletTx(
                amountSats = amount,
                type = "OUTGOING",
                memo = "LN Payment: $merchant ($description)",
                status = "SUCCESS",
                destinationNode = channelToRoute.nodeId.take(15) + "..."
            )
            repository.insertTransaction(tx)

            // Register access
            val purchase = PurchasedAccess(
                url = url,
                merchant = merchant,
                amountPaid = amount,
                accessKey = UUID.randomUUID().toString(),
                contentType = when {
                    url.startsWith("satoshi://paywall-news") -> "NEWS_ARTICLE"
                    url.startsWith("satoshi://streamtune") -> "AUDIO_STREAM"
                    else -> "API_SESSION"
                }
            )
            repository.insertPurchase(purchase)

            val triggerType = if (isAutoPaid) "[Auto-Budget Approved]" else "[User Prompt Approved]"
            val streamSuffix = if (isStreaming) " (Stream packet)" else ""
            addLog("✓ Settled LN Payment: $amount Satoshis paid to $merchant$streamSuffix $triggerType")

            // Unlock specific resources
            if (url.startsWith("satoshi://paywall-news")) {
                _isNewsUnlocked.value = true
            } else if (url.startsWith("satoshi://streamtune")) {
                _streamTicksPaid.update { it + 1 }
            } else if (url.startsWith("satoshi://lumina-api")) {
                // Execute Mock AI API call successfully
                executeMockApiCall()
            }
        }
    }

    // Audio Streaming Page specifics
    fun startStreamingMusic() {
        if (!_isNodeOperating.value) {
            addLogs("⚠ Cannot stream: Satoshi Browser LDK node is offline.")
            return
        }
        _isAudioStreaming.value = true
        addLog("▶ Initializing StreamTune web listener. Demanding streaming payments (1 sat / 3 seconds)")

        streamingJob?.cancel()
        streamingJob = viewModelScope.launch {
            while (_isAudioStreaming.value) {
                delay(3000)
                if (!_isAudioStreaming.value) break

                // Spark streaming invoice payment
                requestPaymentPrompt(
                    merchantName = "StreamTune Audio",
                    description = "Dynamic lightning micropayment stream (3 seconds fee)",
                    amountSats = 1,
                    invoice = "lnbc1u1p0streamtune...",
                    pageUrl = "satoshi://streamtune",
                    isStreaming = true
                )
            }
        }
    }

    fun stopStreaming() {
        _isAudioStreaming.value = false
        streamingJob?.cancel()
        streamingJob = null
        addLog("⏸ Music stream paused. Lightning payment stream terminated.")
    }

    // AI API Pay-per-use specifics
    fun setApiInput(text: String) {
        _apiInput.value = text
    }

    fun runPayPerUseApi() {
        if (!_isNodeOperating.value) {
            addLogs("⚠ Cannot execute API: LDK Node offline.")
            return
        }

        addLog("⚡ Lumina API: Requesting invoice of 5 Satoshis for prompt verification...")

        // Trigger Pay-per-use invoice request
        requestPaymentPrompt(
            merchantName = "Lumina AI Engine",
            description = "Execution payload billing for prompt: '${_apiInput.value}'",
            amountSats = 5,
            invoice = "lnbc50n1pw0luminaapi...",
            pageUrl = "satoshi://lumina-api"
        )
    }

    private fun executeMockApiCall() {
        viewModelScope.launch {
            _apiOutput.value = "Authenticating with Lightning L402 payment proof..."
            delay(800)
            _apiOutput.value = "[M3 Token validation SUCCESS]\n" +
                    "✓ Satisfied budget verification index.\n" +
                    "🔑 Pre-image proof generated successfully.\n" +
                    "🤖 Response:\n" +
                    "\"" + when(_apiInput.value.trim().lowercase()) {
                        "translate 'hello planet' to spanish" -> "Traducido al español: 'Hola planeta'."
                        "explain web3 lightning primitives" -> "Bitcoin and Lightning payments operate as natural HTTP/DOM protocols inside Satoshi Browser. Web masters use standard JS events to program payment requests natively."
                        else -> "Processing complete! Prompt: '${_apiInput.value}' has been run with certified Lightning execution credits."
                    } + "\""
            addLog("✓ Lumina AI prompt executed completely.")
        }
    }

    // Logging helpers
    private fun addLog(message: String) {
        val timeLabel = android.text.format.DateFormat.format("HH:mm:ss", System.currentTimeMillis())
        _paymentLogs.update { current ->
            listOf("[$timeLabel] $message") + current.take(45)
        }
    }

    private fun addLogs(message: String) {
        addLog(message)
    }

    private fun getDomainName(url: String): String {
        return url.replace("satoshi://", "").split("/").firstOrNull() ?: "unknown"
    }

    override fun onCleared() {
        super.onCleared()
        stopStreaming()
    }
}
