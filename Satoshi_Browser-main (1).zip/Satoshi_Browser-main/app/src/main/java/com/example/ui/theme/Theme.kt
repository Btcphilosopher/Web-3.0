package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SatoshiColorScheme = darkColorScheme(
    primary = ElegantPurpleAccent,
    onPrimary = ElegantDarkPurple,
    secondary = ElegantPurpleAccent,
    onSecondary = ElegantDarkPurple,
    tertiary = AccentGold,
    background = ElegantDarkBg,
    surface = ElegantDarkSurface,
    surfaceVariant = ElegantDarkBg, // Elegant Inner card/box container
    onBackground = ElegantDarkOnBg,
    onSurface = ElegantDarkOnSurface,
    outline = ElegantDarkOutline,
    error = AlertRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force premium dark theme by default
    dynamicColor: Boolean = false, // Disable dynamic colors to enforce brand identity
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SatoshiColorScheme,
        typography = Typography,
        content = content
    )
}
