package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.screens.SatoshiMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.SatoshiViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enable edge-to-edge drawing
        enableEdgeToEdge()
        
        // Instantiate our Satoshi Core ViewModel
        val viewModel = SatoshiViewModel(application)
        
        setContent {
            MyApplicationTheme {
                SatoshiMainScreen(viewModel = viewModel)
            }
        }
    }
}
