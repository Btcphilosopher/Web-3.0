package com.example.data.repository

import com.example.data.database.ChannelDao
import com.example.data.database.LnkChannel
import com.example.data.database.PurchasedAccess
import com.example.data.database.PurchasedAccessDao
import com.example.data.database.WalletDao
import com.example.data.database.WalletTx
import kotlinx.coroutines.flow.Flow

class SatoshiRepository(
    private val walletDao: WalletDao,
    private val channelDao: ChannelDao,
    private val purchasedAccessDao: PurchasedAccessDao
) {
    val allTransactions: Flow<List<WalletTx>> = walletDao.getAllTransactions()
    val allChannels: Flow<List<LnkChannel>> = channelDao.getAllChannels()
    val allPurchases: Flow<List<PurchasedAccess>> = purchasedAccessDao.getAllPurchases()

    suspend fun insertTransaction(tx: WalletTx) {
        walletDao.insertTransaction(tx)
    }

    suspend fun insertChannel(channel: LnkChannel) {
        channelDao.insertChannel(channel)
    }

    suspend fun updateChannel(channel: LnkChannel) {
        channelDao.updateChannel(channel)
    }

    suspend fun deleteChannel(channel: LnkChannel) {
        channelDao.deleteChannel(channel)
    }

    suspend fun insertPurchase(access: PurchasedAccess) {
        purchasedAccessDao.insertPurchase(access)
    }

    suspend fun getPurchaseByUrl(url: String): PurchasedAccess? {
        return purchasedAccessDao.getPurchaseByUrl(url)
    }

    suspend fun clearAll() {
        walletDao.deleteAll()
        channelDao.deleteAll()
        purchasedAccessDao.deleteAll()
    }
}
