package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette (Extracted from Design HTML)
val ElegantDarkBg = Color(0xFF1C1B1F)         // Charcoal dark body background
val ElegantDarkOnBg = Color(0xFFE6E1E5)       // Soft silver-lavender body text
val ElegantDarkSurface = Color(0xFF2B2930)    // Deep surface background for modals, bars, and sheets
val ElegantDarkOnSurface = Color(0xFFE6E1E5)  // Soft text on dark surface
val ElegantDarkOutline = Color(0xFF49454F)    // Border & secondary line contrast color
val ElegantPurpleAccent = Color(0xFFD0BCFF)   // Primary glowing lavender accent (secures, buttons)
val ElegantDarkPurple = Color(0xFF381E72)     // High-contrast primary action text/bg pair
val ElegantDarkTextMuted = Color(0xFFCAC4D0)  // Subtitles / medium-contrast text
val ElegantDarkLabel = Color(0xFF938F99)      // Muted label gray

// Mapping original variable names to new elegant dark tokens for continuous design preservation
val BitcoinOrange = ElegantPurpleAccent       // Dynamic purple accent from design
val LightningBlue = ElegantPurpleAccent       // Dynamic purple accent
val DeepObsidian = ElegantDarkBg              // Charcoal base bg
val DarkSteel = ElegantDarkSurface            // Deep surface bg
val SlateCard = ElegantDarkOutline            // Border/secondary container bg
val LightChalk = ElegantDarkOnBg              // Light silver text
val MutedSlate = ElegantDarkTextMuted         // Subtext color
val CryptoGreen = Color(0xFF4ADE80)           // Emerald green from design spec button/accent
val AlertRed = Color(0xFFF87171)              // Sweet soft red
val AccentGold = Color(0xFFF59E0B)            // Smooth amber/gold accent

