package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "blog_posts")
data class BlogPost(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val subtitle: String,
    val author: String,
    val content: String,
    val status: String, // "DRAFT", "PUBLISHED"
    val type: String, // "STANDARD", "INTERACTIVE", "CODE_INTEGRATED"
    val date: String,
    val readTimeMinutes: Int,
    // Multimedia state (saved locally)
    val youtubeVideoId: String = "",
    val hasVideo: Boolean = false,
    val videoChapterMarkers: String = "", // JSON-like list: "Title:TimeInSeconds..."
    val audioUrl: String = "",
    val hasAudio: Boolean = false,
    val audioPlaybackPositionMs: Long = 0L,
    val audioDurationMs: Long = 0L,
    val likesCount: Int = 0,
    val isLiked: Boolean = false
)

@Entity(tableName = "blog_plugins")
data class BlogPlugin(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // "PYTHON", "JAVASCRIPT", "WASM"
    val currentVersion: String,
    val description: String,
    val scriptContent: String,
    val isEnabled: Boolean = false,
    val permissionScope: String = "" // e.g., "READ_STORAGE, NETWORK_API"
)

@Entity(tableName = "hosting_servers")
data class HostingServer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val hostAddress: String,
    val port: Int = 8000,
    val deploymentType: String, // "VPS_FASTAPI", "DOCKER_CONTAINER", "GITHUB_PAGES"
    val isConnected: Boolean = false,
    val environmentVariables: String = "", // comma-separated KEY=VALUE pairs
    val lastDeployTimestamp: Long = 0L
)
