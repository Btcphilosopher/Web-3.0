package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

// Represents a bouncing physical vector ball inside our sandbox
data class PhysicsBall(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val color: Color,
    val radius: Float
)

@Composable
fun PhysicsGravitySandbox(
    gravity: Float,
    mass: Float,
    elasticity: Float,
    isSimulating: Boolean,
    modifier: Modifier = Modifier
) {
    // Keep 4 balls in state
    val balls = remember {
        mutableStateListOf(
            PhysicsBall(x = 100f, y = 100f, vx = 5f, vy = 2f, color = Color(0xFF64FFDA), radius = 18f),
            PhysicsBall(x = 300f, y = 150f, vx = -4f, vy = 4f, color = Color(0xFFE040FB), radius = 24f),
            PhysicsBall(x = 200f, y = 50f, vx = 3f, vy = -3f, color = Color(0xFF29B6F6), radius = 14f),
            PhysicsBall(x = 450f, y = 120f, vx = -2f, vy = 6f, color = Color(0xFFFFB300), radius = 20f)
        )
    }

    // Capture simulation ticks
    LaunchedEffect(isSimulating, gravity, mass, elasticity) {
        if (!isSimulating) return@LaunchedEffect
        var lastTime = System.currentTimeMillis()
        while (true) {
            val now = System.currentTimeMillis()
            val dt = (now - lastTime) / 1000f
            val boundedDt = dt.coerceAtMost(0.03f) // Cap delta time to prevent clipping
            lastTime = now

            for (i in balls.indices) {
                val ball = balls[i]
                
                // Acceleration representing gravity acting on mass
                // Modifying gravity modifier changes velocity vectors
                val forceGravity = gravity * (mass / 5.0f)
                ball.vy += forceGravity * boundedDt * 120f // scale factor

                // Update displacement
                ball.x += ball.vx * boundedDt * 100f
                ball.y += ball.vy * boundedDt * 100f

                // Boundaries collision representing device viewport frames
                val containerWidth = 600f // Hardcoded width of Canvas box
                val containerHeight = 400f // Hardcoded height of Canvas box

                // Bounce horizontal
                if (ball.x - ball.radius < 0) {
                    ball.x = ball.radius
                    ball.vx = -ball.vx * elasticity
                } else if (ball.x + ball.radius > containerWidth) {
                    ball.x = containerWidth - ball.radius
                    ball.vx = -ball.vx * elasticity
                }

                // Bounce vertical (ground & sky)
                if (ball.y - ball.radius < 0) {
                    ball.y = ball.radius
                    ball.vy = -ball.vy * elasticity
                } else if (ball.y + ball.radius > containerHeight) {
                    ball.y = containerHeight - ball.radius
                    ball.vy = -ball.vy * elasticity
                    // Friction damping on ground rolling
                    ball.vx *= 0.98f
                }
            }
            delay(16) // tick roughly 60fps
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF444444), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Live Sandbox Execution Viewport (HTML6 Particle Compiler)",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color(0xFFFFB300),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Canvas drawing
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF121212))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Let's sweep current balls list
                    for (ball in balls) {
                        // Coordinates map to canvas width/height
                        // We scale coordinates proportional to actual container bounds
                        val normX = (ball.x / 600f) * size.width
                        val normY = (ball.y / 400f) * size.height
                        val normRadius = (ball.radius / 600f) * size.width

                        // Draw vector balls
                        drawCircle(
                            color = ball.color,
                            radius = normRadius.coerceAtLeast(6f),
                            center = Offset(normX, normY)
                        )

                        // Draw vector trails
                        drawLine(
                            color = ball.color.copy(alpha = 0.4f),
                            start = Offset(normX, normY),
                            end = Offset(normX - ball.vx * 1.5f, normY - ball.vy * 1.5f),
                            strokeWidth = 3f
                        )
                    }

                    // Draw floor warning indicator grid
                    drawLine(
                        color = Color(0xFF333333),
                        start = Offset(0f, size.height - 2f),
                        end = Offset(size.width, size.height - 2f),
                        strokeWidth = 4f
                    )
                }

                // Overlay details
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .background(Color(0xE0000000), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "G: ${String.format("%.1f", gravity)}m/s² | Mass: ${String.format("%.1f", mass)}kg",
                        color = Color.LightGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Informative parameters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Interactive Live Widgets:",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold
                )
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSimulating) Color(0xFF64FFDA) else Color.Red)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isSimulating) "SANDBOX RUNNING" else "PAUSED",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = if (isSimulating) Color(0xFF64FFDA) else Color.Red
                    )
                }
            }
        }
    }
}

@Composable
fun AudioWaveformVisualizer(
    isPlaying: Boolean,
    currentTimeMs: Long,
    totalTimeMs: Long,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // Generate wave peaks mock once
    val wavePeaks = remember { List(40) { Random.nextFloat().coerceIn(0.15f, 0.95f) } }
    
    // Wave animation offsets
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2 * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF333333), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "TECHNICAL BRIEFING PODCAST",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF9E9E9E),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Sovereign Hosting & HLS Architecture",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFF0D47A1),
                ) {
                    Text(
                        text = "HLS FLAC",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Waveform Box with dynamic click-seek
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF0F0F0F))
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val fraction = (offset.x / size.width).coerceIn(0f, 1f)
                            onSeek(fraction)
                        }
                    }
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val gap = 4.dp.toPx()
                    val barWidth = (size.width - (gap * (wavePeaks.size - 1))) / wavePeaks.size
                    val timeFraction = currentTimeMs.toFloat() / totalTimeMs.toFloat()

                    for (i in wavePeaks.indices) {
                        val peak = wavePeaks[i]
                        // Bouncing dynamic scaling if playing
                        val activeScale = if (isPlaying) {
                            1f + 0.18f * kotlin.math.sin(waveOffset + i * 0.8).toFloat()
                        } else {
                            1f
                        }
                        
                        val rawHeight = size.height * peak * activeScale
                        val barHeight = rawHeight.coerceIn(8.dp.toPx(), size.height * 0.9f)
                        val xOffset = i * (barWidth + gap)
                        val yOffset = (size.height - barHeight) / 2f

                        // Colors active or outline depending on track seeker position
                        val isPlayed = (i.toFloat() / wavePeaks.size) <= timeFraction
                        val color = if (isPlayed) {
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF29B6F6), Color(0xFF0288D1))
                            )
                        } else {
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF333333), Color(0xFF444444))
                            )
                        }

                        drawRect(
                            brush = color,
                            topLeft = Offset(xOffset, yOffset),
                            size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Play progress text
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatTime(currentTimeMs),
                    color = Color.Gray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )

                Text(
                    text = formatTime(totalTimeMs),
                    color = Color.Gray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            }
        }
    }
}

// Format MS to standard readable representation Minutes:Seconds
fun formatTime(ms: Long): String {
    val totalSecs = ms / 1000
    val mins = totalSecs / 60
    val secs = totalSecs % 60
    return String.format("%02d:%02d", mins, secs)
}

@Composable
fun TerminalConsole(
    logs: List<String>,
    isProcessing: Boolean,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    // Auto-scroll when logs change
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF333333), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0E17)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF131A26))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Terminal",
                        tint = Color(0xFF64FFDA),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "nexus-cli@sovereign-node: ~",
                        color = Color.LightGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                // Indicators
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFFF5F56)))
                    Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFFFBD2E)))
                    Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF27C93F)))
                }
            }

            // Screen
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .padding(8.dp)
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(logs) { log ->
                        val logColor = when {
                            log.startsWith("[SUCCESS]") -> Color(0xFF27C93F)
                            log.startsWith("[DOCKER]") || log.startsWith("[VPS]") -> Color(0xFF29B6F6)
                            log.startsWith("[NEXUS-CLI]") -> Color(0xFFFFB300)
                            log.contains("error") || log.contains("failed") -> Color(0xFFFF5F56)
                            log.startsWith("user@nexus") -> Color(0xFF00E676)
                            else -> Color(0xFFE0E0E0)
                        }
                        
                        Text(
                            text = log,
                            color = logColor,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        )
                    }
                    
                    // Processing cursor
                    if (isProcessing) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(10.dp),
                                    strokeWidth = 1.5.dp,
                                    color = Color(0xFF64FFDA)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Processing compilation pipeline steps...",
                                    color = Color(0xFF888888),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
