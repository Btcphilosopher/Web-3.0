package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BlogPost
import com.example.ui.components.AudioWaveformVisualizer
import com.example.ui.components.PhysicsGravitySandbox
import com.example.ui.viewmodel.BlogViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    post: BlogPost,
    viewModel: BlogViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val executionLogs by viewModel.executionOutput.collectAsState()
    val isExecutingCode by viewModel.isExecuting.collectAsState()

    // Subtitles dictionary mapped to chapter markers
    val subtitleMap = mapOf(
        "English" to listOf(
            "Welcome to the Nexus Sovereign hosting webinar!",
            "Now let's configure standard Docker containers and SQLite parameters.",
            "Double-checking dynamic SSL bindings and Cloudflare SSL automation.",
            "Excellent, federated feed discovery is fully operational!"
        ),
        "Deutsch" to listOf(
            "Willkommen beim Nexus Sovereign Hosting Webinar!",
            "Lassen Sie uns nun Docker-Container und SQLite-Parameter konfigurieren.",
            "Doppelprüfung der dynamischen SSL-Bindungen und Cloudflare SSL-Automatisierung.",
            "Hervorragend, die föderierte Feed-Erkennung ist voll funktionsfähig!"
        ),
        "Off" to listOf("", "", "", "")
    )

    // Tokenized sections from Markdown
    val contentBlocks = remember(post.content) {
        post.content.split("\n")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Technical Notebook View",
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF64FFDA)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back_button")) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0C0F17),
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = { viewModel.toggleLike(post) }) {
                        Icon(
                            imageVector = if (post.isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (post.isLiked) Color.Red else Color.LightGray
                        )
                    }
                }
            )
        },
        containerColor = Color(0xFF0C0F17)
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Header Details
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = post.title,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        lineHeight = 28.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = post.subtitle,
                        fontSize = 14.sp,
                        color = Color.Gray,
                        lineHeight = 18.sp
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Brush.linearGradient(listOf(Color(0xFF29B6F6), Color(0xFFE040FB))))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(post.author, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.LightGray)
                                Text("Decentralized Contributor", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                        
                        Text(
                            text = post.date,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Gray
                        )
                    }
                    
                    Divider(color = Color(0xFF222C3F), thickness = 1.dp, modifier = Modifier.padding(vertical = 16.dp))
                }

                // Render loops on parsed Markdown blocks
                items(contentBlocks) { line ->
                    val cleanLine = line.trim()
                    when {
                        // Hook PHYSICS_SANDBOX
                        cleanLine == "<<PHYSICS_SANDBOX>>" -> {
                            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                                PhysicsGravitySandbox(
                                    gravity = viewModel.gravityConstant,
                                    mass = viewModel.particleMass,
                                    elasticity = viewModel.particleElasticity,
                                    isSimulating = viewModel.isPlayingSimulation
                                )
                                
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                // Simulation Sliders layout
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131A26)),
                                    border = BorderStroke(1.dp, Color(0xFF222C3F)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = "ADJUST PHYSICS CONSTANTS (JUPYTER METRIC SLIDERS)",
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFF64FFDA),
                                            fontWeight = FontWeight.Bold
                                        )
                                        
                                        Spacer(modifier = Modifier.height(8.dp))
                                        
                                        // Slider 1: Gravity
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Gravity: ", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.LightGray, modifier = Modifier.width(70.dp))
                                            Slider(
                                                value = viewModel.gravityConstant,
                                                onValueChange = { viewModel.gravityConstant = it },
                                                valueRange = 0f..25f,
                                                modifier = Modifier.weight(1f).testTag("gravity_slider")
                                            )
                                            Text("${String.format("%.1f", viewModel.gravityConstant)}m/s²", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.Gray, modifier = Modifier.width(55.dp))
                                        }

                                        // Slider 2: Mass
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Mass: ", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.LightGray, modifier = Modifier.width(70.dp))
                                            Slider(
                                                value = viewModel.particleMass,
                                                onValueChange = { viewModel.particleMass = it },
                                                valueRange = 1f..15f,
                                                modifier = Modifier.weight(1f).testTag("mass_slider")
                                            )
                                            Text("${String.format("%.1f", viewModel.particleMass)}kg", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.Gray, modifier = Modifier.width(55.dp))
                                        }

                                        // Slider 3: Elasticity (Bounciness)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Elasticity: ", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.LightGray, modifier = Modifier.width(70.dp))
                                            Slider(
                                                value = viewModel.particleElasticity,
                                                onValueChange = { viewModel.particleElasticity = it },
                                                valueRange = 0.1f..1.0f,
                                                modifier = Modifier.weight(1f).testTag("elasticity_slider")
                                            )
                                            Text("${String.format("%.2f", viewModel.particleElasticity)}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.Gray, modifier = Modifier.width(55.dp))
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Control Button
                                        Button(
                                            onClick = { viewModel.isPlayingSimulation = !viewModel.isPlayingSimulation },
                                            modifier = Modifier.align(Alignment.End).testTag("toggle_physics_btn"),
                                            colors = ButtonDefaults.buttonColors(containerColor = if (viewModel.isPlayingSimulation) Color(0xFFFF5F56) else Color(0xFF27C93F))
                                        ) {
                                            Text(
                                                text = if (viewModel.isPlayingSimulation) "PAUSE SIMULATION" else "RUN SIMULATION",
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Hook CODE_NOTEBOOK
                        cleanLine == "<<CODE_NOTEBOOK>>" -> {
                            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                                    border = BorderStroke(1.dp, Color(0xFF333333)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        // Header Row with compiler settings
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Code, contentDescription = "Code Cell", tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "RUNNABLE NOTEBOOK CELL",
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.LightGray
                                                )
                                            }
                                            
                                            // Language Selector row
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                listOf("PYTHON", "JAVASCRIPT", "WASM").forEach { lang ->
                                                    val isSel = viewModel.codeLanguage == lang
                                                    Box(
                                                        modifier = Modifier
                                                            .background(
                                                                if (isSel) Color(0xFF333333) else Color.Transparent,
                                                                RoundedCornerShape(4.dp)
                                                            )
                                                            .border(
                                                                1.dp,
                                                                if (isSel) Color(0xFFFFB300) else Color(0xFF444444),
                                                                RoundedCornerShape(4.dp)
                                                            )
                                                            .clickable { viewModel.codeLanguage = lang }
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                            .testTag("notebook_lang_$lang")
                                                    ) {
                                                        Text(lang, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = if (isSel) Color.White else Color.Gray)
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Editable code block
                                        OutlinedTextField(
                                            value = viewModel.editableCodeBlock,
                                            onValueChange = { viewModel.editableCodeBlock = it },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(130.dp)
                                                .testTag("notebook_code_editor"),
                                            textStyle = androidx.compose.ui.text.TextStyle(
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 12.sp,
                                                color = Color(0xFF9ECE6A)
                                            ),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = Color(0xFFFFB300),
                                                unfocusedBorderColor = Color(0xFF333333),
                                                focusedContainerColor = Color(0xFF121212),
                                                unfocusedContainerColor = Color(0xFF121212)
                                            ),
                                            shape = RoundedCornerShape(6.dp)
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Action Execute button
                                        Button(
                                            onClick = { viewModel.executeSandboxedSnippet() },
                                            enabled = !isExecutingCode,
                                            modifier = Modifier.align(Alignment.End).testTag("execute_code_btn"),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            if (isExecutingCode) {
                                                CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp, color = Color.Black)
                                            } else {
                                                Icon(Icons.Rounded.PlayArrow, contentDescription = "Play", tint = Color.Black, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("EXECUTE IN SANDBOX", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
                                            }
                                        }

                                        if (executionLogs.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Text("RUNTIME CONSOLE:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color(0xFF0F0F0F), RoundedCornerShape(4.dp))
                                                    .padding(8.dp)
                                            ) {
                                                executionLogs.forEach { log ->
                                                    Text(
                                                        log,
                                                        color = if (log.contains("STDOUT")) Color(0xFF5DF294) else Color(0xFF45A2E5),
                                                        fontFamily = FontFamily.Monospace,
                                                        fontSize = 10.sp,
                                                        lineHeight = 13.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Hook AUDIO_PODCAST
                        cleanLine == "<<AUDIO_PODCAST>>" -> {
                            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                                AudioWaveformVisualizer(
                                    isPlaying = viewModel.isPlayingAudio && viewModel.currentAudioPostId == post.id,
                                    currentTimeMs = if (viewModel.currentAudioPostId == post.id) viewModel.audioPlaybackMs else 0L,
                                    totalTimeMs = viewModel.audioTotalMs,
                                    onSeek = { viewModel.seekAudioTo(it) }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                // Center Stream Play Control
                                Button(
                                    onClick = { viewModel.toggleAudioPlayback(post) },
                                    modifier = Modifier.fillMaxWidth().testTag("podcast_playback_toogle"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF29B6F6))
                                ) {
                                    Icon(
                                        imageVector = if (viewModel.isPlayingAudio && viewModel.currentAudioPostId == post.id) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play Podcast"
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (viewModel.isPlayingAudio && viewModel.currentAudioPostId == post.id) "PAUSE PODCAST BRIEF" else "PLAY STREAM AUDIO",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Hook VIDEO_CHAPTERS
                        cleanLine == "<<VIDEO_CHAPTERS>>" -> {
                            val chaptersList = post.videoChapterMarkers.split("|")
                            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0E17)),
                                    border = BorderStroke(1.dp, Color(0xFF222C3F)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            "WEBINAR DEMO VIDEO CAPTURE (WASM RENDERED ENVELOPE)",
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFF29B6F6),
                                            fontWeight = FontWeight.Bold
                                        )
                                        
                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Video Box screen mock
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(160.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color.Black),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            // Simulated moving graphic if playing
                                            if (viewModel.isPlayingVideo) {
                                                CircularProgressIndicator(color = Color(0xFF29B6F6).copy(alpha = 0.2f), strokeWidth = 24.dp, modifier = Modifier.size(120.dp))
                                            } else {
                                                Icon(Icons.Default.Videocam, contentDescription = "Cam", tint = Color(0xFF121824), modifier = Modifier.size(64.dp))
                                            }

                                            // Subtitles Track
                                            val currentSubtitles = subtitleMap[viewModel.selectedSubtitleLanguage] ?: emptyList()
                                            val subText = currentSubtitles.getOrNull(viewModel.activeChapterIndex) ?: ""
                                            if (subText.isNotEmpty() && viewModel.selectedSubtitleLanguage != "Off") {
                                                Box(
                                                    modifier = Modifier
                                                        .align(Alignment.BottomCenter)
                                                        .padding(bottom = 12.dp)
                                                        .background(Color(0xD0000000), RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        subText,
                                                        color = Color(0xFFFFEB3B),
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Controls
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(
                                                onClick = { viewModel.toggleVideoPlayback() },
                                                modifier = Modifier.testTag("video_play_toggle")
                                            ) {
                                                Icon(
                                                    imageVector = if (viewModel.isPlayingVideo) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                    contentDescription = "Play Video",
                                                    tint = Color.White
                                                )
                                            }

                                            Text(
                                                text = "Time: ${viewModel.videoChapterProgressSec}s / 240s",
                                                color = Color.LightGray,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )

                                            // Subtitle Language toggle
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Rounded.Subtitles, contentDescription = "Subtitles", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                listOf("English", "Deutsch", "Off").forEach { lang ->
                                                    val isSel = viewModel.selectedSubtitleLanguage == lang
                                                    Text(
                                                        text = lang.take(3),
                                                        color = if (isSel) Color(0xFF29B6F6) else Color.Gray,
                                                        fontSize = 9.sp,
                                                        fontFamily = FontFamily.Monospace,
                                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                        modifier = Modifier
                                                            .clickable { viewModel.selectedSubtitleLanguage = lang }
                                                            .padding(horizontal = 4.dp).testTag("video_lang_$lang")
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Chapters markers Quick-seek buttons
                                        Text("BOOKMARK CHAPTERS:", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            chaptersList.forEachIndexed { index, chapterText ->
                                                val parts = chapterText.split(":")
                                                val sec = parts.getOrNull(0)?.toIntOrNull() ?: 0
                                                val name = parts.getOrNull(1) ?: ""
                                                val isAct = viewModel.activeChapterIndex == index

                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(if (isAct) Color(0xFF1E293D) else Color.Transparent)
                                                        .border(1.dp, if (isAct) Color(0xFF29B6F6) else Color(0xFF131A26), RoundedCornerShape(4.dp))
                                                        .clickable { viewModel.seekVideoToChapter(sec, index) }
                                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                                        .testTag("chapter_item_$index"),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = name,
                                                        fontSize = 11.sp,
                                                        fontWeight = if (isAct) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (isAct) Color(0xFF29B6F6) else Color.LightGray
                                                    )
                                                    Text(
                                                        text = "${sec}s",
                                                        fontSize = 11.sp,
                                                        fontFamily = FontFamily.Monospace,
                                                        color = Color.Gray
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Handle styled text lines
                        cleanLine.startsWith("# ") -> {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = cleanLine.removePrefix("# "),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                        cleanLine.startsWith("### ") -> {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = cleanLine.removePrefix("### "),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF64FFDA),
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                        cleanLine.startsWith("- ") -> {
                            Row(modifier = Modifier.padding(vertical = 2.dp, horizontal = 4.dp)) {
                                Text("•", color = Color(0xFF64FFDA), modifier = Modifier.padding(end = 8.dp))
                                Text(cleanLine.removePrefix("- "), color = Color.LightGray, fontSize = 14.sp, lineHeight = 18.sp)
                            }
                        }
                        cleanLine.startsWith("<<") && cleanLine.endsWith(">>") -> {
                            // Caught unhandled placeholders
                        }
                        else -> {
                            if (cleanLine.isNotEmpty()) {
                                // simple parser inline formatting
                                val formattedText = cleanLine
                                    .replace("**", "") // stripping or showing normal
                                
                                Text(
                                    text = formattedText,
                                    fontSize = 14.sp,
                                    lineHeight = 20.sp,
                                    color = Color.LightGray,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
