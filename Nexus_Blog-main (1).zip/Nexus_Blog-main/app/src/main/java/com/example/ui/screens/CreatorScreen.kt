package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BlogPost
import com.example.ui.viewmodel.BlogViewModel

@Composable
fun CreatorScreen(
    viewModel: BlogViewModel,
    onNavigateToFeed: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPreviewMode by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0F17))
            .padding(16.dp)
    ) {
        // Studio Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NEXUS CREATOR STUDIO",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    color = Color.White
                )
                Text(
                    text = "MDX Compiling Editor & Live Notebook Planner",
                    fontSize = 11.sp,
                    color = Color(0xFFFFB300)
                )
            }
            
            // Mode Toggle
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF121824))
                    .border(1.dp, Color(0xFF333333), RoundedCornerShape(6.dp))
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (!isPreviewMode) Color(0xFF1E293D) else Color.Transparent)
                        .clickable { isPreviewMode = false }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("editor_mode_write")
                ) {
                    Text(
                        "EDIT SOURCE",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (!isPreviewMode) Color.White else Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isPreviewMode) Color(0xFF1E293D) else Color.Transparent)
                        .clickable { isPreviewMode = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("editor_mode_preview")
                ) {
                    Text(
                        "LIVE PREVIEW",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (isPreviewMode) Color(0xFFFFB300) else Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isPreviewMode) {
            // Live Preview Mode
            val mockPost = BlogPost(
                id = viewModel.activeDraftPostId ?: 0,
                title = if (viewModel.editorTitle.isBlank()) "Untitled Sovereign Post" else viewModel.editorTitle,
                subtitle = if (viewModel.editorSubtitle.isBlank()) "Live preview container" else viewModel.editorSubtitle,
                author = "Sovereign Writer",
                content = viewModel.editorContent,
                status = "DRAFT",
                type = viewModel.editorPostType,
                date = "Drafted Live",
                readTimeMinutes = (viewModel.editorContent.length / 500).coerceAtLeast(1)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, Color(0xFF222C3F), RoundedCornerShape(8.dp))
                    .background(Color(0xFF070B11))
            ) {
                PostDetailScreen(
                    post = mockPost,
                    viewModel = viewModel,
                    onBack = { isPreviewMode = false },
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            // Write Mode
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Post Title
                item {
                    OutlinedTextField(
                        value = viewModel.editorTitle,
                        onValueChange = { viewModel.editorTitle = it },
                        modifier = Modifier.fillMaxWidth().testTag("editor_title_input"),
                        label = { Text("Article Title") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFB300),
                            unfocusedBorderColor = Color(0xFF222C3F),
                            focusedContainerColor = Color(0xFF121824),
                            unfocusedContainerColor = Color(0xFF121824),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.LightGray
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // Post Subtitle
                item {
                    OutlinedTextField(
                        value = viewModel.editorSubtitle,
                        onValueChange = { viewModel.editorSubtitle = it },
                        modifier = Modifier.fillMaxWidth().testTag("editor_subtitle_input"),
                        label = { Text("Subheading or Intro Summary") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFB300),
                            unfocusedBorderColor = Color(0xFF222C3F),
                            focusedContainerColor = Color(0xFF121824),
                            unfocusedContainerColor = Color(0xFF121824),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.LightGray
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // Post Custom Rendering Mode Selection
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Render Protocol:",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Gray,
                            modifier = Modifier.width(110.dp)
                        )
                        
                        val typesList = listOf(
                            "STANDARD" to "Standard (Audio/Video)",
                            "INTERACTIVE" to "Interactive (Physics Map)",
                            "CODE_INTEGRATED" to "Notebook (Console Env)"
                        )

                        typesList.forEach { (typeKey, label) ->
                            val isSel = viewModel.editorPostType == typeKey
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) Color(0xFF1F293D) else Color(0xFF121824))
                                    .border(1.dp, if (isSel) Color(0xFFFFB300) else Color(0xFF222C3F), RoundedCornerShape(6.dp))
                                    .clickable { viewModel.editorPostType = typeKey }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    label.split(" ").getOrNull(0) ?: label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isSel) Color(0xFFFFB300) else Color.Gray
                                )
                            }
                        }
                    }
                }

                // Embedded Blocks Quick Appender
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F141F)),
                        border = BorderStroke(1.dp, Color(0xFF222C3F)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                "INTEGRATED SYSTEM METADATA LAYERS (+ SINGLE-TAP APPEND)",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color.Gray,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val actionAppends = listOf(
                                    Triple("+ Gravity Sandbox", "\n<<PHYSICS_SANDBOX>>\n", Color(0xFFE040FB)),
                                    Triple("+ Code Notebook", "\n<<CODE_NOTEBOOK>>\n", Color(0xFFFFB300)),
                                    Triple("+ Podcast Wave", "\n<<AUDIO_PODCAST>>\n", Color(0xFF29B6F6)),
                                    Triple("+ Video player", "\n<<VIDEO_CHAPTERS>>\n", Color(0xFF27C93F))
                                )

                                actionAppends.forEach { (label, block, tint) ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(tint.copy(alpha = 0.12f))
                                            .border(1.dp, tint.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                            .clickable { viewModel.editorContent = viewModel.editorContent + block }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = label,
                                            color = tint,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Core Source Editor Box
                item {
                    OutlinedTextField(
                        value = viewModel.editorContent,
                        onValueChange = { viewModel.editorContent = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .testTag("editor_body_input"),
                        label = { Text("Markdown & MDX Content Body", fontSize = 13.sp) },
                        placeholder = { Text("Write Markdown or append special blocks like <<PHYSICS_SANDBOX>>...", fontSize = 12.sp, color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFB300),
                            unfocusedBorderColor = Color(0xFF222C3F),
                            focusedContainerColor = Color(0xFF121824),
                            unfocusedContainerColor = Color(0xFF121824),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.LightGray
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // Action Commands Deck
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Clear
                        OutlinedButton(
                            onClick = { viewModel.clearEditor() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("editor_clear_btn"),
                            border = BorderStroke(1.dp, Color(0xFFFF5F56)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5F56)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("CLEAR ALL", fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Save Local Draft
                        Button(
                            onClick = {
                                viewModel.saveDraftBlogPost {
                                    onNavigateToFeed()
                                }
                            },
                            modifier = Modifier
                                .weight(1.5f)
                                .testTag("editor_save_draft_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293D)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save Draft", modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SAVE DRAFT", fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Publish Production
                        Button(
                            onClick = {
                                viewModel.publishBlogPost {
                                    onNavigateToFeed()
                                }
                            },
                            modifier = Modifier
                                .weight(1.5f)
                                .testTag("editor_publish_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Publish, contentDescription = "Publish", tint = Color.Black, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("PUBLISH", fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
                
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
