package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BlogPlugin
import com.example.ui.viewmodel.BlogViewModel

@Composable
fun PluginsScreen(
    viewModel: BlogViewModel,
    modifier: Modifier = Modifier
) {
    val plugins by viewModel.plugins.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0F17))
            .padding(16.dp)
    ) {
        // Plugin Header
        Column {
            Text(
                text = "PLUGIN MATRIX",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                color = Color.White
            )
            Text(
                text = "Extensibility Web-Workers: Python, JS, and C/WASM Engine",
                fontSize = 11.sp,
                color = Color(0xFFE040FB)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick overview card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161021)),
            border = BorderStroke(1.dp, Color(0xFF4A148C).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Extension, contentDescription = "Plugins", tint = Color(0xFFE040FB), modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    "Enable performance compilers or ActivityPub streams. Extensibility scripts run inside isolated VM sandboxes with targeted permission flags.",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active List
        Text(
            text = "REGISTERED EXTENSION MODULES:",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(plugins) { plugin ->
                PluginItemCard(
                    plugin = plugin,
                    onToggleEnabled = { viewModel.togglePlugin(plugin) }
                )
            }
        }
    }
}

@Composable
fun PluginItemCard(
    plugin: BlogPlugin,
    onToggleEnabled: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isAuditingSource by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF222C3F), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF121824)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // First row: Name, Toggle & Type badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = plugin.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        
                        // Type Badges
                        val badgeColor = when (plugin.type) {
                            "PYTHON" -> Color(0xFF29B6F6)
                            "WASM" -> Color(0xFF64FFDA)
                            else -> Color(0xFFE040FB)
                        }
                        Surface(
                            color = badgeColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(3.dp),
                            border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = plugin.type,
                                color = badgeColor,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    
                    Text(
                        text = "ID: ${plugin.id}  •  v${plugin.currentVersion}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray
                    )
                }

                // Toggle Switch
                Switch(
                    checked = plugin.isEnabled,
                    onCheckedChange = { onToggleEnabled() },
                    modifier = Modifier.testTag("plugin_toggle_${plugin.id}"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFFE040FB),
                        checkedTrackColor = Color(0xFF4A148C)
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Second row: description
            Text(
                text = plugin.description,
                color = Color.LightGray,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Permission parameters tag
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = "Scope", tint = Color.Gray, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Permission Scope: [ ${plugin.permissionScope} ]",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Expandable code auditor
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isAuditingSource = !isAuditingSource }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isAuditingSource) "HIDE WORKER RUNTIME SCRIPT SOURCE" else "AUDIT SCRIPT SOURCE",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE040FB)
                )
                Icon(
                    imageVector = if (isAuditingSource) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = "Expand",
                    tint = Color(0xFFE040FB),
                    modifier = Modifier.size(14.dp)
                )
            }

            if (isAuditingSource) {
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = plugin.scriptContent,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = Color(0xFF81C784)
                    )
                }
            }
        }
    }
}
