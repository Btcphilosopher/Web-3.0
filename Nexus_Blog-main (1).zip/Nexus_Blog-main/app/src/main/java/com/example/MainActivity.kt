package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.example.data.local.BlogDatabase
import com.example.data.model.BlogPost
import com.example.data.repository.BlogRepository
import com.example.ui.screens.CreatorScreen
import com.example.ui.screens.DeployScreen
import com.example.ui.screens.FeedScreen
import com.example.ui.screens.PluginsScreen
import com.example.ui.screens.PostDetailScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BlogViewModel

class MainActivity : ComponentActivity() {

    // Lazy Room SQLite Database Creation
    private val database by lazy {
        Room.databaseBuilder(
            applicationContext,
            BlogDatabase::class.java,
            "nexus_blog.db"
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    // Lazy Repository Creation
    private val repository by lazy {
        BlogRepository(database.blogDao())
    }

    // ViewModel injection with custom Provider Factory
    private val viewModel: BlogViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return BlogViewModel(repository) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContainer(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContainer(viewModel: BlogViewModel) {
    // Standard local page switcher route: "FEED", "DETAIL", "CREATOR", "DEPLOY", "PLUGINS"
    var currentScreen by remember { mutableStateOf("FEED") }
    // Backstack pointer for selected post detail target
    var selectedPostForDetail by remember { mutableStateOf<BlogPost?>(null) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Only draw custom edge-to-edge NavigationBar if not inside fullscreen Detail view
            if (currentScreen != "DETAIL") {
                NavigationBar(
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("app_navigation_bar"),
                    containerColor = Color(0xFF070B11),
                    tonalElevation = 8.dp
                ) {
                    // Item 1: Reader Feed
                    NavigationBarItem(
                        selected = currentScreen == "FEED",
                        onClick = { currentScreen = "FEED" },
                        modifier = Modifier.testTag("nav_tab_feed"),
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Book,
                                contentDescription = "Feed",
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                "FEED",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF64FFDA),
                            selectedTextColor = Color(0xFF64FFDA),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1E293D)
                        )
                    )

                    // Item 2: Creator Studio
                    NavigationBarItem(
                        selected = currentScreen == "CREATOR",
                        onClick = { currentScreen = "CREATOR" },
                        modifier = Modifier.testTag("nav_tab_creator"),
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Create,
                                contentDescription = "Creator Studio",
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                "STUDIO",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFFFB300),
                            selectedTextColor = Color(0xFFFFB300),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1E293D)
                        )
                    )

                    // Item 3: Deploy configuration target
                    NavigationBarItem(
                        selected = currentScreen == "DEPLOY",
                        onClick = { currentScreen = "DEPLOY" },
                        modifier = Modifier.testTag("nav_tab_deploy"),
                        icon = {
                            Icon(
                                imageVector = Icons.Default.CloudQueue,
                                contentDescription = "Deploy Console",
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                "DEPLOY",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF29B6F6),
                            selectedTextColor = Color(0xFF29B6F6),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1E293D)
                        )
                    )

                    // Item 4: Pluggability system matrix
                    NavigationBarItem(
                        selected = currentScreen == "PLUGINS",
                        onClick = { currentScreen = "PLUGINS" },
                        modifier = Modifier.testTag("nav_tab_plugins"),
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Extension,
                                contentDescription = "Plugins matrix",
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                "PLUGINS",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFE040FB),
                            selectedTextColor = Color(0xFFE040FB),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1E293D)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF0C0F17)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                "FEED" -> FeedScreen(
                    viewModel = viewModel,
                    onViewPost = { post ->
                        selectedPostForDetail = post
                        currentScreen = "DETAIL"
                    },
                    modifier = Modifier.fillMaxSize()
                )

                "DETAIL" -> {
                    val activePost = selectedPostForDetail
                    if (activePost != null) {
                        PostDetailScreen(
                            post = activePost,
                            viewModel = viewModel,
                            onBack = {
                                selectedPostForDetail = null
                                currentScreen = "FEED"
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        currentScreen = "FEED"
                    }
                }

                "CREATOR" -> CreatorScreen(
                    viewModel = viewModel,
                    onNavigateToFeed = {
                        currentScreen = "FEED"
                    },
                    modifier = Modifier.fillMaxSize()
                )

                "DEPLOY" -> DeployScreen(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxSize()
                )

                "PLUGINS" -> PluginsScreen(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
