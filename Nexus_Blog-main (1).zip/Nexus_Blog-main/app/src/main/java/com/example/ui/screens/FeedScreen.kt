package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BlogPost
import com.example.ui.viewmodel.BlogViewModel

@Composable
fun FeedScreen(
    viewModel: BlogViewModel,
    onViewPost: (BlogPost) -> Unit,
    modifier: Modifier = Modifier
) {
    val posts by viewModel.posts.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // "ALL", "INTERACTIVE", "CODE", "DRAFT"

    val filteredPosts = posts.filter { post ->
        val matchesSearch = post.title.contains(searchQuery, ignoreCase = true) || 
                            post.subtitle.contains(searchQuery, ignoreCase = true) ||
                            post.author.contains(searchQuery, ignoreCase = true)
        
        val matchesFilter = when (selectedFilter) {
            "INTERACTIVE" -> post.type == "INTERACTIVE"
            "CODE" -> post.type == "CODE_INTEGRATED"
            "DRAFTS" -> post.status == "DRAFT"
            else -> post.status == "PUBLISHED" // Default, show published posts
        }
        
        matchesSearch && matchesFilter
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0F17))
            .padding(16.dp)
    ) {
        // Technical Display Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NEXUS FEED",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.5.sp,
                    color = Color.White
                )
                Text(
                    text = "Sovereign Web Publishing Array",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.SansSerif,
                    color = Color(0xFF64FFDA)
                )
            }
            
            // Status Node
            Surface(
                color = Color(0xFF132A13),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.border(1.dp, Color(0xFF27C93F), RoundedCornerShape(4.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF27C93F))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "DECENTRALIZED LOCAL INDEX ACTIVE",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF27C93F)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Technical Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("feed_search_input"),
            placeholder = { Text("Search decentralized cluster index...", fontSize = 13.sp, color = Color.Gray) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.LightGray) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF64FFDA),
                unfocusedBorderColor = Color(0xFF333333),
                focusedContainerColor = Color(0xFF121824),
                unfocusedContainerColor = Color(0xFF121824),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.LightGray
            ),
            shape = RoundedCornerShape(8.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Tag Filters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filterOptions = listOf(
                "ALL" to "Published",
                "INTERACTIVE" to "Interactive Widgets",
                "CODE" to "Notebook Blocks",
                "DRAFTS" to "Local Drafts"
            )

            filterOptions.forEach { (key, label) ->
                val isActive = selectedFilter == key
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { selectedFilter = key }
                        .testTag("filter_tag_$key"),
                    color = if (isActive) Color(0xFF1F293D) else Color(0xFF121824),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isActive) Color(0xFF64FFDA) else Color(0xFF333333)
                    )
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = if (isActive) Color(0xFF64FFDA) else Color.Gray
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Feed List
        if (filteredPosts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.LibraryBooks,
                        contentDescription = "Empty",
                        tint = Color(0xFF2C394F),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "NO LOCAL RECORDS MATCHING CRITERIA",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = "Create a draft in the Studio to test.",
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredPosts) { post ->
                    FeedPostCard(
                        post = post,
                        onClick = { onViewPost(post) },
                        onLike = { viewModel.toggleLike(post) },
                        onDelete = { viewModel.deleteBlogPost(post) }
                    )
                }
            }
        }
    }
}

@Composable
fun FeedPostCard(
    post: BlogPost,
    onClick: () -> Unit,
    onLike: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF222C3F), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag("post_card_${post.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF121824)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Meta Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Author & Date
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(Brush.radialGradient(listOf(Color(0xFF64FFDA), Color(0xFF0288D1))))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = post.author,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "•  ${post.date}",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }

                // Type Badge
                val badgeColor = when (post.type) {
                    "INTERACTIVE" -> Color(0xFFE040FB)
                    "CODE_INTEGRATED" -> Color(0xFFFFB300)
                    else -> Color(0xFF29B6F6)
                }
                
                Surface(
                    color = badgeColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = post.type.replace("_", " "),
                        color = badgeColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title & Subtitle
            Text(
                text = post.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                lineHeight = 22.sp
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = post.subtitle,
                fontSize = 13.sp,
                color = Color.Gray,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Interactive Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Attachment indicators
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (post.hasVideo) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Videocam, contentDescription = "Has Video", tint = Color.Gray, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WASM Video", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                        }
                    }
                    if (post.hasAudio) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Audiotrack, contentDescription = "Has Audio", tint = Color.Gray, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("HLS FLAC", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, contentDescription = "Read Time", tint = Color.Gray, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("${post.readTimeMinutes} min read", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                    }
                }

                // Interactions (Like & Delete)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { onLike() },
                        modifier = Modifier.size(24.dp).testTag("like_post_${post.id}")
                    ) {
                        Icon(
                            imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (post.isLiked) Color.Red else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = post.likesCount.toString(),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray
                    )
                    
                    if (post.status == "DRAFT") {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { onDelete() },
                            modifier = Modifier.size(24.dp).testTag("delete_post_${post.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete",
                                tint = Color.Red,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
