package com.example.ui.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BlogPost
import com.example.data.model.BlogPlugin
import com.example.data.model.HostingServer
import com.example.data.repository.BlogRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BlogViewModel(private val repository: BlogRepository) : ViewModel() {

    // --- Database Streams ---
    val posts: StateFlow<List<BlogPost>> = repository.allPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val plugins: StateFlow<List<BlogPlugin>> = repository.allPlugins
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val servers: StateFlow<List<HostingServer>> = repository.allServers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.ensureDefaultDataPopulated()
        }
    }

    // --- Interactive Physics States ---
    var gravityConstant by mutableFloatStateOf(9.8f)
    var particleMass by mutableFloatStateOf(5.0f)
    var particleElasticity by mutableFloatStateOf(0.7f)
    var isPlayingSimulation by mutableStateOf(true)

    // --- Code Execution Notebook States ---
    var codeLanguage by mutableStateOf("PYTHON") // "PYTHON", "JAVASCRIPT", "WASM"
    var editableCodeBlock by mutableStateOf("""
# Sample Scientific Multiplier Block
def compute_energy(mass, velocity):
    light_speed = 299792458
    joules = mass * (light_speed ** 2)
    return joules

print("Compiling equations...")
val = compute_energy(0.005, 120.0)
print(f"Energy equivalent matrix: {val:.2e} Joules")
    """.trimIndent())
    
    private val _executionOutput = MutableStateFlow<List<String>>(emptyList())
    val executionOutput: StateFlow<List<String>> = _executionOutput.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    // --- Media Player: Podcast/Audio States ---
    var isPlayingAudio by mutableStateOf(false)
    var currentAudioPostId by mutableStateOf<Int?>(null)
    var audioPlaybackMs by mutableStateOf(0L)
    var audioTotalMs by mutableStateOf(372000L) // Default 6:12

    // --- Media Player: Video States ---
    var isPlayingVideo by mutableStateOf(false)
    var videoChapterProgressSec by mutableStateOf(0)
    var selectedSubtitleLanguage by mutableStateOf("English") // "English", "Deutsch", "Off"
    var activeChapterIndex by mutableStateOf(0)

    // --- Deployment & CLI Simulator States ---
    private val _cliLogs = MutableStateFlow<List<String>>(listOf("Execute 'nexus deploy' to sync with sovereign VPS hosting..."))
    val cliLogs: StateFlow<List<String>> = _cliLogs.asStateFlow()

    private val _isDeploying = MutableStateFlow(false)
    val isDeploying: StateFlow<Boolean> = _isDeploying.asStateFlow()

    // --- active WYSIWYG / Markdown Creator Draft State ---
    var editorTitle by mutableStateOf("")
    var editorSubtitle by mutableStateOf("")
    var editorPostType by mutableStateOf("STANDARD") // "STANDARD", "INTERACTIVE", "CODE_INTEGRATED"
    var editorContent by mutableStateOf("")
    var activeDraftPostId by mutableStateOf<Int?>(null)

    // Private tracking jobs
    private var audioTimerJob: Job? = null

    init {
        // Dynamic simulated clock or updater
        viewModelScope.launch {
            while (true) {
                delay(1000)
                if (isPlayingAudio) {
                    audioPlaybackMs = (audioPlaybackMs + 1000L).coerceAtMost(audioTotalMs)
                    if (audioPlaybackMs >= audioTotalMs) {
                        isPlayingAudio = false
                        audioPlaybackMs = 0L
                    }
                }
                if (isPlayingVideo) {
                    videoChapterProgressSec += 1
                    // Wrap around or update chapter based on markers
                    updateVideoChapterIndex()
                }
            }
        }
    }

    private fun updateVideoChapterIndex() {
        // markers are: 0, 45, 120, 210 seconds
        val sec = videoChapterProgressSec
        activeChapterIndex = when {
            sec >= 210 -> 3
            sec >= 120 -> 2
            sec >= 45 -> 1
            else -> 0
        }
    }

    // --- Database Operations ---
    fun saveDraftBlogPost(onCompleted: () -> Unit) {
        if (editorTitle.isBlank() || editorContent.isBlank()) return
        viewModelScope.launch {
            val postToSave = BlogPost(
                id = activeDraftPostId ?: 0,
                title = editorTitle,
                subtitle = editorSubtitle,
                author = "Sovereign Writer",
                content = editorContent,
                status = "DRAFT",
                type = editorPostType,
                date = "Drafted Today",
                readTimeMinutes = (editorContent.length / 500).coerceAtLeast(1)
            )
            repository.insertPost(postToSave)
            clearEditor()
            onCompleted()
        }
    }

    fun publishBlogPost(onCompleted: () -> Unit) {
        if (editorTitle.isBlank() || editorContent.isBlank()) return
        viewModelScope.launch {
            val postToPublish = BlogPost(
                id = activeDraftPostId ?: 0,
                title = editorTitle,
                subtitle = editorSubtitle,
                author = "Sovereign Writer",
                content = editorContent,
                status = "PUBLISHED",
                type = editorPostType,
                date = "June 12, 2026",
                readTimeMinutes = (editorContent.length / 500).coerceAtLeast(1)
            )
            repository.insertPost(postToPublish)
            clearEditor()
            onCompleted()
        }
    }

    fun deleteBlogPost(post: BlogPost) {
        viewModelScope.launch {
            repository.deletePost(post)
        }
    }

    fun loadPostIntoEditor(post: BlogPost) {
        editorTitle = post.title
        editorSubtitle = post.subtitle
        editorPostType = post.type
        editorContent = post.content
        activeDraftPostId = post.id
    }

    fun clearEditor() {
        editorTitle = ""
        editorSubtitle = ""
        editorPostType = "STANDARD"
        editorContent = ""
        activeDraftPostId = null
    }

    fun toggleLike(post: BlogPost) {
        viewModelScope.launch {
            val updated = post.copy(
                isLiked = !post.isLiked,
                likesCount = if (post.isLiked) post.likesCount - 1 else post.likesCount + 1
            )
            repository.updatePost(updated)
        }
    }

    fun togglePlugin(plugin: BlogPlugin) {
        viewModelScope.launch {
            repository.setPluginEnabled(plugin.id, !plugin.isEnabled)
        }
    }

    fun addNewSelfHostedServer(name: String, host: String, port: Int, type: String, env: String) {
        viewModelScope.launch {
            val server = HostingServer(
                name = name,
                hostAddress = host,
                port = port,
                deploymentType = type,
                environmentVariables = env,
                isConnected = false
            )
            repository.insertServer(server)
        }
    }

    fun deleteHostingServer(server: HostingServer) {
        viewModelScope.launch {
            repository.deleteServerById(server.id)
        }
    }

    // --- Simulated Audio Event Handler ---
    fun toggleAudioPlayback(post: BlogPost) {
        if (currentAudioPostId != post.id) {
            currentAudioPostId = post.id
            audioPlaybackMs = 0L
            audioTotalMs = if (post.audioDurationMs > 0) post.audioDurationMs else 372000L
            isPlayingAudio = true
        } else {
            isPlayingAudio = !isPlayingAudio
        }
    }

    fun seekAudioTo(progressFraction: Float) {
        audioPlaybackMs = (progressFraction * audioTotalMs).toLong()
    }

    // --- Simulated Video Event Handler ---
    fun toggleVideoPlayback() {
        isPlayingVideo = !isPlayingVideo
    }

    fun seekVideoToChapter(seconds: Int, index: Int) {
        videoChapterProgressSec = seconds
        activeChapterIndex = index
    }

    // --- Interactive Python & JS Notebook Sandbox Runtime simulator ---
    fun executeSandboxedSnippet() {
        viewModelScope.launch {
            _isExecuting.value = true
            _executionOutput.value = listOf("[NEXUS-RUNTIME] Initializing memory sandbox boundaries...", "[NEXUS-RUNTIME] Allocating execution process thread...")
            delay(600)
            
            val logs = mutableListOf<String>()
            when (codeLanguage) {
                "PYTHON" -> {
                    logs.add("[SYS-LOAD] Python 3.12 micro-sandbox spawned context safely.")
                    logs.add("[SYS-DEPS] Loaded virtual modules: numpy (v1.26), pandas (v2.1).")
                    logs.add("[STDOUT] >> EXECUTION COMMENCED <<")
                    if (editableCodeBlock.contains("def") || editableCodeBlock.contains("print")) {
                        logs.add("[STDOUT] Compiling functional matrix equations...")
                        if (editableCodeBlock.contains("compute_energy")) {
                            logs.add("[STDOUT] Matched function: compute_energy()")
                            logs.add("[STDOUT] Input payload: mass = 0.005 kg, velocity = 120.0 m/s")
                            logs.add("[STDOUT] Energy equivalent matrix: 4.50e+14 Joules")
                        } else {
                            logs.add("[STDOUT] Custom function detected. Output parsed safely.")
                            logs.add("[STDOUT] Execution result: 0.00ms latency, success code (0)")
                        }
                    } else {
                        logs.add("[STDOUT] Standard print executed: Code block resolved nicely.")
                    }
                    logs.add("[SYS-EXIT] Python thread returned status code (0) cleanly.")
                }
                "JAVASCRIPT" -> {
                    logs.add("[SYS-LOAD] JavaScript ES2024 V8 sandbox allocated.")
                    logs.add("[SYS-WIDGET] Initialized Canvas bounds [600x400] on-device.")
                    logs.add("[STDOUT] >> EXECUTION COMMENCED <<")
                    logs.add("[STDOUT] Fetching container bounding box...")
                    logs.add("[STDOUT] Canvas dynamic rendering callback: 60 FPS verified.")
                    logs.add("[STDOUT] Simulated vector bounds computed successfully: (x=102.3, y=56.8)")
                    logs.add("[SYS-EXIT] JS Engine garbage collector flushed 4KB blocks.")
                }
                "WASM" -> {
                    logs.add("[SYS-LOAD] WebAssembly Node (Rust targets v1.78) isolated inside WebWorker.")
                    logs.add("[SYS-WASM] Loaded WASM Binary Block [SHA-256: 8a93ef...]")
                    logs.add("[STDOUT] >> INTENSE MATRIX MULTIPLICATIVE SOLVER START <<")
                    logs.add("[STDOUT] Crunching 1024x1024 float arrays...")
                    logs.add("[STDOUT] Executed high-performance parallel SIMD vector blocks.")
                    logs.add("[STDOUT] WASM execution complete. Microsecond latency: 12μs.")
                    logs.add("[SYS-EXIT] WASM worker terminated safely.")
                }
            }
            _executionOutput.value = logs
            _isExecuting.value = false
        }
    }

    // --- VPS deployment CLI tool simulation (`nexus init`, `nexus build`, `nexus deploy`) ---
    fun runDeploymentPipeline(server: HostingServer) {
        viewModelScope.launch {
            _isDeploying.value = true
            val logs = mutableListOf<String>()
            logs.add("user@nexus:~# nexus deploy --server ${server.hostAddress}")
            _cliLogs.value = logs.toList()
            delay(500)

            logs.add("[NEXUS-CLI] Verifying local blog repository... Found 3 published assets.")
            logs.add("[NEXUS-CLI] Parsing markdown documents. Safety compliance checks: PASSED.")
            _cliLogs.value = logs.toList()
            delay(700)

            logs.add("[NEXUS-CLI] Resolving media streaming dependencies (HLS / MP3 pipeline config)...")
            logs.add("[NEXUS-CLI] Injecting enabled plugins: LaTeX MathJax + WASM Matrix Cruncher.")
            _cliLogs.value = logs.toList()
            delay(800)

            logs.add("[NEXUS-CLI] Connecting to remote host ${server.hostAddress}:${server.port} via TLS auth...")
            if (server.hostAddress.startsWith("159.65")) {
                logs.add("[DOCKER] Target environment matches container stack.")
                logs.add("[DOCKER] Transferring build layers: nexus-blog-app:latest...")
                logs.add("[DOCKER] Spawning unified FastAPI + SQLite indexing daemon...")
            } else {
                logs.add("[VPS] Initiating direct live backup folder mapping on remote directory /var/www/nexus...")
            }
            _cliLogs.value = logs.toList()
            delay(900)

            logs.add("[NEXUS-CLI] Indexing SQLite database records. Creating server schema...")
            logs.add("[NEXUS-CLI] Transferred 42kB of metadata indexes. 2/2 multimedia stream assets verified.")
            _cliLogs.value = logs.toList()
            delay(600)

            logs.add("[SUCCESS] Sovereign article array deployed successfully to ${server.name}!")
            logs.add("[SUCCESS] Feed is live and discovery active (RSS + ActivityPub federated headers)!")
            _cliLogs.value = logs.toList()

            // Update server in the database
            repository.updateServer(server.copy(isConnected = true, lastDeployTimestamp = System.currentTimeMillis()))
            _isDeploying.value = false
        }
    }

    fun editHostServerProperties(server: HostingServer) {
        viewModelScope.launch {
            repository.updateServer(server)
        }
    }
}
