package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HostingServer
import com.example.ui.components.TerminalConsole
import com.example.ui.viewmodel.BlogViewModel

@Composable
fun DeployScreen(
    viewModel: BlogViewModel,
    modifier: Modifier = Modifier
) {
    val servers by viewModel.servers.collectAsState()
    val cliLogs by viewModel.cliLogs.collectAsState()
    val isDeploying by viewModel.isDeploying.collectAsState()

    var showConfigDialog by remember { mutableStateOf(false) }
    var selectedServerForLogs by remember { mutableStateOf<HostingServer?>(null) }
    
    // Server inputs state
    var newServerName by remember { mutableStateOf("") }
    var newServerHost by remember { mutableStateOf("") }
    var newServerPort by remember { mutableStateOf("8000") }
    var newServerType by remember { mutableStateOf("VPS_FASTAPI") } // "VPS_FASTAPI", "DOCKER_CONTAINER", "GITHUB_PAGES"
    var newServerEnv by remember { mutableStateOf("PORT=8000,DEBUG=False") }

    // Tab switcher between Deploy console & Host templates
    var selectedSubTab by remember { mutableStateOf("CONSOLE") } // "CONSOLE", "TEMPLATES"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0F17))
            .padding(16.dp)
    ) {
        // Deployment Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SOVEREIGN DEPLOY",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    color = Color.White
                )
                Text(
                    text = "Self-Hosted Infrastructure Manager & CLI Sync",
                    fontSize = 11.sp,
                    color = Color(0xFF29B6F6)
                )
            }

            // Sub Tab switchers
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF121824))
                    .border(1.dp, Color(0xFF333333), RoundedCornerShape(6.dp))
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (selectedSubTab == "CONSOLE") Color(0xFF1E293D) else Color.Transparent)
                        .clickable { selectedSubTab = "CONSOLE" }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("subtab_console")
                ) {
                    Text(
                        "CONSOLE",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (selectedSubTab == "CONSOLE") Color.White else Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (selectedSubTab == "TEMPLATES") Color(0xFF1E293D) else Color.Transparent)
                        .clickable { selectedSubTab = "TEMPLATES" }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("subtab_templates")
                ) {
                    Text(
                        "TEMPLATES",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (selectedSubTab == "TEMPLATES") Color(0xFF29B6F6) else Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedSubTab == "TEMPLATES") {
            // Docker File & Deploy configs template views
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Intro card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF121824)),
                        border = BorderStroke(1.dp, Color(0xFF222C3F))
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudQueue, contentDescription = "Sovereign Deploy", tint = Color(0xFF29B6F6), modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "To run Nexus Blog autonomously, copy these configuration files to your root host directory and configure DNS records to match.",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // Dockerfile Code Box
                item {
                    TemplateCodeBox(
                        title = "Dockerfile (FastAPI Multi-Stage Build)",
                        language = "Docker",
                        code = """
FROM python:3.12-alpine AS builder
WORKDIR /app
RUN apk add --no-cache gcc musl-dev libffi-dev
COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

FROM python:3.12-alpine
WORKDIR /app
COPY --from=builder /root/.local /root/.local
ENV PATH=/root/.local/bin:${'$'}PATH
COPY . .
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
                        """.trimIndent()
                    )
                }

                // docker-compose.yml Code Box
                item {
                    TemplateCodeBox(
                        title = "docker-compose.yml (FastAPI + SQLite Cache)",
                        language = "YAML",
                        code = """
version: '3.8'
services:
  nexus-blog:
    build: .
    ports:
      - "8000:8000"
    environment:
      - PORT=8000
      - DB_PATH=/data/nexus_blog.db
      - ENVIRONMENT=production
    volumes:
      - ./data:/data
      - ./posts:/app/posts
    restart: always
                        """.trimIndent()
                    )
                }

                // main.py entry code Box
                item {
                    TemplateCodeBox(
                        title = "main.py (FastAPI Routing Entry)",
                        language = "Python",
                        code = """
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Nexus Blog Server", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/posts")
def list_sovereign_posts():
    # Load and resolve local metadata from /posts/ markdown files
    return {"posts": []}
                        """.trimIndent()
                    )
                }
            }
        } else {
            // Console View: Server nodes list & Live click deploy executions
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Unified Terminal Console View
                item {
                    TerminalConsole(
                        logs = cliLogs,
                        isProcessing = isDeploying
                    )
                }

                // Servers List Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIVE SOVEREIGN DEPLOY TARGET DECK:",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray
                        )
                        
                        Button(
                            onClick = { showConfigDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222C3F)),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.testTag("add_target_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add", tint = Color(0xFF29B6F6), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ADD HOST target", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF29B6F6))
                        }
                    }
                }

                // Servers list display card
                if (servers.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF121824)),
                            border = BorderStroke(1.dp, Color(0xFF333333)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                                Text("No deployment server profiles found. Tap Add Host target.", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                } else {
                    items(servers) { server ->
                        ServerInfoCard(
                            server = server,
                            onDeploy = {
                                selectedServerForLogs = server
                                viewModel.runDeploymentPipeline(server)
                            },
                            onDelete = { viewModel.deleteHostingServer(server) },
                            isDeploying = isDeploying
                        )
                    }
                }
            }
        }
    }

    // Modal Sheet Configuration Dialog
    if (showConfigDialog) {
        AlertDialog(
            onDismissRequest = { showConfigDialog = false },
            title = {
                Text(
                    text = "Configure New VPS Array target",
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newServerName,
                        onValueChange = { newServerName = it },
                        modifier = Modifier.fillMaxWidth().testTag("add_srv_name"),
                        label = { Text("Display Label") },
                        placeholder = { Text("e.g., Dallas-VPS Node") },
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newServerHost,
                        onValueChange = { newServerHost = it },
                        modifier = Modifier.fillMaxWidth().testTag("add_srv_host"),
                        label = { Text("IP Address / Domain") },
                        placeholder = { Text("e.g., 104.24.120.45") },
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newServerPort,
                        onValueChange = { newServerPort = it },
                        modifier = Modifier.fillMaxWidth().testTag("add_srv_port"),
                        label = { Text("Port Number") },
                        singleLine = true
                    )

                    // Type selection row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("VPS_FASTAPI", "DOCKER_CONTAINER").forEach { typ ->
                            val isSel = newServerType == typ
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(
                                        1.dp,
                                        if (isSel) Color(0xFF29B6F6) else Color.Gray,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .clickable { newServerType = typ }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    typ.replace("_", " "),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isSel) Color(0xFF29B6F6) else Color.LightGray
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = newServerEnv,
                        onValueChange = { newServerEnv = it },
                        modifier = Modifier.fillMaxWidth().testTag("add_srv_env"),
                        label = { Text("Custom Environment Keys (.env)") },
                        placeholder = { Text("PORT=8000,SECRET_KEY=ABC") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val portInt = newServerPort.toIntOrNull() ?: 8000
                        viewModel.addNewSelfHostedServer(
                            name = newServerName,
                            host = newServerHost,
                            port = portInt,
                            type = newServerType,
                            env = newServerEnv
                        )
                        showConfigDialog = false
                        newServerName = ""
                        newServerHost = ""
                    },
                    modifier = Modifier.testTag("srv_dialog_submit"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF29B6F6))
                ) {
                    Text("ADD METRICS TARGET", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfigDialog = false }) {
                    Text("CANCEL", color = Color.LightGray)
                }
            },
            containerColor = Color(0xFF131A26)
        )
    }
}

@Composable
fun ServerInfoCard(
    server: HostingServer,
    onDeploy: () -> Unit,
    onDelete: () -> Unit,
    isDeploying: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF222C3F), RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF121824)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Title & Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (server.deploymentType == "DOCKER_CONTAINER") Icons.Default.DirectionsBoat else Icons.Default.Computer,
                        contentDescription = "Server Node type",
                        tint = Color(0xFF29B6F6),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = server.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${server.hostAddress}:${server.port}  (Stack: ${server.deploymentType.replace("_", " ")})",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Gray
                        )
                    }
                }

                // Delete Host Profile
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp).testTag("delete_server_${server.id}")) {
                    Icon(Icons.Default.DeleteForever, contentDescription = "Delete Server Profile", tint = Color(0xFFFF5F56), modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Environments summary
            if (server.environmentVariables.isNotEmpty()) {
                Text("Environment Configuration:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F141F), RoundedCornerShape(4.dp))
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    server.environmentVariables.split(",").take(3).forEach { env ->
                        val parts = env.split("=")
                        val k = parts.getOrNull(0) ?: ""
                        val v = parts.getOrNull(1) ?: ""
                        Column {
                            Text(k, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                            Text(v, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Deployment Status Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Online/Last Sync labels
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (server.isConnected) Color(0xFF27C93F) else Color.Gray)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (server.isConnected) "SYNCHRONIZED ONLINE" else "DISCONNECTED",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (server.isConnected) Color(0xFF27C93F) else Color.Gray
                        )
                    }
                    if (server.lastDeployTimestamp > 0) {
                        Text(
                            text = "Last sync: 2026-06-12",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color.DarkGray
                        )
                    }
                }

                // Sync build execution trigger
                Button(
                    onClick = onDeploy,
                    enabled = !isDeploying,
                    modifier = Modifier.testTag("deploy_srv_btn_${server.id}"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF29B6F6)),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = "Deploy", tint = Color.Black, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("NEXUS DEPLOY", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

@Composable
fun TemplateCodeBox(
    title: String,
    language: String,
    code: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF222C3F), RoundedCornerShape(6.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F141F)),
        shape = RoundedCornerShape(6.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                
                Surface(
                    color = Color(0xFF1E293D),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = language,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Core copy cell
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = code,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Color(0xFFA9B1D6),
                    lineHeight = 15.sp
                )
            }
        }
    }
}
