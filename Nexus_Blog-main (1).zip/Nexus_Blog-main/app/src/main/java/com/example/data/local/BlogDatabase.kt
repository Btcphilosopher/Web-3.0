package com.example.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.data.model.BlogPost
import com.example.data.model.BlogPlugin
import com.example.data.model.HostingServer

@Database(
    entities = [BlogPost::class, BlogPlugin::class, HostingServer::class],
    version = 1,
    exportSchema = false
)
abstract class BlogDatabase : RoomDatabase() {
    abstract fun blogDao(): BlogDao
}
