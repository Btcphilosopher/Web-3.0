package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BlogPost
import com.example.data.model.BlogPlugin
import com.example.data.model.HostingServer
import kotlinx.coroutines.flow.Flow

@Dao
interface BlogDao {

    // --- Post Queries ---
    @Query("SELECT * FROM blog_posts ORDER BY id DESC")
    fun getAllPosts(): Flow<List<BlogPost>>

    @Query("SELECT * FROM blog_posts WHERE id = :postId")
    fun getPostById(postId: Int): Flow<BlogPost?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: BlogPost): Long

    @Update
    suspend fun updatePost(post: BlogPost)

    @Delete
    suspend fun deletePost(post: BlogPost)

    // --- Plugin Queries ---
    @Query("SELECT * FROM blog_plugins")
    fun getAllPlugins(): Flow<List<BlogPlugin>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlugin(plugin: BlogPlugin)

    @Query("UPDATE blog_plugins SET isEnabled = :isEnabled WHERE id = :pluginId")
    suspend fun setPluginEnabled(pluginId: String, isEnabled: Boolean)

    // --- Server Queries ---
    @Query("SELECT * FROM hosting_servers ORDER BY id DESC")
    fun getAllServers(): Flow<List<HostingServer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServer(server: HostingServer): Long

    @Query("DELETE FROM hosting_servers WHERE id = :serverId")
    suspend fun deleteServerById(serverId: Int)

    @Update
    suspend fun updateServer(server: HostingServer)
}
