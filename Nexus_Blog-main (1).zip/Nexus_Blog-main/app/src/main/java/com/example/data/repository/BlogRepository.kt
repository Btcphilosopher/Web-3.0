package com.example.data.repository

import com.example.data.local.BlogDao
import com.example.data.model.BlogPost
import com.example.data.model.BlogPlugin
import com.example.data.model.HostingServer
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class BlogRepository(private val blogDao: BlogDao) {

    val allPosts: Flow<List<BlogPost>> = blogDao.getAllPosts()
    val allPlugins: Flow<List<BlogPlugin>> = blogDao.getAllPlugins()
    val allServers: Flow<List<HostingServer>> = blogDao.getAllServers()

    fun getPostById(id: Int): Flow<BlogPost?> = blogDao.getPostById(id)

    suspend fun insertPost(post: BlogPost): Long = blogDao.insertPost(post)

    suspend fun updatePost(post: BlogPost) = blogDao.updatePost(post)

    suspend fun deletePost(post: BlogPost) = blogDao.deletePost(post)

    suspend fun setPluginEnabled(pluginId: String, isEnabled: Boolean) =
        blogDao.setPluginEnabled(pluginId, isEnabled)

    suspend fun insertPlugin(plugin: BlogPlugin) = blogDao.insertPlugin(plugin)

    suspend fun insertServer(server: HostingServer): Long = blogDao.insertServer(server)

    suspend fun deleteServerById(id: Int) = blogDao.deleteServerById(id)

    suspend fun updateServer(server: HostingServer) = blogDao.updateServer(server)

    suspend fun ensureDefaultDataPopulated() {
        // Populating default posts if database is empty
        val currentPosts = blogDao.getAllPosts().firstOrNull()
        if (currentPosts.isNullOrEmpty()) {
            val defaultPosts = listOf(
                BlogPost(
                    title = "Simulating Sandboxed Gravity inside Custom Layout Components",
                    subtitle = "A live canvas widget displaying gravity simulations within dynamic markdown essays.",
                    author = "Aura Vance",
                    content = """
# Sandboxed Gravity Mechanics

This scientific blog post shows how the **NEXUS BLOG** hybrid rendering engine resolves interactive code blocks into rich system layers. Developers can use Kotlin-like HTML tags or markdown inline wrappers to bind variables directly to state.

Here we have an interactive physics sandbox compiling direct gravity formulas. Adjust the slider controls below to manipulate the planetary gravity constant and observe real-time vector decay inside the custom Canvas viewport:

- Plan: Double mass vectors, apply 1/r^2 drag, evaluate particle collision matrices.
- Controls: Modifying the gravity constant affects kinetic energy curves instantly.

### Interactive Sandbox Component:
<<PHYSICS_SANDBOX>>

Using self-hosted CSS classes and standard vector components, this card evaluates layout bounding boxes dynamically, avoiding pixelated container overflows on tablet views.
                    """.trimIndent(),
                    status = "PUBLISHED",
                    type = "INTERACTIVE",
                    date = "June 12, 2026",
                    readTimeMinutes = 5
                ),
                BlogPost(
                    title = "Computational Publishing: High-Performance Matrix Operations with WebAssembly",
                    subtitle = "Running serverless computations, live terminal logging, and multi-language execution blocks.",
                    author = "Dr. Cole Reyes",
                    content = """
# Matrix Multipliers & Performance-Critical Modules

Modern technical authors need their documents to be living environments. In NEXUS BLOG, you are not writing representations of code — you are compiling documents with a integrated runtime.

You can write C modules compiled to **WebAssembly**, run sandboxed **Python** matrix multiplications, or execute custom **JavaScript** layout scripts.

Toggle between Python, JS, and JS-compiled WebAssembly execution modes using the sandbox editor below. Change the source code and press **"Execute Script"** to trigger the on-device compiler output console:

<<CODE_NOTEBOOK>>

### Extensibility Pipeline
1. High-fidelity tokenizer parses standard markdown + MDX wrappers.
2. Sandboxing hooks validate safe execution policies.
3. Pre-compiled WASM binaries receive high-dimensional arrays of dimensions 2x2 up to 1024x1024.
                    """.trimIndent(),
                    status = "PUBLISHED",
                    type = "CODE_INTEGRATED",
                    date = "May 28, 2026",
                    readTimeMinutes = 7
                ),
                BlogPost(
                    title = "Decentralized Hosting, ActivityPub Federation, and Sovereign Media",
                    subtitle = "Deploying autonomous container builds onto private virtual arrays with integrated podcast streams.",
                    author = "Sovereign Dev",
                    content = """
# Sovereign Creator Networks

Social networks and centralized publishing channels represent a fragile baseline for modern writers and journalists. When you publish a thread on Substack or Medium, you participate in leased tenancy.

**NEXUS BLOG** operates identically to WordPress on the hosting layer, but resembles GitHub Pages for developer version control, and provides Substack audience federation rules by default.

This audio asset teaches you how to deploy high-efficiency RSS configurations. Play the technical summary using the integrated podcast waveform deck below:

<<AUDIO_PODCAST>>

### How self-hosted DASH & HLS works:
- Video tracks are fragmented into `.ts` blobs.
- Audio visualizers measure wave frequencies dynamically inside the on-device Media Pipeline.

You can also preview chapters of the deployment webinar detailing physical server setups:

<<VIDEO_CHAPTERS>>
                    """.trimIndent(),
                    status = "PUBLISHED",
                    type = "STANDARD",
                    date = "April 15, 2026",
                    readTimeMinutes = 9,
                    youtubeVideoId = "dQw4w9WgXcQ", // Simulated high quality URL stream
                    hasVideo = true,
                    videoChapterMarkers = "0:Webinar Intro|45:Configuring Docker Compose|120:DNS Records & SSL Setup|210:ActivityPub Federation Protocol",
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", // Public safe sample mp3 stream
                    hasAudio = true,
                    audioDurationMs = 372000L
                )
            )

            for (post in defaultPosts) {
                blogDao.insertPost(post)
            }
        }

        // Populating default plugins if empty
        val currentPlugins = blogDao.getAllPlugins().firstOrNull()
        if (currentPlugins.isNullOrEmpty()) {
            val defaultPlugins = listOf(
                BlogPlugin(
                    id = "latex_compiler",
                    name = "LaTeX MathJax Parser",
                    type = "JAVASCRIPT",
                    currentVersion = "3.2.1",
                    description = "Enables beautiful LaTeX formulas (\$E = mc^2\$) dynamically inside blog posts using an embedded, performance-optimized MathJax compilation script.",
                    scriptContent = "console.log('MathJax loaded successfully. Compiling formula blocks...');",
                    isEnabled = true,
                    permissionScope = "READ_CONTENT"
                ),
                BlogPlugin(
                    id = "activity_pub_federation",
                    name = "ActivityPub Federation Gateway",
                    type = "PYTHON",
                    currentVersion = "1.0.4",
                    description = "Hooks into FastAPI routing to federate native articles directly to Mastodon, Threads, and external sovereign systems over ActivityPub protocols.",
                    scriptContent = "def route_mastodon_payload(blog_post):\n    print('Broadcasting federation activity for post ID: ' + str(blog_post.id))\n",
                    isEnabled = false,
                    permissionScope = "NETWORK_API, READ_STORAGE"
                ),
                BlogPlugin(
                    id = "wasm_matrix_accelerator",
                    name = "WASM Matrix Cruncher",
                    type = "WASM",
                    currentVersion = "2.1.0",
                    description = "Adds compiled WebAssembly support to execute intense 3D render physics and machine learning array computations within custom canvas widgets.",
                    scriptContent = "[WASM Binary Header - 2.1.0 Compiled Node]",
                    isEnabled = true,
                    permissionScope = "LOW_LEVEL_CPU"
                )
            )

            for (plugin in defaultPlugins) {
                blogDao.insertPlugin(plugin)
            }
        }

        // Populating default servers if empty
        val currentServers = blogDao.getAllServers().firstOrNull()
        if (currentServers.isNullOrEmpty()) {
            val defaultServers = listOf(
                HostingServer(
                    name = "Primary Array (Local FastAPI Dev)",
                    hostAddress = "127.0.0.1",
                    port = 8000,
                    deploymentType = "VPS_FASTAPI",
                    isConnected = true,
                    environmentVariables = "PORT=8000,DEBUG=True,DB_PATH=/var/lib/nexus/blog.db,SECURITY_ENCRYPT_ALG=RSA-256",
                    lastDeployTimestamp = System.currentTimeMillis() - 259200000L
                ),
                HostingServer(
                    name = "Singapore DigitalOcean Droplet (Docker Cluster)",
                    hostAddress = "159.65.12.87",
                    port = 443,
                    deploymentType = "DOCKER_CONTAINER",
                    isConnected = false,
                    environmentVariables = "PORT=443,DOCKER_TLS_VERIFY=1,APP_NAME=NEXUS-NODE,FEDERATION_ENABLED=True",
                    lastDeployTimestamp = 0L
                )
            )

            for (server in defaultServers) {
                blogDao.insertServer(server)
            }
        }
    }
}
