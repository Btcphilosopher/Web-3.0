package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Commonwealth Premium Dark Theme Palette
val CyberBlack = Color(0xFF030508)
val DarkSlate = Color(0xFF0A0F17)
val CardSlate = Color(0xFF111827)
val BorderSlate = Color(0xFF1F2937)

val CyberCyan = Color(0xFF00FFCC)
val CyberEmerald = Color(0xFF10B981)
val GoldAccent = Color(0xFFFBBF24)
val CrimsonAlert = Color(0xFFEF4444)

val TextWhite = Color(0xFFF9FAFB)
val TextMuted = Color(0xFF9CA3AF)
val TextDark = Color(0xFF4B5563)
val TerminalLog = Color(0xFF34D399)

