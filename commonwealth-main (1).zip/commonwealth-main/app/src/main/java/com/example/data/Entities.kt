package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "identity_profile")
data class IdentityProfile(
    @PrimaryKey val id: Int = 1,
    val did: String = "did:key:z6Mku7z6Mku" + UUID.randomUUID().toString().replace("-", "").take(16),
    val name: String = "Sovereign Citizen",
    val publicKey: String = "03a89e92bc491902..." + UUID.randomUUID().toString().hashCode().toString(16),
    val seedPhrase: String = "sovereign web network common wealth cloud secure decentralized linux terminal alpha",
    val passkeyEnabled: Boolean = true,
    val backupStatus: String = "Encrypted & Distributed"
)

@Entity(tableName = "sovereign_websites")
data class SovereignWebsite(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val htmlContent: String,
    val cssContent: String,
    val jsContent: String,
    val category: String,
    val version: Int = 1,
    val deployedHash: String = "ipfs://Qm" + UUID.randomUUID().toString().replace("-", "").take(32),
    val ownerDid: String,
    val isLive: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallet_state")
data class WalletState(
    @PrimaryKey val id: Int = 1,
    val btcBalance: Double = 0.4285,
    val usdBalance: Double = 12500.0,
    val gbpBalance: Double = 8900.0,
    val resourceCredits: Double = 7500.0
)

@Entity(tableName = "wallet_transactions")
data class WalletTransaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val coin: String, // "BTC", "USD", "GBP", "CREDITS"
    val txType: String, // "SEND", "RECEIVE", "SWAP", "PAY", "MINED"
    val amount: Double,
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val hash: String = "0x" + UUID.randomUUID().toString().replace("-", "")
)

@Entity(tableName = "node_sharing_state")
data class NodeSharingState(
    @PrimaryKey val id: Int = 1,
    val isMining: Boolean = false,
    val allocatedCpu: Float = 50.0f, // percentage
    val allocatedRam: Float = 4.0f, // GB
    val allocatedStorage: Float = 20.0f, // GB
    val totalCreditsEarned: Double = 145.20,
    val uptimeSeconds: Long = 18400L,
    val averageBandwidthMbps: Float = 45.8f,
    val currentBps: Long = 45000000L
)
