package com.example.data

import android.util.Log
import com.example.BuildConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val MODEL_NAME = "gemini-3.5-flash"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    // Data class to represent the generated site code.
    data class GeneratedSite(
        val html: String,
        val css: String,
        val js: String,
        val description: String,
        val brandName: String
    )

    suspend fun generateWeb3Site(prompt: String): GeneratedSite? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e(TAG, "Gemini API key is blank or mock. Emulating high-fidelity local generation.")
            return@withContext generateEmulatedSite(prompt)
        }

        // We want a standard structured format. We prompt Gemini to output a strict, parseable JSON payload.
        val systemPrompt = """
            You are Commonwealth AI Architect, an expert Web 3.0 developer and UI/UX designer. Your task is to generate website mock files (HTML, CSS, JS) based on the user's brand prompt.
            You must output a single valid JSON object with EXACTLY the following keys:
            - 'brandName': A short, elegant brand name or title for the page.
            - 'description': A brief, 1-sentence descriptor of what was generated.
            - 'html': Full single-page responsive webpage design. It must have elegant structure, custom sections, proper text copy, and reference class names (no external assets besides FontAwesome or standard CDN fonts). DO NOT include <html>, <head> or <body> tags. Just write the inner body content layout (e.g. headers, main, hero sections, grids, lists, footers) to embed in a container. Use Material 3-like styling, grids, dark ambient tones.
            - 'css': A clean CSS stylesheet styles targeting the generated elements. Use beautiful color aesthetics (deep background, slate accents, text gradients, smooth transitions, shadows).
            - 'js': JavaScript code adding interactivity (e.g. simple state changes, clicking filters, interactive product details, contact form simulation, crypto-wallet payment triggers, simulated decentralized deployment).
            
            Strictly return ONLY the raw JSON block without markdown formatting or code wrappers. Ensure it is valid, double-escaped JSON. No block comments in CSS or JS that could break parsing if they contain quote marks.
        """.trimIndent()

        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"

        val requestPayload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "User Prompt: Generate a creative Web 3.0 site for: $prompt")
                        })
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemPrompt)
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }

        val request = Request.Builder()
            .url(endpoint)
            .post(requestPayload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string()
                    Log.e(TAG, "Request failed code: ${response.code}, body: $errBody")
                    return@withContext generateEmulatedSite(prompt)
                }

                val bodyStr = response.body?.string() ?: return@withContext generateEmulatedSite(prompt)
                val jsonObject = JSONObject(bodyStr)
                val candidates = jsonObject.optJSONArray("candidates")
                val textResponse = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text") ?: ""

                Log.d(TAG, "Raw text response from Gemini: $textResponse")

                // Parse the inner JSON returned from the Model
                val resultJson = JSONObject(textResponse.trim())
                GeneratedSite(
                    html = resultJson.optString("html", "<h1>Hello Web3</h1>"),
                    css = resultJson.optString("css", "body { background: #121212; color: white; }"),
                    js = resultJson.optString("js", "console.log('Sovereign Client Init');"),
                    description = resultJson.optString("description", "A custom Web3 landing page"),
                    brandName = resultJson.optString("brandName", "My Web3 App")
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during site generation", e)
            generateEmulatedSite(prompt)
        }
    }

    private fun generateEmulatedSite(prompt: String): GeneratedSite {
        // High fidelity emulation if offline or key is missing. This respects offline-first usability.
        val brand = prompt.replace("Create a ", "").replace("create a ", "").replace(" brand", "").replace(" website", "").trim().capitalize()
        val fixedBrand = if (brand.isEmpty()) "Alpha Tech" else brand
        
        val html = """
            <div class="web3-container">
                <header class="app-header">
                    <div class="logo">🧬 $fixedBrand</div>
                    <div class="network-badge">COMMONWEALTH L2</div>
                </header>
                
                <section class="hero-section">
                    <h1>Sovereign Ownership of <span>$fixedBrand</span></h1>
                    <p class="description">This property is cryptographically hosted on the decentralized Commonwealth Operating System. Zero intermediate servers. Full user governance.</p>
                    <div class="button-row">
                        <button class="btn btn-primary" onclick="simulateAction('interact')">Activate Node</button>
                        <button class="btn btn-outline" onclick="simulateAction('pay')">Purchase via BTC</button>
                    </div>
                </section>
                
                <section class="features-grid">
                    <div class="feat-card">
                        <div class="f-icon">⛓️</div>
                        <h3>Decentralized Identity</h3>
                        <p>Fully compliant with W3C DID specifications.</p>
                    </div>
                    <div class="feat-card">
                        <div class="f-icon">🛸</div>
                        <h3>WebAssembly Host</h3>
                        <p>Lightning calculations sandboxed locally in the browser.</p>
                    </div>
                    <div class="feat-card">
                        <div class="f-icon">🔋</div>
                        <h3>Sovereign Marketplace</h3>
                        <p>Integrated decentralized billing model.</p>
                    </div>
                </section>
                
                <div class="wallet-status" id="ws-box">
                    <p id="statusText">Status: Web3 Portal Ready. Connect sovereign wallet credentials below.</p>
                </div>
            </div>
        """.trimIndent()

        val css = """
            .web3-container {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                background-color: #0b0c10;
                color: #c5c6c7;
                padding: 24px;
                border-radius: 16px;
                box-shadow: 0 8px 32px rgba(0,0,0,0.4);
                max-width: 800px;
                margin: 0 auto;
                border: 1px solid #1f2833;
            }
            .app-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid #1f2833;
                padding-bottom: 16px;
                margin-bottom: 24px;
            }
            .logo {
                font-size: 1.5rem;
                font-weight: 800;
                color: #66fcf1;
                letter-spacing: 1px;
            }
            .network-badge {
                font-size: 0.75rem;
                background: #1f2833;
                color: #66fcf1;
                padding: 4px 10px;
                border-radius: 20px;
                border: 1px solid #66fcf1;
            }
            .hero-section {
                text-align: center;
                padding: 16px 0 32px 0;
            }
            .hero-section h1 {
                font-size: 2.2rem;
                color: #ffffff;
                margin-bottom: 12px;
                line-height: 1.2;
            }
            .hero-section h1 span {
                color: #66fcf1;
            }
            .hero-section p {
                font-size: 1.05rem;
                line-height: 1.6;
                color: #8b949e;
                max-width: 600px;
                margin: 0 auto 24px auto;
            }
            .button-row {
                display: flex;
                gap: 12px;
                justify-content: center;
            }
            .btn {
                padding: 12px 24px;
                border-radius: 8px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.2s ease;
            }
            .btn-primary {
                background: #66fcf1;
                color: #0b0c10;
                border: none;
            }
            .btn-primary:hover {
                background: #45a29e;
            }
            .btn-outline {
                background: transparent;
                color: #c5c6c7;
                border: 1px solid #45a29e;
            }
            .btn-outline:hover {
                border-color: #66fcf1;
                color: #fff;
            }
            .features-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 16px;
                margin-top: 16px;
            }
            .feat-card {
                background: #1f2833;
                padding: 16px;
                border-radius: 12px;
                border: 1px solid #1f2833;
                transition: transform 0.2s;
            }
            .feat-card:hover {
                transform: translateY(-4px);
                border-color: #45a29e;
            }
            .f-icon {
                font-size: 1.8rem;
                margin-bottom: 8px;
            }
            .feat-card h3 {
                color: #fff;
                margin: 0 0 8px 0;
                font-size: 1.1rem;
            }
            .feat-card p {
                font-size: 0.85rem;
                color: #8b949e;
                margin: 0;
                line-height: 1.4;
            }
            .wallet-status {
                margin-top: 24px;
                padding: 12px 16px;
                border-radius: 8px;
                background: #0b0c10;
                border-left: 4px solid #66fcf1;
                font-size: 0.9rem;
                text-align: center;
            }
        """.trimIndent()

        val js = """
            function simulateAction(action) {
                var box = document.getElementById("ws-box");
                var text = document.getElementById("statusText");
                if (action === 'interact') {
                    text.innerText = "🌐 Core Node Connection Initialized! Proof-of-Authority verification complete.";
                    box.style.borderLeftColor = "#45a29e";
                } else if (action === 'pay') {
                    text.innerText = "💳 Dispatching native bitcoin invoice. Check your Commonwealth Wallet!";
                    box.style.borderLeftColor = "orange";
                }
            }
        """.trimIndent()

        return GeneratedSite(
            html = html,
            css = css,
            js = js,
            description = "Sovereign platform for $fixedBrand hosted directly inside your decentralized browser storage nodes.",
            brandName = fixedBrand
        )
    }
}
