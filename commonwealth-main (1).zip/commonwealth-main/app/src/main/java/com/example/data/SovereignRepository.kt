package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class SovereignRepository(private val db: AppDatabase) {
    val identityProfile: Flow<IdentityProfile?> = db.identityDao().getProfile()
    val websites: Flow<List<SovereignWebsite>> = db.websiteDao().getAllWebsites()
    val walletState: Flow<WalletState?> = db.walletDao().getWalletState()
    val transactions: Flow<List<WalletTransaction>> = db.transactionDao().getAllTransactions()
    val nodeSharingState: Flow<NodeSharingState?> = db.nodeSharingDao().getNodeState()

    suspend fun checkAndSeedInitialDatabase() {
        // Seed initial Profile if absent
        val existingProfile = db.identityDao().getProfile().firstOrNull()
        if (existingProfile == null) {
            db.identityDao().insertOrUpdateProfile(IdentityProfile())
        }

        // Seed initial wallet balance if absent
        val existingWallet = db.walletDao().getWalletState().firstOrNull()
        if (existingWallet == null) {
            db.walletDao().insertOrUpdateWalletState(WalletState())
            // Seed a few demo transactions
            db.transactionDao().insertTransaction(
                WalletTransaction(
                    coin = "CREDITS",
                    txType = "RECEIVE",
                    amount = 5000.0,
                    details = "Genesis Allocation (Developer Grant)"
                )
            )
            db.transactionDao().insertTransaction(
                WalletTransaction(
                    coin = "BTC",
                    txType = "RECEIVE",
                    amount = 0.4285,
                    details = "Imported Cold Wallet Signature"
                )
            )
        }

        // Seed initial Node Sharing structure if absent
        val existingNode = db.nodeSharingDao().getNodeState().firstOrNull()
        if (existingNode == null) {
            db.nodeSharingDao().insertOrUpdateNodeState(NodeSharingState())
        }
    }

    suspend fun saveIdentityProfile(profile: IdentityProfile) = db.identityDao().insertOrUpdateProfile(profile)
    
    suspend fun saveWebsite(website: SovereignWebsite): Long = db.websiteDao().insertWebsite(website)
    
    suspend fun deleteWebsite(website: SovereignWebsite) = db.websiteDao().deleteWebsite(website)
    
    suspend fun getWebsiteById(id: Int): SovereignWebsite? = db.websiteDao().getWebsiteById(id)

    suspend fun saveWalletState(state: WalletState) = db.walletDao().insertOrUpdateWalletState(state)

    suspend fun addTransaction(transaction: WalletTransaction) {
        db.transactionDao().insertTransaction(transaction)
    }

    suspend fun saveNodeSharingState(state: NodeSharingState) = db.nodeSharingDao().insertOrUpdateNodeState(state)
}
