package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class CommonwealthViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val repository = SovereignRepository(db)

    // Room Database states
    val profile: StateFlow<IdentityProfile?> = repository.identityProfile.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val websites: StateFlow<List<SovereignWebsite>> = repository.websites.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val walletState: StateFlow<WalletState?> = repository.walletState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val transactions: StateFlow<List<WalletTransaction>> = repository.transactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val nodeSharingState: StateFlow<NodeSharingState?> = repository.nodeSharingState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // Tab state: "DASHBOARD", "TERMINAL", "IDENTITY", "WALLET", "BUILDER", "MARKETPLACE", "RESOURCES", "FILES", "ROADMAP"
    var activeTab by mutableStateOf("DASHBOARD")
        private set

    fun selectTab(tab: String) {
        activeTab = tab
    }

    // AI Site Architect Generation states
    var isGeneratingSite by mutableStateOf(false)
        private set
    var generationStatus by mutableStateOf("")
        private set

    // Website selection and edit forms
    var selectedWebsiteForPreview by mutableStateOf<SovereignWebsite?>(null)
    var editHtml by mutableStateOf("")
    var editCss by mutableStateOf("")
    var editJs by mutableStateOf("")
    var editName by mutableStateOf("")

    // Terminal Emulator state
    var terminalInput by mutableStateOf("")
    var terminalConsoleLogs by mutableStateOf(listOf(
        "COMMONWEALTH SOVEREIGN OS [Version 0.9.1-beta]",
        "(c) 2026 Sovereign Web Alliance. Distributed kernel loaded.",
        "Type 'help' to examine secure decentralized command registry.",
        "Secure digital sandbox initialized at /home/sovereign."
    ))

    // Mining Ticker Thread management
    private var miningJob: Job? = null

    init {
        viewModelScope.launch {
            repository.checkAndSeedInitialDatabase()
            startMiningTickLoop()
        }
    }

    // High fidelity ticking loops for CPU resource contribution mining
    private fun startMiningTickLoop() {
        miningJob?.cancel()
        miningJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val node = nodeSharingState.value ?: continue
                if (node.isMining) {
                    val rate = 0.05 * (node.allocatedCpu / 50.0f)
                    val newCredits = node.totalCreditsEarned + rate
                    val newUptime = node.uptimeSeconds + 1L
                    val newBps = (1000000..90000000).random().toLong()

                    // update node state
                    repository.saveNodeSharingState(
                        node.copy(
                            totalCreditsEarned = newCredits,
                            uptimeSeconds = newUptime,
                            currentBps = newBps
                        )
                    )

                    // add to wallet state
                    val wallet = walletState.value
                    if (wallet != null) {
                        repository.saveWalletState(
                            wallet.copy(resourceCredits = wallet.resourceCredits + rate)
                        )
                    }

                    // Occasionally log an earn transaction or update local state
                    if (newUptime % 10 == 0L) {
                        repository.addTransaction(
                            WalletTransaction(
                                coin = "CREDITS",
                                txType = "MINED",
                                amount = rate * 10,
                                details = "Node resource contribution allocation (PoW credits)"
                            )
                        )
                    }
                }
            }
        }
    }

    // Identity functions
    fun regenerateSovereignKeys(newName: String) {
        viewModelScope.launch {
            val oldDoc = profile.value ?: IdentityProfile()
            val newProfile = IdentityProfile(
                id = 1,
                name = if (newName.isNotBlank()) newName else oldDoc.name,
                did = "did:key:z6Mku7z" + UUID.randomUUID().toString().replace("-", "").take(16),
                publicKey = "03a89e" + UUID.randomUUID().toString().replace("-", "").take(20),
                seedPhrase = "sovereign web network common wealth cloud secure decentralized linux terminal alpha " + (100..999).random(),
                passkeyEnabled = oldDoc.passkeyEnabled,
                backupStatus = "Distributed Key Recovery Set"
            )
            repository.saveIdentityProfile(newProfile)
            addTerminalLogs(listOf("SYSTEM: Regenerated decentralized identity keys for '${newProfile.name}'. DID is ${newProfile.did}"))
        }
    }

    fun togglePasskey(enabled: Boolean) {
        viewModelScope.launch {
            val oldDoc = profile.value ?: IdentityProfile()
            repository.saveIdentityProfile(oldDoc.copy(passkeyEnabled = enabled))
            addTerminalLogs(listOf("SECURITY: Passkey validation state changed to: $enabled"))
        }
    }

    // Wallet functions
    fun simulateSendCrypto(coin: String, amount: Double, recipientDid: String, description: String = "Sovereign Settlement") {
        viewModelScope.launch {
            val wallet = walletState.value ?: return@launch
            if (amount <= 0) return@launch

            val isSufficient = when (coin) {
                "BTC" -> wallet.btcBalance >= amount
                "USD" -> wallet.usdBalance >= amount
                "GBP" -> wallet.gbpBalance >= amount
                "CREDITS" -> wallet.resourceCredits >= amount
                else -> false
            }

            if (!isSufficient) {
                addTerminalLogs(listOf("WALLET WARNING: Insufficient balance to send $amount $coin to $recipientDid"))
                return@launch
            }

            // Deduct balance
            val updatedWallet = when (coin) {
                "BTC" -> wallet.copy(btcBalance = wallet.btcBalance - amount)
                "USD" -> wallet.copy(usdBalance = wallet.usdBalance - amount)
                "GBP" -> wallet.copy(gbpBalance = wallet.gbpBalance - amount)
                "CREDITS" -> wallet.copy(resourceCredits = wallet.resourceCredits - amount)
                else -> wallet
            }
            repository.saveWalletState(updatedWallet)

            // Save transaction record
            repository.addTransaction(
                WalletTransaction(
                    coin = coin,
                    txType = "SEND",
                    amount = amount,
                    details = "To: ${recipientDid.take(15)}... ($description)"
                )
            )
            addTerminalLogs(listOf("WALLET SUCCESS: Sent $amount $coin to recipient DID: $recipientDid. Transaction ID logged."))
        }
    }

    fun simulateSwap(sourceCoin: String, destCoin: String, sourceAmount: Double) {
        viewModelScope.launch {
            val wallet = walletState.value ?: return@launch
            if (sourceAmount <= 0) return@launch

            val isSufficient = when (sourceCoin) {
                "BTC" -> wallet.btcBalance >= sourceAmount
                "USD" -> wallet.usdBalance >= sourceAmount
                "GBP" -> wallet.gbpBalance >= sourceAmount
                "CREDITS" -> wallet.resourceCredits >= sourceAmount
                else -> false
            }

            if (!isSufficient) return@launch

            // Imprecise, high-fidelity mock conversion ratios
            val conversionRate = when {
                sourceCoin == "USD" && destCoin == "CREDITS" -> 1.0 / 0.10 // 1 credit = $0.10
                sourceCoin == "CREDITS" && destCoin == "BTC" -> 0.000001
                sourceCoin == "BTC" && destCoin == "USD" -> 68000.0
                sourceCoin == "USD" && destCoin == "BTC" -> 1.0 / 68000.0
                sourceCoin == "GBP" && destCoin == "USD" -> 1.28
                sourceCoin == "USD" && destCoin == "GBP" -> 1.0 / 1.28
                else -> 1.0 // default parity
            }

            val destAmount = sourceAmount * conversionRate

            val step1 = when (sourceCoin) {
                "BTC" -> wallet.copy(btcBalance = wallet.btcBalance - sourceAmount)
                "USD" -> wallet.copy(usdBalance = wallet.usdBalance - sourceAmount)
                "GBP" -> wallet.copy(gbpBalance = wallet.gbpBalance - sourceAmount)
                "CREDITS" -> wallet.copy(resourceCredits = wallet.resourceCredits - sourceAmount)
                else -> wallet
            }

            val step2 = when (destCoin) {
                "BTC" -> step1.copy(btcBalance = step1.btcBalance + destAmount)
                "USD" -> step1.copy(usdBalance = step1.usdBalance + destAmount)
                "GBP" -> step1.copy(gbpBalance = step1.gbpBalance + destAmount)
                "CREDITS" -> step1.copy(resourceCredits = step1.resourceCredits + destAmount)
                else -> step1
            }

            repository.saveWalletState(step2)

            repository.addTransaction(
                WalletTransaction(
                    coin = sourceCoin,
                    txType = "SWAP",
                    amount = sourceAmount,
                    details = "Exchanged $sourceAmount $sourceCoin for $destAmount $destCoin"
                )
            )
            addTerminalLogs(listOf("DEX SWAP: Exchanged $sourceAmount $sourceCoin to $destAmount $destCoin successfully!"))
        }
    }

    // Node & Mining contribution functions
    fun toggleMining(isMining: Boolean) {
        viewModelScope.launch {
            val node = nodeSharingState.value ?: return@launch
            repository.saveNodeSharingState(node.copy(isMining = isMining))
            addTerminalLogs(listOf("NODE MONITOR: Mining states updated. Node active: $isMining"))
        }
    }

    fun updateNodeAllocation(cpu: Float, ram: Float, storage: Float) {
        viewModelScope.launch {
            val node = nodeSharingState.value ?: return@launch
            repository.saveNodeSharingState(
                node.copy(
                    allocatedCpu = cpu,
                    allocatedRam = ram,
                    allocatedStorage = storage
                )
            )
            addTerminalLogs(listOf("NODE CONFIG: Updated resource contribution limits CPU: $cpu%, RAM: $ram GB, Storage: $storage GB"))
        }
    }

    // AI Web Architect and code builder operations
    fun generateSiteViaAI(prompt: String) {
        if (prompt.isBlank()) return
        isGeneratingSite = true
        generationStatus = "Initializing Sovereign Code Engine..."
        viewModelScope.launch {
            delay(800)
            generationStatus = "Broadcasting cryptographic prompt payload..."
            delay(1000)
            generationStatus = "AI Synthesizing static page mockup (HTML, CSS, JS)..."
            
            val result = GeminiClient.generateWeb3Site(prompt)
            if (result != null) {
                generationStatus = "Injecting design templates..."
                delay(800)
                generationStatus = "Signing local deployment ledger..."
                
                val userDid = profile.value?.did ?: "did:key:anonymous"
                val newSite = SovereignWebsite(
                    name = result.brandName,
                    description = result.description,
                    htmlContent = result.html,
                    cssContent = result.css,
                    jsContent = result.js,
                    category = "AI Generated",
                    ownerDid = userDid
                )
                val idLong = repository.saveWebsite(newSite)
                val insertedSite = newSite.copy(id = idLong.toInt())

                repository.addTransaction(
                    WalletTransaction(
                        coin = "CREDITS",
                        txType = "PAY",
                        amount = 45.0,
                        details = "AI site generation architect contract: '${result.brandName}'"
                    )
                )

                // update wallet credits fee
                val wallet = walletState.value
                if (wallet != null) {
                    repository.saveWalletState(wallet.copy(resourceCredits = (wallet.resourceCredits - 45.0).coerceAtLeast(0.0)))
                }

                selectedWebsiteForPreview = insertedSite
                editHtml = insertedSite.htmlContent
                editCss = insertedSite.cssContent
                editJs = insertedSite.jsContent
                editName = insertedSite.name

                addTerminalLogs(listOf(
                    "AI ENGINE: Generated '${result.brandName}' successfully.",
                    "DECENTRALIZED IPFS HASH: ${insertedSite.deployedHash}",
                    "BILLING: Paid 45.0 PoW credits for AI generation."
                ))
            } else {
                addTerminalLogs(listOf("AI ENGINE ERROR: Unstable REST feedback. Process reverted."))
            }
            isGeneratingSite = false
            generationStatus = ""
        }
    }

    fun deployLauncherTemplate(templateName: String, category: String) {
        viewModelScope.launch {
            val userDid = profile.value?.did ?: "did:key:anonymous"
            val html = """
                <div style="padding: 24px; text-align: center; color: white; background: radial-gradient(circle, #2d3748 0%, #1a202c 100%); border-radius: 12px; font-family: sans-serif;">
                    <div style="font-size: 3rem; margin-bottom: 12px;">🛸</div>
                    <h1 style="color: #66fcf1; margin-bottom: 8px;">Welcome to $templateName</h1>
                    <p style="color: #cbd5e0; line-height: 1.5; margin-bottom: 24px;">This is a fully decentralized, Sovereign template launched on the Commonwealth protocol.</p>
                    <button id="mainBtn" style="padding: 12px 24px; background-color: #66fcf1; border: none; color: #1a202c; font-weight: bold; border-radius: 8px; cursor: pointer;">
                        Verify Sovereign Identity
                    </button>
                    <p style="margin-top: 20px; font-size: 0.8rem; color: #a0aec0;" id="status">Status: Waiting for passkey login...</p>
                </div>
            """.trimIndent()

            val css = """
                body { margin: 0; background-color: #1a202c; color: #fff; }
                #mainBtn:hover { transform: scale(1.05); transition: 0.2s; }
            """.trimIndent()

            val js = """
                document.getElementById('mainBtn').addEventListener('click', function() {
                    document.getElementById('status').innerText = '🔑 DID Identity verified on-chain. Sovereign Node Active!';
                    document.getElementById('mainBtn').style.backgroundColor = '#45a29e';
                });
            """.trimIndent()

            val newSite = SovereignWebsite(
                name = templateName,
                description = "Sovereign $category template deployment.",
                htmlContent = html,
                cssContent = css,
                jsContent = js,
                category = category,
                ownerDid = userDid
            )

            val idLong = repository.saveWebsite(newSite)
            selectedWebsiteForPreview = newSite.copy(id = idLong.toInt())
            editHtml = html
            editCss = css
            editJs = js
            editName = templateName

            // charge credit fee
            val wallet = walletState.value
            if (wallet != null) {
                repository.saveWalletState(wallet.copy(resourceCredits = (wallet.resourceCredits - 20.0).coerceAtLeast(0.0)))
            }

            repository.addTransaction(
                WalletTransaction(
                    coin = "CREDITS",
                    txType = "PAY",
                    amount = 20.0,
                    details = "Deployed template: '$templateName'"
                )
            )

            addTerminalLogs(listOf(
                "SYSTEM: Initialized '$templateName' visual template.",
                "RESOURCE LOG: Charged 20.0 resource hosting credits."
            ))
        }
    }

    fun saveWebsiteChanges() {
        val current = selectedWebsiteForPreview ?: return
        viewModelScope.launch {
            val updated = current.copy(
                name = editName,
                htmlContent = editHtml,
                cssContent = editCss,
                jsContent = editJs,
                version = current.version + 1,
                timestamp = System.currentTimeMillis()
            )
            repository.saveWebsite(updated)
            selectedWebsiteForPreview = updated
            addTerminalLogs(listOf("BUILDER: Successfully deployed code update for '${updated.name}'. Bumped version to v${updated.version}"))
        }
    }

    fun deleteWebsite(website: SovereignWebsite) {
        viewModelScope.launch {
            repository.deleteWebsite(website)
            if (selectedWebsiteForPreview?.id == website.id) {
                selectedWebsiteForPreview = null
            }
            addTerminalLogs(listOf("BUILDER: Removed page registry for '${website.name}'"))
        }
    }

    // Terminal Input processing
    fun executeConsoleCommand() {
        val rawCmd = terminalInput.trim()
        if (rawCmd.isEmpty()) return

        val newHistory = terminalConsoleLogs.toMutableList()
        newHistory.add("> $rawCmd")

        val parts = rawCmd.split(" ")
        val command = parts[0].lowercase()

        when (command) {
            "help" -> {
                newHistory.addAll(listOf(
                    "COMMWANWEALTH SECURE COMMAND REGISTRY:",
                    "  help                    - Display available commands and execution guide.",
                    "  identity                - Visual audit of public key configuration and DID keys.",
                    "  wallet                  - Display balances and recent ledger activity logs.",
                    "  wallet send <amt> <did> - Dispatch coins/credits directly to another DID endpoint.",
                    "  mine                    - Connect device computing core and earn credits.",
                    "  resources               - Display storage, RAM, and CPU telemetry.",
                    "  gemini <prompt>         - Trigger AI Site Architect via deep developer script.",
                    "  clear                   - Clear current screen telemetry.",
                    "  version                 - Show operating system kernel revisions."
                ))
            }
            "clear" -> {
                terminalConsoleLogs = emptyList()
                terminalInput = ""
                return
            }
            "version" -> {
                newHistory.add("Commonwealth HyperKernel 0.9.1-beta-WASM x86_64.")
            }
            "identity" -> {
                val p = profile.value
                if (p != null) {
                    newHistory.addAll(listOf(
                        "--- CRYPTOGRAPHIC PROFILE STATE ---",
                        "NAME: ${p.name}",
                        "DID:  ${p.did}",
                        "PUB KEY: ${p.publicKey}",
                        "PASSKEY STATE: ${if (p.passkeyEnabled) "ACTIVE" else "DISABLED"}",
                        "BACKUP STATUS: ${p.backupStatus}",
                        "SEED Mnemonic (Restricted): [${p.seedPhrase}]"
                    ))
                } else {
                    newHistory.add("SYSTEM ERROR: Profile not synced.")
                }
            }
            "wallet" -> {
                val w = walletState.value
                if (w != null) {
                    newHistory.addAll(listOf(
                        "--- WALLET MATRIX BALANCES ---",
                        "  BTC Balance:        ${w.btcBalance} BTC",
                        "  stable USD Coin:    $${w.usdBalance} USD",
                        "  stable GBP Coin:    £${w.gbpBalance} GBP",
                        "  Resource Credits:   ${"%.4f".format(w.resourceCredits)} CREDITS"
                    ))
                } else {
                    newHistory.add("SYSTEM ERROR: Wallet not loaded.")
                }
            }
            "mine" -> {
                val node = nodeSharingState.value
                if (node != null) {
                    val nextMining = !node.isMining
                    toggleMining(nextMining)
                    newHistory.add("PoW MINING TELEMETRY CHANGED: Active = $nextMining")
                } else {
                    newHistory.add("SYSTEM ERROR: Mining node absent.")
                }
            }
            "resources" -> {
                val s = nodeSharingState.value
                val w = walletState.value
                if (s != null && w != null) {
                    newHistory.addAll(listOf(
                        "--- DISTRIBUTED RESOURCE PROFILE ---",
                        "  ALLOCATED CPU:  ${s.allocatedCpu}%",
                        "  ALLOCATED RAM:  ${s.allocatedRam} GB",
                        "  STORAGE CHUNK:  ${s.allocatedStorage} GB",
                        "  UPTIME TRACKER: ${s.uptimeSeconds} seconds",
                        "  BANDWIDTH STAT: ${s.averageBandwidthMbps} Mbps (Real-time: ${s.currentBps / 1000000.0} Mbps)",
                        "  ESTIMATED ACCRUAL: ${(s.allocatedCpu / 50.0f) * 0.05} Credits/sec",
                        "  COST INDEX RATIO: 1.0 GB Storage Deployment = 10 Credits/month"
                    ))
                } else {
                    newHistory.add("SYSTEM ERROR: Metrics unaligned.")
                }
            }
            "gemini" -> {
                if (parts.size < 2) {
                    newHistory.add("ERROR: Usage: gemini <prompt to architect website>")
                } else {
                    val prompt = parts.drop(1).joinToString(" ")
                    newHistory.add("AI COMPILING PROMPT: '$prompt'...")
                    generateSiteViaAI(prompt)
                }
            }
            "wallet" -> {
                if (parts.size >= 4 && parts[1].lowercase() == "send") {
                    val amtStr = parts[2]
                    val destDid = parts[3]
                    try {
                        val amt = amtStr.toDouble()
                        simulateSendCrypto("CREDITS", amt, destDid, "Terminal Transfer")
                        newHistory.add("TRANSACTION_BROADCAST: Pending block completion...")
                    } catch (e: Exception) {
                        newHistory.add("ERROR: Invalid amount parameters.")
                    }
                } else {
                    // standard print
                    val w = walletState.value
                    if (w != null) {
                        newHistory.addAll(listOf(
                            "--- WALLET MATRIX BALANCES ---",
                            "  BTC Balance:        ${w.btcBalance} BTC",
                            "  stable USD Coin:    $${w.usdBalance} USD",
                            "  Resource Credits:   ${"%.4f".format(w.resourceCredits)} CREDITS"
                        ))
                    }
                }
            }
            else -> {
                newHistory.add("UNRECOGNIZED DEC_SHELL COMMAND: '$command'. Type 'help' for support parameters.")
            }
        }

        terminalConsoleLogs = newHistory
        terminalInput = ""
    }

    private fun addTerminalLogs(logs: List<String>) {
        val temp = terminalConsoleLogs.toMutableList()
        temp.addAll(logs)
        terminalConsoleLogs = temp
    }
}
