package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface IdentityDao {
    @Query("SELECT * FROM identity_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<IdentityProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: IdentityProfile)
}

@Dao
interface SovereignWebsiteDao {
    @Query("SELECT * FROM sovereign_websites ORDER BY timestamp DESC")
    fun getAllWebsites(): Flow<List<SovereignWebsite>>

    @Query("SELECT * FROM sovereign_websites WHERE id = :id LIMIT 1")
    suspend fun getWebsiteById(id: Int): SovereignWebsite?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebsite(website: SovereignWebsite): Long

    @Delete
    suspend fun deleteWebsite(website: SovereignWebsite)
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallet_state WHERE id = 1 LIMIT 1")
    fun getWalletState(): Flow<WalletState?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateWalletState(state: WalletState)
}

@Dao
interface WalletTransactionDao {
    @Query("SELECT * FROM wallet_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<WalletTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: WalletTransaction)
}

@Dao
interface NodeSharingDao {
    @Query("SELECT * FROM node_sharing_state WHERE id = 1 LIMIT 1")
    fun getNodeState(): Flow<NodeSharingState?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateNodeState(state: NodeSharingState)
}
