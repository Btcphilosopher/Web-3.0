package com.example.ui

import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import java.util.UUID
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.IdentityProfile
import com.example.data.NodeSharingState
import com.example.data.SovereignWebsite
import com.example.data.WalletState
import com.example.data.WalletTransaction
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommonwealthDashboard(
    viewModel: CommonwealthViewModel,
    modifier: Modifier = Modifier
) {
    val activeTab = viewModel.activeTab
    val scaffoldState = rememberBottomSheetScaffoldState()
    val scope = rememberCoroutineScope()

    // Observe DB states
    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val websites by viewModel.websites.collectAsStateWithLifecycle()
    val walletState by viewModel.walletState.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val nodeState by viewModel.nodeSharingState.collectAsStateWithLifecycle()

    // Render primary edge-to-edge layout
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Systems Status bar (Bloomberg terminal / Linux dock vibe)
            SystemStatusBar(profile, walletState, nodeState)

            // Dynamic Core Workspace Layout
            Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
                // Adaptive Left Sidebar Dock
                AppSidebarDock(
                    activeTab = activeTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )

                // Main Display Workstation Box
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .background(DarkSlate)
                        .padding(16.dp)
                ) {
                    when (activeTab) {
                        "DASHBOARD" -> MainMetricsDashboard(
                            viewModel, profile, walletState, nodeState, websites, transactions
                        )
                        "IDENTITY" -> SovereignIdentityLayer(viewModel, profile)
                        "WALLET" -> NativeWalletSystem(viewModel, walletState, transactions)
                        "BUILDER" -> WebsiteBuilderWorkspace(viewModel, websites)
                        "NODES" -> CloudResourceDashboard(viewModel, nodeState)
                        "MARKETPLACE" -> TemplateApplicationMarket(viewModel)
                        "FILES" -> FileManagerRegistry(viewModel, websites, profile)
                        "TERMINAL" -> SovereignTerminalConsole(viewModel)
                        "ROADMAP" -> FutureEcosystemRoadmap()
                    }
                }
            }
        }

        // Global AI Site Builder Progress overlay
        if (viewModel.isGeneratingSite) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
                    .clickable(enabled = false) {},
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.widthIn(max = 450.dp).padding(24.dp),
                    colors = CardDefaults.cardColors(containerColor = CardSlate),
                    border = BorderStroke(1.dp, CyberCyan)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = CyberCyan)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "COMMONWEALTH AI SITE ARCHITECT",
                            color = CyberCyan,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = viewModel.generationStatus,
                            color = TextWhite,
                            textAlign = TextAlign.Center,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "compiling secure WebAssembly containers and on-chain files...",
                            color = TextMuted,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SystemStatusBar(
    profile: IdentityProfile?,
    walletState: WalletState?,
    nodeState: NodeSharingState?
) {
    var currentTime by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberBlack)
            .border(width = 1.dp, color = BorderSlate)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "COMMONWEALTH SOVEREIGN OS // L2-HYPERKERNEL",
                color = CyberCyan,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (nodeState?.isMining == true) CyberEmerald else CyberCyan)
            )
            Text(
                text = if (nodeState?.isMining == true) "NODE_MINING_UP" else "NODE_IDLE_STANDBY",
                color = if (nodeState?.isMining == true) CyberEmerald else TextMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.horizontalScroll(rememberScrollState())
        ) {
            Text(
                "ID: ${profile?.name ?: "ANON"} (${profile?.did?.take(18)}...)",
                color = TextWhite,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "BAL: ${(walletState?.resourceCredits ?: 0.0).toInt()} CC // ${(walletState?.btcBalance ?: 0.0)} BTC",
                color = GoldAccent,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                currentTime,
                color = TextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun AppSidebarDock(
    activeTab: String,
    onTabSelected: (String) -> Unit
) {
    // Navigation bar / dock layout representing a hybrid Apple OS / Bloomberg workstation feel
    NavigationRail(
        containerColor = CyberBlack,
        header = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Text(
                    text = "CW",
                    fontSize = 24.sp,
                    color = CyberCyan,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "v0.9-b",
                    fontSize = 9.sp,
                    color = TextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
        },
        modifier = Modifier
            .width(84.dp)
            .border(1.dp, BorderSlate)
    ) {
        val navItems = listOf(
            Triple("DASHBOARD", Icons.Default.Home, "Hub"),
            Triple("IDENTITY", Icons.Default.Lock, "Identity"),
            Triple("WALLET", Icons.Default.AccountBox, "Wallet"),
            Triple("BUILDER", Icons.Default.Build, "Builder"),
            Triple("NODES", Icons.Default.Share, "Nodes"),
            Triple("MARKETPLACE", Icons.Default.ShoppingCart, "Shop"),
            Triple("FILES", Icons.Default.Menu, "Files"),
            Triple("TERMINAL", Icons.Default.KeyboardArrowUp, "CMD"),
            Triple("ROADMAP", Icons.Default.Info, "Future")
        )

        LazyColumn(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth().testTag("sidebar_list")
        ) {
            items(navItems) { (tab, icon, label) ->
                val selected = activeTab == tab
                NavigationRailItem(
                    selected = selected,
                    onClick = { onTabSelected(tab) },
                    icon = {
                        Icon(
                            icon,
                            contentDescription = label,
                            tint = if (selected) CyberCyan else TextMuted,
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = label,
                            color = if (selected) CyberCyan else TextMuted,
                            fontSize = 10.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    alwaysShowLabel = true,
                    colors = NavigationRailItemDefaults.colors(
                        indicatorColor = BorderSlate
                    ),
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .testTag("nav_item_${tab.lowercase()}")
                )
            }
        }
    }
}

// ---------------- DASHBOARD APP ----------------
@Composable
fun MainMetricsDashboard(
    viewModel: CommonwealthViewModel,
    profile: IdentityProfile?,
    walletState: WalletState?,
    nodeState: NodeSharingState?,
    websites: List<SovereignWebsite>,
    transactions: List<WalletTransaction>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("dashboard_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "SOVEREIGN USER WORKSTATION",
                        style = TextStyle(
                            color = TextWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    Text(
                        "Unified dashboard interface for decentralized identities, cloud nodes, and peer payments.",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Four primary metrics boxes (Linux Desktop resource monitor layout)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Identity Metric Card
                MetricSummaryCard(
                    title = "IDENTITY CHECKLIST",
                    subtitle = profile?.name ?: "Sovereign Profile",
                    value = if (profile?.passkeyEnabled == true) "98% SAFE" else "25% RISKY",
                    info = profile?.did?.take(22) ?: "Empty DID key",
                    color = if (profile?.passkeyEnabled == true) : CyberCyan else : GoldAccent,
                    icon = Icons.Default.Lock,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectTab("IDENTITY") }
                )

                // Wallet Metric Card
                MetricSummaryCard(
                    title = "PORTFOLIO SPREAD",
                    subtitle = "Sovereign Ledger Assets",
                    value = "$${walletState?.usdBalance?.toInt() ?: 0} USD",
                    info = "${walletState?.btcBalance ?: 0.0} BTC // ${(walletState?.resourceCredits ?: 0.0).toInt()} Credits",
                    color = GoldAccent,
                    icon = Icons.Default.AccountBox,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectTab("WALLET") }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Hosting Metric Card
                MetricSummaryCard(
                    title = "HOSTED PROPERTIES",
                    subtitle = "Distributed Deployments",
                    value = "${websites.size} ACTIVE",
                    info = "Deployments signed: ${websites.count { it.isLive }} online",
                    color = CyberEmerald,
                    icon = Icons.Default.Build,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectTab("BUILDER") }
                )

                // Dynamic poW node Card
                MetricSummaryCard(
                    title = "CLOUD POWER UNIT",
                    subtitle = "Contributor Node",
                    value = if (nodeState?.isMining == true) "SHARING ACTIVE" else "NODE INACTIVE",
                    info = "Earned: ${"%.4f".format(nodeState?.totalCreditsEarned ?: 0.0)} credits so far",
                    color = if (nodeState?.isMining == true) CyberEmerald else TextMuted,
                    icon = Icons.Default.Share,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.selectTab("NODES") }
                )
            }
        }

        // Live Cloud Resource Monitor Visualization (Bloomberg Vibe)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "INTEGRATED WEB-HOSTING INFRASTRUCTURE CHANNELS",
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CPU UTILIATION", color = TextMuted, fontSize = 10.sp)
                            Text("${nodeState?.allocatedCpu ?: 0f}% contributed", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("STORAGE RESERVED", color = TextMuted, fontSize = 10.sp)
                            Text("${nodeState?.allocatedStorage ?: 0f} GB allocated", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("ACCUMULATED REVENUE", color = TextMuted, fontSize = 10.sp)
                            Text("${"%.2f".format(nodeState?.totalCreditsEarned ?: 0.0)} credits", color = CyberEmerald, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Simulated visual line chart using canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .background(CyberBlack)
                            .border(1.dp, BorderSlate)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val pathPoints = listOf(10f, 40f, 25f, 50f, 30f, 75f, 20f, 85f, 60f, 90f, 70f, 82f, 99f)
                            val stepX = size.width / (pathPoints.size - 1)
                            for (i in 0 until pathPoints.size - 1) {
                                val currentX = i * stepX
                                val currentY = size.height - (pathPoints[i] / 100f * size.height)
                                val nextX = (i + 1) * stepX
                                val nextY = size.height - (pathPoints[i + 1] / 100f * size.height)
                                drawLine(
                                    color = if (nodeState?.isMining == true) CyberEmerald else CyberCyan,
                                    start = androidx.compose.ui.geometry.Offset(currentX, currentY),
                                    end = androidx.compose.ui.geometry.Offset(nextX, nextY),
                                    strokeWidth = 3f
                                )
                            }
                        }
                        Text(
                            "LIVE PoW BANDWIDTH ACCRUAL MATRIX",
                            color = TextMuted,
                            fontSize = 8.sp,
                            modifier = Modifier.padding(4.dp).align(Alignment.BottomStart),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Quick Ledger Activity logs list
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "ON-CHAIN SETTLEMENT SYSTEM LOGS [LATEST]",
                            color = CyberCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            "Status: SYNCED",
                            color = CyberEmerald,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    if (transactions.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No recent transaction blocks logged.", color = TextMuted)
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            transactions.take(4).forEach { tx ->
                                TransactionRowItem(tx)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricSummaryCard(
    title: String,
    subtitle: String,
    value: String,
    info: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .border(1.dp, BorderSlate, RoundedCornerShape(12.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = CardSlate),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    color = color,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Icon(
                    icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                value,
                color = TextWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
            Text(
                subtitle,
                color = TextMuted,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Divider(color = BorderSlate, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                info,
                color = TextMuted,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

// ---------------- IDENTITY LAYER APP ----------------
@Composable
fun SovereignIdentityLayer(
    viewModel: CommonwealthViewModel,
    profile: IdentityProfile?
) {
    var editNameInput by remember { mutableStateOf(profile?.name ?: "") }
    var seedVisible by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("identity_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "DECENTRALIZED WORKSPACE CREDENTIALS (W3C DID)",
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "You do not possess a centralized registry password. Your identity is forged on-device using ECDSA hardware keypairs.",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("REVOLVING CRYPTO KEYPAIR STATUS", color = TextMuted, fontSize = 10.sp)
                            Text(profile?.name ?: "Sovereign Citizen", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .background(CyberCyan.copy(alpha = 0.15f))
                                .border(1.dp, CyberCyan, CircleShape)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("SECURE PASSKEY", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Divider(color = BorderSlate)

                    Column {
                        Text("DECENTRALIZED IDENTIFIER URL (DID):", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = profile?.did ?: "",
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Column {
                        Text("ECDSA SECP256K1 COMPRESSED PUBLIC KEY:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = profile?.publicKey ?: "",
                            color = TextWhite,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Column {
                        Text("LOCAL KEY STORAGE SECURITY COMPLIANCE:", color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = profile?.backupStatus ?: "",
                            color = CyberEmerald,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }

        // Customize layout credentials
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("REGENERATE IDENTIFIER / RENAME ENDPOINT", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = editNameInput,
                        onValueChange = { editNameInput = it },
                        label = { Text("Set Custom Name Label") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderSlate,
                            focusedLabelColor = CyberCyan,
                            cursorColor = CyberCyan,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("username_input")
                    )

                    Button(
                        onClick = { viewModel.regenerateSovereignKeys(editNameInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("regenerate_button")
                    ) {
                        Text("Forger New DID & Public/Private Keys", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Seed Mnemonic display (Future proof security feature)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("BIP39 HD WALLET RECOVERY SEED", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("12-word mnemonic phrase generated locally.", color = TextMuted, fontSize = 10.sp)
                        }
                        IconButton(onClick = { seedVisible = !seedVisible }) {
                            Icon(
                                if (seedVisible) Icons.Default.Delete else Icons.Default.Lock,
                                contentDescription = "Toggle Visibility",
                                tint = CyberCyan
                            )
                        }
                    }

                    AnimatedVisibility(visible = seedVisible) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CyberBlack)
                                .border(1.dp, BorderSlate, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = profile?.seedPhrase ?: "",
                                color = GoldAccent,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                    if (!seedVisible) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CyberBlack)
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⬤ ⬤ ⬤  RECOVERY SEED IS CRYPTOGRAPHICALLY COLD  ⬤ ⬤ ⬤", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// ---------------- NATIVE WALLET APP ----------------
@Composable
fun NativeWalletSystem(
    viewModel: CommonwealthViewModel,
    walletState: WalletState?,
    transactions: List<WalletTransaction>
) {
    var sendCoin by remember { mutableStateOf("CREDITS") }
    var sendAmount by remember { mutableStateOf("") }
    var sendRecipient by remember { mutableStateOf("") }
    var sendDesc by remember { mutableStateOf("") }

    var swapSource by remember { mutableStateOf("USD") }
    var swapDest by remember { mutableStateOf("CREDITS") }
    var swapAmount by remember { mutableStateOf("") }

    // Lightning invoice features requested
    var lightningStatus by remember { mutableStateOf("") }
    var mockInvoiceStr by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("wallet_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "NATIVE MULTI-ASSET CRYPTOGRAPHIC WALLET",
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "A sovereign system handles digital dollars, Bitcoin lightning channels, and local cloud hosting credits on the same layer.",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        // Live Balances Grid
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(
                    modifier = Modifier.weight(1f).border(1.dp, BorderSlate, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = CardSlate)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("BITCOIN (LIGHTNING)", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${walletState?.btcBalance ?: 0.0} BTC", color = GoldAccent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("⚡ Live Lightning Node UP", color = CyberEmerald, fontSize = 10.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f).border(1.dp, BorderSlate, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = CardSlate)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("SOVEREIGN CREDITS", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${"%.2f".format(walletState?.resourceCredits ?: 0.0)} CC", color = CyberCyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Used for AI & Hosting", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(
                    modifier = Modifier.weight(1f).border(1.dp, BorderSlate, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = CardSlate)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("STABLE STRAW DOLLAR", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("$${walletState?.usdBalance?.toInt() ?: 0} USD", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("On-Chain Treasury: 1.00", color = TextMuted, fontSize = 10.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f).border(1.dp, BorderSlate, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = CardSlate)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("STABLE SOVEREIGN POUND", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("£${walletState?.gbpBalance?.toInt() ?: 0} GBP", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("W3C Liquidity Lock Up", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }

        // DEX Swap Mechanism
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("SOVEREIGN INSTANT SWAP (DECENTRALIZED DEX)", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Source
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Source Token", color = TextMuted, fontSize = 10.sp)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CyberBlack)
                                    .border(1.dp, BorderSlate)
                                    .clickable {
                                        swapSource = if (swapSource == "USD") "CREDITS" else "USD"
                                        swapDest = if (swapSource == "USD") "CREDITS" else "USD"
                                    }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(swapSource, color = CyberCyan, fontWeight = FontWeight.Bold)
                                Icon(Icons.Default.Refresh, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
                            }
                        }

                        Icon(Icons.Default.Add, contentDescription = null, tint = TextMuted)

                        // Dest
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Target Token", color = TextMuted, fontSize = 10.sp)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CyberBlack)
                                    .border(1.dp, BorderSlate)
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(swapDest, color = CyberCyan, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = swapAmount,
                        onValueChange = { swapAmount = it },
                        label = { Text("Exchange Amount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderSlate,
                            focusedLabelColor = CyberCyan,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val amt = swapAmount.toDoubleOrNull() ?: 0.0
                            if (amt > 0) {
                                viewModel.simulateSwap(swapSource, swapDest, amt)
                                swapAmount = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Swap Assets Instantly", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Lightning / Merchant Instant Payment Simulator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("⚡ LIGHTNING MERCHANT PAYMENT CHANNELS", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Establish point-of-sale invoices using instant Lightning routing.", color = TextMuted, fontSize = 11.sp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val invoiceVal = "lnbc" + (1000..9999).random() + "p1xpv5gr..." + UUID.randomUUID().toString().take(12)
                                mockInvoiceStr = invoiceVal
                                lightningStatus = "Invoice generated! Scan to clear."
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BorderSlate, contentColor = TextWhite),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Forge Lightning QR", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                if (mockInvoiceStr.isNotBlank()) {
                                    viewModel.simulateSendCrypto("BTC", 0.0025, "did:key:z6MkuMerchant", "⚡ Lightning Invoice Settlement")
                                    mockInvoiceStr = ""
                                    lightningStatus = "⚡ Payment Broadcasted! Channels balanced and cleared."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald, contentColor = CyberBlack),
                            modifier = Modifier.weight(1f),
                            enabled = mockInvoiceStr.isNotBlank()
                        ) {
                            Text("Settle QR Invoice", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (mockInvoiceStr.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CyberBlack)
                                .border(1.dp, GoldAccent, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("LIGHTNING INVOICE TO PAY (0.0025 BTC):", color = GoldAccent, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text(mockInvoiceStr, color = TextWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }

                    if (lightningStatus.isNotBlank()) {
                        Text(lightningStatus, color = CyberCyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Outbound DID Settlement
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("PEER-TO-PEER CRYPTO TRANSFER (ANY DID)", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("CREDITS", "BTC", "USD").forEach { c ->
                            ElevatedCard(
                                onClick = { sendCoin = c },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (sendCoin == c) CyberCyan.copy(alpha = 0.15f) else CyberBlack
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, if (sendCoin == c) CyberCyan else BorderSlate, RoundedCornerShape(8.dp))
                            ) {
                                Box(modifier = Modifier.padding(8.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Text(c, color = if (sendCoin == c) CyberCyan else TextWhite, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = sendAmount,
                        onValueChange = { sendAmount = it },
                        label = { Text("Transfer Value") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderSlate,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("transfer_val")
                    )

                    OutlinedTextField(
                        value = sendRecipient,
                        onValueChange = { sendRecipient = it },
                        label = { Text("Recipient DID Anchor") },
                        placeholder = { Text("did:key:...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderSlate,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("recipient_input")
                    )

                    OutlinedTextField(
                        value = sendDesc,
                        onValueChange = { sendDesc = it },
                        label = { Text("Private Memo (Encrypted)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderSlate,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val amt = sendAmount.toDoubleOrNull() ?: 0.0
                            if (amt > 0 && sendRecipient.isNotBlank()) {
                                viewModel.simulateSendCrypto(sendCoin, amt, sendRecipient, sendDesc)
                                sendAmount = ""
                                sendRecipient = ""
                                sendDesc = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("send_button")
                    ) {
                        Text("Sign & Disperse Ledger Block", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionRowItem(tx: WalletTransaction) {
    val dateStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(tx.timestamp))
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberBlack)
            .border(1.dp, BorderSlate, RoundedCornerShape(8.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        when (tx.txType) {
                            "SEND" -> CrimsonAlert.copy(alpha = 0.15f)
                            "RECEIVE" -> CyberEmerald.copy(alpha = 0.15f)
                            "SWAP" -> CyberCyan.copy(alpha = 0.15f)
                            else -> CyberEmerald.copy(alpha = 0.15f)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    when (tx.txType) {
                        "SEND" -> Icons.Default.Home
                        "RECEIVE" -> Icons.Default.Check
                        "SWAP" -> Icons.Default.Refresh
                        else -> Icons.Default.Star
                    },
                    contentDescription = null,
                    tint = when (tx.txType) {
                        "SEND" -> CrimsonAlert
                        "RECEIVE" -> CyberEmerald
                        "SWAP" -> CyberCyan
                        else -> CyberEmerald
                    },
                    modifier = Modifier.size(16.dp)
                )
            }

            Column {
                Text(tx.details, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("TX: ${tx.hash.take(16)}... // Time: $dateStr", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            val prefix = when (tx.txType) {
                "SEND", "PAY" -> "-"
                else -> "+"
            }
            Text(
                "$prefix${tx.amount} ${tx.coin}",
                color = when (tx.txType) {
                    "SEND", "PAY" -> CrimsonAlert
                    else -> CyberEmerald
                },
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                tx.txType,
                color = TextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

// ---------------- WEBSITE BUILDER APP ----------------
@Composable
fun WebsiteBuilderWorkspace(
    viewModel: CommonwealthViewModel,
    websites: List<SovereignWebsite>
) {
    var promptInput by remember { mutableStateOf("") }
    var activeSubTab by remember { mutableStateOf("PREVIEW") } // "PREVIEW", "CODE_HTML", "CODE_CSS", "CODE_JS"

    val selected = viewModel.selectedWebsiteForPreview

    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("builder_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "INTEGRATED SOVEREIGN DEV-ROOM & AI ARCHITECT",
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "Design and deploy responsive codebases directly from the browser using direct Gemini intelligence or direct manual hand-coding.",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        // Prompt input block
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "AI WEBSITE BUILDER (SPEND 45 COINS)",
                        color = GoldAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    OutlinedTextField(
                        value = promptInput,
                        onValueChange = { promptInput = it },
                        label = { Text("What brand or app do you request to build?") },
                        placeholder = { Text("e.g., Create a luxury perfume brand website.") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderSlate,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("ai_prompt_field")
                    )

                    Button(
                        onClick = {
                            viewModel.generateSiteViaAI(promptInput)
                            promptInput = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("ai_build_button")
                    ) {
                        Text("Deploy via AI Site Architect Engine", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Saved Deployed websites explorer
        item {
            Text("DEPLOYED SITES REGISTRY", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))

            if (websites.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberBlack)
                        .border(1.dp, BorderSlate, RoundedCornerShape(8.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No decentralized deployments logged yet. Ask Gemini above!", color = TextMuted, fontSize = 12.sp)
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    websites.forEach { site ->
                        val isSelected = selected?.id == site.id
                        Card(
                            modifier = Modifier
                                .width(160.dp)
                                .border(
                                    1.dp,
                                    if (isSelected) CyberCyan else BorderSlate,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    viewModel.selectedWebsiteForPreview = site
                                    viewModel.editHtml = site.htmlContent
                                    viewModel.editCss = site.cssContent
                                    viewModel.editJs = site.jsContent
                                    viewModel.editName = site.name
                                },
                            colors = CardDefaults.cardColors(containerColor = CardSlate)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    site.name,
                                    color = TextWhite,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(site.category, color = CyberCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "v${site.version} // Deployed",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    IconButton(
                                        onClick = { viewModel.deleteWebsite(site) },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonAlert, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Rendering Visual Browser Simulation Frame
        if (selected != null) {
            item {
                Divider(color = BorderSlate)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "LIVE BROWSER SIMULATOR: ${viewModel.editName}",
                            color = CyberCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("IPFS deployment: ${selected.deployedHash.take(24)}...", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("PREVIEW", "HTML", "CSS", "JS").forEach { item ->
                            Button(
                                onClick = { activeSubTab = item },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activeSubTab == item) CyberCyan else BorderSlate,
                                    contentColor = if (activeSubTab == item) CyberBlack else TextWhite
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text(item, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                when (activeSubTab) {
                    "PREVIEW" -> {
                        // Embedded native WebView rendering the CSS styles and JS logic directly
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(380.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(2.dp, BorderSlate, RoundedCornerShape(12.dp))
                                .background(Color.White)
                        ) {
                            WebPreviewFrame(
                                html = viewModel.editHtml,
                                css = viewModel.editCss,
                                js = viewModel.editJs
                            )
                        }
                    }
                    "HTML" -> {
                        ManualCodeEditor(
                            label = "HTML DOM layout Node",
                            value = viewModel.editHtml,
                            onValueChange = { viewModel.editHtml = it },
                            placeholder = "<div>Hello</div>"
                        )
                    }
                    "CSS" -> {
                        ManualCodeEditor(
                            label = "Aesthetic CSS Canvas styles",
                            value = viewModel.editCss,
                            onValueChange = { viewModel.editCss = it },
                            placeholder = "body { background: #000; }"
                        )
                    }
                    "JS" -> {
                        ManualCodeEditor(
                            label = "Dynamic JS Action callbacks",
                            value = viewModel.editJs,
                            onValueChange = { viewModel.editJs = it },
                            placeholder = "console.log('Action');"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = viewModel.editName,
                        onValueChange = { viewModel.editName = it },
                        label = { Text("Web3 Property URL Alias") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderSlate,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    Button(
                        onClick = { viewModel.saveWebsiteChanges() },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald, contentColor = CyberBlack),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.align(Alignment.CenterVertically).testTag("save_code_button")
                    ) {
                        Text("Compile & Deploy Rev v${selected.version + 1}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun WebPreviewFrame(html: String, css: String, js: String) {
    val context = LocalContext.current
    val combinedHtml = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    margin: 0;
                    padding: 0;
                    background-color: #0d1117;
                    color: #c9d1d9;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
                }
                $css
            </style>
        </head>
        <body>
            $html
            <script>
                try {
                    $js
                } catch(e) {
                    console.error("Simulation JS Error: " + e.message);
                }
            </script>
        </body>
        </html>
    """.trimIndent()

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
                loadDataWithBaseURL(null, combinedHtml, "text/html", "UTF-8", null)
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL(null, combinedHtml, "text/html", "UTF-8", null)
        },
        modifier = Modifier.fillMaxSize().testTag("webview_preview")
    )
}

@Composable
fun ManualCodeEditor(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String
) {
    Column {
        Text(label, color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = TextDark) },
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TerminalLog),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyberCyan,
                unfocusedBorderColor = BorderSlate,
                focusedContainerColor = CyberBlack,
                unfocusedContainerColor = CyberBlack,
                focusedTextColor = TerminalLog,
                unfocusedTextColor = TerminalLog
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
        )
    }
}

// ---------------- NODE APP / SHARING MONITOR ----------------
@Composable
fun CloudResourceDashboard(
    viewModel: CommonwealthViewModel,
    nodeState: NodeSharingState?
) {
    if (nodeState == null) return

    var sliderCpu by remember { mutableStateOf(nodeState.allocatedCpu) }
    var sliderRam by remember { mutableStateOf(nodeState.allocatedRam) }
    var sliderStorage by remember { mutableStateOf(nodeState.allocatedStorage) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("resources_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "DISTRIBUTED CLOUD infrastructure CHANNEL",
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "Contribute CPU computing threads, temporary memory (RAM), and server storage. Earn Proof-of-Work resource credits in real-time.",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        // Toggling Mine action
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, if (nodeState.isMining) CyberEmerald else BorderSlate)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (nodeState.isMining) "POW SHARING UNIT ACTIVE" else "SHARING CHANNEL OFFLINE",
                            color = if (nodeState.isMining) CyberEmerald else TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (nodeState.isMining) "Actively contributing CPU slices and network routing bandwidth to Commonwealth subnet L2." else "Idle. Fire up resource channels to gain hosting credits.",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = nodeState.isMining,
                        onCheckedChange = { viewModel.toggleMining(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberEmerald,
                            checkedTrackColor = CyberEmerald.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = BorderSlate
                        ),
                        modifier = Modifier.testTag("mine_switch")
                    )
                }
            }
        }

        // Live contribution speed dial metrics
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(
                    modifier = Modifier.weight(1.0f).border(1.dp, BorderSlate, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = CardSlate)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("PoW ACCRUAL RATE", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = if (nodeState.isMining) "+${"%.4f".format(0.05 * (nodeState.allocatedCpu / 50.0f))} CC/s" else "0.00 CC/s",
                            color = CyberCyan,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("Accruing into browser", color = TextMuted, fontSize = 9.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1.0f).border(1.dp, BorderSlate, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = CardSlate)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("ACTIVE METRICS", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("${nodeState.uptimeSeconds} SECS", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("Continuous runtime", color = TextMuted, fontSize = 9.sp)
                    }
                }
            }
        }

        // Configuration limits
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("NODE RESOURCE CONTRIBUTION THROTTLE SENSORS", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    // CPU Slider
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("CPU Contribution Cap", color = TextMuted, fontSize = 11.sp)
                            Text("${sliderCpu.toInt()}%", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = sliderCpu,
                            onValueChange = { sliderCpu = it },
                            valueRange = 10f..100f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = CyberCyan,
                                inactiveTrackColor = BorderSlate
                            ),
                            modifier = Modifier.testTag("cpu_slider")
                        )
                    }

                    // RAM Slider
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Allocated RAM Capacity", color = TextMuted, fontSize = 11.sp)
                            Text("${"%.1f".format(sliderRam)} GB", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = sliderRam,
                            onValueChange = { sliderRam = it },
                            valueRange = 1f..32f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = CyberCyan,
                                inactiveTrackColor = BorderSlate
                            ),
                            modifier = Modifier.testTag("ram_slider")
                        )
                    }

                    // Storage Slider
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Assigned Storage Partition", color = TextMuted, fontSize = 11.sp)
                            Text("${sliderStorage.toInt()} GB", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = sliderStorage,
                            onValueChange = { sliderStorage = it },
                            valueRange = 5f..500f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = CyberCyan,
                                inactiveTrackColor = BorderSlate
                            )
                        )
                    }

                    Button(
                        onClick = { viewModel.updateNodeAllocation(sliderCpu, sliderRam, sliderStorage) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("apply_limits_button")
                    ) {
                        Text("Lock-In Allocation Values", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ---------------- DECENTRALIZED TEMPLATES & APP MARKETPLACE ----------------
@Composable
fun TemplateApplicationMarket(viewModel: CommonwealthViewModel) {
    val templates = listOf(
        TemplateMarketItem(
            name = "Stellar Decentralized Shop",
            category = "E-Commerce",
            price = "20 CC",
            description = "Complete digital store with sovereign wallet check-outs and catalog selectors.",
            logo = "🛍️"
        ),
        TemplateMarketItem(
            name = "Sovereign Blogging Engine",
            category = "Media",
            price = "20 CC",
            description = "Sovereign publishing blog layout for secure identity, RSS feeds, and visual designs.",
            logo = "📝"
        ),
        TemplateMarketItem(
            name = "DeFi Liquidity Hub",
            category = "FinTech",
            price = "20 CC",
            description = "Interactive transaction swaps dashboard, token registries, and chart trackers.",
            logo = "📈"
        ),
        TemplateMarketItem(
            name = "Chronicle Cyber CV",
            category = "Professional",
            price = "20 CC",
            description = "High resolution visual portfolio layout built for on-chain identity validation.",
            logo = "🥋"
        )
    )

    val extensions = listOf(
        Triple("Cargo Rust W3C Compiler", "DevTool", "Enables direct WASM compiling in browser."),
        Triple("Zero-Knowledge Messaging Matrix", "Plugin", "End-to-end multi-device encrypted feeds."),
        Triple("Cosmopolitan Theme Set", "Theme", "High-contrast synthwave visual dashboard style.")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("marketplace_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "SOVEREIGN PROPERTY & APPLICATIONS CHANNELS",
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "Purchase layouts or system extensions utilizing your locally earned Proof-of-Work resource credits.",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        item {
            Text("READY-MADE VISUAL LAYOUT TEMPLATES", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        items(templates) { template ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSlate, RoundedCornerShape(10.dp)),
                colors = CardDefaults.cardColors(containerColor = CardSlate)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberBlack),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(template.logo, fontSize = 22.sp)
                        }

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(template.name, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Box(
                                    modifier = Modifier
                                        .background(CyberCyan.copy(alpha = 0.15f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(template.category, color = CyberCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                            Text(template.description, color = TextMuted, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Button(
                        onClick = { viewModel.deployLauncherTemplate(template.name, template.category) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(36.dp).testTag("deploy_${template.name.replace(" ", "_").lowercase()}")
                    ) {
                        Text("Deploy (${template.price})", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }

        item {
            Text("ECOSYSTEM INTEGRATION PLUGINS & PLOTS", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        items(extensions) { (pName, pType, pDesc) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSlate, RoundedCornerShape(10.dp)),
                colors = CardDefaults.cardColors(containerColor = CardSlate)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(pName, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("•", color = TextMuted)
                            Text(pType, color = GoldAccent, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(pDesc, color = TextMuted, fontSize = 11.sp)
                    }

                    Button(
                        onClick = { /* Simulated installer downloads */ },
                        colors = ButtonDefaults.buttonColors(containerColor = BorderSlate, contentColor = TextWhite),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Install", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

data class TemplateMarketItem(
    val name: String,
    val category: String,
    val price: String,
    val description: String,
    val logo: String
)

// ---------------- FILE MANAGER & REGISTRY APP ----------------
@Composable
fun FileManagerRegistry(
    viewModel: CommonwealthViewModel,
    websites: List<SovereignWebsite>,
    profile: IdentityProfile?
) {
    var dialogMsg by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("files_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "SOVEREIGN KERNEL FILE REGISTRY & MANIFEST",
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "Manage local physical deployments and transfer ownership certificates of visual blocks on the decentralized network.",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { dialogMsg = "Registry JSON Snapshot compiled! Output saved to: /home/sovereign/snapshot.json" },
                    colors = ButtonDefaults.buttonColors(containerColor = BorderSlate, contentColor = TextWhite),
                    modifier = Modifier.weight(1f).testTag("download_snapshot_button")
                ) {
                    Text("Backup Registry SNAPSHOT", fontSize = 11.sp)
                }

                Button(
                    onClick = { dialogMsg = "Registry integrity scanned! 14 integrity points cryptographically balanced." },
                    colors = ButtonDefaults.buttonColors(containerColor = BorderSlate, contentColor = TextWhite),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Integrity Check Block", fontSize = 11.sp)
                }
            }
        }

        if (dialogMsg.isNotBlank()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberBlack)
                        .border(1.dp, CyberCyan, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(dialogMsg, color = CyberCyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        IconButton(onClick = { dialogMsg = "" }) {
                            Icon(Icons.Default.Home, contentDescription = "Close", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardSlate),
                border = BorderStroke(1.dp, BorderSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("COGNITIVE PROPERTY OWNERSHIP CERTIFICATES", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Sites in this browser possess cryptographic manifest proofs. You may trade or transfer ownership directly to a counter-party.", color = TextMuted, fontSize = 11.sp)

                    if (websites.isEmpty()) {
                        Text("No registered assets to package or transfer.", color = TextMuted, fontSize = 11.sp, style = TextStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic))
                    } else {
                        websites.forEach { site ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CyberBlack)
                                    .border(1.dp, BorderSlate, RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(site.name, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("FINGERPRINT: SHA-256 [${site.deployedHash.replace("ipfs://", "").take(16)}...]", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    Text("Current holder: W3C ID [${profile?.name ?: "Anon"}]", color = CyberCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }

                                Button(
                                    onClick = { dialogMsg = "Transferred '${site.name}' property card ownership to: did:recipient_counterparty" },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("Transfer cert", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- LINUX TERMINAL CLI APP ----------------
@Composable
fun SovereignTerminalConsole(viewModel: CommonwealthViewModel) {
    val logs = viewModel.terminalConsoleLogs
    val lazyListState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Scroll automatically when logs expand
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            coroutineScope.launch {
                lazyListState.animateScrollToItem(logs.size - 1)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .border(2.dp, BorderSlate, RoundedCornerShape(12.dp))
            .padding(12.dp)
            .testTag("terminal_root")
    ) {
        // Terminal Window Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(CrimsonAlert))
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(GoldAccent))
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(CyberEmerald))
            }
            Text(
                "sovereign@commonwealth: /home/sovereign",
                color = TextMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Terminal", tint = TextMuted, modifier = Modifier.size(14.dp))
        }

        Divider(color = BorderSlate, modifier = Modifier.padding(bottom = 8.dp))

        // Logs display scroll
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("terminal_logs_list"),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(logs) { log ->
                Text(
                    text = log,
                    color = if (log.startsWith("> ")) CyberCyan else if (log.contains("SYSTEM") || log.contains("SECURITY")) GoldAccent else TerminalLog,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Prompt input line
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSlate, RoundedCornerShape(6.dp))
                .background(DarkSlate)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "dec_shell $ ",
                color = CyberCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            BasicTextField(
                value = viewModel.terminalInput,
                onValueChange = { viewModel.terminalInput = it },
                textStyle = TextStyle(
                    color = TextWhite,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                ),
                cursorBrush = Brush.verticalGradient(listOf(CyberCyan, CyberCyan)),
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Go
                ),
                keyboardActions = KeyboardActions(
                    onGo = { viewModel.executeConsoleCommand() }
                ),
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 12.dp)
                    .testTag("terminal_input_field")
            )

            IconButton(
                onClick = { viewModel.executeConsoleCommand() },
                modifier = Modifier.size(24.dp).testTag("terminal_send_button")
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = CyberCyan,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

// ---------------- 10-YEAR ROADMAP VIEW ----------------
@Composable
fun FutureEcosystemRoadmap() {
    val phases = listOf(
        RoadmapMilestone(
            title = "Phase I (2026–2028) // Genesis Core Node Architecture",
            description = "Deployment of sovereign ECDSA keys across secure browser kernels. Multi-device passkey authentication sets active compliance standard.",
            stateBadge = "IN-PROGRESS",
            badgeColor = CyberCyan
        ),
        RoadmapMilestone(
            title = "Phase II (2028–2030) // WebAssembly (WASM) Isolation Runtime",
            description = "Execution of fully isolated decentralized apps directly on browser client partitions. Dynamic rust-to-wasm packages compiled seamlessly in the browser.",
            stateBadge = "PLANNED",
            badgeColor = GoldAccent
        ),
        RoadmapMilestone(
            title = "Phase III (2030–2033) // Local Cognitive Coprocessor Grid",
            description = "Secure distributed LLMs hosted in consumer device graphics matrices. Sharing spare GPU layers is rewarded through native PoW credits billing layers.",
            stateBadge = "CONCEPT",
            badgeColor = TextMuted
        ),
        RoadmapMilestone(
            title = "Phase IV (2033–2036) // Collective HyperKernel Sovereign Business Layers",
            description = "Complete independence from centralized registries. All visual platforms, online shops, communication systems, and identity networks hosted locally on browser layers.",
            stateBadge = "FUTURE VISION",
            badgeColor = TextMuted
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("roadmap_root")
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "COMMONWEALTH ECOSYSTEM ROADMAP (2026–2036)",
            color = CyberCyan,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            "Strategic layout guiding absolute user independence from hardware-layers to cognitive network registries.",
            color = TextMuted,
            fontSize = 12.sp
        )

        phases.forEachIndexed { idx, ms ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSlate, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = CardSlate)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "0${idx + 1} // MILESTONE SEGMENT",
                            color = ms.badgeColor,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .background(ms.badgeColor.copy(alpha = 0.12f))
                                .border(1.dp, ms.badgeColor, CircleShape)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(ms.stateBadge, color = ms.badgeColor, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(ms.title, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(ms.description, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

data class RoadmapMilestone(
    val title: String,
    val description: String,
    val stateBadge: String,
    val badgeColor: Color
)
